window.__ModuleLoader__.load({ id: 'dsh-personal-sidebar', factory: (require) => { var module = { exports: {} }; var exports = module.exports;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/workstation/personal-sidebar/src/client/index.tsx
var index_exports = {};
__export(index_exports, {
  apply: () => apply,
  inject: () => inject
});
module.exports = __toCommonJS(index_exports);

// src/workstation/personal-sidebar/src/client/styles.ts
var CSS = String.raw`
/* PHASE D：统一 Aux Tool Registry（右侧/底部同一注册表 + 同一能力元数据） */
.dps-root {
  height: 100%;
  display: flex;
  flex-direction: column;
  min-height: 0;
  user-select: none;
}
.dps-nav {
  flex: 0 0 auto;
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 6px 8px 4px;
}
.dps-cta {
  display: flex; align-items: center; gap: 7px;
  width: 100%; border: none; border-radius: 8px;
  padding: 7px 9px; cursor: pointer; text-align: left;
  font: var(--dsw-font-xxs-strong-12, 600 12px);
  color: var(--dsw-alias-label-primary);
  background: var(--dsw-alias-interactive-bg-active, var(--dsw-alias-interactive-bg-hover));
}
.dps-cta:hover { filter: brightness(1.08); }
.dps-cta svg { color: var(--dsw-alias-brand-primary, var(--dsw-alias-label-primary)); }
/* 2026-09-10 真机反馈（「这些字和图标不是一个等级」）：主导航行行与既有第三方
   「任务看板」入口**逐项同级**——高 36px / 左右内边距 10px / 圆角 8px / 字号 13px /
   导航字形 18px / gap 8px / 正文色 label-secondary，hover 升 label-primary，
   选中态加粗 600 + interactive-bg-active。数值直接对齐 dsh-client-ui-task-board
   的 .entry（同一侧栏里的「同一条导航」就应该是同一个等级）。 */
.dps-nav-item {
  display: flex; align-items: center; gap: 8px;
  width: 100%; height: 36px;
  border: none; border-radius: 8px; background: transparent;
  padding: 0 10px; cursor: pointer; text-align: left;
  font-size: 13px;
  color: var(--dsw-alias-label-secondary);
}
.dps-nav-item:hover { background: var(--dsw-alias-interactive-bg-hover); color: var(--dsw-alias-label-primary); }
.dps-nav-item[data-active="true"] {
  background: var(--dsw-alias-interactive-bg-active, var(--dsw-alias-interactive-bg-hover));
  color: var(--dsw-alias-label-primary);
  font-weight: 600;
}
.dps-nav-item svg { flex: 0 0 auto; width: 18px; height: 18px; }
.dps-nav-foot { border-top: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.2)); margin-top: 4px; padding-top: 4px; }
.dps-scroll {
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 2px 6px 8px;
}
.dps-h { font: var(--dsw-font-s-strong-14, 600 14px); margin: 2px 4px 6px; color: var(--dsw-alias-label-primary); }
.dps-sub { font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary); margin: 0 4px 8px; }
.dps-row {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  border: none;
  border-radius: 6px;
  background: transparent;
  text-align: left;
  padding: 5px 6px;
  cursor: pointer;
  color: var(--dsw-alias-label-primary);
}
.dps-row:hover { background: var(--dsw-alias-interactive-bg-hover); }
.dps-row[data-active="true"] { background: var(--dsw-alias-interactive-bg-active, var(--dsw-alias-interactive-bg-hover)); }
.dps-glyph {
  flex: 0 0 22px;
  width: 22px;
  height: 22px;
  border-radius: 6px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
  color: var(--dsw-alias-label-secondary);
  background: var(--dsw-alias-bg-layer-2);
  border: 1px solid var(--dsw-alias-border-l1, transparent);
}
.dps-row-text { flex: 1 1 auto; min-width: 0; }
.dps-row-name { display: block; font: var(--dsw-font-xxs-12, 12px); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.dps-row-desc { display: block; font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 1px; }
.dps-chev { flex: 0 0 auto; font-size: 10px; color: var(--dsw-alias-label-dimmed); }
.dps-detail {
  margin: 0 6px 8px 36px;
  padding: 6px 9px;
  border: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.2));
  border-radius: 6px;
  font: var(--dsw-font-xxs-12, 12px);
  color: var(--dsw-alias-label-secondary);
  background: color-mix(in srgb, var(--dsw-alias-bg-layer-2, transparent) 45%, transparent);
}
.dps-detail-line { margin-bottom: 4px; line-height: 1.5; }
.dps-chip-row { display: flex; flex-wrap: wrap; gap: 4px; margin: 4px 0; }
.dps-chip {
  border: 1px solid var(--dsw-alias-border-l1, transparent);
  border-radius: 4px;
  padding: 0 6px;
  font: var(--dsw-font-xxxs-11, 11px);
  color: var(--dsw-alias-label-tertiary);
}
.dps-hint { margin-top: 6px; font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-dimmed); line-height: 1.5; }
.dps-more-hint { padding: 2px 8px 4px; font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-dimmed); }
.dps-session-row .dps-dot {
  width: 6px; height: 6px; border-radius: 50%; flex: 0 0 auto;
  background: transparent;
}
.dps-session-row .dps-dot[data-running="true"] { background: var(--dsw-alias-state-business-primary, #3b82f6); }
.dps-time { font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-dimmed); flex: 0 0 auto; }
.dps-empty { padding: 10px 8px; font: var(--dsw-font-xxs-12, 12px); color: var(--dsw-alias-label-tertiary); line-height: 1.5; }
.dps-link {
  display: flex; align-items: center; gap: 6px;
  width: 100%; border: none; border-radius: 6px; background: transparent;
  padding: 6px; cursor: pointer; text-align: left;
  font: var(--dsw-font-xxs-12, 12px); color: var(--dsw-alias-label-secondary);
}
.dps-link:hover { background: var(--dsw-alias-interactive-bg-hover); color: var(--dsw-alias-label-primary); }
.dps-link-strong { color: var(--dsw-alias-brand-primary, var(--dsw-alias-label-primary)); }
.dps-rail {
  height: 100%; display: flex; flex-direction: column; align-items: center;
  gap: 4px; padding-top: 8px;
}
.dps-rail-btn {
  /* 窄栏同样与第三方「任务看板」收起态入口同级：36×36、图标 18px。 */
  width: 36px; height: 36px; border: none; border-radius: 8px; background: transparent;
  cursor: pointer; display: inline-flex; align-items: center; justify-content: center;
  font-size: 13px;
  color: var(--dsw-alias-label-secondary);
}
.dps-rail-btn:hover { background: var(--dsw-alias-interactive-bg-hover); color: var(--dsw-alias-label-primary); }
.dps-rail-btn svg { width: 18px; height: 18px; }
.dps-rail-btn[data-active="true"] { background: var(--dsw-alias-interactive-bg-active, var(--dsw-alias-interactive-bg-hover)); color: var(--dsw-alias-label-primary); }
.dps-foot-toggle {
  display: inline-flex; align-items: center; gap: 5px;
  border: none; background: transparent; border-radius: 6px;
  padding: 3px 6px; cursor: pointer;
  font: var(--dsw-font-xxs-12, 12px);
  color: var(--dsw-alias-label-secondary);
}
.dps-foot-toggle:hover { background: var(--dsw-alias-interactive-bg-hover); color: var(--dsw-alias-label-primary); }
.dps-foot-toggle[data-on="true"] { color: var(--dsw-alias-brand-primary, var(--dsw-alias-label-primary)); }
/* 2026-09-10 清理：此处原本残留一段**没有选择器的裸声明块**（PHASE N 删除会话头
   .dps-head-toggle 时只删掉选择器行，留下 declarations + 右花括号）。浏览器按 CSS
   错误恢复规则会丢弃它，但它是实打实的无效样式表内容（也会让严格 CSS 解析器整张表
   解析失败）——已整段删除。 */

/* =========================================================================
   E4-FIX-IA-2 · IA2-2 — 一级导航面板模型（Mini Mission Control 已删除；旧
   「官方会话浏览」导航行与左栏「辅助工具」列表亦已按真机反馈移除）
   ========================================================================= */
.dps-mm {
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  display: flex;
  flex-direction: column;
  gap: 9px;
  border-top: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.2));
  margin-top: 6px;
  padding: 8px 8px 12px;
}
.dps-mm-h {
  font: var(--dsw-font-xxxs-strong-11, 600 11px);
  letter-spacing: .06em;
  color: var(--dsw-alias-label-tertiary, #9a9aa5);
}
.dps-mm-sec { display: flex; flex-direction: column; gap: 1px; }
.dps-mm-head { display: flex; align-items: center; gap: 5px; color: var(--dsw-alias-label-secondary, #c8c8d0); font: var(--dsw-font-xxxs-11, 11px); padding: 0 2px; }
.dps-mm-count {
  font: var(--dsw-font-xxxs-11, 11px);
  color: var(--dsw-alias-label-tertiary, #9a9aa5);
  border: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.25));
  border-radius: 10px;
  padding: 0 5px;
}
.dps-mm-empty { font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-dimmed, #8f8f99); padding: 2px 2px 2px 12px; }
.dps-mm-row {
  display: flex; align-items: center; gap: 7px; min-width: 0;
  border: none; background: transparent; border-radius: 5px;
  padding: 3px 6px; text-align: left; cursor: pointer;
  color: var(--dsw-alias-label-primary, #e8e8ec); font: var(--dsw-font-xxs-12, 12px);
}
.dps-mm-row:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); }
.dps-mm-label { flex: 1 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dps-mm-dot { width: 6px; height: 6px; border-radius: 50%; flex: 0 0 auto; background: transparent; }
.dps-mm-dot.run { background: var(--dsw-alias-state-business-primary, #3b82f6); }
.dps-mm-dot.attn { background: #e8b64c; }
.dps-mm-dot.ok { background: #37c871; }
.dps-mm-dot.idle { background: var(--dsw-alias-label-dimmed, #6a6a74); }
.dps-mm-more, .dps-mm-all {
  border: none; background: transparent; cursor: pointer; text-align: left;
  font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary, #9a9aa5);
  padding: 2px 6px;
}
.dps-mm-more:hover, .dps-mm-all:hover { color: var(--dsw-alias-label-primary, #e8e8ec); }
.dps-mm-all { align-self: flex-start; padding-left: 2px; }
.dps-mm-notice {
  font: var(--dsw-font-xxxs-11, 11px); line-height: 1.5;
  color: #e0b96a; border: 1px dashed rgba(240,180,60,.4); border-radius: 6px;
  padding: 4px 8px;
}

/* ---------------------------------------------------------------------------
   E4-FIX-IA-2 · SIDEBAR CONVERSATION LIST（E4-FIX-IA-2 收口）
   传统 AI Chat Sidebar 风格的「最近会话」：标题单行 + 右对齐相对时间 + hover/selected。
   设计语言沿用官方 --dsw-* token（与 Personal 其他区域一致），不引入新视觉体系。 */
.dps-conv { display: flex; flex-direction: column; gap: 2px; margin-top: 10px; padding-top: 8px; border-top: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.18)); }
.dps-conv-h { display: flex; align-items: center; gap: 6px; padding: 0 6px 4px; font: var(--dsw-font-xxxs-strong-11, 600 11px); letter-spacing: .04em; color: var(--dsw-alias-label-tertiary, #9a9aa5); }
.dps-conv-n { font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary, #9a9aa5); background: var(--dsw-alias-bg-layer-2, rgba(128,128,128,.12)); border-radius: 999px; padding: 0 6px; }
.dps-conv-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 1px; }
.dps-conv-row {
  display: flex; align-items: center; gap: 8px; width: 100%;
  border: none; background: transparent; cursor: pointer; text-align: left;
  border-radius: 7px; padding: 4px 6px; color: inherit; font: inherit;
}
.dps-conv-row:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); }
.dps-conv-row[data-conv-active="true"] { background: var(--dsw-alias-interactive-bg-active, rgba(120,150,255,.16)); }
.dps-conv-row[data-conv-active="true"] .dps-conv-title { color: var(--dsw-alias-label-primary, #e8e8ec); font-weight: 600; }
.dps-conv-title { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font: var(--dsw-font-xxs-12, 12px); color: var(--dsw-alias-label-secondary, #c8c8d0); display: flex; align-items: center; gap: 5px; }
.dps-conv-row:hover .dps-conv-title { color: var(--dsw-alias-label-primary, #e8e8ec); }
.dps-conv-run { flex: none; width: 6px; height: 6px; border-radius: 50%; background: var(--dsw-alias-state-ok-primary, #3ba272); }
.dps-conv-time { flex: none; font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary, #9a9aa5); font-variant-numeric: tabular-nums; white-space: nowrap; }
.dps-conv-more { border: none; background: transparent; cursor: pointer; text-align: left; padding: 3px 6px; border-radius: 6px; font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary, #9a9aa5); }
.dps-conv-more:hover { color: var(--dsw-alias-label-primary, #e8e8ec); background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); }
.dps-conv-empty { padding: 4px 6px 6px; font: var(--dsw-font-xxxs-11, 11px); line-height: 1.6; color: var(--dsw-alias-label-dimmed, #8f8f99); display: flex; flex-direction: column; gap: 4px; align-items: flex-start; }
.dps-conv-cta { border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,.35)); background: transparent; color: var(--dsw-alias-label-secondary, #c8c8d0); border-radius: 6px; padding: 2px 8px; cursor: pointer; font: var(--dsw-font-xxxs-11, 11px); }
.dps-conv-cta:hover { color: var(--dsw-alias-label-primary, #e8e8ec); border-color: var(--dsw-alias-brand-primary, rgba(120,150,255,.6)); }
.dps-conv-note { padding: 2px 6px; font: var(--dsw-font-xxxs-11, 11px); line-height: 1.5; color: var(--dsw-alias-label-tertiary, #9a9aa5); }

/* ---------------------------------------------------------------------------
   E4-FINAL · 会话行的官方 Session 菜单（重命名 / 分叉会话 / 归档会话）
   官方同款行为（ui-workspace Rows.module.css）：行 hover 或菜单展开时，
   右侧时间让位给「…」按钮；菜单本体是官方 Menu（portal 到 body，不受侧栏裁剪）。
   这里只有**装载位置与显现时机**的版面规则，没有任何菜单/动作的第二套实现。 */
.dps-conv-item { position: relative; display: block; }
.dps-conv-actions { position: absolute; inset-inline-end: 4px; top: 50%; transform: translateY(-50%); display: none; align-items: center; }
.dps-conv-item:hover .dps-conv-actions,
.dps-conv-item[data-conv-menu-open="true"] .dps-conv-actions { display: inline-flex; }
/* 官方行为：hover / 菜单展开时隐藏时间列，避免与「…」重叠（官方 .sessionRow:hover .time{display:none}）。 */
.dps-conv-item:hover .dps-conv-time,
.dps-conv-item[data-conv-menu-open="true"] .dps-conv-time { display: none; }
.dps-conv-item:hover .dps-conv-row,
.dps-conv-item[data-conv-menu-open="true"] .dps-conv-row { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); }
/* 官方 iconButton 同款：16×16、无边框、tertiary → hover primary。 */
.dps-conv-menu-btn {
  display: inline-flex; align-items: center; justify-content: center;
  width: 16px; height: 16px; padding: 0; flex: none;
  border: none; border-radius: 4px; background: transparent; cursor: pointer;
  color: var(--dsw-alias-label-tertiary, #9a9aa5);
}
.dps-conv-menu-btn:hover { color: var(--dsw-alias-label-primary, #e8e8ec); background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); }
/* 官方 renameInput 同款输入框（对话框内）。 */
.dps-conv-rename-input {
  width: 100%; box-sizing: border-box; min-width: 0;
  border: .5px solid var(--dsw-alias-border-l4, rgba(128,128,128,.4));
  background: var(--dsw-alias-button-elevated-fill, rgba(128,128,128,.08));
  color: inherit; border-radius: 4px; outline: none; padding: 4px 6px;
  font: var(--dsw-font-xxs-12, 12px); line-height: 20px;
}
.dps-conv-rename-input:disabled { opacity: .6; }
.dps-conv-rename-error { margin-top: 8px; font-size: 12px; line-height: 18px; color: var(--dsw-alias-state-error-primary, #e5646a); }

/* =========================================================================
   品牌头部（2026-09-10 用户真机反馈）
   左栏顶部原本空着的官方品牌行（.logoRow → sidebar.brand.mark + sidebar.brand.name）
   现在承载「官方鲸鱼 + Personal Harness + Personal Workspace 副标题」。
   · 本插件只占官方 sidebar.brand.name 单槽；鲸鱼仍由官方 mark occupant 绘制
     （零图标复制、零 require、零外部图片）。
   · 风格贴官方左栏：白底/官方 token 文字色、无渐变、无卡片、无横幅。
   · 高度 72–84px（用户要求）；窄栏/收起回到官方 36px 行高，只留图标不溢出。
   ========================================================================= */
.dps-brand { display: inline-flex; flex-direction: column; justify-content: center; align-items: flex-start; gap: 3px; min-width: 0; max-width: 100%; }
.dps-brand-title { font-size: 14px; font-weight: 600; line-height: 18px; letter-spacing: 0; color: var(--dsw-alias-label-primary, inherit); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
.dps-brand-sub { font-size: 11px; font-weight: 400; line-height: 14px; letter-spacing: 0; color: var(--dsw-alias-label-tertiary, #8f8f99); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
html[data-dps-personal] [class*="_logoRow"] { height: 76px; }
html[data-dps-personal] [class*="_collapsed"] [class*="_logoRow"] { height: 36px; }
html[data-dps-personal] [class*="_brandIdentity"] { align-items: center; gap: 10px; height: auto; }
html[data-dps-personal] [class*="_brandName"] { height: auto; font-size: 14px; font-weight: 400; letter-spacing: 0; gap: 0; }
/* 品牌头部是「头部」，不是入口：官方 brand 按钮的中性化由 brand.tsx 在挂载时施加
   （鼠标/键盘/读屏三面一致）；此处再加一层 CSS 兜底，避免重渲染间隙可点。 */
html[data-dps-personal] [class*="_logoRow"] [class*="_brand"] { pointer-events: none; cursor: default; }

/* IA2-2 §2（修正）：personal 模式只隐藏官方**独立**的「＋ 新会话」大按钮。
   注意：官方 brand 按钮的 aria-label 同样是「新建会话」—— 早前按 aria-label 通杀会连品牌行
   一起隐藏（那正是左栏顶部的空白区），且与 brand.tsx 改写 aria-label 后行为不稳定。
   现在改为只按 css-module class 精确隐藏独立按钮；品牌行由我方占用并中性化。 */
html[data-dps-personal] [class*="_newSession"] { display: none !important; }
`;

// src/workstation/personal-sidebar/src/client/controller.ts
var import_react = require("react");
var KEY = "dsh.personalSidebar.mode";
var KEY_SET = "dsh.personalSidebar.userSet";
var DEFAULT_MODE = "personal";
function readMode() {
  try {
    const chosen = window.localStorage.getItem(KEY_SET) === "1";
    if (chosen) return window.localStorage.getItem(KEY) === "personal" ? "personal" : "official";
    return DEFAULT_MODE;
  } catch {
    return DEFAULT_MODE;
  }
}
var mode = readMode();
var subs = /* @__PURE__ */ new Set();
var personalMode = {
  get() {
    return mode;
  },
  set(next) {
    if (mode === next) return;
    mode = next;
    try {
      window.localStorage.setItem(KEY_SET, "1");
      window.localStorage.setItem(KEY, mode);
    } catch {
    }
    subs.forEach((f) => f());
  },
  subscribe(f) {
    subs.add(f);
    return () => {
      subs.delete(f);
    };
  }
};
function usePersonalMode() {
  return (0, import_react.useSyncExternalStore)(
    (f) => personalMode.subscribe(f),
    () => personalMode.get(),
    () => "personal"
  );
}

// src/workstation/personal-sidebar/src/client/PersonalBrowser.tsx
var import_react3 = require("react");

// src/workstation/personal-sidebar/src/client/icons.tsx
var import_jsx_runtime = require("react/jsx-runtime");
function base(size) {
  return {
    width: size,
    height: size,
    viewBox: "0 0 16 16",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.4,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": true
  };
}
function WorkspaceIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { ...base(size), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "2", y: "2", width: "5", height: "5", rx: "1" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "9", y: "2", width: "5", height: "5", rx: "1" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "2", y: "9", width: "5", height: "5", rx: "1" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "9", y: "9", width: "5", height: "5", rx: "1" })
  ] });
}
function ChatIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { ...base(size), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2.5 3h11v8h-7l-3.5 2.5V3Z" }) });
}
function SwitcherIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { ...base(size), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 10V4.5M4 4.5 2.2 6M4 4.5 5.8 6" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 6v5.5M12 11.5l1.8-1.5M12 11.5l-1.8-1.5" })
  ] });
}
function PlusIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { ...base(size), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 3v10M3 8h10" }) });
}
function HomeIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { ...base(size), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2.8 7.2 8 3l5.2 4.2" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 6.5V13h8V6.5" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6.6 13v-3.2h2.8V13" })
  ] });
}
function ClockIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { ...base(size), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "8", cy: "8", r: "5.4" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 5.2V8l2 1.6" })
  ] });
}
function FolderIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { ...base(size), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2.4 4.6h4l1.6 1.8H13.6v5.2a1 1 0 0 1-1 1H3.4a1 1 0 0 1-1-1V4.6Z" }) });
}

// src/workstation/personal-sidebar/src/client/conversations.ts
var EMPTY_CONVERSATIONS = { rows: [], ready: false };
var DEFAULT_VISIBLE = 5;
var CONV_EMPTY_TEXT = "\u6682\u65E0\u6700\u8FD1\u4F1A\u8BDD";
var CONV_EMPTY_CTA = "\u53BB\u4E3B\u9875\u5F00\u59CB\u4F1A\u8BDD";
var CONV_ARCHIVE_UNKNOWN_NOTE = "\u5F52\u6863\u72B6\u6001\u672A\u77E5\uFF1A\u5B98\u65B9 workspaces\uFF08\u5F52\u6863\u6765\u6E90\uFF09\u672A\u5C31\u7EEA\uFF0C\u672C\u5217\u8868\u672A\u6309\u5F52\u6863\u8FC7\u6EE4\u3002";
var CONV_SCOPE_NOTE = "\u8FD9\u91CC\u53EA\u662F\u4F1A\u8BDD\u5165\u53E3\uFF08\u6062\u590D\u5BF9\u8BDD\uFF09\uFF1B\u4EFB\u52A1\u72B6\u6001/\u9700\u8981\u5904\u7406\u5728\u4EFB\u52A1\u770B\u677F\u3002";
function str(v) {
  return typeof v === "string" ? v : "";
}
function parseConversations(snapshot) {
  if (snapshot === null || snapshot === void 0) return EMPTY_CONVERSATIONS;
  const s = snapshot;
  const raw = [];
  const byId = s.byId;
  if (byId !== null && typeof byId === "object" && !Array.isArray(byId)) {
    raw.push(...Object.values(byId));
  } else if (Array.isArray(s)) {
    raw.push(...s);
  } else if (Array.isArray(s.list)) {
    raw.push(...s.list);
  } else if (Array.isArray(s.sessions)) {
    raw.push(...s.sessions);
  } else {
    return EMPTY_CONVERSATIONS;
  }
  const rows = [];
  for (const item of raw) {
    const r = item ?? {};
    const id = str(r.id) || str(r.sessionId);
    if (id === "") continue;
    const displayTitle = str(r.displayTitle);
    const title = str(r.title);
    const cwd = str(r.cwd);
    const fallback = cwd !== "" ? cwd.split("/").filter(Boolean).pop() ?? cwd : id;
    rows.push({
      id,
      title: displayTitle !== "" ? displayTitle : title !== "" ? title : fallback,
      updatedAt: typeof r.updatedAt === "number" && Number.isFinite(r.updatedAt) ? r.updatedAt : 0,
      running: r.running === true,
      blank: r.blank === true,
      ...str(r.parentId) !== "" ? { parentId: str(r.parentId) } : {},
      ...str(r.origin) !== "" ? { origin: str(r.origin) } : {},
      ...cwd !== "" ? { cwd } : {}
    });
  }
  const currentId = str(s.current) !== "" ? str(s.current) : void 0;
  return { rows, currentId, ready: true };
}
function archiveTruthOf(source) {
  const s = source ?? {};
  const ids = s.archivedSessionIds;
  if (!Array.isArray(ids)) return { known: false, ids: /* @__PURE__ */ new Set() };
  return { known: true, ids: new Set(ids.filter((x) => typeof x === "string")) };
}
function visibleConversations(snap, archive) {
  const out = snap.rows.filter((r) => {
    if (r.origin === "subagent") return false;
    if (archive.known && archive.ids.has(r.id)) return false;
    if (r.blank && r.id !== snap.currentId) return false;
    return true;
  });
  return out.sort((a, b) => b.updatedAt !== a.updatedAt ? b.updatedAt - a.updatedAt : a.id < b.id ? -1 : 1);
}
function conversationListModel(rows, archive, expanded, limit = DEFAULT_VISIBLE) {
  const shown = expanded ? [...rows] : rows.slice(0, limit);
  const hiddenCount = expanded ? 0 : Math.max(0, rows.length - limit);
  return {
    shown,
    hiddenCount,
    expandLabel: hiddenCount > 0 ? `\u5C55\u5F00\u5176\u4F59 ${hiddenCount} \u4E2A\u4F1A\u8BDD` : "",
    archiveUnknown: !archive.known
  };
}
function relativeTime(updatedAt, now) {
  if (!Number.isFinite(updatedAt) || updatedAt <= 0) return "";
  const diff = Math.max(0, now - updatedAt);
  const min = Math.floor(diff / 6e4);
  if (min < 1) return "\u521A\u521A";
  if (min < 60) return `${min} \u5206\u949F`;
  const hours = Math.floor(min / 60);
  if (hours < 24) return `${hours} \u5C0F\u65F6`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} \u5929`;
  const months = Math.floor(days / 30);
  return `${months} \u4E2A\u6708`;
}

// src/workstation/personal-workspace/src/client/mainview.ts
var MAIN_VIEW_TITLES = {
  conversation: "\u4F1A\u8BDD",
  home: "\u4E3B\u9875",
  "task-board": "\u4EFB\u52A1\u770B\u677F",
  "new-task": "\uFF0B\u65B0\u4EFB\u52A1",
  "project-center": "\u9879\u76EE",
  "project-detail": "\u9879\u76EE\u8BE6\u60C5",
  unassigned: "\u672A\u5206\u914D",
  "workspace-center": "\u5DE5\u4F5C\u533A",
  recent: "\u6700\u8FD1"
};
var MAIN_OPEN_EVENT = "dsh:personal-main-open";
var MAIN_ACK_EVENT = "dsh:personal-main-ack";
var MAIN_STATE_EVENT = "dsh:personal-main-state";
var MAIN_UNAVAILABLE_EVENT = "dsh:personal-main-unavailable";
var INSTANCE_TAG = "dpw-" + Math.random().toString(36).slice(2, 8);
var CSS_MAIN_HOST = String.raw`
.dpw-main-host {
  box-sizing: border-box;
  height: 100%;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  background: var(--dsw-alias-bg-base, transparent);
  color: var(--dsw-alias-label-primary, inherit);
}
.dpw-main-error {
  padding: 20px;
  font: 13px/1.7 var(--ds-font-family, system-ui, sans-serif);
  color: var(--dsw-alias-label-tertiary, #9a9aa5);
}
.dpw-main-error code { font-family: var(--ds-font-family-code, monospace); word-break: break-all; }
`;

// src/workstation/personal-sidebar/src/client/diag.ts
function ensureDiag() {
  try {
    const w = window;
    if (!w.__dshDiag) w.__dshDiag = {};
    return w.__dshDiag;
  } catch {
    return {};
  }
}
function diagPkgTick(pkg, version, sha) {
  try {
    const d = ensureDiag();
    const p = d.pkg ??= {};
    p[`${pkg}Instances`] = (p[`${pkg}Instances`] ?? 0) + 1;
    p[`${pkg}Version`] = version;
    p[`${pkg}Sha`] = sha;
    const s = d.sha ??= {};
    s[pkg] = sha;
  } catch {
  }
}
function diagTrace(kind, data) {
  try {
    const d = ensureDiag();
    const list = d.traces ??= [];
    list.push({ t: Date.now(), kind, ...data });
    if (list.length > 600) list.splice(0, list.length - 600);
  } catch {
  }
}
function elDesc(el) {
  if (!el) return null;
  const tag = el.tagName.toLowerCase();
  const id = el.id ? `#${el.id}` : "";
  const cls = typeof el.className === "string" && el.className.trim().length > 0 ? "." + el.className.trim().split(/\s+/).slice(0, 3).join(".") : "";
  const data = [...el.attributes].filter((a) => a.name.startsWith("data-")).slice(0, 4).map((a) => `${a.name}="${a.value.slice(0, 30)}"`).join(" ");
  return `${tag}${id}${cls}${data ? " [" + data + "]" : ""}`.slice(0, 160);
}
function buildSelfCheckReport() {
  const out = { t: Date.now() };
  try {
    const d = ensureDiag();
    out.pkg = d.pkg ?? {};
    out.crashes = d.crashes ?? [];
    out.sha = d.sha ?? {};
    try {
      out.hostReady = window.__dshPersonalMainReady === true;
    } catch {
      out.hostReady = false;
    }
    try {
      out.mainDiag = window.__dshMainDiag ?? null;
    } catch {
      out.mainDiag = null;
    }
    try {
      out.persistedMainView = window.localStorage.getItem("dsh.personal.mainview.v1");
    } catch {
      out.persistedMainView = null;
    }
    if (typeof document !== "undefined") {
      const navRoots = document.querySelectorAll('[data-dps-nav="1"], [data-dps-nav-rail="1"]');
      out.dom = out.dom ?? {};
      out.dom.navRoots = navRoots.length;
      const rows = [...document.querySelectorAll("[data-nav]")];
      out.dom.navRows = rows.length;
      const byId = {};
      for (const r of rows) {
        const id = r.getAttribute("data-nav") ?? "?";
        byId[id] = (byId[id] ?? 0) + 1;
      }
      const dups = Object.entries(byId).filter(([, n]) => n > 1);
      out.dom.duplicateRows = dups.length > 0 ? dups : null;
      const ownBoardRows = [...document.querySelectorAll('[data-dps-nav] [data-nav="task-board"]')];
      const foreignBoardRows = [...document.querySelectorAll("[data-dsh-taskboard-entry]")];
      out.dom.taskboardEntries = {
        own: ownBoardRows.length,
        ownLabels: ownBoardRows.map((r) => (r.textContent ?? "").trim()),
        foreign: foreignBoardRows.length,
        foreignLabels: foreignBoardRows.map((r) => (r.textContent ?? "").trim()),
        foreignOwners: foreignBoardRows.map((r) => ({
          plugin: r.getAttribute("data-dsh-plugin"),
          part: r.getAttribute("data-dsh-part"),
          inSidebarPane: r.closest('[data-pane="sidebar"]') !== null
        }))
      };
      const hits = [];
      for (const r of rows) {
        const rect = r.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        let top = null;
        try {
          top = document.elementFromPoint(cx, cy);
        } catch {
          top = null;
        }
        hits.push({
          nav: r.getAttribute("data-nav"),
          x: Math.round(cx),
          y: Math.round(cy),
          rowRect: `${Math.round(rect.width)}x${Math.round(rect.height)}`,
          top: elDesc(top),
          onRow: top === r || top !== null && r.contains(top)
        });
      }
      ;
      out.dom.navHitTest = hits;
      const host = document.querySelector('[data-dsh-main-host="1"]');
      out.dom.mainHostView = host?.getAttribute("data-dsh-main-view") ?? null;
      out.dom.mainHostError = document.querySelector('[data-dsh-main-error="1"]') !== null;
      out.dom.mainHostFound = host !== null;
      try {
        const mounts = ensureDiag().mounts ?? [];
        out.dom.mounts = mounts.slice(-12);
      } catch {
        ;
        out.dom.mounts = [];
      }
      const labels = ["\u4EFB\u52A1\u770B\u677F", "\u4EFB\u52A1\u677F", "\u65B0\u4EFB\u52A1", "\uFF0B\u65B0\u4EFB\u52A1", "\uFF0B \u65B0\u4EFB\u52A1"];
      const labelHits = [];
      const seen = /* @__PURE__ */ new Set();
      const walk = (el) => {
        for (const child of el.children) {
          if (seen.has(child)) continue;
          seen.add(child);
          walk(child);
          const text = (child.textContent ?? "").trim();
          if (text.length === 0 || text.length > 24) continue;
          if (labels.includes(text) || labels.includes(text.replace(/\s+/g, " "))) {
            labelHits.push({ text, where: elDesc(child), path: pathOf(child) });
          }
        }
      };
      const pathOf = (el) => {
        const parts = [];
        let cur = el;
        let guard = 0;
        while (cur && guard < 8) {
          const p = elDesc(cur);
          parts.unshift(p ?? cur.tagName);
          cur = cur.parentElement;
          guard += 1;
        }
        return parts.join(" < ");
      };
      walk(document.body);
      out.dom.labelScan = labelHits;
      try {
        const slots = window.__dshDiag?.slotsRaw;
        if (slots && typeof slots.snapshot === "function") {
          const conv = slots.snapshot("conversation");
          const side = slots.snapshot("sidebar");
          out.seats = { conversation: conv, sidebar: side };
        } else {
          out.seats = { note: "slotsRaw \u53E5\u67C4\u7F3A\u5931\uFF08workspace \u672A\u8FD0\u884C\u6216\u7248\u672C\u8FC7\u65E7\uFF09" };
        }
      } catch (error) {
        out.seats = { error: error instanceof Error ? error.message : String(error) };
      }
    }
  } catch (error) {
    out.error = error instanceof Error ? error.message : String(error);
  }
  return out;
}

// src/workstation/personal-sidebar/src/client/sessionActions.tsx
var import_react2 = require("react");
var import_dsh_client_ui_primitives = require("@deepseek-ai/dsh-client-ui-primitives");
var import_jsx_runtime2 = require("react/jsx-runtime");
var SESSION_ACTION_LABELS = {
  rename: "\u91CD\u547D\u540D",
  fork: "\u5206\u53C9\u4F1A\u8BDD",
  archive: "\u5F52\u6863\u4F1A\u8BDD"
};
var SESSION_MENU_ITEMS = [
  { id: "rename", label: SESSION_ACTION_LABELS.rename, icon: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_dsh_client_ui_primitives.IconEditOutline16, {}) },
  { id: "fork", label: SESSION_ACTION_LABELS.fork, icon: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_dsh_client_ui_primitives.IconBranchOutline16, {}) },
  { id: "archive", label: SESSION_ACTION_LABELS.archive, icon: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_dsh_client_ui_primitives.IconArchiveOutline20, { size: 16 }) }
];
function SessionActionsMenu(props) {
  const { title, open, onOpenChange, onRename, onFork, onArchive } = props;
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
    import_dsh_client_ui_primitives.Menu,
    {
      open,
      onClose: () => onOpenChange(false),
      items: SESSION_MENU_ITEMS,
      onSelect: (id) => {
        onOpenChange(false);
        if (id === "rename") onRename();
        if (id === "fork") onFork();
        if (id === "archive") onArchive();
      },
      portal: true,
      closeOnPointerLeave: true,
      anchor: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        "button",
        {
          type: "button",
          className: "dps-conv-menu-btn",
          "data-dps-conv-menu": "1",
          "aria-haspopup": "menu",
          "aria-expanded": open ? "true" : void 0,
          "aria-label": `\u4F1A\u8BDD\u201C${title}\u201D\u7684\u64CD\u4F5C`,
          onClick: (e) => {
            e.stopPropagation();
            onOpenChange(!open);
          },
          children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_dsh_client_ui_primitives.IconEllipsisOutline16, {})
        }
      )
    }
  );
}
function SessionRenameDialog(props) {
  const { open, draft, renaming, blocked, error, onDraft, onConfirm, onClose } = props;
  const composingRef = (0, import_react2.useRef)(false);
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(
    import_dsh_client_ui_primitives.Modal,
    {
      open,
      onClose,
      closeLabel: "\u5173\u95ED",
      title: "\u91CD\u547D\u540D\u4F1A\u8BDD",
      footer: /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_jsx_runtime2.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_dsh_client_ui_primitives.Button, { variant: "outline", disabled: renaming, onClick: onClose, children: "\u53D6\u6D88" }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_dsh_client_ui_primitives.Button, { variant: "primary", disabled: blocked, onClick: onConfirm, children: "\u91CD\u547D\u540D" })
      ] }),
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
          "input",
          {
            className: "dps-conv-rename-input",
            "data-dps-conv-rename-input": "1",
            value: draft,
            "aria-label": "\u4F1A\u8BDD\u540D\u79F0",
            autoFocus: true,
            disabled: renaming,
            onFocus: (e) => {
              e.target.select();
            },
            onChange: (e) => {
              onDraft(e.target.value);
            },
            onCompositionStart: () => {
              composingRef.current = true;
            },
            onCompositionEnd: () => {
              composingRef.current = false;
            },
            onKeyDown: (e) => {
              if (e.key === "Enter" && !composingRef.current) {
                e.preventDefault();
                onConfirm();
              }
            }
          }
        ),
        error !== null ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "dps-conv-rename-error", "data-dps-conv-rename-error": "1", role: "alert", children: error }) : null
      ]
    }
  );
}

// src/workstation/personal-sidebar/src/client/PersonalBrowser.tsx
var import_jsx_runtime3 = require("react/jsx-runtime");
var TAB_NEW_TASK = "new-task";
var TAB_HOME = "mission-control";
var TAB_PROJECTS = "project-center";
var TAB_WORKSPACES = "workspace-center";
var TAB_RECENT = "recent";
var SafeBoundary = class extends import_react3.Component {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error) {
    console.warn("[dsh-personal-sidebar] PersonalBrowser crashed:", error);
  }
  render() {
    if (this.state.failed) {
      return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dps-root dps-empty", children: [
        "Personal Sidebar \u6E32\u67D3\u51FA\u9519\u3002",
        /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("button", { type: "button", className: "dps-link dps-link-strong", onClick: () => this.props.onFallback(), children: [
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(SwitcherIcon, { size: 12 }),
          " \u5207\u56DE\u5B98\u65B9\u4F1A\u8BDD\u6D4F\u89C8"
        ] })
      ] });
    }
    return this.props.children;
  }
};
var ATTENTION_EVENT = "dsh:personal-attention";
var ATTENTION_REQUEST_EVENT = "dsh:personal-attention-request";
var BOARD_ENTRY_SELECTOR = "[data-dsh-taskboard-entry]";
var BOARD_OPEN_ATTR = "data-dsh-taskboard-active";
function closeBoardIfOpen() {
  try {
    if (typeof document === "undefined") return;
    const root = document.documentElement;
    if (root === null || !root.hasAttribute(BOARD_OPEN_ATTR)) return;
    const entry = document.querySelector(BOARD_ENTRY_SELECTOR);
    if (entry !== null && typeof entry.click === "function") entry.click();
  } catch {
  }
}
function adaptAttentionPayload(raw) {
  const p = raw ?? {};
  if (p.v !== 1) return null;
  const n = typeof p.n === "number" && Number.isFinite(p.n) ? p.n : null;
  return {
    n,
    ready: p.ready === true,
    hostUp: p.hostUp === true,
    hostError: typeof p.hostError === "string" ? p.hostError : void 0
  };
}
var NAV = [
  // 双加号修复（E4-FIX-IA-2 · MAIN NAV）：行内已渲染 PlusIcon（加号图标），
  // label 若再以「＋ 」开头 = 图标加号 + 文本加号 = 视觉“＋＋新任务”（真机投诉项）。
  // 唯一加号来源 = 图标；文案仅「新任务」。
  { id: "new-task", tab: TAB_NEW_TASK, path: "new", label: "\u65B0\u4EFB\u52A1", hint: "\u521B\u5EFA\u4E00\u4E2A\u9700\u8981\u6267\u884C\u3001\u8DDF\u8E2A\u3001\u63A7\u5236\u7684\u4EFB\u52A1\uFF08\u4E2D\u592E\u4E3B\u533A\u6253\u5F00\u5B8C\u6574 New Task Composer\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(PlusIcon, { size: 18 }), main: "new-task" },
  { id: "home", tab: TAB_HOME, path: "home", label: "\u4E3B\u9875", hint: "Mission Control\uFF1A\u6211\u73B0\u5728\u8981\u505A\u4EC0\u4E48 / AI \u5728\u505A\u4EC0\u4E48\uFF08\u4E2D\u592E\u4E3B\u533A\u6253\u5F00\u5B8C\u6574\u4E3B\u9875\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(HomeIcon, { size: 18 }), main: "home" },
  { id: "projects", tab: TAB_PROJECTS, path: "center", label: "\u9879\u76EE", hint: "\u6211\u957F\u671F\u5728\u641E\u54EA\u4E9B\u4E8B\u60C5\uFF08\u4E2D\u592E\u4E3B\u533A\u6253\u5F00 Project Center\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(FolderIcon, { size: 18 }), main: "project-center" },
  { id: "workspaces", tab: TAB_WORKSPACES, path: "center", label: "\u5DE5\u4F5C\u533A", hint: "AI \u5B9E\u9645\u5728\u54EA\u4E9B\u771F\u5B9E\u6587\u4EF6/\u76EE\u5F55\u91CC\u5DE5\u4F5C\uFF08\u4E2D\u592E\u4E3B\u533A\u6253\u5F00 Workspace Center\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(WorkspaceIcon, { size: 18 }), main: "workspace-center" },
  { id: "recent", tab: TAB_RECENT, path: "list", label: "\u6700\u8FD1", hint: "\u6700\u8FD1\u53D1\u751F\u4E86\u4EC0\u4E48\uFF08\u4E2D\u592E\u4E3B\u533A\u6253\u5F00 Recent\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(ClockIcon, { size: 18 }), main: "recent" },
  { id: "conversation", tab: "", path: "", label: "\u4F1A\u8BDD", hint: "\u56DE\u5230\u4E2D\u592E Conversation\uFF08\u5F53\u524D\u4F1A\u8BDD\uFF1B\u4F1A\u8BDD\u72B6\u6001\u7531\u5B98\u65B9\u5F15\u64CE\u4FDD\u7559\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(ChatIcon, { size: 18 }), main: "conversation" }
];
var NAV_ID_OF_VIEW = {
  conversation: "conversation",
  home: "home",
  // 'task-board' **有意不设**：Personal 任务板无主导航行（辅助区能力），
  // 故打开它时不高亮任何主导航行——避免用高亮暗示它是第二个 Primary Entry。
  "new-task": "new-task",
  "project-center": "projects",
  "project-detail": "projects",
  "workspace-center": "workspaces",
  recent: "recent"
};
function PersonalBrowser(props) {
  const { wide, expandSidebar, switchOfficial, betterSidebar, conversations } = props;
  const [attention, setAttention] = (0, import_react3.useState)(null);
  const [notice, setNotice] = (0, import_react3.useState)(null);
  const [activeNavId, setActiveNavId] = (0, import_react3.useState)(null);
  const [convSnap, setConvSnap] = (0, import_react3.useState)({ rows: [], ready: false });
  const [archiveKnownNow, setArchiveKnownNow] = (0, import_react3.useState)({ known: false, ids: /* @__PURE__ */ new Set() });
  const [convExpanded, setConvExpanded] = (0, import_react3.useState)(false);
  const [convNow, setConvNow] = (0, import_react3.useState)(() => Date.now());
  const [menuOpenId, setMenuOpenId] = (0, import_react3.useState)(null);
  const [renameTarget, setRenameTarget] = (0, import_react3.useState)(null);
  const [renameDraft, setRenameDraft] = (0, import_react3.useState)("");
  const [renaming, setRenaming] = (0, import_react3.useState)(false);
  const [renameError, setRenameError] = (0, import_react3.useState)(null);
  const noticeTimer = (0, import_react3.useRef)(null);
  const navSeq = (0, import_react3.useRef)(0);
  const sendCleanupRef = (0, import_react3.useRef)(null);
  (0, import_react3.useEffect)(() => {
    if (conversations === null || conversations === void 0) return;
    const read = () => {
      try {
        const snap = parseConversations(conversations.getSnapshot());
        setConvSnap(snap);
      } catch {
        setConvSnap({ rows: [], ready: false });
      }
      try {
        setArchiveKnownNow(archiveTruthOf(conversations.archive()));
      } catch {
        setArchiveKnownNow({ known: false, ids: /* @__PURE__ */ new Set() });
      }
    };
    read();
    let off = null;
    try {
      off = conversations.subscribe(read);
    } catch {
      off = null;
    }
    let offArchive = null;
    const ensureArchiveSub = () => {
      if (offArchive !== null) return true;
      try {
        offArchive = conversations.subscribeArchive(read);
      } catch {
        offArchive = null;
      }
      return offArchive !== null;
    };
    ensureArchiveSub();
    let tries = 0;
    const timer = setInterval(() => {
      tries += 1;
      read();
      if (ensureArchiveSub() || tries >= 24) clearInterval(timer);
    }, 500);
    return () => {
      try {
        off?.();
      } catch {
      }
      try {
        offArchive?.();
      } catch {
      }
      clearInterval(timer);
    };
  }, [conversations]);
  (0, import_react3.useEffect)(() => {
    const t = setInterval(() => setConvNow(Date.now()), 6e4);
    return () => clearInterval(t);
  }, []);
  (0, import_react3.useEffect)(() => {
    if (typeof window === "undefined") return;
    const onUnavailable = (ev) => {
      try {
        const detail = ev.detail;
        const view = typeof detail?.view === "string" ? detail.view : null;
        const label = view !== null ? MAIN_VIEW_TITLES[view] ?? view : "\u8BE5\u9875\u9762";
        const reason = typeof detail?.reason === "string" ? detail.reason : "\u4E2D\u592E\u4E3B\u533A\u5C1A\u672A\u5C31\u7EEA";
        showNotice(`\u300C${label}\u300D\u672A\u80FD\u6253\u5F00\uFF1A${reason}\u3002\u8BF7\u7A0D\u5019\u91CD\u8BD5\u3002`);
        setActiveNavId(null);
      } catch {
      }
    };
    const onState = (ev) => {
      try {
        const view = ev.detail?.view;
        if (typeof view !== "string") return;
        setActiveNavId(NAV_ID_OF_VIEW[view] ?? null);
      } catch {
      }
    };
    try {
      window.addEventListener(MAIN_STATE_EVENT, onState);
      window.addEventListener(MAIN_UNAVAILABLE_EVENT, onUnavailable);
      return () => {
        try {
          window.removeEventListener(MAIN_STATE_EVENT, onState);
          window.removeEventListener(MAIN_UNAVAILABLE_EVENT, onUnavailable);
        } catch {
        }
      };
    } catch {
      return;
    }
  }, []);
  (0, import_react3.useEffect)(
    () => () => {
      if (noticeTimer.current) {
        try {
          clearTimeout(noticeTimer.current);
        } catch {
        }
      }
      if (sendCleanupRef.current) {
        try {
          const c = sendCleanupRef.current;
          sendCleanupRef.current = null;
          c();
        } catch {
        }
      }
    },
    []
  );
  (0, import_react3.useEffect)(() => {
    if (typeof window === "undefined") return;
    let alive = true;
    const onAttention = (ev) => {
      try {
        const next = adaptAttentionPayload(ev.detail);
        if (next === null) return;
        if (alive) setAttention(next);
      } catch {
      }
    };
    try {
      window.addEventListener(ATTENTION_EVENT, onAttention);
    } catch {
      return;
    }
    try {
      window.dispatchEvent(new CustomEvent(ATTENTION_REQUEST_EVENT));
    } catch {
    }
    return () => {
      alive = false;
      try {
        window.removeEventListener(ATTENTION_EVENT, onAttention);
      } catch {
      }
    };
  }, []);
  (0, import_react3.useEffect)(() => {
    if (typeof document === "undefined") return;
    let observer = null;
    let disposed = false;
    const paint = () => {
      if (disposed) return;
      const row = document.querySelector(BOARD_ENTRY_SELECTOR);
      if (row === null || row === void 0) return;
      const existing = row.querySelector("[data-dps-attn-badge]");
      const n = attention !== null && attention.hostUp && attention.n !== null ? attention.n : null;
      if (n === null || n <= 0) {
        if (existing !== null) existing.remove();
        return;
      }
      if (existing !== null) {
        if (existing.textContent !== String(n)) existing.textContent = String(n);
        return;
      }
      const badge2 = document.createElement("span");
      badge2.setAttribute("data-dps-attn-badge", "1");
      badge2.textContent = String(n);
      badge2.title = `\u9700\u8981\u4F60\u5904\u7406\uFF1A${n} \u9879\uFF08\u5931\u8D25 / \u9700\u6743\u9650\u786E\u8BA4 / \u5BBF\u4E3B\u9519\u8BEF\uFF09`;
      badge2.style.cssText = "margin-left:auto;flex:none;min-width:18px;height:18px;padding:0 5px;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;line-height:18px;background:rgba(240,180,60,.18);color:#e8b64c;border:1px solid rgba(240,180,60,.4)";
      try {
        row.appendChild(badge2);
      } catch {
      }
    };
    paint();
    const root = document.body;
    if (root !== null && root !== void 0 && typeof MutationObserver === "function") {
      observer = new MutationObserver(() => paint());
      observer.observe(root, { childList: true, subtree: true });
    }
    return () => {
      disposed = true;
      try {
        observer?.disconnect();
      } catch {
      }
      try {
        document.querySelector("[data-dps-attn-badge]")?.remove();
      } catch {
      }
    };
  }, [attention]);
  const showNotice = (text) => {
    setNotice(text);
    if (noticeTimer.current) {
      try {
        clearTimeout(noticeTimer.current);
      } catch {
      }
    }
    if (typeof window !== "undefined" && typeof window.setTimeout === "function") {
      noticeTimer.current = window.setTimeout(() => setNotice(null), 3200);
    }
  };
  const handleUnavailable = (item, reason) => {
    diagTrace("main-unavailable", { nav: item.id, detail: reason });
    setActiveNavId((prev) => prev === item.id ? null : prev);
    showNotice(
      `\u300C${item.label}\u300D\u662F\u4E2D\u592E\u4E3B\u533A\u9875\u9762\uFF1A\u5F53\u524D${reason}\u3002\u8BF7\u7A0D\u5019\u91CD\u8BD5\uFF1B\u82E5\u6301\u7EED\u4E0D\u53EF\u7528\uFF0C\u8BF7\u786E\u8BA4 Personal \u5DE5\u4F5C\u53F0\u63D2\u4EF6\u5DF2\u542F\u7528\u540E\u91CD\u65B0\u6253\u5F00\u7A97\u53E3\uFF08\u672C\u63D2\u4EF6\u4E0D\u518D\u5728\u8F85\u52A9\u9762\u677F\u63D0\u4F9B\u91CD\u590D\u9875\u9762\uFF09\u3002`
    );
  };
  const sendMain = (view, item, seq) => {
    if (typeof window === "undefined") return;
    closeBoardIfOpen();
    const t0 = Date.now();
    if (sendCleanupRef.current) {
      try {
        const c = sendCleanupRef.current;
        sendCleanupRef.current = null;
        c();
      } catch {
        sendCleanupRef.current = null;
      }
    }
    let hostReady = false;
    try {
      hostReady = window.__dshPersonalMainReady === true;
    } catch {
      hostReady = false;
    }
    diagTrace("main-click", { nav: item.id, view, detail: `hostReady=${hostReady} seq=${seq}` });
    setActiveNavId(item.id);
    const stale = () => seq !== navSeq.current;
    const cancelPending = () => {
      if (sendCleanupRef.current) {
        try {
          const c = sendCleanupRef.current;
          sendCleanupRef.current = null;
          c();
        } catch {
          sendCleanupRef.current = null;
        }
      }
    };
    const fallbackToAux = (reason) => {
      if (stale()) return;
      diagTrace("main-unavailable", { nav: item.id, view, detail: reason, ms: Date.now() - t0 });
      setActiveNavId((prev) => prev === item.id ? null : prev);
      if (view === "conversation") {
        showNotice("\u65E0\u6CD5\u5207\u6362\u5230\u4E2D\u592E\u4F1A\u8BDD\uFF1APersonal \u5DE5\u4F5C\u53F0\u672A\u8FDE\u63A5\uFF08\u8BF7\u786E\u8BA4\u5DF2\u542F\u7528 Personal \u5DE5\u4F5C\u53F0\uFF09\u3002");
        return;
      }
      showNotice(`\u4E2D\u592E\u4E3B\u533A\u6682\u4E0D\u53EF\u7528\uFF08${reason}\uFF09\u2014\u2014\u300C${item.label}\u300D\u4E0D\u518D\u63D0\u4F9B\u8F85\u52A9\u9762\u677F\u590D\u5236\u54C1\uFF0C\u8BF7\u7A0D\u5019\u91CD\u8BD5\u3002`);
    };
    const markOk = (detail) => {
      if (stale()) return;
      diagTrace("main-ok", { nav: item.id, view, detail, ms: Date.now() - t0 });
      cancelPending();
    };
    let acked = false;
    const onAck = (ev) => {
      try {
        const detail = ev.detail;
        if (detail?.view !== view || acked) return;
        acked = true;
        diagTrace("main-ack", {
          nav: item.id,
          view,
          detail: `ok=${detail?.ok === true} seat=${detail?.seatPriority ?? "\u2014"}`,
          ms: Date.now() - t0
        });
        if (detail?.ok !== true) {
          try {
            window.removeEventListener(MAIN_ACK_EVENT, onAck);
          } catch {
          }
          cancelPending();
          fallbackToAux("\u4E2D\u592E\u4E3B\u533A seat \u6CE8\u518C\u5931\u8D25");
        }
      } catch {
      }
    };
    const checkMainDom = () => {
      if (typeof document === "undefined") return "no-dom";
      const host = document.querySelector('[data-dsh-main-host="1"]');
      if (!host) return "absent";
      if (host.getAttribute("data-dsh-main-error") === "1") return "error";
      return host.getAttribute("data-dsh-main-view") ?? "unknown";
    };
    const verifyTarget = (expected, attempt) => {
      if (stale()) return;
      const actual = checkMainDom();
      const ok = expected === "conversation" ? actual === "absent" || actual === "no-dom" : actual === expected;
      if (ok) {
        markOk(`verified data-dsh-main-view=${actual} (attempt ${attempt + 1})`);
        return;
      }
      if (attempt >= 1) {
        diagTrace("main-verify-fail", {
          nav: item.id,
          view,
          detail: `expected ${expected}, got ${actual}`,
          ms: Date.now() - t0
        });
        cancelPending();
        if (actual === "error") {
          fallbackToAux("\u4E2D\u592E\u4E3B\u533A\u89C6\u56FE\u6E32\u67D3\u5D29\u6E83\uFF08\u8BE6\u89C1\u8BCA\u65AD\u65E5\u5FD7\uFF09");
          return;
        }
        let hostNow = false;
        try {
          hostNow = window.__dshPersonalMainReady === true;
        } catch {
          hostNow = false;
        }
        fallbackToAux(
          actual === "absent" && !hostNow ? "Personal \u5DE5\u4F5C\u53F0\u5BBF\u4E3B\u672A\u8FD0\u884C\uFF08\u8BF7\u786E\u8BA4\u5DF2\u542F\u7528\u540E\u91CD\u8BD5\uFF09" : expected === "conversation" ? "\u4E2D\u592E\u4E3B\u533A\u4ECD\u88AB Personal \u89C6\u56FE\u5360\u7528" : `\u4E2D\u592E\u4E3B\u533A\u672A\u663E\u793A\u300C${item.label}\u300D\uFF08\u5B9E\u9645 ${actual}\uFF09`
        );
        return;
      }
      window.setTimeout(() => verifyTarget(expected, attempt + 1), 330);
    };
    const arm = () => {
      const tVerify = window.setTimeout(() => verifyTarget(view, 0), 120);
      sendCleanupRef.current = () => {
        try {
          window.clearTimeout(tVerify);
        } catch {
        }
        try {
          window.removeEventListener(MAIN_ACK_EVENT, onAck);
        } catch {
        }
      };
    };
    try {
      window.addEventListener(MAIN_ACK_EVENT, onAck);
    } catch {
    }
    try {
      window.dispatchEvent(new CustomEvent(MAIN_OPEN_EVENT, { detail: { view } }));
    } catch {
      try {
        window.removeEventListener(MAIN_ACK_EVENT, onAck);
      } catch {
      }
      cancelPending();
      fallbackToAux("\u4E8B\u4EF6\u6D3E\u53D1\u5931\u8D25");
      return;
    }
    arm();
  };
  const convArchive = archiveKnownNow;
  const convRows = visibleConversations(convSnap, convArchive);
  const convModel = conversationListModel(convRows, convArchive, convExpanded, DEFAULT_VISIBLE);
  const go = (item) => {
    navSeq.current += 1;
    const seq = navSeq.current;
    if (!wide) expandSidebar();
    if (item.main) {
      sendMain(item.main, item, seq);
      return;
    }
    handleUnavailable(item, "\u8BE5\u5165\u53E3\u4E0D\u662F\u4E2D\u592E\u4E3B\u533A\u9875\u9762");
  };
  const goHome = () => {
    const item = NAV.find((n) => n.id === "home");
    if (item) go(item);
  };
  const goConversationIfOccupied = () => {
    if (typeof document === "undefined") return;
    if (document.querySelector('[data-dsh-main-host="1"]') === null) return;
    const item = NAV.find((n) => n.id === "conversation");
    if (item) go(item);
  };
  const openConversationRow = (sessionId) => {
    closeBoardIfOpen();
    goConversationIfOccupied();
    try {
      conversations?.open(sessionId);
    } catch {
      showNotice("\u6253\u5F00\u4F1A\u8BDD\u5931\u8D25\uFF1A\u5B98\u65B9 sessions.open \u8C03\u7528\u5F02\u5E38\u3002");
    }
  };
  const renameTrimmed = renameDraft.trim();
  const renameBlocked = renaming || renameTrimmed === "" || renameTarget === null;
  const beginSessionRename = (row) => {
    setRenameTarget({ id: row.id, title: row.title });
    setRenameDraft(row.title);
    setRenameError(null);
  };
  const closeSessionRename = () => {
    if (renaming) return;
    setRenameTarget(null);
    setRenameError(null);
  };
  const confirmSessionRename = () => {
    if (renameBlocked || renameTarget === null) return;
    const handle = conversations;
    if (handle === null || handle === void 0 || typeof handle.rename !== "function") {
      setRenameError("\u5B98\u65B9\u4F1A\u8BDD\u670D\u52A1\u672A\u5C31\u7EEA\uFF08sessions.rename \u4E0D\u53EF\u8FBE\uFF09\u2014\u2014 \u672A\u505A\u4EFB\u4F55\u4FEE\u6539\u3002");
      return;
    }
    setRenaming(true);
    setRenameError(null);
    void handle.rename(renameTarget.id, renameTrimmed).then(() => {
      setRenaming(false);
      setRenameTarget(null);
    }).catch((reason) => {
      setRenaming(false);
      setRenameError(reason instanceof Error ? reason.message : String(reason));
    });
  };
  const forkSessionRow = (row) => {
    const handle = conversations;
    if (handle === null || handle === void 0 || typeof handle.fork !== "function") {
      showNotice("\u5206\u53C9\u4F1A\u8BDD\u5931\u8D25\uFF1A\u5B98\u65B9\u4F1A\u8BDD\u670D\u52A1\u672A\u5C31\u7EEA\uFF08sessions.fork \u4E0D\u53EF\u8FBE\uFF09\u3002");
      return;
    }
    void handle.fork(row.id).then((childId) => {
      openConversationRow(childId);
    }).catch((reason) => {
      showNotice(`\u5206\u53C9\u4F1A\u8BDD\u5931\u8D25\uFF1A${reason instanceof Error ? reason.message : String(reason)}`);
    });
  };
  const archiveSessionRow = (row) => {
    const handle = conversations;
    if (handle === null || handle === void 0 || typeof handle.archiveSession !== "function") {
      showNotice("\u5F52\u6863\u4F1A\u8BDD\u5931\u8D25\uFF1A\u5B98\u65B9 workspaces \u670D\u52A1\u672A\u5C31\u7EEA\uFF08archiveSession \u4E0D\u53EF\u8FBE\uFF09\u3002");
      return;
    }
    void handle.archiveSession(row.id).then(() => {
    }).catch((reason) => {
      showNotice(`\u5F52\u6863\u4F1A\u8BDD\u5931\u8D25\uFF1A${reason instanceof Error ? reason.message : String(reason)}`);
    });
  };
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(SafeBoundary, { onFallback: switchOfficial, children: !wide ? /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dps-rail", "data-dps-nav-rail": "1", children: [
    NAV.map((n) => /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
      "button",
      {
        type: "button",
        className: "dps-rail-btn",
        title: n.hint,
        onClick: () => go(n),
        "data-nav": n.id,
        "data-active": activeNavId === n.id ? "true" : void 0,
        children: n.icon
      },
      n.id
    )),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { style: { flex: 1 } }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "dps-rail-btn", title: "\u5207\u56DE\u5B98\u65B9\u4F1A\u8BDD\u6D4F\u89C8", onClick: switchOfficial, children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(SwitcherIcon, { size: 15 }) })
  ] }) : /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dps-root", "data-dps-nav": "1", children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dps-nav", children: NAV.map((n) => /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(
      "button",
      {
        type: "button",
        className: "dps-nav-item",
        "data-nav": n.id,
        "data-active": activeNavId === n.id ? "true" : void 0,
        title: n.hint,
        onClick: () => go(n),
        children: [
          n.icon,
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { children: n.label })
        ]
      },
      n.id
    )) }),
    conversations !== null && conversations !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dps-conv", "data-dps-conversations": "1", "aria-label": "\u4F1A\u8BDD\u5217\u8868", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dps-conv-h", children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { children: "\u4F1A\u8BDD\u5217\u8868" }),
        convSnap.ready && convRows.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dps-conv-n", "data-dps-conv-count": convRows.length, children: convRows.length }) : null
      ] }),
      !convSnap.ready ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dps-conv-empty", "data-dps-conv-state": "loading", children: "\u6B63\u5728\u8BFB\u53D6\u5B98\u65B9\u4F1A\u8BDD\u2026" }) : convRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dps-conv-empty", "data-dps-conv-state": "empty", children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { children: CONV_EMPTY_TEXT }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "dps-conv-cta", "data-dps-conv-cta": "1", onClick: goHome, children: CONV_EMPTY_CTA })
      ] }) : /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_jsx_runtime3.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("ul", { className: "dps-conv-list", children: convModel.shown.map((row) => {
          const active = convSnap.currentId !== void 0 && convSnap.currentId === row.id;
          const menuOpen = menuOpenId === row.id;
          return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(
            "li",
            {
              className: "dps-conv-item",
              "data-conv-menu-open": menuOpen ? "true" : void 0,
              children: [
                /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(
                  "button",
                  {
                    type: "button",
                    className: "dps-conv-row",
                    "data-dps-conv-row": "1",
                    "data-conv-id": row.id,
                    "data-conv-active": active ? "true" : "false",
                    "aria-current": active ? "true" : void 0,
                    title: `${row.title}${row.cwd !== void 0 ? `\uFF5C\u5DE5\u4F5C\u533A ${row.cwd}` : ""}\uFF5C\u6253\u5F00\u8BE5\u5B98\u65B9\u4F1A\u8BDD`,
                    onClick: () => {
                      setMenuOpenId(null);
                      openConversationRow(row.id);
                    },
                    children: [
                      /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("span", { className: "dps-conv-title", children: [
                        row.title,
                        row.running ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dps-conv-run", "aria-label": "\u8FD0\u884C\u4E2D" }) : null
                      ] }),
                      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dps-conv-time", children: relativeTime(row.updatedAt, convNow) })
                    ]
                  }
                ),
                /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dps-conv-actions", children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
                  SessionActionsMenu,
                  {
                    title: row.title,
                    open: menuOpen,
                    onOpenChange: (next) => setMenuOpenId(next ? row.id : null),
                    onRename: () => beginSessionRename(row),
                    onFork: () => forkSessionRow(row),
                    onArchive: () => archiveSessionRow(row)
                  }
                ) })
              ]
            },
            row.id
          );
        }) }),
        convModel.hiddenCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
          "button",
          {
            type: "button",
            className: "dps-conv-more",
            "data-dps-conv-expand": "1",
            onClick: () => setConvExpanded(true),
            children: convModel.expandLabel
          }
        ) : convExpanded && convRows.length > DEFAULT_VISIBLE ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
          "button",
          {
            type: "button",
            className: "dps-conv-more",
            "data-dps-conv-collapse": "1",
            onClick: () => setConvExpanded(false),
            children: "\u6536\u8D77"
          }
        ) : null
      ] }),
      convModel.archiveUnknown ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dps-conv-note", "data-dps-conv-archive-unknown": "1", children: CONV_ARCHIVE_UNKNOWN_NOTE }) : null,
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dps-conv-note", "data-dps-conv-scope": "1", children: CONV_SCOPE_NOTE }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
        SessionRenameDialog,
        {
          open: renameTarget !== null,
          draft: renameDraft,
          renaming,
          blocked: renameBlocked,
          error: renameError,
          onDraft: (value) => {
            setRenameDraft(value);
            setRenameError(null);
          },
          onConfirm: confirmSessionRename,
          onClose: closeSessionRename
        }
      )
    ] }) : null,
    notice ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dps-mm", "data-dps-nav-notice-host": "1", children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dps-mm-notice", "data-dps-nav-notice": "1", children: notice }) }) : null
  ] }) });
}

// src/workstation/personal-sidebar/src/client/brand.tsx
var import_react4 = require("react");
var import_jsx_runtime4 = require("react/jsx-runtime");
var FALLBACK_VERSION = "0.1.24";
var FALLBACK_PRODUCT_NAME = "Personal Harness";
var FALLBACK_PRODUCT_VERSION = "V1.1";
var BRAND_TITLE = "Personal Harness";
function productName() {
  return "Personal Harness".length > 0 ? "Personal Harness" : FALLBACK_PRODUCT_NAME;
}
function productVersion() {
  return "V1.1".length > 0 ? "V1.1" : FALLBACK_PRODUCT_VERSION;
}
function brandSubtitle() {
  return `${productName()} \xB7 ${productVersion()}`;
}
function brandVersion() {
  return "0.1.24".length > 0 ? "0.1.24" : FALLBACK_VERSION;
}
function useBrandNeutralizer() {
  const ref = (0, import_react4.useRef)(null);
  (0, import_react4.useEffect)(() => {
    const btn = ref.current?.closest("button") ?? null;
    if (btn === null) return;
    const prevLabel = btn.getAttribute("aria-label");
    const prevTab = btn.getAttribute("tabindex");
    const prevTitle = btn.getAttribute("title");
    const prevPointer = btn.style.pointerEvents;
    const prevCursor = btn.style.cursor;
    btn.setAttribute("aria-label", `${BRAND_TITLE}\uFF5C${brandSubtitle()}\uFF08sidebar ${brandVersion()}\uFF09`);
    btn.setAttribute("tabindex", "-1");
    btn.removeAttribute("title");
    btn.style.pointerEvents = "none";
    btn.style.cursor = "default";
    return () => {
      if (prevLabel === null) btn.removeAttribute("aria-label");
      else btn.setAttribute("aria-label", prevLabel);
      if (prevTab === null) btn.removeAttribute("tabindex");
      else btn.setAttribute("tabindex", prevTab);
      if (prevTitle !== null) btn.setAttribute("title", prevTitle);
      btn.style.pointerEvents = prevPointer;
      btn.style.cursor = prevCursor;
    };
  }, []);
  return ref;
}
function PersonalBrandName() {
  const ref = useBrandNeutralizer();
  const version = brandVersion();
  return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(
    "span",
    {
      className: "dps-brand",
      "data-dps-brand": "1",
      "data-dps-brand-version": version,
      "data-dps-product-version": productVersion(),
      ref,
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dps-brand-title", "data-dps-brand-title": "1", children: BRAND_TITLE }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dps-brand-sub", "data-dps-brand-sub": "1", children: brandSubtitle() })
      ]
    }
  );
}

// src/workstation/personal-sidebar/src/client/index.tsx
var import_jsx_runtime5 = require("react/jsx-runtime");
var inject = ["slots", "sessions"];
var reloadFallback = () => {
  try {
    window.setTimeout(() => {
      try {
        window.location.reload();
      } catch {
      }
    }, 150);
  } catch {
  }
};
var DPS_VERSION = "0.1.24".length > 0 ? "0.1.24" : "0.1.18";
var DPS_SHA = "a4a2092".length > 0 ? "a4a2092" : "dev";
var DIAG_DEBUG_Z = 2147483e3;
var DPS_DEBUG = (() => {
  try {
    return window.localStorage.getItem("dps.debug") === "1";
  } catch {
    return false;
  }
})();
var badge = (phase) => {
  if (!DPS_DEBUG) return;
  try {
    let el = document.getElementById("dps-live-badge");
    if (!el) {
      el = document.createElement("div");
      el.id = "dps-live-badge";
      el.style.cssText = "position:fixed;right:10px;bottom:30px;z-index:" + DIAG_DEBUG_Z + ";font:11px/1.3 system-ui,sans-serif;color:#fff;background:rgba(40,44,60,.85);padding:2px 7px;border-radius:5px;pointer-events:none;";
      document.body.appendChild(el);
    }
    el.textContent = phase;
  } catch {
  }
};
if (DPS_DEBUG) badge("dps:" + DPS_VERSION + " loaded");
function ModeToggle(_props) {
  const mode2 = usePersonalMode();
  const personal = mode2 === "personal";
  return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(
    "button",
    {
      type: "button",
      className: "dps-foot-toggle",
      "data-on": personal,
      "aria-pressed": personal,
      title: personal ? "Personal Sidebar \u5DF2\u5F00\u542F \xB7 \u70B9\u51FB\u8FD4\u56DE\u5B98\u65B9\u6D4F\u89C8" : "\u8FDB\u5165 Personal Harness\uFF08\u4E2A\u4EBA\u5DE5\u4F5C\u53F0\uFF09",
      onClick: () => personalMode.set(personal ? "official" : "personal"),
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(SwitcherIcon, { size: 12 }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { children: personal ? "\u8FD4\u56DE\u5B98\u65B9" : "\u8FDB\u5165 Personal" })
      ]
    }
  );
}
function apply(ctx) {
  try {
    applyInner(ctx);
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    badge("dps\u2717 " + msg.slice(0, 42));
    console.warn("[dsh-personal-sidebar] apply aborted, kept stock UI:", error);
  }
}
function armDiagnostics() {
  try {
    const w = window;
    w.__dshRunSelfCheck = () => buildSelfCheckReport();
  } catch {
  }
  if (!DPS_DEBUG) return;
  try {
    const arm = () => {
      const host = document.getElementById("dps-debug-panel");
      if (host) return;
      const el = document.createElement("div");
      el.id = "dps-debug-panel";
      el.style.cssText = "position:fixed;top:8px;right:8px;z-index:" + DIAG_DEBUG_Z + ";max-width:380px;max-height:72vh;overflow:auto;font:11px/1.5 ui-monospace,SFMono-Regular,Menlo,monospace;color:#dde2ec;background:rgba(28,32,46,.94);border:1px solid rgba(255,255,255,.18);border-radius:8px;padding:7px 10px;pointer-events:auto;user-select:text;white-space:pre-wrap;word-break:break-all;";
      const refresh = () => {
        try {
          const r = buildSelfCheckReport();
          const pkg = r.pkg ?? {};
          const dom = r.dom ?? {};
          const md = r.mainDiag ?? {};
          const lines = [];
          lines.push(`[dps-nav ${DPS_VERSION} ${DPS_SHA}] sidebar\xD7${pkg.sidebarInstances ?? "?"} ws\xD7${pkg.workspaceInstances ?? "?"}`);
          lines.push(`hostReady=${r.hostReady} domHost=${dom.mainHostView ?? "\u2205"}${dom.mainHostError ? " ERROR" : ""}`);
          lines.push(`mainDiag: cur=${md.current ?? "?"} tag=${md.tag ?? "?"} reg=${md.registered ?? "?"} pri=${md.seatPriority ?? "?"}`);
          lines.push(`navRoots=${dom.navRoots ?? "?"} rows=${dom.navRows ?? "?"} dupRows=${dom.duplicateRows ? JSON.stringify(dom.duplicateRows) : "0"}`);
          const scan = dom.labelScan ?? [];
          lines.push(`labelScan=${scan.length}${scan.length > 0 ? " \u2192 " + JSON.stringify(scan.slice(0, 6)) : ""}`);
          const seats = r.seats;
          lines.push(`seats: conv=${JSON.stringify(seats?.conversation ?? "\u2205").slice(0, 140)}`);
          const traces = window.__dshDiag?.traces ?? [];
          const last = traces.slice(-3).map((x) => `${x.kind}:${x.nav ?? ""}${x.ms != null ? `+${x.ms}ms` : ""}${x.detail ? `(${x.detail})` : ""}`);
          lines.push(`trace: ${last.join(" | ") || "\u2014"}`);
          el.textContent = lines.join("\n");
        } catch {
          el.textContent = "dps-debug: refresh error";
        }
      };
      refresh();
      const iv = window.setInterval(refresh, 900);
      el.addEventListener("click", () => {
        try {
          const full = JSON.stringify(buildSelfCheckReport(), null, 1);
          el.textContent = el.textContent === full ? "dps-debug panel\uFF08\u70B9\u51FB\u5237\u65B0\u8BE6\u60C5\uFF09" : full;
        } catch {
        }
      });
      const stop = () => {
        try {
          window.clearInterval(iv);
        } catch {
        }
        try {
          el.remove();
        } catch {
        }
      };
      try {
        window.addEventListener("beforeunload", stop);
      } catch {
      }
      document.body.appendChild(el);
    };
    if (typeof document !== "undefined" && document.body) arm();
    else if (typeof window !== "undefined") window.addEventListener("DOMContentLoaded", arm);
  } catch {
  }
}
function applyInner(ctx) {
  try {
    diagPkgTick("sidebar", DPS_VERSION, DPS_SHA);
  } catch {
  }
  armDiagnostics();
  const slots = ctx?.slots;
  if (!ctx || !slots || typeof slots.inject !== "function") {
    badge("dps no-slots");
    return false;
  }
  let handle = null;
  let mounted = false;
  const sessionsOf = () => {
    try {
      return typeof ctx.get === "function" ? ctx.get("sessions") : void 0;
    } catch {
      return void 0;
    }
  };
  const conversationsOf = () => {
    const listOf = () => {
      try {
        const svc = sessionsOf();
        const list = svc?.list;
        return list && typeof list.getSnapshot === "function" && typeof list.subscribe === "function" ? list : null;
      } catch {
        return null;
      }
    };
    const archiveOf = () => {
      try {
        const svc = typeof ctx.get === "function" ? ctx.get("workspaces") : void 0;
        const list = svc?.list;
        if (!list || typeof list.getSnapshot !== "function") return null;
        const snap = list.getSnapshot();
        return snap !== null && typeof snap === "object" ? snap : null;
      } catch {
        return null;
      }
    };
    return {
      /** 官方会话快照（未就绪 → undefined，UI 说「读取中」而不是「暂无会话」）。 */
      getSnapshot: () => listOf()?.getSnapshot?.() ?? void 0,
      /** 订阅官方 store（会话创建/重命名/继续/归档 → 官方自行推送，无需轮询）。 */
      subscribe: (fn) => {
        try {
          const off = listOf()?.subscribe?.(fn);
          return typeof off === "function" ? off : () => {
          };
        } catch {
          return () => {
          };
        }
      },
      /** 官方归档集（workspaces.list）；null = 源不可读（未知）。 */
      archive: () => archiveOf(),
      /**
       * 订阅官方归档集 store（`workspaces.list.subscribe`；源码证据：官方 ui-workspace
       * 自身即 `this.workspaces.list.subscribe(reconcile)`）。
       * 归档/取消归档由官方推送 → 会话列表即时刷新，**不轮询**。
       * 返回 null = 官方 workspaces 服务（或其 list store）尚不可用 → 调用方**有界**重试。
       */
      subscribeArchive: (fn) => {
        try {
          const svc = typeof ctx.get === "function" ? ctx.get("workspaces") : void 0;
          const list = svc?.list;
          if (!list || typeof list.subscribe !== "function") return null;
          const off = list.subscribe(fn);
          return typeof off === "function" ? off : () => {
          };
        } catch {
          return null;
        }
      },
      /** 打开官方会话（唯一合法路径；不创建会话/不建任务/不重放 prompt）。 */
      open: (sessionId) => {
        try {
          const svc = sessionsOf();
          svc?.open?.(sessionId);
        } catch {
        }
      },
      // -----------------------------------------------------------------------
      // E4-FINAL · Personal「会话列表」复现官方 Session 菜单：三个动作**逐句复用官方 handler**
      // （官方接线源码证据：@deepseek-ai/dsh-client-ui-workspace/lib/client.js:2674-2700）。
      //   rename  → `const session = sessions.binding(id)?.session; if (session===void 0)
      //              throw new Error(\`unknown session "${id}"\`); const r = await session.rename(t);
      //              if (!r.ok) throw new Error(r.error.message)`
      //   fork    → `sessions.fork({sessionId, increaseTitle:true})` → childId（官方随后 sessions.open）
      //   archive → `workspaces.archiveSession(sessionId)`（官方归档真源唯一写路径）
      // 本层**不新增**任何会话状态/归档真源/缓存：调用成功 → 官方 store 自行推送 → 列表刷新。
      // 失败一律**抛出**（不吞、不假装成功），由 UI 如实呈现。
      // -----------------------------------------------------------------------
      rename: async (sessionId, title) => {
        const svc = sessionsOf();
        const session = typeof svc?.binding === "function" ? svc.binding(sessionId)?.session : void 0;
        if (session === void 0 || typeof session.rename !== "function") {
          throw new Error(`unknown session "${sessionId}"`);
        }
        const result = await session.rename(title);
        if (result === void 0 || result.ok !== true) {
          throw new Error(result?.error?.message ?? "\u5B98\u65B9\u4F1A\u8BDD\u91CD\u547D\u540D\u672A\u8FD4\u56DE\u6210\u529F\u7ED3\u679C");
        }
      },
      fork: async (sessionId) => {
        const svc = sessionsOf();
        if (typeof svc?.fork !== "function") throw new Error("\u5B98\u65B9 sessions.fork \u4E0D\u53EF\u7528");
        const child = await svc.fork({ sessionId, increaseTitle: true });
        const childId = typeof child === "string" ? child : child !== null && typeof child === "object" ? child.id : void 0;
        if (typeof childId !== "string" || childId === "") {
          throw new Error("\u5B98\u65B9 sessions.fork \u672A\u8FD4\u56DE\u5B50\u4F1A\u8BDD id");
        }
        return childId;
      },
      /**
       * 归档会话 = **写动作**（官方 `workspaces.archiveSession`）。
       * 命名注意：上面那个 `archive()` 是**只读真源读取**（`workspaces.list.archivedSessionIds`），
       * 两者一字之差但语义相反（读真值 vs 写动作），故此处沿用官方方法名 `archiveSession` 以免混淆。
       * 归档 ≠ 删除：会话本体保留，恢复入口仍在官方侧。
       */
      archiveSession: async (sessionId) => {
        const svc = typeof ctx.get === "function" ? ctx.get("workspaces") : void 0;
        if (typeof svc?.archiveSession !== "function") throw new Error("\u5B98\u65B9 workspaces.archiveSession \u4E0D\u53EF\u7528");
        await svc.archiveSession(sessionId);
      }
    };
  };
  const betterSidebarOf = () => {
    try {
      return typeof ctx.get === "function" ? ctx.get("betterSidebar") : void 0;
    } catch {
      return void 0;
    }
  };
  const setPersonalAttr = (on) => {
    try {
      const root = typeof document !== "undefined" ? document.documentElement : void 0;
      if (!root) return;
      if (on) root.setAttribute("data-dps-personal", "1");
      else root.removeAttribute("data-dps-personal");
    } catch {
    }
  };
  const unmount = () => {
    setPersonalAttr(false);
    if (mounted) {
      let removed = false;
      if (handle) {
        try {
          handle();
          removed = true;
        } catch {
        }
      }
      if (!removed) reloadFallback();
    }
    handle = null;
    mounted = false;
  };
  const mount = () => {
    if (mounted) return;
    setPersonalAttr(true);
    const sessions = sessionsOf();
    try {
      const cleanup = slots.register(
        {
          name: "sidebar.workspaces",
          id: "personal-sidebar-workspaces",
          // Shadow the built-in ui-workspace browser (default priority 0).
          priority: -1e3,
          inject: () => ({
            openSession: (sessionId) => {
              try {
                sessions?.open?.(sessionId);
              } catch {
              }
            },
            switchOfficial: () => {
              personalMode.set("official");
            },
            /** §5/§6：Sidebar 会话列表的 official Session 只读投影 + 官方打开路径。 */
            conversations: conversationsOf(),
            betterSidebar: betterSidebarOf()
          })
        },
        PersonalBrowser
      );
      handle = typeof cleanup === "function" ? cleanup : null;
      mounted = handle !== null;
    } catch (error) {
      console.warn("[dsh-personal-sidebar] occupant registration failed:", error);
      handle = null;
      setPersonalAttr(false);
    }
  };
  let brandHandle = null;
  let brandMounted = false;
  const unmountBrand = () => {
    if (!brandMounted) return;
    try {
      brandHandle?.();
    } catch {
    }
    brandHandle = null;
    brandMounted = false;
  };
  const mountBrand = () => {
    if (brandMounted) return;
    try {
      const cleanup = slots.register(
        { name: "sidebar.brand.name", id: "personal-sidebar-brand", priority: -1e3 },
        PersonalBrandName
      );
      brandHandle = typeof cleanup === "function" ? cleanup : null;
      brandMounted = brandHandle !== null;
    } catch (error) {
      console.warn("[dsh-personal-sidebar] brand seat registration failed:", error);
      brandHandle = null;
      brandMounted = false;
    }
  };
  const syncBrand = () => {
    if (personalMode.get() === "personal") mountBrand();
    else unmountBrand();
  };
  const brandLife = () => {
    syncBrand();
    const off = personalMode.subscribe(syncBrand);
    return () => {
      off();
      unmountBrand();
    };
  };
  const sync = () => {
    if (personalMode.get() === "personal") mount();
    else unmount();
  };
  const injectStyles = () => {
    const el = document.createElement("style");
    el.setAttribute("data-dsh-plugin", "dsh-personal-sidebar");
    el.textContent = CSS;
    document.head.appendChild(el);
    return () => {
      el.remove();
    };
  };
  const errors = [];
  const step = (label, fn) => {
    try {
      return fn();
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      errors.push(`${label}: ${msg}`);
      console.warn("[dsh-personal-sidebar] step failed:", label, error);
      return void 0;
    }
  };
  step("styles", () => {
    if (typeof ctx.effect === "function") return ctx.effect(injectStyles, "dps: styles");
    return injectStyles();
  });
  const seatLife = () => {
    sync();
    const off = personalMode.subscribe(sync);
    return () => {
      off();
      unmount();
    };
  };
  const injectSeat = (name, make, label) => {
    step(label, () => {
      if (typeof ctx.effect === "function") {
        return ctx.effect(() => slots.inject(name, make, label), label + " lifecycle");
      }
      return slots.inject(name, make, label);
    });
  };
  injectSeat("sidebar.workspaces", seatLife, "dps: occupant");
  injectSeat("sidebar.brand.name", brandLife, "dps: brand");
  injectSeat(
    "sidebar.footer.action",
    () => slots.register(
      { name: "sidebar.footer.action", id: "personal-sidebar-toggle", order: 1 },
      (props) => ModeToggle(props)
    ),
    "dps: footer"
  );
  if (errors.length > 0) {
    badge("dps\u2717 " + errors[0].slice(0, 42));
  } else {
    badge("dps:" + DPS_VERSION + " applied");
  }
  return errors.length === 0;
}
return module.exports; } });
