window.__ModuleLoader__.load({ id: 'dsh-personal-sidebar', factory: (require) => { var module = { exports: {} }; var exports = module.exports;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/workstation/personal-sidebar/src/client/index.tsx
var index_exports = {};
__export(index_exports, {
  apply: () => apply,
  inject: () => inject
});
module.exports = __toCommonJS(index_exports);

// src/workstation/personal-workspace/src/client/layering.ts
var LAYERS = {
  /** Official AppFrame in-frame overlay seat (shell.overlay). */
  frameOverlay: 20,
  /** better-sidebar body-level panel host (all Aux panels live inside it). */
  auxHost: 25,
  /** better-sidebar right/bottom workbench panel. */
  auxPanel: 40,
  /** better-sidebar free-floating window. */
  auxFloat: 42,
  /** better-sidebar top-right "＋" toggle cluster. */
  auxToggle: 45,
  /** better-sidebar boundary error banner. */
  auxBoundary: 50,
  /** better-sidebar text-selection popup. */
  auxSelection: 60,
  /**
   * hud status bar & Inspector live between the Aux selection popup (60) and
   * the official Modal (1000): they are always-on chrome that must stay above
   * the workbench panels yet never cover a modal backdrop / toast.
   */
  hudStatus: 450,
  hudInspector: 550,
  /** Official primitives band (body-portaled when they need to escape). */
  popover: 100,
  /**
   * personal-sidebar 的浮动 tabbar（`.dps-tabbar[data-dps-overlay-open]`，浮层打开时置顶）：
   * 必须盖住官方 popover 带（100）与我方 Aux 面板，但**不得**盖住 hud status bar（450）
   * 与官方 Modal（1000）。130 = 逐值保留 2026-09-14 的原值（零行为变化；原为魔数，
   * 违反 smoke-overlay-layering 的「一律 LAYERS.xxx」守则）。
   */
  sidebarTabbarOverlay: 130,
  modal: 1e3,
  toast: 1100
};

// src/workstation/personal-sidebar/src/client/styles.ts
var CSS = String.raw`
/* PHASE D：统一 Aux Tool Registry（右侧/底部同一注册表 + 同一能力元数据） */
.dps-root {
  height: 100%;
  display: flex;
  flex-direction: column;
  min-height: 0;
  user-select: none;
  /* 2026-09-14 真机反馈（「图标什么的没有对齐」）：官方侧栏区域容器只吃左侧内边距
     （regionArea padding-left 4px），内容盒右边界比列根内容盒外扩 12px。这里把右侧
     收回来，使本插件所有行与第三方「任务看板」行落在**同一条内容盒**上
     （x=12 → 右边界 268，宽 256）。 */
  padding-right: 12px;
  /* 兜底滚动：窗口压矮时整栏仍可滚（会话列表自身另有滚动，见 .dps-conv-list）。 */
  overflow-y: auto;
  overflow-x: hidden;
}
.dps-nav {
  flex: 0 0 auto;
  display: flex;
  flex-direction: column;
  gap: 2px;
  /* 左右内边距归零：行的横向基准由 .dps-root 的 padding-right 决定，
     保证与第三方「任务看板」行逐像素同级（此前左 8px 让它整体右移 8px）。 */
  padding: 6px 0 4px;
}
.dps-cta {
  display: flex; align-items: center; gap: 7px;
  width: 100%; border: none; border-radius: 8px;
  padding: 7px 9px; cursor: pointer; text-align: left;
  font: var(--dsw-font-xxs-strong-12, 600 12px);
  color: var(--dsw-alias-label-primary);
  background: var(--dsw-alias-interactive-bg-active, var(--dsw-alias-interactive-bg-hover));
}
.dps-cta:hover { filter: brightness(1.08); }
.dps-cta svg { color: var(--dsw-alias-brand-primary, var(--dsw-alias-label-primary)); }
/* 2026-09-10 真机反馈（「这些字和图标不是一个等级」）：主导航行行与既有第三方
   「任务看板」入口**逐项同级**——高 36px / 左右内边距 10px / 圆角 8px / 字号 13px /
   导航字形 18px / gap 8px / 正文色 label-secondary，hover 升 label-primary，
   选中态加粗 600 + interactive-bg-active。数值直接对齐 dsh-client-ui-task-board
   的 .entry（同一侧栏里的「同一条导航」就应该是同一个等级）。 */
.dps-nav-item {
  display: flex; align-items: center; gap: 8px;
  width: 100%; height: 36px;
  border: none; border-radius: 8px; background: transparent;
  padding: 0 10px; cursor: pointer; text-align: left;
  font-size: 13px;
  color: var(--dsw-alias-label-secondary);
}
.dps-nav-item:hover { background: var(--dsw-alias-interactive-bg-hover); color: var(--dsw-alias-label-primary); }
.dps-nav-item[data-active="true"] {
  background: var(--dsw-alias-interactive-bg-active, var(--dsw-alias-interactive-bg-hover));
  color: var(--dsw-alias-label-primary);
  font-weight: 600;
}
/* 2026-09-14 真机反馈（「图标什么的没有对齐」）：第三方 task-board 行的字形盒是 24px
   （18px 图标 + 左右各 3px），文字因此从 x=54 起；本插件原本按 18px 字形盒排版，文字
   从 x=48 起 —— 两行文字差 6px。这里给图标补 3px 横向外边距，字形盒同为 24px。 */
.dps-nav-item svg { flex: 0 0 auto; width: 18px; height: 18px; margin: 0 3px; }

/* =========================================================================
   V1.2-J（J1 收起/展开 + J2 拖动排序）—— 只加规则，不动上面任何既有声明。
   -------------------------------------------------------------------------
   J1 为什么用「属性 + CSS display:none」而不是条件卸载 / slice(0,4)：
     核验套件（scripts/smoke-nav-integration.mjs）用 querySelectorAll('[data-nav]')
     **数**导航行并逐字断言 8 行 id 与顺序 —— 条件卸载会让那些断言直接 FAIL，
     也会让「顺序真源」失去可核对的行集合。因此收起 = 行仍在 DOM、data-nav 仍在，
     只多一个 data-nav-hidden="true" 与一条 display:none。
     真机视觉结论（"收起后只有 4 行"）由真机观察，见新套件的诚实边界声明。
   J2 拖动：原生 HTML5 DnD（draggable + dragover + drop + dragend），零第三方依赖。
     落点提示只用一条不改变行高的 2px 内阴影（避免 hover/拖动时行抖动）。 */
.dps-nav-item[data-nav-hidden="true"] { display: none; }
.dps-nav-item[draggable="true"] { cursor: grab; }
.dps-nav-item[data-nav-dragging="true"] { opacity: .55; cursor: grabbing; }
.dps-nav-item[data-nav-drop="before"] { box-shadow: inset 0 2px 0 0 var(--dsw-alias-brand-primary, #4d6bfe); }
.dps-nav-item[data-nav-drop="after"] { box-shadow: inset 0 -2px 0 0 var(--dsw-alias-brand-primary, #4d6bfe); }
/* 收起/展开 + 「恢复默认顺序」控件行：比导航行矮一档（26px），颜色走三级标签色，
   与列表本身区分开（它不是导航行，也不带 data-nav）。 */
.dps-nav-ctl { display: flex; align-items: center; gap: 6px; padding: 2px 0 2px; }
.dps-nav-ctl-btn {
  display: inline-flex; align-items: center; justify-content: center;
  height: 26px; padding: 0 10px;
  border: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.24));
  border-radius: 8px; background: transparent; cursor: pointer;
  font-size: 12px; color: var(--dsw-alias-label-tertiary, #8f8f99);
}
.dps-nav-ctl-btn:hover { background: var(--dsw-alias-interactive-bg-hover); color: var(--dsw-alias-label-primary); }
/* 领养 ThoughtDAG 的「对话 / 思维图」开关（见 thoughtdagSwitch.ts）：容器插在第三方
   「任务看板」行之前，开关节点被搬进来。下列规则的特异性高于 ThoughtDAG 自己注入的
   .dsh-td-switch（0,1,0）与 .dsh-td-switch button（0,1,1），因此不依赖样式注入顺序；
   定位相关的 4 条另加 !important，防它后续版本改用 !important 声明。 */
.dps-tabbar { flex: 0 0 auto; padding: 6px 0 2px; }
.dps-tabbar .dsh-td-switch {
  position: static !important;
  top: auto !important;
  left: auto !important;
  transform: none !important;
  display: flex;
  gap: 2px;
  width: 100%;
  box-sizing: border-box;
  margin: 0;
  padding: 2px;
  border: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.28));
  border-radius: 8px;
  background: var(--dsw-alias-bg-layer-2, rgba(128,128,128,.08));
}
.dps-tabbar .dsh-td-switch button {
  flex: 1 1 0;
  height: 30px;
  border: none;
  border-radius: 6px;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #c8c8d0);
  font: var(--dsw-font-xxs-12, 12px);
  cursor: pointer;
}
.dps-tabbar .dsh-td-switch button:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); }
.dps-tabbar .dsh-td-switch button.active {
  background: var(--dsw-alias-interactive-bg-active, rgba(120,150,255,.16));
  color: var(--dsw-alias-label-primary, #e8e8ec);
  font-weight: 600;
}
/* 思维图全屏覆盖层打开时：领养条被搬到 body 顶层做浮层，压在覆盖层的 z-index:100 之上，
   并显示显式「返回对话」按钮。没有这条规则，覆盖层会把侧栏里的开关整片盖住，
   用户就困在思维图里出不来（2026-09-14 真机反馈）。配色沿用第三方开关原本的浅色，
   因为覆盖层底色是第三方硬编码的浅色 (#faf9f7)，不能跟随应用主题变深。 */
.dps-tabbar[data-dps-overlay-open] {
  position: fixed;
  top: 12px;
  left: 50%;
  transform: translateX(-50%);
  z-index: ${LAYERS.sidebarTabbarOverlay};
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 0;
  flex: 0 0 auto;
}
.dps-tabbar[data-dps-overlay-open] .dsh-td-switch {
  width: auto;
  padding: 3px;
  border-color: #d1d5db;
  border-radius: 999px;
  background: rgba(255,255,255,.96);
}
.dps-tabbar[data-dps-overlay-open] .dsh-td-switch button {
  flex: 0 0 auto;
  height: 28px;
  padding: 0 11px;
  border-radius: 999px;
  color: #6b7280;
}
.dps-tabbar[data-dps-overlay-open] .dsh-td-switch button.active {
  background: #111827;
  color: #fff;
}
.dps-td-back {
  height: 30px;
  padding: 0 14px;
  border: 1px solid #d1d5db;
  border-radius: 999px;
  background: rgba(255,255,255,.96);
  color: #111827;
  font: 600 12px Inter, system-ui, sans-serif;
  cursor: pointer;
  white-space: nowrap;
  box-shadow: 0 1px 4px rgba(0,0,0,.12);
}
.dps-td-back:hover { background: #111827; color: #fff; }
.dps-nav-foot { border-top: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.2)); margin-top: 4px; padding-top: 4px; }
.dps-scroll {
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 2px 6px 8px;
}
.dps-h { font: var(--dsw-font-s-strong-14, 600 14px); margin: 2px 4px 6px; color: var(--dsw-alias-label-primary); }
.dps-sub { font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary); margin: 0 4px 8px; }
.dps-row {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  border: none;
  border-radius: 6px;
  background: transparent;
  text-align: left;
  padding: 5px 6px;
  cursor: pointer;
  color: var(--dsw-alias-label-primary);
}
.dps-row:hover { background: var(--dsw-alias-interactive-bg-hover); }
.dps-row[data-active="true"] { background: var(--dsw-alias-interactive-bg-active, var(--dsw-alias-interactive-bg-hover)); }
.dps-glyph {
  flex: 0 0 22px;
  width: 22px;
  height: 22px;
  border-radius: 6px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
  color: var(--dsw-alias-label-secondary);
  background: var(--dsw-alias-bg-layer-2);
  border: 1px solid var(--dsw-alias-border-l1, transparent);
}
.dps-row-text { flex: 1 1 auto; min-width: 0; }
.dps-row-name { display: block; font: var(--dsw-font-xxs-12, 12px); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.dps-row-desc { display: block; font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 1px; }
.dps-chev { flex: 0 0 auto; font-size: 10px; color: var(--dsw-alias-label-dimmed); }
.dps-detail {
  margin: 0 6px 8px 36px;
  padding: 6px 9px;
  border: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.2));
  border-radius: 6px;
  font: var(--dsw-font-xxs-12, 12px);
  color: var(--dsw-alias-label-secondary);
  background: color-mix(in srgb, var(--dsw-alias-bg-layer-2, transparent) 45%, transparent);
}
.dps-detail-line { margin-bottom: 4px; line-height: 1.5; }
.dps-chip-row { display: flex; flex-wrap: wrap; gap: 4px; margin: 4px 0; }
.dps-chip {
  border: 1px solid var(--dsw-alias-border-l1, transparent);
  border-radius: 4px;
  padding: 0 6px;
  font: var(--dsw-font-xxxs-11, 11px);
  color: var(--dsw-alias-label-tertiary);
}
.dps-hint { margin-top: 6px; font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-dimmed); line-height: 1.5; }
.dps-more-hint { padding: 2px 8px 4px; font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-dimmed); }
.dps-session-row .dps-dot {
  width: 6px; height: 6px; border-radius: 50%; flex: 0 0 auto;
  background: transparent;
}
.dps-session-row .dps-dot[data-running="true"] { background: var(--dsw-alias-state-business-primary, #3b82f6); }
.dps-time { font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-dimmed); flex: 0 0 auto; }
.dps-empty { padding: 10px 8px; font: var(--dsw-font-xxs-12, 12px); color: var(--dsw-alias-label-tertiary); line-height: 1.5; }
.dps-link {
  display: flex; align-items: center; gap: 6px;
  width: 100%; border: none; border-radius: 6px; background: transparent;
  padding: 6px; cursor: pointer; text-align: left;
  font: var(--dsw-font-xxs-12, 12px); color: var(--dsw-alias-label-secondary);
}
.dps-link:hover { background: var(--dsw-alias-interactive-bg-hover); color: var(--dsw-alias-label-primary); }
.dps-link-strong { color: var(--dsw-alias-brand-primary, var(--dsw-alias-label-primary)); }
.dps-rail {
  height: 100%; display: flex; flex-direction: column; align-items: center;
  gap: 4px; padding-top: 8px;
}
.dps-rail-btn {
  /* 窄栏同样与第三方「任务看板」收起态入口同级：36×36、图标 18px。 */
  width: 36px; height: 36px; border: none; border-radius: 8px; background: transparent;
  cursor: pointer; display: inline-flex; align-items: center; justify-content: center;
  font-size: 13px;
  color: var(--dsw-alias-label-secondary);
}
.dps-rail-btn:hover { background: var(--dsw-alias-interactive-bg-hover); color: var(--dsw-alias-label-primary); }
.dps-rail-btn svg { width: 18px; height: 18px; }
.dps-rail-btn[data-active="true"] { background: var(--dsw-alias-interactive-bg-active, var(--dsw-alias-interactive-bg-hover)); color: var(--dsw-alias-label-primary); }
.dps-foot-toggle {
  display: inline-flex; align-items: center; gap: 5px;
  border: none; background: transparent; border-radius: 6px;
  padding: 3px 6px; cursor: pointer;
  font: var(--dsw-font-xxs-12, 12px);
  color: var(--dsw-alias-label-secondary);
}
.dps-foot-toggle:hover { background: var(--dsw-alias-interactive-bg-hover); color: var(--dsw-alias-label-primary); }
.dps-foot-toggle[data-on="true"] { color: var(--dsw-alias-brand-primary, var(--dsw-alias-label-primary)); }
/* 2026-09-10 清理：此处原本残留一段**没有选择器的裸声明块**（PHASE N 删除会话头
   .dps-head-toggle 时只删掉选择器行，留下 declarations + 右花括号）。浏览器按 CSS
   错误恢复规则会丢弃它，但它是实打实的无效样式表内容（也会让严格 CSS 解析器整张表
   解析失败）——已整段删除。 */

/* =========================================================================
   E4-FIX-IA-2 · IA2-2 — 一级导航面板模型（Mini Mission Control 已删除；旧
   「官方会话浏览」导航行与左栏「辅助工具」列表亦已按真机反馈移除）
   ========================================================================= */
.dps-mm {
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  display: flex;
  flex-direction: column;
  gap: 9px;
  border-top: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.2));
  margin-top: 6px;
  padding: 8px 8px 12px;
}
.dps-mm-h {
  font: var(--dsw-font-xxxs-strong-11, 600 11px);
  letter-spacing: .06em;
  color: var(--dsw-alias-label-tertiary, #9a9aa5);
}
.dps-mm-sec { display: flex; flex-direction: column; gap: 1px; }
.dps-mm-head { display: flex; align-items: center; gap: 5px; color: var(--dsw-alias-label-secondary, #c8c8d0); font: var(--dsw-font-xxxs-11, 11px); padding: 0 2px; }
.dps-mm-count {
  font: var(--dsw-font-xxxs-11, 11px);
  color: var(--dsw-alias-label-tertiary, #9a9aa5);
  border: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.25));
  border-radius: 10px;
  padding: 0 5px;
}
.dps-mm-empty { font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-dimmed, #8f8f99); padding: 2px 2px 2px 12px; }
.dps-mm-row {
  display: flex; align-items: center; gap: 7px; min-width: 0;
  border: none; background: transparent; border-radius: 5px;
  padding: 3px 6px; text-align: left; cursor: pointer;
  color: var(--dsw-alias-label-primary, #e8e8ec); font: var(--dsw-font-xxs-12, 12px);
}
.dps-mm-row:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); }
.dps-mm-label { flex: 1 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dps-mm-dot { width: 6px; height: 6px; border-radius: 50%; flex: 0 0 auto; background: transparent; }
.dps-mm-dot.run { background: var(--dsw-alias-state-business-primary, #3b82f6); }
.dps-mm-dot.attn { background: #e8b64c; }
.dps-mm-dot.ok { background: #37c871; }
.dps-mm-dot.idle { background: var(--dsw-alias-label-dimmed, #6a6a74); }
.dps-mm-more, .dps-mm-all {
  border: none; background: transparent; cursor: pointer; text-align: left;
  font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary, #9a9aa5);
  padding: 2px 6px;
}
.dps-mm-more:hover, .dps-mm-all:hover { color: var(--dsw-alias-label-primary, #e8e8ec); }
.dps-mm-all { align-self: flex-start; padding-left: 2px; }
.dps-mm-notice {
  font: var(--dsw-font-xxxs-11, 11px); line-height: 1.5;
  color: #e0b96a; border: 1px dashed rgba(240,180,60,.4); border-radius: 6px;
  padding: 4px 8px;
}

/* ---------------------------------------------------------------------------
   E4-FIX-IA-2 · SIDEBAR CONVERSATION LIST（E4-FIX-IA-2 收口）
   传统 AI Chat Sidebar 风格的「最近会话」：标题单行 + 右对齐相对时间 + hover/selected。
   设计语言沿用官方 --dsw-* token（与 Personal 其他区域一致），不引入新视觉体系。 */
/* 2026-09-14 真机反馈（「会话列表展开之后没法上下滚动，展开后是死的」）：原因是整栏
   的滚动链在宿主侧被切断（祖先区域容器 overflow-y: hidden），而本列表自身不是滚动
   容器、又没有最小高度，展开后被压成 0 高。修法（已在真机逐档视口实测）：
   · 列表自身 = 滚动容器（flex 内可伸缩 + min-height 120px）；
   · .dps-root 保留 overflow-y: auto 作为外层兜底（窗口很矮时列表滚到底后还能继续滚）。
   实测：矮视口（620px）列表内滚 269/120、外层兜底 157，末行可达。 */
.dps-conv { flex: 1 1 auto; min-height: 0; display: flex; flex-direction: column; gap: 2px; margin-top: 10px; padding-top: 8px; border-top: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.18)); }
.dps-conv-h { display: flex; align-items: center; gap: 6px; padding: 0 6px 4px; font: var(--dsw-font-xxxs-strong-11, 600 11px); letter-spacing: .04em; color: var(--dsw-alias-label-tertiary, #9a9aa5); }
.dps-conv-n { font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary, #9a9aa5); background: var(--dsw-alias-bg-layer-2, rgba(128,128,128,.12)); border-radius: 999px; padding: 0 6px; }
/* V1.2-C：后台任务会话开关（次要动作 —— 与分组标题同色阶，不抢会话行）。 */
.dps-conv-toggle { margin-left: auto; border: 0; background: transparent; cursor: pointer; padding: 0 2px; font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary, #9a9aa5); text-decoration: underline; text-underline-offset: 2px; }
.dps-conv-toggle:hover { color: var(--dsw-alias-label-secondary, #c8c8d0); }
.dps-conv-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 1px; flex: 1 1 auto; min-height: 120px; overflow-y: auto; overflow-x: hidden; }
.dps-conv-row {
  display: flex; align-items: center; gap: 8px; width: 100%;
  border: none; background: transparent; cursor: pointer; text-align: left;
  border-radius: 7px; padding: 4px 6px; color: inherit; font: inherit;
}
.dps-conv-row:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); }
.dps-conv-row[data-conv-active="true"] { background: var(--dsw-alias-interactive-bg-active, rgba(120,150,255,.16)); }
.dps-conv-row[data-conv-active="true"] .dps-conv-title { color: var(--dsw-alias-label-primary, #e8e8ec); font-weight: 600; }
.dps-conv-title { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font: var(--dsw-font-xxs-12, 12px); color: var(--dsw-alias-label-secondary, #c8c8d0); display: flex; align-items: center; gap: 5px; }
.dps-conv-row:hover .dps-conv-title { color: var(--dsw-alias-label-primary, #e8e8ec); }
/* 会话行状态点（2026-09-14 用户收口）：运作 = 旋转圈 / 需要我审批或介入 = 黄色闪烁 /
   刚完成且未查看 = 绿点（点开即消失）/ **已结束的历史会话 = 不画点**。
   真源 = 官方 sessions.list.running + 官方 uiSession.pendingInteractions（**会话级**真相，
   不是 Task 字段）。容器同尺寸（10px）→ 行内文字不跳动；圆点仍 6px，保持既有观感。 */
.dps-conv-state { flex: none; width: 10px; height: 10px; border-radius: 50%; display: inline-block; }
.dps-conv-run { border: 1.5px solid color-mix(in srgb, var(--dsw-alias-label-tertiary, #9a9aa5) 35%, transparent); border-top-color: var(--dsw-alias-brand-primary, #5b8cff); animation: dps-conv-spin .8s linear infinite; }
.dps-conv-wait { background: var(--dsw-alias-state-warn-primary, #e8b64c); animation: dps-conv-blink 1s ease-in-out infinite; }
.dps-conv-done { position: relative; }
.dps-conv-done:after { content: ''; position: absolute; inset: 2px; border-radius: 50%; background: var(--dsw-alias-state-ok-primary, #3ba272); }
/* V1.2-I（G9/G10）：被 Quick Stop 中断且未查看 = **紫点**（UNSEEN INTERRUPTED INDICATOR）。
   语义刻意与绿点分开：绿点 = 刚完成（正向结果）；紫点 = 用户主动暂停、后续可能继续 ——
   **不是** failed / cancelled / completed / error。无动画（G10：不是永久装饰，打开即消失）。
   颜色走 --dps-conv-interrupted：官方 token 表里**未找到**紫色语义 token（I-C 侦查结论），
   故给自有变量 + 兜底色；用户若指定官方 token，只需覆盖变量，不必改这张表。 */
.dps-conv-int { position: relative; }
.dps-conv-int:after { content: ''; position: absolute; inset: 2px; border-radius: 50%; background: var(--dps-conv-interrupted, #a06bff); }
@keyframes dps-conv-spin { to { transform: rotate(360deg); } }
@keyframes dps-conv-blink { 0%, 100% { opacity: 1; } 50% { opacity: .25; } }
@media (prefers-reduced-motion: reduce) { .dps-conv-run, .dps-conv-wait { animation: none; } }
.dps-conv-time { flex: none; font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary, #9a9aa5); font-variant-numeric: tabular-nums; white-space: nowrap; }
.dps-conv-more { border: none; background: transparent; cursor: pointer; text-align: left; padding: 3px 6px; border-radius: 6px; font: var(--dsw-font-xxxs-11, 11px); color: var(--dsw-alias-label-tertiary, #9a9aa5); }
.dps-conv-more:hover { color: var(--dsw-alias-label-primary, #e8e8ec); background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); }
.dps-conv-empty { padding: 4px 6px 6px; font: var(--dsw-font-xxxs-11, 11px); line-height: 1.6; color: var(--dsw-alias-label-dimmed, #8f8f99); display: flex; flex-direction: column; gap: 4px; align-items: flex-start; }
.dps-conv-cta { border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,.35)); background: transparent; color: var(--dsw-alias-label-secondary, #c8c8d0); border-radius: 6px; padding: 2px 8px; cursor: pointer; font: var(--dsw-font-xxxs-11, 11px); }
.dps-conv-cta:hover { color: var(--dsw-alias-label-primary, #e8e8ec); border-color: var(--dsw-alias-brand-primary, rgba(120,150,255,.6)); }
.dps-conv-note { padding: 2px 6px; font: var(--dsw-font-xxxs-11, 11px); line-height: 1.5; color: var(--dsw-alias-label-tertiary, #9a9aa5); }

/* ---------------------------------------------------------------------------
   E4-FINAL · 会话行的官方 Session 菜单（重命名 / 分叉会话 / 归档会话）
   官方同款行为（ui-workspace Rows.module.css）：行 hover 或菜单展开时，
   右侧时间让位给「…」按钮；菜单本体是官方 Menu（portal 到 body，不受侧栏裁剪）。
   这里只有**装载位置与显现时机**的版面规则，没有任何菜单/动作的第二套实现。 */
.dps-conv-item { position: relative; display: block; }
.dps-conv-actions { position: absolute; inset-inline-end: 4px; top: 50%; transform: translateY(-50%); display: none; align-items: center; }
.dps-conv-item:hover .dps-conv-actions,
.dps-conv-item[data-conv-menu-open="true"] .dps-conv-actions { display: inline-flex; }
/* 官方行为：hover / 菜单展开时隐藏时间列，避免与「…」重叠（官方 .sessionRow:hover .time{display:none}）。 */
.dps-conv-item:hover .dps-conv-time,
.dps-conv-item[data-conv-menu-open="true"] .dps-conv-time { display: none; }
.dps-conv-item:hover .dps-conv-row,
.dps-conv-item[data-conv-menu-open="true"] .dps-conv-row { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); }
/* 官方 iconButton 同款：16×16、无边框、tertiary → hover primary。 */
.dps-conv-menu-btn {
  display: inline-flex; align-items: center; justify-content: center;
  width: 16px; height: 16px; padding: 0; flex: none;
  border: none; border-radius: 4px; background: transparent; cursor: pointer;
  color: var(--dsw-alias-label-tertiary, #9a9aa5);
}
.dps-conv-menu-btn:hover { color: var(--dsw-alias-label-primary, #e8e8ec); background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); }
/* 官方 renameInput 同款输入框（对话框内）。 */
.dps-conv-rename-input {
  width: 100%; box-sizing: border-box; min-width: 0;
  border: .5px solid var(--dsw-alias-border-l4, rgba(128,128,128,.4));
  background: var(--dsw-alias-button-elevated-fill, rgba(128,128,128,.08));
  color: inherit; border-radius: 4px; outline: none; padding: 4px 6px;
  font: var(--dsw-font-xxs-12, 12px); line-height: 20px;
}
.dps-conv-rename-input:disabled { opacity: .6; }
.dps-conv-rename-error { margin-top: 8px; font-size: 12px; line-height: 18px; color: var(--dsw-alias-state-error-primary, #e5646a); }

/* ⓐ「加入项目」对话框（2026-09-17 用户需求）。风格贴官方对话框：无卡片、无渐变、
   官方 label/border token；列表项用 radiogroup 语义，选中态用官方 interactive-bg。 */
.dps-pp-sub { font-size: 12px; line-height: 18px; color: var(--dsw-alias-label-secondary, #b6b6c0);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.dps-pp-hint { margin-top: 2px; margin-bottom: 8px; font-size: 12px; line-height: 18px;
  color: var(--dsw-alias-label-tertiary, #9a9aa5); }
.dps-pp-list { max-height: 264px; overflow-y: auto; display: flex; flex-direction: column; gap: 2px;
  border: .5px solid var(--dsw-alias-border-l4, rgba(128,128,128,.4)); border-radius: 6px; padding: 4px; }
.dps-pp-item { display: flex; align-items: center; gap: 8px; width: 100%; box-sizing: border-box;
  padding: 5px 7px; border: none; border-radius: 4px; background: transparent; cursor: pointer;
  color: inherit; text-align: left; font: inherit; }
.dps-pp-item:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12)); }
.dps-pp-item.is-picked { background: var(--dsw-alias-interactive-bg-active, rgba(128,128,128,.18)); }
.dps-pp-item.is-current .dps-pp-name { font-weight: 600; }
.dps-pp-glyph { flex: none; width: 20px; height: 20px; display: inline-flex; align-items: center;
  justify-content: center; font-size: 13px; line-height: 20px; }
.dps-pp-name { flex: 1; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  font-size: 13px; line-height: 20px; }
.dps-pp-badge { flex: none; font-size: 11px; line-height: 16px; padding: 0 5px; border-radius: 3px;
  color: var(--dsw-alias-label-secondary, #b6b6c0);
  background: var(--dsw-alias-button-elevated-fill, rgba(128,128,128,.08)); }
.dps-pp-empty { font-size: 12px; line-height: 18px; color: var(--dsw-alias-label-tertiary, #9a9aa5); }
.dps-pp-error { margin-top: 8px; font-size: 12px; line-height: 18px; color: var(--dsw-alias-state-error-primary, #e5646a); }

/* =========================================================================
   品牌头部（2026-09-10 用户真机反馈）
   左栏顶部原本空着的官方品牌行（.logoRow → sidebar.brand.mark + sidebar.brand.name）
   现在承载「官方鲸鱼 + Personal Harness + Personal Workspace 副标题」。
   · 本插件只占官方 sidebar.brand.name 单槽；鲸鱼仍由官方 mark occupant 绘制
     （零图标复制、零 require、零外部图片）。
   · 风格贴官方左栏：白底/官方 token 文字色、无渐变、无卡片、无横幅。
   · 高度 72–84px（用户要求）；窄栏/收起回到官方 36px 行高，只留图标不溢出。
   ========================================================================= */
.dps-brand { display: inline-flex; flex-direction: column; justify-content: center; align-items: flex-start; gap: 3px; min-width: 0; max-width: 100%; }
.dps-brand-title { font-size: 14px; font-weight: 600; line-height: 18px; letter-spacing: 0; color: var(--dsw-alias-label-primary, inherit); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
.dps-brand-sub { font-size: 11px; font-weight: 400; line-height: 14px; letter-spacing: 0; color: var(--dsw-alias-label-tertiary, #8f8f99); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
html[data-dps-personal] [class*="_logoRow"] { height: 76px; }
html[data-dps-personal] [class*="_collapsed"] [class*="_logoRow"] { height: 36px; }
html[data-dps-personal] [class*="_brandIdentity"] { align-items: center; gap: 10px; height: auto; }
html[data-dps-personal] [class*="_brandName"] { height: auto; font-size: 14px; font-weight: 400; letter-spacing: 0; gap: 0; }
/* 品牌头部是「头部」，不是入口：官方 brand 按钮的中性化由 brand.tsx 在挂载时施加
   （鼠标/键盘/读屏三面一致）；此处再加一层 CSS 兜底，避免重渲染间隙可点。 */
html[data-dps-personal] [class*="_logoRow"] [class*="_brand"] { pointer-events: none; cursor: default; }

/* IA2-2 §2（修正）：personal 模式只隐藏官方**独立**的「＋ 新会话」大按钮。
   注意：官方 brand 按钮的 aria-label 同样是「新建会话」—— 早前按 aria-label 通杀会连品牌行
   一起隐藏（那正是左栏顶部的空白区），且与 brand.tsx 改写 aria-label 后行为不稳定。
   现在改为只按 css-module class 精确隐藏独立按钮；品牌行由我方占用并中性化。 */
html[data-dps-personal] [class*="_newSession"] { display: none !important; }
`;

// src/workstation/personal-sidebar/src/client/controller.ts
var import_react = require("react");
var KEY = "dsh.personalSidebar.mode";
var KEY_SET = "dsh.personalSidebar.userSet";
var DEFAULT_MODE = "personal";
function readMode() {
  try {
    const chosen = window.localStorage.getItem(KEY_SET) === "1";
    if (chosen) return window.localStorage.getItem(KEY) === "personal" ? "personal" : "official";
    return DEFAULT_MODE;
  } catch {
    return DEFAULT_MODE;
  }
}
var mode = readMode();
var subs = /* @__PURE__ */ new Set();
var personalMode = {
  get() {
    return mode;
  },
  set(next) {
    if (mode === next) return;
    mode = next;
    try {
      window.localStorage.setItem(KEY_SET, "1");
      window.localStorage.setItem(KEY, mode);
    } catch {
    }
    subs.forEach((f) => f());
  },
  subscribe(f) {
    subs.add(f);
    return () => {
      subs.delete(f);
    };
  }
};
function usePersonalMode() {
  return (0, import_react.useSyncExternalStore)(
    (f) => personalMode.subscribe(f),
    () => personalMode.get(),
    () => "personal"
  );
}

// src/workstation/personal-sidebar/src/client/PersonalBrowser.tsx
var import_react4 = require("react");

// src/workstation/personal-sidebar/src/client/icons.tsx
var import_jsx_runtime = require("react/jsx-runtime");
function base(size) {
  return {
    width: size,
    height: size,
    viewBox: "0 0 16 16",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.4,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": true
  };
}
function WorkspaceIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { ...base(size), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "2", y: "2", width: "5", height: "5", rx: "1" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "9", y: "2", width: "5", height: "5", rx: "1" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "2", y: "9", width: "5", height: "5", rx: "1" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "9", y: "9", width: "5", height: "5", rx: "1" })
  ] });
}
function ChatIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { ...base(size), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2.5 3h11v8h-7l-3.5 2.5V3Z" }) });
}
function SwitcherIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { ...base(size), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 10V4.5M4 4.5 2.2 6M4 4.5 5.8 6" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 6v5.5M12 11.5l1.8-1.5M12 11.5l-1.8-1.5" })
  ] });
}
function PlusIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { ...base(size), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 3v10M3 8h10" }) });
}
function HomeIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { ...base(size), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2.8 7.2 8 3l5.2 4.2" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 6.5V13h8V6.5" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6.6 13v-3.2h2.8V13" })
  ] });
}
function ClockIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { ...base(size), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "8", cy: "8", r: "5.4" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 5.2V8l2 1.6" })
  ] });
}
function FolderIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { ...base(size), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2.4 4.6h4l1.6 1.8H13.6v5.2a1 1 0 0 1-1 1H3.4a1 1 0 0 1-1-1V4.6Z" }) });
}
function AgentIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { ...base(size), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 1.4v1.9" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "8", cy: "1.3", r: "0.6" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "3", y: "3.3", width: "10", height: "7.2", rx: "2.2" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6 6.7h.01" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M10 6.7h.01" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6.3 11.4v1.5" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M9.7 11.4v1.5" })
  ] });
}
function MemoryIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { ...base(size), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "3.2", cy: "8", r: "1.7" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "12.8", cy: "4", r: "1.7" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "12.8", cy: "12", r: "1.7" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4.9 8h3.1V4h3.1" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 8v4h3.1" })
  ] });
}

// src/workstation/personal-sidebar/src/client/conversations.ts
var EMPTY_CONVERSATIONS = { rows: [], ready: false };
var VISIBLE_PENDING_KINDS = /* @__PURE__ */ new Set(["approval", "plan-review", "question"]);
function isVisiblePendingKind(kind) {
  return typeof kind === "string" && VISIBLE_PENDING_KINDS.has(kind);
}
function pendingSessions(pending) {
  const out = /* @__PURE__ */ new Map();
  if (pending === null || typeof pending !== "object") return out;
  const entries = pending.entries;
  if (typeof entries !== "function") return out;
  let list;
  try {
    list = entries.call(pending);
  } catch {
    return out;
  }
  for (const [sessionId, interaction] of list) {
    if (typeof sessionId !== "string" || sessionId === "") continue;
    const raw = interaction ?? {};
    if (!isVisiblePendingKind(raw.kind)) continue;
    out.set(sessionId, raw);
  }
  return out;
}
var PENDING_ATTACH_TRIES = 10;
var PENDING_ATTACH_MS = 800;
function samePendingSessions(left, right) {
  if (left === right) return true;
  if (left.size !== right.size) return false;
  for (const [sessionId, interaction] of left) if (right.get(sessionId) !== interaction) return false;
  return true;
}
function conversationDotState(row, pending, unseenDone = false, interruptedUnread = false) {
  if (pending.has(row.id)) return "waiting";
  if (row.running === true) return "running";
  if (interruptedUnread === true) return "interrupted";
  return unseenDone ? "done" : "idle";
}
var EMPTY_COMPLETION_TRACK = { prevRunning: /* @__PURE__ */ new Map(), unseen: /* @__PURE__ */ new Set() };
function trackUnseenCompletions(track, rows, pending) {
  const prevRunning = /* @__PURE__ */ new Map();
  const unseen = /* @__PURE__ */ new Set();
  let changed = rows.length !== track.prevRunning.size;
  for (const row of rows) {
    const was = track.prevRunning.get(row.id);
    const isRunning = row.running === true;
    prevRunning.set(row.id, isRunning);
    if (was !== isRunning) changed = true;
    const justFinished = was === true && !isRunning && !pending.has(row.id);
    if (justFinished) {
      unseen.add(row.id);
      if (!track.unseen.has(row.id)) changed = true;
    } else if (track.unseen.has(row.id)) {
      unseen.add(row.id);
      changed = true;
    }
  }
  if (!changed) return track;
  return { prevRunning, unseen };
}
function markConversationSeen(track, id) {
  if (!track.unseen.has(id)) return track;
  const unseen = new Set(track.unseen);
  unseen.delete(id);
  return { prevRunning: track.prevRunning, unseen };
}
function conversationDotNote(state, interaction) {
  if (state === "running") return "\u8FD0\u4F5C\u4E2D";
  if (state === "interrupted") return "\u4E0A\u6B21\u88AB\u5FEB\u901F\u505C\u6B62\uFF1B\u4F60\u8FD8\u6CA1\u6253\u5F00\u770B\u8FC7\uFF08\u6253\u5F00\u540E\u6B64\u70B9\u6D88\u5931\uFF09";
  if (state === "done") return "\u5DF2\u5B8C\u6210\uFF08\u4F60\u8FD8\u6CA1\u6253\u5F00\u770B\u8FC7\uFF1B\u6253\u5F00\u540E\u6B64\u70B9\u6D88\u5931\uFF09";
  if (state === "idle") return "\u5DF2\u7ED3\u675F\uFF08\u5F53\u524D\u6CA1\u5728\u505A\u4E8B\uFF09";
  const kind = interaction?.kind;
  if (kind === "approval") {
    const tool = typeof interaction?.toolName === "string" && interaction.toolName !== "" ? interaction.toolName : "";
    const reason = typeof interaction?.reason === "string" && interaction.reason !== "" ? `\uFF1A${interaction.reason}` : "";
    return tool !== "" ? `\u9700\u8981\u4F60\u5BA1\u6279\uFF08${tool}\uFF09${reason}` : "\u9700\u8981\u4F60\u5BA1\u6279";
  }
  if (Array.isArray(interaction?.questions)) {
    const n = interaction.questions.length;
    return n > 0 ? `\u9700\u8981\u4F60\u56DE\u7B54\uFF08${n} \u4E2A\u95EE\u9898\uFF09` : "\u9700\u8981\u4F60\u56DE\u7B54";
  }
  return kind === "question" || kind === "plan-review" ? "\u9700\u8981\u4F60\u56DE\u7B54" : "\u9700\u8981\u4F60\u4ECB\u5165";
}
var CONVERSATION_DOT_CLASS = {
  running: "dps-conv-run",
  waiting: "dps-conv-wait",
  done: "dps-conv-done",
  idle: "dps-conv-idle",
  interrupted: "dps-conv-int"
};
var DEFAULT_VISIBLE = 5;
var CONV_EMPTY_TEXT = "\u6682\u65E0\u6700\u8FD1\u4F1A\u8BDD";
var CONV_EMPTY_CTA = "\u53BB\u4E3B\u9875\u5F00\u59CB\u4F1A\u8BDD";
var CONV_ARCHIVE_UNKNOWN_NOTE = "\u5F52\u6863\u72B6\u6001\u672A\u77E5\uFF1A\u5B98\u65B9 workspaces\uFF08\u5F52\u6863\u6765\u6E90\uFF09\u672A\u5C31\u7EEA\uFF0C\u672C\u5217\u8868\u672A\u6309\u5F52\u6863\u8FC7\u6EE4\u3002";
var CONV_SCOPE_NOTE = "\u8FD9\u91CC\u53EA\u662F\u4F1A\u8BDD\u5165\u53E3\uFF08\u6062\u590D\u5BF9\u8BDD\uFF09\uFF1B\u4EFB\u52A1\u72B6\u6001/\u9700\u8981\u5904\u7406\u5728\u4EFB\u52A1\u770B\u677F\u3002";
var CONV_BACKGROUND_UNKNOWN_NOTE = "\u540E\u53F0\u4EFB\u52A1\u4F1A\u8BDD\u72B6\u6001\u672A\u77E5\uFF1A\u4EFB\u52A1\u770B\u677F\u7684\u6267\u884C\u8BB0\u5F55\u5F53\u524D\u8BFB\u4E0D\u5230\uFF0C\u672C\u5217\u8868**\u672A**\u6309\u540E\u53F0\u4EFB\u52A1\u8FC7\u6EE4\u3002";
function convBackgroundHiddenNote(hidden) {
  return hidden > 0 ? `\u5DF2\u9690\u85CF ${hidden} \u4E2A\u540E\u53F0\u4EFB\u52A1\u4F1A\u8BDD\uFF08\u672A\u5220\u9664\uFF0C\u53EF\u5728\u4EFB\u52A1\u2192\u6267\u884C\u5386\u53F2\u6253\u5F00\uFF09` : "";
}
var CONV_BACKGROUND_TOGGLE_HIDE = "\u9690\u85CF\u540E\u53F0\u4EFB\u52A1\u4F1A\u8BDD";
var CONV_BACKGROUND_TOGGLE_SHOW = "\u663E\u793A\u540E\u53F0\u4EFB\u52A1\u4F1A\u8BDD";
function str(v) {
  return typeof v === "string" ? v : "";
}
function parseConversations(snapshot2) {
  if (snapshot2 === null || snapshot2 === void 0) return EMPTY_CONVERSATIONS;
  const s = snapshot2;
  const raw = [];
  const byId = s.byId;
  if (byId !== null && typeof byId === "object" && !Array.isArray(byId)) {
    raw.push(...Object.values(byId));
  } else if (Array.isArray(s)) {
    raw.push(...s);
  } else if (Array.isArray(s.list)) {
    raw.push(...s.list);
  } else if (Array.isArray(s.sessions)) {
    raw.push(...s.sessions);
  } else {
    return EMPTY_CONVERSATIONS;
  }
  const rows = [];
  for (const item of raw) {
    const r = item ?? {};
    const id = str(r.id) || str(r.sessionId);
    if (id === "") continue;
    const displayTitle = str(r.displayTitle);
    const title = str(r.title);
    const cwd = str(r.cwd);
    const fallback = cwd !== "" ? cwd.split("/").filter(Boolean).pop() ?? cwd : id;
    rows.push({
      id,
      title: displayTitle !== "" ? displayTitle : title !== "" ? title : fallback,
      updatedAt: typeof r.updatedAt === "number" && Number.isFinite(r.updatedAt) ? r.updatedAt : 0,
      running: r.running === true,
      blank: r.blank === true,
      ...str(r.parentId) !== "" ? { parentId: str(r.parentId) } : {},
      ...str(r.origin) !== "" ? { origin: str(r.origin) } : {},
      ...cwd !== "" ? { cwd } : {}
    });
  }
  const currentId = str(s.current) !== "" ? str(s.current) : void 0;
  return { rows, currentId, ready: true };
}
function archiveTruthOf(source) {
  const s = source ?? {};
  const ids = s.archivedSessionIds;
  if (!Array.isArray(ids)) return { known: false, ids: /* @__PURE__ */ new Set() };
  return { known: true, ids: new Set(ids.filter((x) => typeof x === "string")) };
}
function visibleConversations(snap, archive) {
  const out = snap.rows.filter((r) => {
    if (r.origin === "subagent") return false;
    if (archive.known && archive.ids.has(r.id)) return false;
    if (r.blank && r.id !== snap.currentId) return false;
    return true;
  });
  return out.sort((a, b) => b.updatedAt !== a.updatedAt ? b.updatedAt - a.updatedAt : a.id < b.id ? -1 : 1);
}
function conversationListModel(rows, archive, expanded, limit = DEFAULT_VISIBLE) {
  const shown = expanded ? [...rows] : rows.slice(0, limit);
  const hiddenCount = expanded ? 0 : Math.max(0, rows.length - limit);
  return {
    shown,
    hiddenCount,
    expandLabel: hiddenCount > 0 ? `\u5C55\u5F00\u5176\u4F59 ${hiddenCount} \u4E2A\u4F1A\u8BDD` : "",
    archiveUnknown: !archive.known
  };
}
function relativeTime(updatedAt, now) {
  if (!Number.isFinite(updatedAt) || updatedAt <= 0) return "";
  const diff = Math.max(0, now - updatedAt);
  const min = Math.floor(diff / 6e4);
  if (min < 1) return "\u521A\u521A";
  if (min < 60) return `${min} \u5206\u949F`;
  const hours = Math.floor(min / 60);
  if (hours < 24) return `${hours} \u5C0F\u65F6`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} \u5929`;
  const months = Math.floor(days / 30);
  return `${months} \u4E2A\u6708`;
}

// src/workstation/personal-sidebar/src/client/convbackground.ts
var UNKNOWN_BACKGROUND = { known: false, bySession: /* @__PURE__ */ new Map() };
function str2(v) {
  return typeof v === "string" ? v : "";
}
function backgroundTruthOf(snapshot2) {
  if (snapshot2 === null || snapshot2 === void 0) return UNKNOWN_BACKGROUND;
  const s = snapshot2;
  if (typeof s !== "object" || Array.isArray(s)) return UNKNOWN_BACKGROUND;
  if (!Array.isArray(s.tasks)) return UNKNOWN_BACKGROUND;
  const bySession = /* @__PURE__ */ new Map();
  for (const rawTask of s.tasks) {
    const task = rawTask ?? {};
    const taskId = str2(task.id);
    const taskTitle = str2(task.title);
    const executions = Array.isArray(task.executions) ? task.executions : [];
    const owner = /* @__PURE__ */ new Map();
    for (const rawExec of executions) {
      const exec = rawExec ?? {};
      const sid = str2(exec.sessionId);
      if (sid === "") continue;
      owner.set(sid, str2(exec.id));
    }
    for (const [sid, executionId] of owner) {
      if (bySession.has(sid)) continue;
      bySession.set(sid, { taskId, taskTitle, executionId });
    }
  }
  return { known: true, bySession };
}
function filterBackgroundSessions(rows, truth, showBackground) {
  if (!truth.known) {
    return { rows: [...rows], hiddenBackground: 0, backgroundUnknown: true };
  }
  if (showBackground) {
    return { rows: [...rows], hiddenBackground: 0, backgroundUnknown: false };
  }
  const kept = [];
  let hidden = 0;
  for (const row of rows) {
    if (truth.bySession.has(row.id)) {
      hidden += 1;
      continue;
    }
    kept.push(row);
  }
  return { rows: kept, hiddenBackground: hidden, backgroundUnknown: false };
}

// src/workstation/personal-sidebar/src/client/convledger.ts
var TASK_BOARD_STATE_URL = "/api/task-board/state";
var LEDGER_TIMEOUT_MS = 15e3;
var LEDGER_POLL_MS = 3e4;
var LEDGER_RETRY_MS = 2e3;
var LEDGER_RETRY_TRIES = 5;
function overrideNum(key, fallback) {
  const g = globalThis;
  const w = g.window;
  const fromWindow = w !== void 0 && w !== null ? w[key] : void 0;
  const v = typeof fromWindow === "number" ? fromWindow : g[key];
  return typeof v === "number" && Number.isFinite(v) && v > 0 ? v : fallback;
}
function ledgerPollMs() {
  return overrideNum("__DPS_LEDGER_POLL_MS", LEDGER_POLL_MS);
}
function ledgerRetryDelayMs() {
  return overrideNum("__DPS_LEDGER_RETRY_MS", LEDGER_RETRY_MS);
}
function getFetch() {
  const f = globalThis.fetch;
  return typeof f === "function" ? f : void 0;
}
async function readBackgroundTruth() {
  const f = getFetch();
  if (f === void 0) return UNKNOWN_BACKGROUND;
  const controller = typeof AbortController === "function" ? new AbortController() : void 0;
  let timer;
  if (controller !== void 0) {
    timer = setTimeout(() => {
      try {
        controller.abort();
      } catch {
      }
    }, LEDGER_TIMEOUT_MS);
  }
  try {
    const res = await f(TASK_BOARD_STATE_URL, {
      method: "GET",
      headers: { accept: "application/json" },
      signal: controller?.signal
    });
    if (!res.ok) return UNKNOWN_BACKGROUND;
    const body = await res.json();
    return backgroundTruthOf(body);
  } catch {
    return UNKNOWN_BACKGROUND;
  } finally {
    if (timer !== void 0) clearTimeout(timer);
  }
}
function sameBackgroundTruth(a, b) {
  if (a === b) return true;
  if (a.known !== b.known) return false;
  if (a.bySession.size !== b.bySession.size) return false;
  for (const [sid, ref] of a.bySession) {
    const other = b.bySession.get(sid);
    if (other === void 0) return false;
    if (other.taskId !== ref.taskId || other.executionId !== ref.executionId || other.taskTitle !== ref.taskTitle) {
      return false;
    }
  }
  return true;
}
function createLedgerReader() {
  let stopped = false;
  let interval;
  let retryTimer;
  let last;
  let retries = 0;
  const emit = (next, onChange) => {
    if (stopped) return;
    if (last !== void 0 && sameBackgroundTruth(last, next)) return;
    last = next;
    onChange(next);
  };
  const scheduleRetry = (onChange) => {
    if (stopped || retries >= LEDGER_RETRY_TRIES) return;
    retries += 1;
    retryTimer = setTimeout(() => {
      if (stopped) return;
      void tick(onChange);
    }, ledgerRetryDelayMs());
  };
  const tick = async (onChange) => {
    const next = await readBackgroundTruth();
    if (stopped) return;
    emit(next, onChange);
    if (!next.known) scheduleRetry(onChange);
    else retries = LEDGER_RETRY_TRIES;
  };
  return {
    async read() {
      return await readBackgroundTruth();
    },
    start(onChange) {
      void tick(onChange);
      const loop = () => {
        if (stopped) return;
        interval = setTimeout(() => {
          void (async () => {
            await tick(onChange);
            loop();
          })();
        }, ledgerPollMs());
      };
      loop();
      return () => {
        stopped = true;
        if (interval !== void 0) clearTimeout(interval);
        if (retryTimer !== void 0) clearTimeout(retryTimer);
      };
    }
  };
}

// src/workstation/personal-quickstop/server/routes.mjs
var QUICKSTOP_PREFIX = "/api/personal/quickstop";
var QUICKSTOP_STATE_PATH = `${QUICKSTOP_PREFIX}/state`;
var QUICKSTOP_READ_PATH = `${QUICKSTOP_PREFIX}/read`;
var QUICKSTOP_PLAN_PATH = `${QUICKSTOP_PREFIX}/plan`;
var QUICKSTOP_RUN_PATH = `${QUICKSTOP_PREFIX}/run`;
var QUICKSTOP_RESUME_PATH = `${QUICKSTOP_PREFIX}/resume`;

// src/workstation/personal-sidebar/src/client/interrupts.ts
var INTERRUPT_STATE_URL = QUICKSTOP_STATE_PATH;
var INTERRUPT_READ_URL = QUICKSTOP_READ_PATH;
var INTERRUPT_TIMEOUT_MS = 15e3;
var INTERRUPT_POLL_MS = 3e4;
var INTERRUPT_RETRY_MS = 2e3;
var INTERRUPT_RETRY_TRIES = 5;
var UNKNOWN_INTERRUPTS = Object.freeze({
  known: false,
  unreadSessions: /* @__PURE__ */ new Set(),
  unreadTasks: 0,
  records: []
});
function overrideNum2(key, fallback) {
  const g = globalThis;
  const w = g.window;
  const fromWindow = w !== void 0 && w !== null ? w[key] : void 0;
  const v = typeof fromWindow === "number" ? fromWindow : g[key];
  return typeof v === "number" && Number.isFinite(v) && v > 0 ? v : fallback;
}
function interruptTimeoutMs() {
  return overrideNum2("__DPS_INTERRUPT_TIMEOUT_MS", INTERRUPT_TIMEOUT_MS);
}
function interruptPollMs() {
  return overrideNum2("__DPS_INTERRUPT_POLL_MS", INTERRUPT_POLL_MS);
}
function interruptRetryDelayMs() {
  return overrideNum2("__DPS_INTERRUPT_RETRY_MS", INTERRUPT_RETRY_MS);
}
function getFetch2() {
  const f = globalThis.fetch;
  return typeof f === "function" ? f : void 0;
}
function resolveUrl(path) {
  const g = globalThis;
  const raw = g.window?.["__DPS_INTERRUPT_BASE_URL"] ?? g["__DPS_INTERRUPT_BASE_URL"];
  const base2 = typeof raw === "string" ? raw : "";
  return base2 === "" ? path : `${base2.replace(/\/+$/, "")}${path}`;
}
function isSource(value) {
  return value === "session" || value === "task" || value === "subagent" || value === "background";
}
function recordOf(raw) {
  if (raw === null || typeof raw !== "object") return null;
  const r = raw;
  if (!isSource(r.source) || typeof r.sourceId !== "string" || r.sourceId === "") return null;
  const checkpoint = r.checkpoint;
  return {
    source: r.source,
    sourceId: r.sourceId,
    stoppedAt: typeof r.stoppedAt === "string" && r.stoppedAt !== "" ? r.stoppedAt : null,
    unread: r.unread !== false,
    interrupted: r.interrupted !== false,
    checkpointIncomplete: r.checkpointIncomplete === true,
    checkpoint: checkpoint !== null && typeof checkpoint === "object" ? checkpoint : null
  };
}
function interruptTruthOf(body) {
  if (body === null || typeof body !== "object") return UNKNOWN_INTERRUPTS;
  const b = body;
  if (b.ok !== true) return UNKNOWN_INTERRUPTS;
  if (!Array.isArray(b.records)) return UNKNOWN_INTERRUPTS;
  const counts = b.counts;
  const unread = counts?.unread;
  const unreadTasks = unread?.tasks;
  if (typeof unreadTasks !== "number" || !Number.isFinite(unreadTasks)) return UNKNOWN_INTERRUPTS;
  const records = [];
  const unreadSessions = /* @__PURE__ */ new Set();
  for (const raw of b.records) {
    const record = recordOf(raw);
    if (record === null) return UNKNOWN_INTERRUPTS;
    records.push(record);
    if ((record.source === "session" || record.source === "subagent") && record.unread) {
      unreadSessions.add(record.sourceId);
    }
  }
  return { known: true, unreadSessions, unreadTasks, records };
}
function sameInterruptTruth(a, b) {
  if (a === b) return true;
  if (a.known !== b.known) return false;
  if (a.unreadTasks !== b.unreadTasks) return false;
  if (a.unreadSessions.size !== b.unreadSessions.size) return false;
  for (const id of a.unreadSessions) if (!b.unreadSessions.has(id)) return false;
  if (a.records.length !== b.records.length) return false;
  for (let i = 0; i < a.records.length; i += 1) {
    const x = a.records[i];
    const y = b.records[i];
    if (x.source !== y.source || x.sourceId !== y.sourceId || x.stoppedAt !== y.stoppedAt || x.unread !== y.unread || x.interrupted !== y.interrupted || x.checkpointIncomplete !== y.checkpointIncomplete || JSON.stringify(x.checkpoint) !== JSON.stringify(y.checkpoint)) {
      return false;
    }
  }
  return true;
}
async function readInterruptTruth() {
  const f = getFetch2();
  if (f === void 0) return UNKNOWN_INTERRUPTS;
  const controller = typeof AbortController === "function" ? new AbortController() : void 0;
  let timer;
  if (controller !== void 0) {
    timer = setTimeout(() => {
      try {
        controller.abort();
      } catch {
      }
    }, interruptTimeoutMs());
  }
  try {
    const res = await f(resolveUrl(INTERRUPT_STATE_URL), {
      method: "GET",
      headers: { accept: "application/json" },
      signal: controller?.signal
    });
    if (!res.ok) return UNKNOWN_INTERRUPTS;
    const body = await res.json();
    return interruptTruthOf(body);
  } catch {
    return UNKNOWN_INTERRUPTS;
  } finally {
    if (timer !== void 0) clearTimeout(timer);
  }
}
async function markInterruptRead(source, sourceId) {
  const f = getFetch2();
  if (f === void 0) return { ok: false, status: null };
  try {
    const res = await f(resolveUrl(INTERRUPT_READ_URL), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ source, sourceId })
    });
    return { ok: res.ok, status: res.status };
  } catch {
    return { ok: false, status: null };
  }
}
function clearUnread(truth, source, sourceId) {
  if (!truth.known) return truth;
  const target = truth.records.find((r) => r.source === source && r.sourceId === sourceId);
  if (target === void 0 || !target.unread) return truth;
  const records = truth.records.map((r) => r === target ? { ...r, unread: false } : r);
  const unreadSessions = new Set(truth.unreadSessions);
  if (source === "session") unreadSessions.delete(sourceId);
  return {
    known: true,
    unreadSessions,
    unreadTasks: source === "task" ? Math.max(0, truth.unreadTasks - 1) : truth.unreadTasks,
    records
  };
}
function createInterruptReader() {
  let stopped = false;
  let pollTimer;
  let retryTimer;
  let last;
  let retries = 0;
  const emit = (next, onChange) => {
    if (stopped) return;
    if (last !== void 0 && sameInterruptTruth(last, next)) return;
    last = next;
    onChange(next);
  };
  const scheduleRetry = (onChange) => {
    if (stopped || retries >= INTERRUPT_RETRY_TRIES) return;
    retries += 1;
    retryTimer = setTimeout(() => {
      if (stopped) return;
      void tick(onChange);
    }, interruptRetryDelayMs());
  };
  const tick = async (onChange) => {
    const next = await readInterruptTruth();
    if (stopped) return;
    emit(next, onChange);
    if (!next.known) scheduleRetry(onChange);
    else retries = INTERRUPT_RETRY_TRIES;
  };
  const loop = (onChange) => {
    if (stopped) return;
    pollTimer = setTimeout(() => {
      void (async () => {
        await tick(onChange);
        loop(onChange);
      })();
    }, interruptPollMs());
  };
  return {
    async read() {
      return await readInterruptTruth();
    },
    start(onChange) {
      void tick(onChange);
      loop(onChange);
      return () => {
        stopped = true;
        if (pollTimer !== void 0) clearTimeout(pollTimer);
        if (retryTimer !== void 0) clearTimeout(retryTimer);
      };
    }
  };
}

// src/workstation/personal-sidebar/src/client/diag.ts
function ensureDiag() {
  try {
    const w = window;
    if (!w.__dshDiag) w.__dshDiag = {};
    return w.__dshDiag;
  } catch {
    return {};
  }
}
function diagPkgTick(pkg, version, sha) {
  try {
    const d = ensureDiag();
    const p = d.pkg ??= {};
    p[`${pkg}Instances`] = (p[`${pkg}Instances`] ?? 0) + 1;
    p[`${pkg}Version`] = version;
    p[`${pkg}Sha`] = sha;
    const s = d.sha ??= {};
    s[pkg] = sha;
  } catch {
  }
}
function diagTrace(kind, data) {
  try {
    const d = ensureDiag();
    const list = d.traces ??= [];
    list.push({ t: Date.now(), kind, ...data });
    if (list.length > 600) list.splice(0, list.length - 600);
  } catch {
  }
}
function elDesc(el) {
  if (!el) return null;
  const tag = el.tagName.toLowerCase();
  const id = el.id ? `#${el.id}` : "";
  const cls = typeof el.className === "string" && el.className.trim().length > 0 ? "." + el.className.trim().split(/\s+/).slice(0, 3).join(".") : "";
  const data = [...el.attributes].filter((a) => a.name.startsWith("data-")).slice(0, 4).map((a) => `${a.name}="${a.value.slice(0, 30)}"`).join(" ");
  return `${tag}${id}${cls}${data ? " [" + data + "]" : ""}`.slice(0, 160);
}
function buildSelfCheckReport() {
  const out = { t: Date.now() };
  try {
    const d = ensureDiag();
    out.pkg = d.pkg ?? {};
    out.crashes = d.crashes ?? [];
    out.sha = d.sha ?? {};
    try {
      out.hostReady = window.__dshPersonalMainReady === true;
    } catch {
      out.hostReady = false;
    }
    try {
      out.mainDiag = window.__dshMainDiag ?? null;
    } catch {
      out.mainDiag = null;
    }
    try {
      out.persistedMainView = window.localStorage.getItem("dsh.personal.mainview.v1");
    } catch {
      out.persistedMainView = null;
    }
    if (typeof document !== "undefined") {
      const navRoots = document.querySelectorAll('[data-dps-nav="1"], [data-dps-nav-rail="1"]');
      out.dom = out.dom ?? {};
      out.dom.navRoots = navRoots.length;
      const rows = [...document.querySelectorAll("[data-nav]")];
      out.dom.navRows = rows.length;
      const byId = {};
      for (const r of rows) {
        const id = r.getAttribute("data-nav") ?? "?";
        byId[id] = (byId[id] ?? 0) + 1;
      }
      const dups = Object.entries(byId).filter(([, n]) => n > 1);
      out.dom.duplicateRows = dups.length > 0 ? dups : null;
      const ownBoardRows = [...document.querySelectorAll('[data-dps-nav] [data-nav="task-board"]')];
      const foreignBoardRows = [...document.querySelectorAll("[data-dsh-taskboard-entry]")];
      out.dom.taskboardEntries = {
        own: ownBoardRows.length,
        ownLabels: ownBoardRows.map((r) => (r.textContent ?? "").trim()),
        foreign: foreignBoardRows.length,
        foreignLabels: foreignBoardRows.map((r) => (r.textContent ?? "").trim()),
        foreignOwners: foreignBoardRows.map((r) => ({
          plugin: r.getAttribute("data-dsh-plugin"),
          part: r.getAttribute("data-dsh-part"),
          inSidebarPane: r.closest('[data-pane="sidebar"]') !== null
        }))
      };
      const hits = [];
      for (const r of rows) {
        const rect = r.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        let top = null;
        try {
          top = document.elementFromPoint(cx, cy);
        } catch {
          top = null;
        }
        hits.push({
          nav: r.getAttribute("data-nav"),
          x: Math.round(cx),
          y: Math.round(cy),
          rowRect: `${Math.round(rect.width)}x${Math.round(rect.height)}`,
          top: elDesc(top),
          onRow: top === r || top !== null && r.contains(top)
        });
      }
      ;
      out.dom.navHitTest = hits;
      const host = document.querySelector('[data-dsh-main-host="1"]');
      out.dom.mainHostView = host?.getAttribute("data-dsh-main-view") ?? null;
      out.dom.mainHostError = document.querySelector('[data-dsh-main-error="1"]') !== null;
      out.dom.mainHostFound = host !== null;
      try {
        const mounts = ensureDiag().mounts ?? [];
        out.dom.mounts = mounts.slice(-12);
      } catch {
        ;
        out.dom.mounts = [];
      }
      const labels = ["\u4EFB\u52A1\u770B\u677F", "\u4EFB\u52A1\u677F", "\u65B0\u4EFB\u52A1", "\uFF0B\u65B0\u4EFB\u52A1", "\uFF0B \u65B0\u4EFB\u52A1"];
      const labelHits = [];
      const seen = /* @__PURE__ */ new Set();
      const walk = (el) => {
        for (const child of el.children) {
          if (seen.has(child)) continue;
          seen.add(child);
          walk(child);
          const text = (child.textContent ?? "").trim();
          if (text.length === 0 || text.length > 24) continue;
          if (labels.includes(text) || labels.includes(text.replace(/\s+/g, " "))) {
            labelHits.push({ text, where: elDesc(child), path: pathOf(child) });
          }
        }
      };
      const pathOf = (el) => {
        const parts = [];
        let cur = el;
        let guard = 0;
        while (cur && guard < 8) {
          const p = elDesc(cur);
          parts.unshift(p ?? cur.tagName);
          cur = cur.parentElement;
          guard += 1;
        }
        return parts.join(" < ");
      };
      walk(document.body);
      out.dom.labelScan = labelHits;
      try {
        const slots = window.__dshDiag?.slotsRaw;
        if (slots && typeof slots.snapshot === "function") {
          const conv = slots.snapshot("conversation");
          const side = slots.snapshot("sidebar");
          out.seats = { conversation: conv, sidebar: side };
        } else {
          out.seats = { note: "slotsRaw \u53E5\u67C4\u7F3A\u5931\uFF08workspace \u672A\u8FD0\u884C\u6216\u7248\u672C\u8FC7\u65E7\uFF09" };
        }
      } catch (error) {
        out.seats = { error: error instanceof Error ? error.message : String(error) };
      }
    }
  } catch (error) {
    out.error = error instanceof Error ? error.message : String(error);
  }
  return out;
}

// src/workstation/personal-sidebar/src/client/taskDetailRead.ts
var TASK_DETAIL_ID_ATTR = "data-dsh-taskboard-task-id";
var TASK_DETAIL_SELECTOR = `[${TASK_DETAIL_ID_ATTR}]`;
var TASK_READ_TRACE_KIND = Object.freeze({
  cleared: "task-read-cleared",
  "no-record": "task-read-no-record",
  failed: "task-read-failed"
});
function taskIdFromAttrValue(raw) {
  if (raw === null) return null;
  if (raw.trim() === "") return null;
  return raw;
}
function readOpenTaskId(root) {
  if (root === null || root === void 0 || typeof root.querySelectorAll !== "function") {
    return { kind: "none" };
  }
  let nodes;
  try {
    nodes = root.querySelectorAll(TASK_DETAIL_SELECTOR);
  } catch {
    return { kind: "none" };
  }
  const ids = /* @__PURE__ */ new Set();
  for (let i = 0; i < nodes.length; i += 1) {
    const el = nodes[i];
    if (el === null || el === void 0 || typeof el.getAttribute !== "function") continue;
    const id = taskIdFromAttrValue(el.getAttribute(TASK_DETAIL_ID_ATTR));
    if (id !== null) ids.add(id);
  }
  if (ids.size === 0) return { kind: "none" };
  if (ids.size > 1) return { kind: "ambiguous" };
  return { kind: "one", id: [...ids][0] };
}
function taskIdOf(reading) {
  return reading.kind === "one" ? reading.id : null;
}
function classifyReadOutcome(res) {
  if (res.ok === true) return "cleared";
  if (res.status === 404) return "no-record";
  return "failed";
}
function taskReadTransition(observed, fired) {
  if (observed === null) return { fire: null, next: null };
  if (observed === fired) return { fire: null, next: fired };
  return { fire: observed, next: observed };
}
function createTaskDetailReadWatcher(deps = {}) {
  const read = deps.read ?? ((taskId) => markInterruptRead("task", taskId));
  const root = deps.root ?? (typeof document === "undefined" ? null : document);
  let stopped = false;
  let fired = null;
  let observer = null;
  const fire = async (taskId) => {
    let res;
    try {
      res = await read(taskId);
    } catch {
      res = { ok: false, status: null };
    }
    if (stopped) return;
    const outcome = classifyReadOutcome(res);
    if (outcome === "cleared") deps.onCleared?.(taskId);
    deps.onEvent?.({ taskId, outcome, status: res.status });
    diagTrace(TASK_READ_TRACE_KIND[outcome], { detail: `task=${taskId} status=${res.status ?? "null"}` });
  };
  const scan = () => {
    if (stopped) return;
    const step = taskReadTransition(taskIdOf(readOpenTaskId(root)), fired);
    fired = step.next;
    if (step.fire === null) return;
    void fire(step.fire);
  };
  if (root !== null && root !== void 0 && typeof MutationObserver === "function") {
    try {
      observer = new MutationObserver(() => scan());
      observer.observe(root, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: [TASK_DETAIL_ID_ATTR]
      });
    } catch {
      observer = null;
    }
  }
  scan();
  return {
    scan,
    get watching() {
      return observer !== null && !stopped;
    },
    stop: () => {
      stopped = true;
      try {
        observer?.disconnect();
      } catch {
      }
      observer = null;
    }
  };
}

// src/workstation/personal-workspace/src/client/mainview.ts
var MAIN_VIEW_TITLES = {
  conversation: "\u4F1A\u8BDD",
  home: "\u4E3B\u9875",
  "task-board": "\u4EFB\u52A1\u770B\u677F",
  "new-task": "\uFF0B\u65B0\u4EFB\u52A1",
  "project-center": "\u9879\u76EE",
  "project-detail": "\u9879\u76EE\u8BE6\u60C5",
  unassigned: "\u672A\u5206\u914D",
  "workspace-center": "\u5DE5\u4F5C\u533A",
  recent: "\u6700\u8FD1",
  "agent-center": "\u667A\u80FD\u4F53",
  "memory-tree": "\u8BB0\u5FC6"
};
var MAIN_OPEN_EVENT = "dsh:personal-main-open";
var MAIN_ACK_EVENT = "dsh:personal-main-ack";
var MAIN_STATE_EVENT = "dsh:personal-main-state";
var MAIN_UNAVAILABLE_EVENT = "dsh:personal-main-unavailable";
var INSTANCE_TAG = "dpw-" + Math.random().toString(36).slice(2, 8);
var CSS_MAIN_HOST = String.raw`
.dpw-main-host {
  box-sizing: border-box;
  height: 100%;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  background: var(--dsw-alias-bg-base, transparent);
  color: var(--dsw-alias-label-primary, inherit);
}
.dpw-main-error {
  padding: 20px;
  font: 13px/1.7 var(--ds-font-family, system-ui, sans-serif);
  color: var(--dsw-alias-label-tertiary, #9a9aa5);
}
.dpw-main-error code { font-family: var(--ds-font-family-code, monospace); word-break: break-all; }
`;

// src/workstation/personal-sidebar/src/client/navorder.ts
var import_react2 = require("react");
var NAV_PREFS_KEY = "dsh.personal.nav.v1";
var NAV_COLLAPSED_DEFAULT = true;
var NAV_VISIBLE_WHEN_COLLAPSED = 4;
var NAV_LIST_SELECTOR = ".dps-nav";
var THIRD_PARTY_NAV_ROW_SELECTOR = "[data-dsh-taskboard-entry]";
var DEFAULT_PREFS = { v: 1, order: [], collapsed: NAV_COLLAPSED_DEFAULT };
function applyNavOrder(defaultIds, stored) {
  const defaults = [...defaultIds];
  if (!Array.isArray(stored)) return defaults;
  const seen = /* @__PURE__ */ new Set();
  const ordered = [];
  for (const raw of stored) {
    if (typeof raw !== "string") continue;
    if (seen.has(raw)) continue;
    if (!defaultIds.includes(raw)) continue;
    seen.add(raw);
    ordered.push(raw);
  }
  for (const id of defaults) if (!seen.has(id)) ordered.push(id);
  return ordered;
}
function isDefaultNavOrder(defaultIds, order) {
  return order.length === defaultIds.length && order.every((id, i) => id === defaultIds[i]);
}
function parseNavPrefs(raw) {
  if (raw === null || typeof raw !== "object" || Array.isArray(raw)) return { ...DEFAULT_PREFS };
  const value = raw;
  const order = Array.isArray(value.order) ? value.order.filter((x) => typeof x === "string") : [];
  const collapsed = typeof value.collapsed === "boolean" ? value.collapsed : NAV_COLLAPSED_DEFAULT;
  return { v: 1, order, collapsed };
}
function decodeNavPrefs(text) {
  if (text === null || text === "") return { ...DEFAULT_PREFS };
  try {
    return parseNavPrefs(JSON.parse(text));
  } catch {
    return { ...DEFAULT_PREFS };
  }
}
function hiddenNavIds(order, collapsed, aboveThirdPartyVisible = 0) {
  if (!collapsed) return [];
  const above = Number.isFinite(aboveThirdPartyVisible) ? Math.max(0, Math.floor(aboveThirdPartyVisible)) : 0;
  const ownVisible = Math.max(1, NAV_VISIBLE_WHEN_COLLAPSED - above);
  return order.slice(ownVisible);
}
function collapsedHiddenCount(orderLength, aboveThirdPartyVisible = 0) {
  const above = Number.isFinite(aboveThirdPartyVisible) ? Math.max(0, Math.floor(aboveThirdPartyVisible)) : 0;
  const ownVisible = Math.max(1, NAV_VISIBLE_WHEN_COLLAPSED - above);
  return Math.max(0, orderLength - ownVisible);
}
function reorderNavIds(order, fromId, targetId, half) {
  const next = [...order];
  const from = next.indexOf(fromId);
  if (from < 0) return next;
  next.splice(from, 1);
  const target = next.indexOf(targetId);
  if (target < 0) return [...order];
  next.splice(half === "after" ? target + 1 : target, 0, fromId);
  return next;
}
var subscribers = /* @__PURE__ */ new Set();
function readPrefs() {
  try {
    if (typeof window === "undefined" || window.localStorage === void 0) return { ...DEFAULT_PREFS };
    return decodeNavPrefs(window.localStorage.getItem(NAV_PREFS_KEY));
  } catch {
    return { ...DEFAULT_PREFS };
  }
}
function writePrefs(prefs) {
  try {
    if (typeof window === "undefined" || window.localStorage === void 0) return;
    window.localStorage.setItem(NAV_PREFS_KEY, JSON.stringify(prefs));
  } catch {
  }
}
function notify() {
  for (const fn of subscribers) fn();
}
var cacheRaw;
var cacheValue = DEFAULT_PREFS;
function snapshot() {
  let raw;
  try {
    raw = typeof window === "undefined" || window.localStorage === void 0 ? null : window.localStorage.getItem(NAV_PREFS_KEY);
  } catch {
    raw = null;
  }
  if (cacheRaw !== void 0 && cacheRaw === raw) return cacheValue;
  cacheRaw = raw;
  cacheValue = decodeNavPrefs(raw);
  return cacheValue;
}
if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
  try {
    window.addEventListener("storage", (event) => {
      const key = event.key;
      if (key !== null && key !== void 0 && key !== NAV_PREFS_KEY) return;
      notify();
    });
  } catch {
  }
}
function setNavOrder(defaultIds, order) {
  const normalized = applyNavOrder(defaultIds, [...order]);
  const current = readPrefs();
  writePrefs({ v: 1, order: isDefaultNavOrder(defaultIds, normalized) ? [] : normalized, collapsed: current.collapsed });
  notify();
}
function setNavCollapsed(collapsed) {
  const current = readPrefs();
  writePrefs({ v: 1, order: current.order, collapsed: collapsed === true });
  notify();
}
function subscribeNavPrefs(fn) {
  subscribers.add(fn);
  return () => {
    subscribers.delete(fn);
  };
}
function getServerNavPrefs() {
  return { ...DEFAULT_PREFS };
}
function useNavPrefs() {
  return (0, import_react2.useSyncExternalStore)(subscribeNavPrefs, snapshot, getServerNavPrefs);
}
var isElementVisible = (el) => {
  if (el.hasAttribute("hidden")) return false;
  if (el.getAttribute("data-nav-hidden") === "true") return false;
  const style = el.getAttribute("style");
  if (style !== null && /display\s*:\s*none/i.test(style)) return false;
  return true;
};
function countVisibleThirdPartyRowsAbove(root, thirdPartySelector = THIRD_PARTY_NAV_ROW_SELECTOR) {
  if (root === null || root === void 0) return 0;
  let nav = null;
  try {
    nav = root.querySelector(NAV_LIST_SELECTOR);
  } catch {
    nav = null;
  }
  if (nav === null) return 0;
  let rows = [];
  try {
    rows = [...root.querySelectorAll(thirdPartySelector)];
  } catch {
    rows = [];
  }
  let above = 0;
  for (const row of rows) {
    if (!isElementVisible(row)) continue;
    let before = false;
    try {
      const rel = nav.compareDocumentPosition(row);
      before = (rel & Node.DOCUMENT_POSITION_FOLLOWING) !== 0;
    } catch {
      before = false;
    }
    if (before) above += 1;
  }
  return above;
}

// src/workstation/personal-sidebar/src/client/sessionActions.tsx
var import_react3 = require("react");

// src/workstation/personal-sidebar/src/client/projectAssign.tsx
var import_dsh_client_ui_primitives = require("@deepseek-ai/dsh-client-ui-primitives");
var import_jsx_runtime2 = require("react/jsx-runtime");
var PROJECT_BRIDGE_KEY = "__dshPersonalProjects";
var PROJECT_BRIDGE_VERSION = 1;
var PROJECT_MENU_ITEM_ID = "project";
var PROJECT_MENU_ITEM_LABEL = "\u52A0\u5165\u9879\u76EE";
function bridgeUnavailableReason() {
  return "\u9879\u76EE\u6570\u636E\u6682\u4E0D\u53EF\u7528\uFF1APersonal \u5DE5\u4F5C\u53F0\u672A\u8FDE\u63A5\uFF08\u8BF7\u786E\u8BA4\u5DF2\u542F\u7528 Personal \u5DE5\u4F5C\u53F0\uFF09\u2014\u2014 \u672A\u505A\u4EFB\u4F55\u4FEE\u6539\u3002";
}
function versionMismatchReason() {
  return "\u9879\u76EE\u6570\u636E\u7248\u672C\u4E0D\u5339\u914D\uFF08\u5F53\u524D\u754C\u9762\u4E0E\u5DF2\u52A0\u8F7D\u7684\u5DE5\u4F5C\u53F0\u4E0D\u662F\u540C\u4E00\u7248\u672C\uFF09\u2014\u2014 \u672A\u505A\u4EFB\u4F55\u4FEE\u6539\u3002";
}
function probeBridge(win) {
  if (typeof win !== "object" || win === null) return { kind: "missing" };
  const b = win[PROJECT_BRIDGE_KEY];
  if (typeof b !== "object" || b === null) return { kind: "missing" };
  const need = ["list", "projectOfSession", "assignSession", "unassignSession"];
  for (const k of need) {
    if (typeof b[k] !== "function") return { kind: "missing" };
  }
  if (b.version !== PROJECT_BRIDGE_VERSION) return { kind: "badVersion", version: b.version };
  return { kind: "ready", bridge: b };
}
function probeReason(p) {
  if (p.kind === "badVersion") return versionMismatchReason();
  return bridgeUnavailableReason();
}
function hasProjectBridge(win) {
  return probeBridge(win).kind === "ready";
}
function readProjectAssignData(win, sessionId) {
  const p = probeBridge(win);
  if (p.kind !== "ready") return { ok: false, reason: probeReason(p) };
  const b = p.bridge;
  try {
    const list = b.list() ?? [];
    const cur = b.projectOfSession(sessionId);
    return { ok: true, projects: [...list], currentId: typeof cur === "string" ? cur : null };
  } catch (e) {
    return { ok: false, reason: `\u8BFB\u53D6\u9879\u76EE\u5217\u8868\u5931\u8D25\uFF1A${e instanceof Error ? e.message : String(e)}` };
  }
}
function applyProjectAssign(win, sessionId, projectId) {
  const p = probeBridge(win);
  if (p.kind !== "ready") return { ok: false, reason: probeReason(p) };
  const b = p.bridge;
  try {
    if (projectId === null) {
      return b.unassignSession(sessionId);
    }
    return b.assignSession(sessionId, projectId);
  } catch (e) {
    return { ok: false, reason: e instanceof Error ? e.message : String(e) };
  }
}
function confirmDisabled(data, draftId) {
  if (!data.ok) return true;
  if (draftId === null) return true;
  return draftId === data.currentId;
}
function ProjectAssignDialog(props) {
  const { open, sessionTitle, data, draftId, error, onPick, onConfirm, onUnassign, onClose } = props;
  const currentName = data.ok ? data.projects.find((p) => p.id === data.currentId)?.name : void 0;
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(
    import_dsh_client_ui_primitives.Modal,
    {
      open,
      onClose,
      closeLabel: "\u5173\u95ED",
      title: PROJECT_MENU_ITEM_LABEL,
      footer: /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_jsx_runtime2.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_dsh_client_ui_primitives.Button, { variant: "outline", onClick: onClose, children: "\u53D6\u6D88" }),
        data.ok && data.currentId !== null ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_dsh_client_ui_primitives.Button, { variant: "outline", onClick: onUnassign, children: "\u79FB\u51FA\u9879\u76EE" }) : null,
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_dsh_client_ui_primitives.Button, { variant: "primary", disabled: confirmDisabled(data, draftId), onClick: onConfirm, children: PROJECT_MENU_ITEM_LABEL })
      ] }),
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "dps-pp-sub", "data-dps-pp-sub": "1", children: [
          "\u4F1A\u8BDD\u300C",
          sessionTitle,
          "\u300D"
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "dps-pp-hint", "data-dps-pp-current": "1", children: !data.ok ? "\u9879\u76EE\u5F52\u5C5E\u672A\u77E5\uFF08\u6570\u636E\u6E90\u4E0D\u53EF\u7528\uFF09" : data.currentId === null ? "\u5F53\u524D\u672A\u52A0\u5165\u4EFB\u4F55\u9879\u76EE" : `\u5F53\u524D\u9879\u76EE\uFF1A${currentName ?? data.currentId}` }),
        data.ok ? data.projects.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "dps-pp-empty", "data-dps-pp-empty": "1", children: "\u6CA1\u6709\u53EF\u52A0\u5165\u7684\u9879\u76EE\uFF08\u6D3B\u8DC3\u9879\u76EE\u4E3A\u7A7A\uFF1B\u5DF2\u5C01\u5B58/\u5DF2\u5220\u9664\u7684\u9879\u76EE\u4E0D\u51FA\u73B0\u5728\u6B64\uFF0C\u8BF7\u5148\u5728\u300C\u9879\u76EE\u300D\u91CC\u65B0\u5EFA\u6216\u6062\u590D\uFF09\u3002" }) : /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "dps-pp-list", "data-dps-pp-list": "1", role: "listbox", "aria-label": "\u9009\u62E9\u9879\u76EE", children: data.projects.map((p) => {
          const isCurrent = p.id === data.currentId;
          const isPicked = p.id === draftId;
          return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(
            "button",
            {
              type: "button",
              className: `dps-pp-item${isPicked ? " is-picked" : ""}${isCurrent ? " is-current" : ""}`,
              "data-dps-pp-item": p.id,
              role: "option",
              "aria-selected": isPicked,
              onClick: () => {
                onPick(p.id);
              },
              children: [
                /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "dps-pp-glyph", "aria-hidden": "true", children: p.glyph }),
                /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "dps-pp-name", children: p.name }),
                isCurrent ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "dps-pp-badge", "data-dps-pp-badge": "1", children: "\u5F53\u524D" }) : null
              ]
            },
            p.id
          );
        }) }) : /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "dps-pp-error", "data-dps-pp-unavailable": "1", role: "alert", children: data.reason }),
        error !== null ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "dps-pp-error", "data-dps-pp-error": "1", role: "alert", children: error }) : null
      ]
    }
  );
}
function projectMenuItem() {
  return { id: PROJECT_MENU_ITEM_ID, label: PROJECT_MENU_ITEM_LABEL, icon: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_dsh_client_ui_primitives.IconProjectAddOutline16, { size: 16 }) };
}

// src/workstation/personal-sidebar/src/client/sessionActions.tsx
var import_dsh_client_ui_primitives2 = require("@deepseek-ai/dsh-client-ui-primitives");
var import_jsx_runtime3 = require("react/jsx-runtime");
var SESSION_ACTION_LABELS = {
  rename: "\u91CD\u547D\u540D",
  fork: "\u5206\u53C9\u4F1A\u8BDD",
  archive: "\u5F52\u6863\u4F1A\u8BDD"
};
var SESSION_MENU_ITEMS = [
  { id: "rename", label: SESSION_ACTION_LABELS.rename, icon: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_dsh_client_ui_primitives2.IconEditOutline16, {}) },
  { id: "fork", label: SESSION_ACTION_LABELS.fork, icon: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_dsh_client_ui_primitives2.IconBranchOutline16, {}) },
  { id: "archive", label: SESSION_ACTION_LABELS.archive, icon: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_dsh_client_ui_primitives2.IconArchiveOutline20, { size: 16 }) }
];
function SessionActionsMenu(props) {
  const { title, open, onOpenChange, onRename, onFork, onArchive, onProject } = props;
  const items = onProject === void 0 ? SESSION_MENU_ITEMS : [...SESSION_MENU_ITEMS, projectMenuItem()];
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
    import_dsh_client_ui_primitives2.Menu,
    {
      open,
      onClose: () => onOpenChange(false),
      items,
      onSelect: (id) => {
        onOpenChange(false);
        if (id === "rename") onRename();
        if (id === "fork") onFork();
        if (id === "archive") onArchive();
        if (id === PROJECT_MENU_ITEM_ID) onProject?.();
      },
      portal: true,
      closeOnPointerLeave: true,
      anchor: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
        "button",
        {
          type: "button",
          className: "dps-conv-menu-btn",
          "data-dps-conv-menu": "1",
          "aria-haspopup": "menu",
          "aria-expanded": open ? "true" : void 0,
          "aria-label": `\u4F1A\u8BDD\u201C${title}\u201D\u7684\u64CD\u4F5C`,
          onClick: (e) => {
            e.stopPropagation();
            onOpenChange(!open);
          },
          children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_dsh_client_ui_primitives2.IconEllipsisOutline16, {})
        }
      )
    }
  );
}
function SessionRenameDialog(props) {
  const { open, draft, renaming, blocked, error, onDraft, onConfirm, onClose } = props;
  const composingRef = (0, import_react3.useRef)(false);
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(
    import_dsh_client_ui_primitives2.Modal,
    {
      open,
      onClose,
      closeLabel: "\u5173\u95ED",
      title: "\u91CD\u547D\u540D\u4F1A\u8BDD",
      footer: /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_jsx_runtime3.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_dsh_client_ui_primitives2.Button, { variant: "outline", disabled: renaming, onClick: onClose, children: "\u53D6\u6D88" }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_dsh_client_ui_primitives2.Button, { variant: "primary", disabled: blocked, onClick: onConfirm, children: "\u91CD\u547D\u540D" })
      ] }),
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
          "input",
          {
            className: "dps-conv-rename-input",
            "data-dps-conv-rename-input": "1",
            value: draft,
            "aria-label": "\u4F1A\u8BDD\u540D\u79F0",
            autoFocus: true,
            disabled: renaming,
            onFocus: (e) => {
              e.target.select();
            },
            onChange: (e) => {
              onDraft(e.target.value);
            },
            onCompositionStart: () => {
              composingRef.current = true;
            },
            onCompositionEnd: () => {
              composingRef.current = false;
            },
            onKeyDown: (e) => {
              if (e.key === "Enter" && !composingRef.current) {
                e.preventDefault();
                onConfirm();
              }
            }
          }
        ),
        error !== null ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dps-conv-rename-error", "data-dps-conv-rename-error": "1", role: "alert", children: error }) : null
      ]
    }
  );
}

// src/workstation/personal-sidebar/src/client/PersonalBrowser.tsx
var import_jsx_runtime4 = require("react/jsx-runtime");
var TAB_NEW_TASK = "new-task";
var TAB_HOME = "mission-control";
var TAB_PROJECTS = "project-center";
var TAB_WORKSPACES = "workspace-center";
var TAB_RECENT = "recent";
var TAB_AGENTS = "agents";
var TAB_MEMORY = "";
var SafeBoundary = class extends import_react4.Component {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error) {
    console.warn("[dsh-personal-sidebar] PersonalBrowser crashed:", error);
  }
  render() {
    if (this.state.failed) {
      return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dps-root dps-empty", children: [
        "Personal Sidebar \u6E32\u67D3\u51FA\u9519\u3002",
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("button", { type: "button", className: "dps-link dps-link-strong", onClick: () => this.props.onFallback(), children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(SwitcherIcon, { size: 12 }),
          " \u5207\u56DE\u5B98\u65B9\u4F1A\u8BDD\u6D4F\u89C8"
        ] })
      ] });
    }
    return this.props.children;
  }
};
var ATTENTION_EVENT = "dsh:personal-attention";
var ATTENTION_REQUEST_EVENT = "dsh:personal-attention-request";
var BOARD_ENTRY_SELECTOR = "[data-dsh-taskboard-entry]";
var BOARD_OPEN_ATTR = "data-dsh-taskboard-active";
function closeBoardIfOpen() {
  try {
    if (typeof document === "undefined") return;
    const root = document.documentElement;
    if (root === null || !root.hasAttribute(BOARD_OPEN_ATTR)) return;
    const entry = document.querySelector(BOARD_ENTRY_SELECTOR);
    if (entry !== null && typeof entry.click === "function") entry.click();
  } catch {
  }
}
function parseBadge(raw) {
  if (raw === null || typeof raw !== "object") return null;
  const b = raw;
  const num = (v) => typeof v === "number" && Number.isFinite(v) && v >= 0 ? v : null;
  const total = num(b.total);
  const running = num(b.running);
  const attention = num(b.attention);
  const tone = b.tone;
  if (total === null || running === null || attention === null) return null;
  if (tone !== "attention" && tone !== "running" && tone !== "none") return null;
  return { total, running, attention, tone };
}
function adaptAttentionPayload(raw) {
  const p = raw ?? {};
  if (p.v !== 1) return null;
  const badge2 = parseBadge(p.badge);
  if (badge2 === null) return null;
  return {
    ready: p.ready === true,
    hostUp: p.hostUp === true,
    hostError: typeof p.hostError === "string" ? p.hostError : void 0,
    badge: badge2
  };
}
var NAV = [
  // 双加号修复（E4-FIX-IA-2 · MAIN NAV）：行内已渲染 PlusIcon（加号图标），
  // label 若再以「＋ 」开头 = 图标加号 + 文本加号 = 视觉“＋＋新任务”（真机投诉项）。
  // 唯一加号来源 = 图标；文案仅「新任务」。
  { id: "new-task", tab: TAB_NEW_TASK, path: "new", label: "\u65B0\u4EFB\u52A1", hint: "\u521B\u5EFA\u4E00\u4E2A\u9700\u8981\u6267\u884C\u3001\u8DDF\u8E2A\u3001\u63A7\u5236\u7684\u4EFB\u52A1\uFF08\u4E2D\u592E\u4E3B\u533A\u6253\u5F00\u5B8C\u6574 New Task Composer\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(PlusIcon, { size: 18 }), main: "new-task" },
  { id: "home", tab: TAB_HOME, path: "home", label: "\u4E3B\u9875", hint: "Mission Control\uFF1A\u6211\u73B0\u5728\u8981\u505A\u4EC0\u4E48 / AI \u5728\u505A\u4EC0\u4E48\uFF08\u4E2D\u592E\u4E3B\u533A\u6253\u5F00\u5B8C\u6574\u4E3B\u9875\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(HomeIcon, { size: 18 }), main: "home" },
  { id: "projects", tab: TAB_PROJECTS, path: "center", label: "\u9879\u76EE", hint: "\u6211\u957F\u671F\u5728\u641E\u54EA\u4E9B\u4E8B\u60C5\uFF08\u4E2D\u592E\u4E3B\u533A\u6253\u5F00 Project Center\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(FolderIcon, { size: 18 }), main: "project-center" },
  { id: "workspaces", tab: TAB_WORKSPACES, path: "center", label: "\u5DE5\u4F5C\u533A", hint: "AI \u5B9E\u9645\u5728\u54EA\u4E9B\u771F\u5B9E\u6587\u4EF6/\u76EE\u5F55\u91CC\u5DE5\u4F5C\uFF08\u4E2D\u592E\u4E3B\u533A\u6253\u5F00 Workspace Center\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(WorkspaceIcon, { size: 18 }), main: "workspace-center" },
  { id: "recent", tab: TAB_RECENT, path: "list", label: "\u6700\u8FD1", hint: "\u6700\u8FD1\u53D1\u751F\u4E86\u4EC0\u4E48\uFF08\u4E2D\u592E\u4E3B\u533A\u6253\u5F00 Recent\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(ClockIcon, { size: 18 }), main: "recent" },
  { id: "conversation", tab: "", path: "", label: "\u4F1A\u8BDD", hint: "\u56DE\u5230\u4E2D\u592E Conversation\uFF08\u5F53\u524D\u4F1A\u8BDD\uFF1B\u4F1A\u8BDD\u72B6\u6001\u7531\u5B98\u65B9\u5F15\u64CE\u4FDD\u7559\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(ChatIcon, { size: 18 }), main: "conversation" },
  // V1.2-G · Agent Center：按用户规格「会话之下」新增，且**追加在表尾**——
  // 既有行（新任务/主页/项目/工作区/最近/会话）的 id、顺序、main 目标一字未动，
  // 因此不改变任何既有跳转路径与高亮镜像（NAV_ID_OF_VIEW 亦为增量新增）。
  // 语义：会话 = 我此刻在跟谁说话；智能体 = 我有哪些能自己干活的专业主体。
  { id: "agents", tab: TAB_AGENTS, path: "center", label: "\u667A\u80FD\u4F53", hint: "\u6211\u6709\u54EA\u4E9B\u4E13\u4E1A\u667A\u80FD\u4F53\u3001\u5404\u81EA\u80FD\u5E72\u4EC0\u4E48\uFF08\u4E2D\u592E\u4E3B\u533A\u6253\u5F00 Agent Center\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(AgentIcon, { size: 18 }), main: "agent-center" },
  // V1.2-E2 · 记忆树：同样**追加在表尾**（E-1 裁定「左栏新增一条导航行」）——
  // 既有行的 id、顺序、main 目标一字未动，故不改变任何既有跳转路径与高亮镜像。
  // 语义：会话/最近看的是**官方会话真源**；记忆树看的是**跨会话记忆库**的层级结构
  // （工作区 → 会话 → 轮次），且是**只读**视图。
  { id: "memory", tab: TAB_MEMORY, path: "", label: "\u8BB0\u5FC6", hint: "\u8DE8\u4F1A\u8BDD\u8BB0\u5FC6\u7684\u5C42\u7EA7\u7ED3\u6784\uFF08\u4E2D\u592E\u4E3B\u533A\u6253\u5F00\u8BB0\u5FC6\u6811\uFF1B\u53EA\u8BFB\uFF0C\u4E0D\u6539\u8BB0\u5FC6\u5E93\uFF09", icon: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(MemoryIcon, { size: 18 }), main: "memory-tree" }
];
var NAV_ID_OF_VIEW = {
  conversation: "conversation",
  home: "home",
  // 'task-board' **有意不设**：Personal 任务板无主导航行（辅助区能力），
  // 故打开它时不高亮任何主导航行——避免用高亮暗示它是第二个 Primary Entry。
  "new-task": "new-task",
  "project-center": "projects",
  "project-detail": "projects",
  "workspace-center": "workspaces",
  recent: "recent",
  "agent-center": "agents",
  "memory-tree": "memory"
};
var NAV_ORDER_HINT = "\u62D6\u52A8\u53EF\u8C03\u6574\u987A\u5E8F\uFF08\u53EA\u5F71\u54CD\u672C\u673A\u663E\u793A\u987A\u5E8F\uFF0C\u4E0D\u6539\u53D8\u4EFB\u4F55\u6570\u636E\uFF09";
var NAV_TOGGLE_COLLAPSE = "\u6536\u8D77";
var NAV_TOGGLE_EXPAND = "\u5C55\u5F00";
var NAV_RESTORE_DEFAULT = "\u6062\u590D\u9ED8\u8BA4\u987A\u5E8F";
function navDropHalf(target, clientY) {
  if (typeof clientY !== "number" || !Number.isFinite(clientY)) return "before";
  const rect = typeof target.getBoundingClientRect === "function" ? target.getBoundingClientRect() : null;
  const height = rect?.height ?? 0;
  const effective = height > 0 ? height : 36;
  const top = rect !== null && height > 0 ? rect.top : 0;
  return clientY < top + effective / 2 ? "before" : "after";
}
function navDragFromId(event) {
  const dt = event.dataTransfer ?? null;
  try {
    const raw = dt?.getData?.("application/x-dps-nav") ?? dt?.getData?.("text/plain") ?? "";
    if (typeof raw === "string" && raw.startsWith("dps-nav:")) return raw.slice("dps-nav:".length);
  } catch {
  }
  return NAV_DRAG_FROM;
}
var NAV_DRAG_FROM = "";
var NAV_DRAG_GUARD_MS = 250;
function PersonalBrowser(props) {
  const { wide, expandSidebar, switchOfficial, betterSidebar, conversations, pending } = props;
  const [attention, setAttention] = (0, import_react4.useState)(null);
  const [notice, setNotice] = (0, import_react4.useState)(null);
  const [activeNavId, setActiveNavId] = (0, import_react4.useState)(null);
  const navPrefs = useNavPrefs();
  const navCollapsed = navPrefs.collapsed === true;
  const [thirdPartyAbove, setThirdPartyAbove] = (0, import_react4.useState)(0);
  const navWrapRef = (0, import_react4.useRef)(null);
  const dragState = (0, import_react4.useRef)(null);
  const [dragFrom, setDragFrom] = (0, import_react4.useState)(null);
  const dragEndAt = (0, import_react4.useRef)(0);
  const [dropMark, setDropMark] = (0, import_react4.useState)(null);
  const [convSnap, setConvSnap] = (0, import_react4.useState)({ rows: [], ready: false });
  const [archiveKnownNow, setArchiveKnownNow] = (0, import_react4.useState)({ known: false, ids: /* @__PURE__ */ new Set() });
  const [convExpanded, setConvExpanded] = (0, import_react4.useState)(false);
  const [convNow, setConvNow] = (0, import_react4.useState)(() => Date.now());
  const [convBackground, setConvBackground] = (0, import_react4.useState)(UNKNOWN_BACKGROUND);
  const [backgroundShow, setBackgroundShow] = (0, import_react4.useState)(false);
  (0, import_react4.useEffect)(() => {
    const reader = createLedgerReader();
    return reader.start((next) => {
      setConvBackground((prev) => sameBackgroundTruth(prev, next) ? prev : next);
    });
  }, []);
  const [interrupts, setInterrupts] = (0, import_react4.useState)(UNKNOWN_INTERRUPTS);
  (0, import_react4.useEffect)(() => {
    const reader = createInterruptReader();
    return reader.start((next) => {
      setInterrupts((prev) => sameInterruptTruth(prev, next) ? prev : next);
    });
  }, []);
  (0, import_react4.useEffect)(() => {
    if (typeof document === "undefined") return;
    const climb = (start) => {
      let node = start;
      let best = start;
      for (let i = 0; i < 6 && node !== null; i += 1) {
        best = node;
        if (typeof node.querySelector === "function" && node.querySelector(THIRD_PARTY_NAV_ROW_SELECTOR) !== null) break;
        node = node.parentElement;
      }
      return best;
    };
    const root = climb(navWrapRef.current?.parentElement ?? null);
    if (root === null) return;
    const measure = () => {
      const above = countVisibleThirdPartyRowsAbove(root);
      setThirdPartyAbove((prev) => prev === above ? prev : above);
    };
    measure();
    if (typeof MutationObserver === "undefined") return;
    const observer = new MutationObserver(measure);
    observer.observe(root, { childList: true, subtree: true });
    return () => {
      observer.disconnect();
    };
  }, []);
  (0, import_react4.useEffect)(() => {
    if (typeof document === "undefined") return;
    const doc = document;
    const clearIfStale = (event) => {
      const target = event.target;
      if (target instanceof Element && target.closest(NAV_ROW_SELECTOR) !== null) return;
      if (dragState.current !== null) {
        dragState.current = null;
        setDragFrom(null);
        setDropMark(null);
      }
    };
    doc.addEventListener("drop", clearIfStale);
    return () => {
      doc.removeEventListener("drop", clearIfStale);
    };
  }, []);
  const [pendingBySession, setPendingBySession] = (0, import_react4.useState)(
    () => /* @__PURE__ */ new Map()
  );
  const [convTrack, setConvTrack] = (0, import_react4.useState)(EMPTY_COMPLETION_TRACK);
  (0, import_react4.useEffect)(() => {
    if (pending === null || pending === void 0) {
      setPendingBySession((prev) => prev.size === 0 ? prev : /* @__PURE__ */ new Map());
      return;
    }
    let disposed = false;
    let timer = null;
    let tries = 0;
    let off = null;
    const apply2 = (next) => {
      setPendingBySession((prev) => samePendingSessions(prev, next) ? prev : next);
    };
    const attach = () => {
      if (disposed) return;
      let snap;
      try {
        snap = pending.getSnapshot();
      } catch {
        snap = void 0;
      }
      if (snap === void 0 || snap === null) {
        if (tries < PENDING_ATTACH_TRIES) {
          tries += 1;
          timer = window.setTimeout(attach, PENDING_ATTACH_MS);
        }
        return;
      }
      apply2(pendingSessions(snap));
      try {
        off = pending.subscribe(() => {
          if (disposed) return;
          let live;
          try {
            live = pending.getSnapshot();
          } catch {
            return;
          }
          if (live === void 0 || live === null) return;
          apply2(pendingSessions(live));
        });
      } catch {
        off = null;
      }
    };
    attach();
    return () => {
      disposed = true;
      if (timer !== null) window.clearTimeout(timer);
      try {
        off?.();
      } catch {
      }
    };
  }, [pending]);
  const [menuOpenId, setMenuOpenId] = (0, import_react4.useState)(null);
  const [renameTarget, setRenameTarget] = (0, import_react4.useState)(null);
  const [renameDraft, setRenameDraft] = (0, import_react4.useState)("");
  const [renaming, setRenaming] = (0, import_react4.useState)(false);
  const [renameError, setRenameError] = (0, import_react4.useState)(null);
  const [projectTarget, setProjectTarget] = (0, import_react4.useState)(null);
  const [projectData, setProjectData] = (0, import_react4.useState)(null);
  const [projectDraftId, setProjectDraftId] = (0, import_react4.useState)(null);
  const [projectError, setProjectError] = (0, import_react4.useState)(null);
  const noticeTimer = (0, import_react4.useRef)(null);
  const navSeq = (0, import_react4.useRef)(0);
  const sendCleanupRef = (0, import_react4.useRef)(null);
  (0, import_react4.useEffect)(() => {
    if (conversations === null || conversations === void 0) return;
    const read = () => {
      try {
        const snap = parseConversations(conversations.getSnapshot());
        setConvSnap(snap);
      } catch {
        setConvSnap({ rows: [], ready: false });
      }
      try {
        setArchiveKnownNow(archiveTruthOf(conversations.archive()));
      } catch {
        setArchiveKnownNow({ known: false, ids: /* @__PURE__ */ new Set() });
      }
    };
    read();
    let off = null;
    try {
      off = conversations.subscribe(read);
    } catch {
      off = null;
    }
    let offArchive = null;
    const ensureArchiveSub = () => {
      if (offArchive !== null) return true;
      try {
        offArchive = conversations.subscribeArchive(read);
      } catch {
        offArchive = null;
      }
      return offArchive !== null;
    };
    ensureArchiveSub();
    let tries = 0;
    const timer = setInterval(() => {
      tries += 1;
      read();
      if (ensureArchiveSub() || tries >= 24) clearInterval(timer);
    }, 500);
    return () => {
      try {
        off?.();
      } catch {
      }
      try {
        offArchive?.();
      } catch {
      }
      clearInterval(timer);
    };
  }, [conversations]);
  (0, import_react4.useEffect)(() => {
    const t = setInterval(() => setConvNow(Date.now()), 6e4);
    return () => clearInterval(t);
  }, []);
  (0, import_react4.useEffect)(() => {
    if (typeof window === "undefined") return;
    const onUnavailable = (ev) => {
      try {
        const detail = ev.detail;
        const view = typeof detail?.view === "string" ? detail.view : null;
        const label = view !== null ? MAIN_VIEW_TITLES[view] ?? view : "\u8BE5\u9875\u9762";
        const reason = typeof detail?.reason === "string" ? detail.reason : "\u4E2D\u592E\u4E3B\u533A\u5C1A\u672A\u5C31\u7EEA";
        showNotice(`\u300C${label}\u300D\u672A\u80FD\u6253\u5F00\uFF1A${reason}\u3002\u8BF7\u7A0D\u5019\u91CD\u8BD5\u3002`);
        setActiveNavId(null);
      } catch {
      }
    };
    const onState = (ev) => {
      try {
        const view = ev.detail?.view;
        if (typeof view !== "string") return;
        setActiveNavId(NAV_ID_OF_VIEW[view] ?? null);
      } catch {
      }
    };
    try {
      window.addEventListener(MAIN_STATE_EVENT, onState);
      window.addEventListener(MAIN_UNAVAILABLE_EVENT, onUnavailable);
      return () => {
        try {
          window.removeEventListener(MAIN_STATE_EVENT, onState);
          window.removeEventListener(MAIN_UNAVAILABLE_EVENT, onUnavailable);
        } catch {
        }
      };
    } catch {
      return;
    }
  }, []);
  (0, import_react4.useEffect)(
    () => () => {
      if (noticeTimer.current) {
        try {
          clearTimeout(noticeTimer.current);
        } catch {
        }
      }
      if (sendCleanupRef.current) {
        try {
          const c = sendCleanupRef.current;
          sendCleanupRef.current = null;
          c();
        } catch {
        }
      }
    },
    []
  );
  (0, import_react4.useEffect)(() => {
    if (typeof window === "undefined") return;
    let alive = true;
    const onAttention = (ev) => {
      try {
        const next = adaptAttentionPayload(ev.detail);
        if (next === null) return;
        if (alive) setAttention(next);
      } catch {
      }
    };
    try {
      window.addEventListener(ATTENTION_EVENT, onAttention);
    } catch {
      return;
    }
    try {
      window.dispatchEvent(new CustomEvent(ATTENTION_REQUEST_EVENT));
    } catch {
    }
    return () => {
      alive = false;
      try {
        window.removeEventListener(ATTENTION_EVENT, onAttention);
      } catch {
      }
    };
  }, []);
  (0, import_react4.useEffect)(() => {
    if (typeof document === "undefined") return;
    let observer = null;
    let disposed = false;
    const TONE = {
      // 红 = 需要你介入 / 已失败（盖过橙）
      attention: { bg: "rgba(229,100,106,.18)", fg: "#e5646a", border: "rgba(229,100,106,.45)" },
      // 橙 = 正在运作
      running: { bg: "rgba(240,180,60,.18)", fg: "#e8b64c", border: "rgba(240,180,60,.4)" }
    };
    const paint = () => {
      if (disposed) return;
      const row = document.querySelector(BOARD_ENTRY_SELECTOR);
      if (row === null || row === void 0) return;
      const existing = row.querySelector("[data-dps-attn-badge]");
      const badge2 = attention !== null && attention.hostUp ? attention.badge : null;
      const n = badge2 !== null && badge2.tone !== "none" ? badge2.total : null;
      if (n === null || n <= 0) {
        if (existing !== null) existing.remove();
        return;
      }
      const phrase = badge2 !== null && badge2.attention > 0 && badge2.running > 0 ? `\u9700\u8981\u4F60\u4ECB\u5165 ${badge2.attention} \u9879 \xB7 \u8FD0\u4F5C\u4E2D ${badge2.running} \u9879` : badge2 !== null && badge2.attention > 0 ? `\u9700\u8981\u4F60\u4ECB\u5165 ${badge2.attention} \u9879\uFF08\u5931\u8D25 / \u9700\u6743\u9650\u786E\u8BA4 / \u5BBF\u4E3B\u9519\u8BEF\uFF09` : `\u8FD0\u4F5C\u4E2D ${badge2?.running ?? n} \u9879`;
      const tone = TONE[badge2?.tone === "attention" ? "attention" : "running"];
      const style = `margin-left:auto;flex:none;min-width:18px;height:18px;padding:0 5px;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;line-height:18px;background:${tone.bg};color:${tone.fg};border:1px solid ${tone.border}`;
      if (existing !== null) {
        if (existing.textContent !== String(n)) existing.textContent = String(n);
        existing.setAttribute("data-dps-attn-tone", badge2?.tone ?? "none");
        if (existing.getAttribute("title") !== phrase) existing.setAttribute("title", phrase);
        if (existing.getAttribute("style") !== style) existing.setAttribute("style", style);
        return;
      }
      const el = document.createElement("span");
      el.setAttribute("data-dps-attn-badge", "1");
      el.setAttribute("data-dps-attn-tone", badge2?.tone ?? "none");
      el.textContent = String(n);
      el.title = phrase;
      el.style.cssText = style;
      try {
        row.appendChild(el);
      } catch {
      }
    };
    paint();
    const root = document.body;
    if (root !== null && root !== void 0 && typeof MutationObserver === "function") {
      observer = new MutationObserver(() => paint());
      observer.observe(root, { childList: true, subtree: true });
    }
    return () => {
      disposed = true;
      try {
        observer?.disconnect();
      } catch {
      }
      try {
        document.querySelector("[data-dps-attn-badge]")?.remove();
      } catch {
      }
    };
  }, [attention]);
  (0, import_react4.useEffect)(() => {
    if (typeof document === "undefined") return;
    let observer = null;
    let disposed = false;
    const paint = () => {
      if (disposed) return;
      const row = document.querySelector(BOARD_ENTRY_SELECTOR);
      if (row === null || row === void 0) return;
      const existing = row.querySelector("[data-dps-int-badge]");
      const n = interrupts.known ? interrupts.unreadTasks : null;
      if (n === null || n <= 0) {
        if (existing !== null) existing.remove();
        return;
      }
      const phrase = `\u6709 ${n} \u4E2A\u4EFB\u52A1\u88AB\u5FEB\u901F\u505C\u6B62\u3001\u4F60\u8FD8\u6CA1\u770B\u8FC7`;
      const style = "flex:none;margin-left:6px;min-width:18px;height:18px;padding:0 5px;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;line-height:18px;background:rgba(160,107,255,.18);color:#a06bff;border:1px solid rgba(160,107,255,.45)";
      if (existing !== null) {
        if (existing.textContent !== String(n)) existing.textContent = String(n);
        if (existing.getAttribute("title") !== phrase) existing.setAttribute("title", phrase);
        if (existing.getAttribute("style") !== style) existing.setAttribute("style", style);
        return;
      }
      const el = document.createElement("span");
      el.setAttribute("data-dps-int-badge", "1");
      el.textContent = String(n);
      el.title = phrase;
      el.style.cssText = style;
      try {
        row.appendChild(el);
      } catch {
      }
    };
    paint();
    const root = document.body;
    if (root !== null && root !== void 0 && typeof MutationObserver === "function") {
      observer = new MutationObserver(() => paint());
      observer.observe(root, { childList: true, subtree: true });
    }
    return () => {
      disposed = true;
      try {
        observer?.disconnect();
      } catch {
      }
      try {
        document.querySelector("[data-dps-int-badge]")?.remove();
      } catch {
      }
    };
  }, [interrupts]);
  (0, import_react4.useEffect)(() => {
    const watcher = createTaskDetailReadWatcher({
      // 成功才清点：宿主确认（200）⇒ 乐观翻掉未读位；404（该任务本就没有中断记录）
      // 与 5xx/网络失败都**不清**，等下一轮真源刷新 —— 宁可暂时不消，也不谎报已读。
      onCleared: (taskId) => {
        setInterrupts((prev) => clearUnread(prev, "task", taskId));
      }
    });
    return () => {
      watcher.stop();
    };
  }, []);
  const showNotice = (text) => {
    setNotice(text);
    if (noticeTimer.current) {
      try {
        clearTimeout(noticeTimer.current);
      } catch {
      }
    }
    if (typeof window !== "undefined" && typeof window.setTimeout === "function") {
      noticeTimer.current = window.setTimeout(() => setNotice(null), 3200);
    }
  };
  const handleUnavailable = (item, reason) => {
    diagTrace("main-unavailable", { nav: item.id, detail: reason });
    setActiveNavId((prev) => prev === item.id ? null : prev);
    showNotice(
      `\u300C${item.label}\u300D\u662F\u4E2D\u592E\u4E3B\u533A\u9875\u9762\uFF1A\u5F53\u524D${reason}\u3002\u8BF7\u7A0D\u5019\u91CD\u8BD5\uFF1B\u82E5\u6301\u7EED\u4E0D\u53EF\u7528\uFF0C\u8BF7\u786E\u8BA4 Personal \u5DE5\u4F5C\u53F0\u63D2\u4EF6\u5DF2\u542F\u7528\u540E\u91CD\u65B0\u6253\u5F00\u7A97\u53E3\uFF08\u672C\u63D2\u4EF6\u4E0D\u518D\u5728\u8F85\u52A9\u9762\u677F\u63D0\u4F9B\u91CD\u590D\u9875\u9762\uFF09\u3002`
    );
  };
  const sendMain = (view, item, seq) => {
    if (typeof window === "undefined") return;
    closeBoardIfOpen();
    const t0 = Date.now();
    if (sendCleanupRef.current) {
      try {
        const c = sendCleanupRef.current;
        sendCleanupRef.current = null;
        c();
      } catch {
        sendCleanupRef.current = null;
      }
    }
    let hostReady = false;
    try {
      hostReady = window.__dshPersonalMainReady === true;
    } catch {
      hostReady = false;
    }
    diagTrace("main-click", { nav: item.id, view, detail: `hostReady=${hostReady} seq=${seq}` });
    setActiveNavId(item.id);
    const stale = () => seq !== navSeq.current;
    const cancelPending = () => {
      if (sendCleanupRef.current) {
        try {
          const c = sendCleanupRef.current;
          sendCleanupRef.current = null;
          c();
        } catch {
          sendCleanupRef.current = null;
        }
      }
    };
    const fallbackToAux = (reason) => {
      if (stale()) return;
      diagTrace("main-unavailable", { nav: item.id, view, detail: reason, ms: Date.now() - t0 });
      setActiveNavId((prev) => prev === item.id ? null : prev);
      if (view === "conversation") {
        showNotice("\u65E0\u6CD5\u5207\u6362\u5230\u4E2D\u592E\u4F1A\u8BDD\uFF1APersonal \u5DE5\u4F5C\u53F0\u672A\u8FDE\u63A5\uFF08\u8BF7\u786E\u8BA4\u5DF2\u542F\u7528 Personal \u5DE5\u4F5C\u53F0\uFF09\u3002");
        return;
      }
      showNotice(`\u4E2D\u592E\u4E3B\u533A\u6682\u4E0D\u53EF\u7528\uFF08${reason}\uFF09\u2014\u2014\u300C${item.label}\u300D\u4E0D\u518D\u63D0\u4F9B\u8F85\u52A9\u9762\u677F\u590D\u5236\u54C1\uFF0C\u8BF7\u7A0D\u5019\u91CD\u8BD5\u3002`);
    };
    const markOk = (detail) => {
      if (stale()) return;
      diagTrace("main-ok", { nav: item.id, view, detail, ms: Date.now() - t0 });
      cancelPending();
    };
    let acked = false;
    const onAck = (ev) => {
      try {
        const detail = ev.detail;
        if (detail?.view !== view || acked) return;
        acked = true;
        diagTrace("main-ack", {
          nav: item.id,
          view,
          detail: `ok=${detail?.ok === true} seat=${detail?.seatPriority ?? "\u2014"}`,
          ms: Date.now() - t0
        });
        if (detail?.ok !== true) {
          try {
            window.removeEventListener(MAIN_ACK_EVENT, onAck);
          } catch {
          }
          cancelPending();
          fallbackToAux("\u4E2D\u592E\u4E3B\u533A seat \u6CE8\u518C\u5931\u8D25");
        }
      } catch {
      }
    };
    const checkMainDom = () => {
      if (typeof document === "undefined") return "no-dom";
      const host = document.querySelector('[data-dsh-main-host="1"]');
      if (!host) return "absent";
      if (host.getAttribute("data-dsh-main-error") === "1") return "error";
      return host.getAttribute("data-dsh-main-view") ?? "unknown";
    };
    const verifyTarget = (expected, attempt) => {
      if (stale()) return;
      const actual = checkMainDom();
      const ok = expected === "conversation" ? actual === "absent" || actual === "no-dom" : actual === expected;
      if (ok) {
        markOk(`verified data-dsh-main-view=${actual} (attempt ${attempt + 1})`);
        return;
      }
      if (attempt >= 1) {
        diagTrace("main-verify-fail", {
          nav: item.id,
          view,
          detail: `expected ${expected}, got ${actual}`,
          ms: Date.now() - t0
        });
        cancelPending();
        if (actual === "error") {
          fallbackToAux("\u4E2D\u592E\u4E3B\u533A\u89C6\u56FE\u6E32\u67D3\u5D29\u6E83\uFF08\u8BE6\u89C1\u8BCA\u65AD\u65E5\u5FD7\uFF09");
          return;
        }
        let hostNow = false;
        try {
          hostNow = window.__dshPersonalMainReady === true;
        } catch {
          hostNow = false;
        }
        fallbackToAux(
          actual === "absent" && !hostNow ? "Personal \u5DE5\u4F5C\u53F0\u5BBF\u4E3B\u672A\u8FD0\u884C\uFF08\u8BF7\u786E\u8BA4\u5DF2\u542F\u7528\u540E\u91CD\u8BD5\uFF09" : expected === "conversation" ? "\u4E2D\u592E\u4E3B\u533A\u4ECD\u88AB Personal \u89C6\u56FE\u5360\u7528" : `\u4E2D\u592E\u4E3B\u533A\u672A\u663E\u793A\u300C${item.label}\u300D\uFF08\u5B9E\u9645 ${actual}\uFF09`
        );
        return;
      }
      window.setTimeout(() => verifyTarget(expected, attempt + 1), 330);
    };
    const arm = () => {
      const tVerify = window.setTimeout(() => verifyTarget(view, 0), 120);
      sendCleanupRef.current = () => {
        try {
          window.clearTimeout(tVerify);
        } catch {
        }
        try {
          window.removeEventListener(MAIN_ACK_EVENT, onAck);
        } catch {
        }
      };
    };
    try {
      window.addEventListener(MAIN_ACK_EVENT, onAck);
    } catch {
    }
    try {
      window.dispatchEvent(new CustomEvent(MAIN_OPEN_EVENT, { detail: { view } }));
    } catch {
      try {
        window.removeEventListener(MAIN_ACK_EVENT, onAck);
      } catch {
      }
      cancelPending();
      fallbackToAux("\u4E8B\u4EF6\u6D3E\u53D1\u5931\u8D25");
      return;
    }
    arm();
  };
  const convArchive = archiveKnownNow;
  const convVisible = visibleConversations(convSnap, convArchive);
  const convFiltered = filterBackgroundSessions(convVisible, convBackground, backgroundShow);
  const convRows = convFiltered.rows;
  const convModel = conversationListModel(convRows, convArchive, convExpanded, DEFAULT_VISIBLE);
  const convRunSig = convRows.map((r) => `${r.id}:${r.running === true ? "1" : "0"}`).join("|");
  (0, import_react4.useEffect)(() => {
    setConvTrack((prev) => trackUnseenCompletions(prev, convRows, pendingBySession));
  }, [convRunSig, pendingBySession]);
  const go = (item) => {
    if (dragEndAt.current > 0 && Date.now() - dragEndAt.current <= NAV_DRAG_GUARD_MS) return;
    dragEndAt.current = 0;
    navSeq.current += 1;
    const seq = navSeq.current;
    if (!wide) expandSidebar();
    if (item.main) {
      sendMain(item.main, item, seq);
      return;
    }
    handleUnavailable(item, "\u8BE5\u5165\u53E3\u4E0D\u662F\u4E2D\u592E\u4E3B\u533A\u9875\u9762");
  };
  const goHome = () => {
    const item = NAV.find((n) => n.id === "home");
    if (item) go(item);
  };
  const navOrderIds = applyNavOrder(NAV.map((n) => n.id), navPrefs.order);
  const navById = new Map(NAV.map((n) => [n.id, n]));
  const navItems = navOrderIds.map((id) => navById.get(id)).filter(Boolean);
  const navHidden = new Set(hiddenNavIds(navOrderIds, navCollapsed, thirdPartyAbove));
  const navOwnHiddenCount = collapsedHiddenCount(navOrderIds.length, thirdPartyAbove);
  const navOrderCustom = navPrefs.order.length > 0;
  const navAriaLabelOrder = navItems.filter((n) => !navHidden.has(n.id)).map((n) => n.label).join("\u3001");
  const navDropIndex = (targetId, half) => {
    const others = navItems.filter((n) => n.id !== dragFrom).map((n) => n.id);
    const at = others.indexOf(targetId);
    return at < 0 ? others.length : half === "after" ? at + 1 : at;
  };
  const handleNavDragStart = (event, item) => {
    NAV_DRAG_FROM = item.id;
    dragEndAt.current = 0;
    dragState.current = null;
    setDropMark(null);
    setDragFrom(item.id);
    try {
      event.dataTransfer?.setData("application/x-dps-nav", `dps-nav:${item.id}`);
      event.dataTransfer?.setData("text/plain", `dps-nav:${item.id}`);
      if (event.dataTransfer) event.dataTransfer.effectAllowed = "move";
    } catch {
    }
  };
  const handleNavDragOver = (event, item) => {
    const from = dragState.current?.from ?? dragFrom ?? NAV_DRAG_FROM;
    if (from === "" || from === item.id) {
      setDropMark(null);
      return;
    }
    event.preventDefault();
    try {
      if (event.dataTransfer) event.dataTransfer.dropEffect = "move";
    } catch {
    }
    const half = navDropHalf(event.currentTarget, event.clientY);
    dragState.current = { from, target: item.id, half };
    setDropMark((prev) => prev !== null && prev.target === item.id && prev.half === half ? prev : { target: item.id, half });
  };
  const handleNavDrop = (event, item) => {
    event.preventDefault();
    const from = navDragFromId(event);
    const half = dragState.current?.half ?? navDropHalf(event.currentTarget, event.clientY);
    dragState.current = { from, target: item.id, half };
    setDropMark({ target: item.id, half });
  };
  const handleNavDragEnd = () => {
    const state = dragState.current;
    dragState.current = null;
    setDragFrom(null);
    setDropMark(null);
    if (state !== null) dragEndAt.current = Date.now();
    if (state === null) return;
    if (state.from === state.target) return;
    const next = reorderNavIds(navOrderIds, state.from, state.target, state.half);
    if (next.join("|") === navOrderIds.join("|")) return;
    setNavOrder(NAV.map((n) => n.id), next);
  };
  const restoreNavOrder = () => {
    setNavOrder(NAV.map((n) => n.id), NAV.map((n) => n.id));
  };
  const toggleNavCollapsed = () => {
    setNavCollapsed(!navCollapsed);
  };
  const goConversationIfOccupied = () => {
    if (typeof document === "undefined") return;
    if (document.querySelector('[data-dsh-main-host="1"]') === null) return;
    const item = NAV.find((n) => n.id === "conversation");
    if (item) go(item);
  };
  const openConversationRow = (sessionId) => {
    closeBoardIfOpen();
    goConversationIfOccupied();
    try {
      conversations?.open(sessionId);
    } catch {
      showNotice("\u6253\u5F00\u4F1A\u8BDD\u5931\u8D25\uFF1A\u5B98\u65B9 sessions.open \u8C03\u7528\u5F02\u5E38\u3002");
    }
  };
  const renameTrimmed = renameDraft.trim();
  const renameBlocked = renaming || renameTrimmed === "" || renameTarget === null;
  const beginSessionRename = (row) => {
    setRenameTarget({ id: row.id, title: row.title });
    setRenameDraft(row.title);
    setRenameError(null);
  };
  const closeSessionRename = () => {
    if (renaming) return;
    setRenameTarget(null);
    setRenameError(null);
  };
  const confirmSessionRename = () => {
    if (renameBlocked || renameTarget === null) return;
    const handle = conversations;
    if (handle === null || handle === void 0 || typeof handle.rename !== "function") {
      setRenameError("\u5B98\u65B9\u4F1A\u8BDD\u670D\u52A1\u672A\u5C31\u7EEA\uFF08sessions.rename \u4E0D\u53EF\u8FBE\uFF09\u2014\u2014 \u672A\u505A\u4EFB\u4F55\u4FEE\u6539\u3002");
      return;
    }
    setRenaming(true);
    setRenameError(null);
    void handle.rename(renameTarget.id, renameTrimmed).then(() => {
      setRenaming(false);
      setRenameTarget(null);
    }).catch((reason) => {
      setRenaming(false);
      setRenameError(reason instanceof Error ? reason.message : String(reason));
    });
  };
  const beginProjectAssign = (row) => {
    setProjectTarget({ id: row.id, title: row.title });
    setProjectData(readProjectAssignData(typeof window === "undefined" ? null : window, row.id));
    setProjectDraftId(null);
    setProjectError(null);
  };
  const closeProjectAssign = () => {
    setProjectTarget(null);
    setProjectData(null);
    setProjectDraftId(null);
    setProjectError(null);
  };
  const confirmProjectAssign = () => {
    if (projectTarget === null || projectData === null || !projectData.ok) return;
    const projectId = projectDraftId;
    if (projectId === null) return;
    const name = projectData.projects.find((p) => p.id === projectId)?.name ?? projectId;
    const r = applyProjectAssign(typeof window === "undefined" ? null : window, projectTarget.id, projectId);
    if (r.ok) {
      closeProjectAssign();
      showNotice(`\u5DF2\u628A\u4F1A\u8BDD\u300C${projectTarget.title}\u300D\u52A0\u5165\u9879\u76EE\u300C${name}\u300D\u3002`);
      return;
    }
    setProjectError(r.reason ?? "\u5199\u5165\u5931\u8D25\uFF08\u672A\u77E5\u539F\u56E0\uFF09");
  };
  const unassignProjectAssign = () => {
    if (projectTarget === null || projectData === null || !projectData.ok) return;
    const r = applyProjectAssign(typeof window === "undefined" ? null : window, projectTarget.id, null);
    if (r.ok) {
      const title = projectTarget.title;
      closeProjectAssign();
      showNotice(`\u5DF2\u628A\u4F1A\u8BDD\u300C${title}\u300D\u79FB\u51FA\u9879\u76EE\u3002`);
      return;
    }
    setProjectError(r.reason ?? "\u5199\u5165\u5931\u8D25\uFF08\u672A\u77E5\u539F\u56E0\uFF09");
  };
  const forkSessionRow = (row) => {
    const handle = conversations;
    if (handle === null || handle === void 0 || typeof handle.fork !== "function") {
      showNotice("\u5206\u53C9\u4F1A\u8BDD\u5931\u8D25\uFF1A\u5B98\u65B9\u4F1A\u8BDD\u670D\u52A1\u672A\u5C31\u7EEA\uFF08sessions.fork \u4E0D\u53EF\u8FBE\uFF09\u3002");
      return;
    }
    void handle.fork(row.id).then((childId) => {
      openConversationRow(childId);
    }).catch((reason) => {
      showNotice(`\u5206\u53C9\u4F1A\u8BDD\u5931\u8D25\uFF1A${reason instanceof Error ? reason.message : String(reason)}`);
    });
  };
  const archiveSessionRow = (row) => {
    const handle = conversations;
    if (handle === null || handle === void 0 || typeof handle.archiveSession !== "function") {
      showNotice("\u5F52\u6863\u4F1A\u8BDD\u5931\u8D25\uFF1A\u5B98\u65B9 workspaces \u670D\u52A1\u672A\u5C31\u7EEA\uFF08archiveSession \u4E0D\u53EF\u8FBE\uFF09\u3002");
      return;
    }
    void handle.archiveSession(row.id).then(() => {
    }).catch((reason) => {
      showNotice(`\u5F52\u6863\u4F1A\u8BDD\u5931\u8D25\uFF1A${reason instanceof Error ? reason.message : String(reason)}`);
    });
  };
  return /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(SafeBoundary, { onFallback: switchOfficial, children: !wide ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dps-rail", "data-dps-nav-rail": "1", children: [
    NAV.map((n) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
      "button",
      {
        type: "button",
        className: "dps-rail-btn",
        title: n.hint,
        onClick: () => go(n),
        "data-nav": n.id,
        "data-active": activeNavId === n.id ? "true" : void 0,
        children: n.icon
      },
      n.id
    )),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { style: { flex: 1 } }),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("button", { type: "button", className: "dps-rail-btn", title: "\u5207\u56DE\u5B98\u65B9\u4F1A\u8BDD\u6D4F\u89C8", onClick: switchOfficial, children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(SwitcherIcon, { size: 15 }) })
  ] }) : /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dps-root", "data-dps-nav": "1", "data-dps-nav-collapsed": navCollapsed ? "true" : "false", children: [
    /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(
      "div",
      {
        className: "dps-navwrap",
        "data-dps-nav-wrap": "1",
        ref: navWrapRef,
        "data-dps-nav-visible-limit": String(NAV_VISIBLE_WHEN_COLLAPSED),
        "data-dps-nav-third-party-above": String(thirdPartyAbove),
        "data-dps-nav-hidden-count": String(navOwnHiddenCount),
        "data-dps-nav-order-custom": navOrderCustom ? "true" : "false",
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dps-nav", "aria-label": `\u4E3B\u5BFC\u822A\uFF08\u5F53\u524D\u53EF\u89C1\uFF1A${navAriaLabelOrder || "\u65E0"}\uFF09`, children: navItems.map((n) => {
            const isHidden = navHidden.has(n.id);
            const isDropTarget = dropMark !== null && dropMark.target === n.id;
            return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(
              "button",
              {
                type: "button",
                className: "dps-nav-item",
                "data-nav": n.id,
                "data-active": activeNavId === n.id ? "true" : void 0,
                "data-nav-hidden": isHidden ? "true" : void 0,
                "data-nav-index": String(navOrderIds.indexOf(n.id)),
                "data-nav-dragging": dragFrom === n.id ? "true" : void 0,
                "data-nav-drop": isDropTarget ? dropMark.half : void 0,
                title: `${n.hint}${navCollapsed ? "" : `
${NAV_ORDER_HINT}`}`,
                draggable: "true",
                "aria-grabbed": dragFrom === n.id ? "true" : void 0,
                onClick: () => go(n),
                onDragStart: (event) => handleNavDragStart(event, n),
                onDragOver: (event) => handleNavDragOver(event, n),
                onDrop: (event) => handleNavDrop(event, n),
                onDragEnd: handleNavDragEnd,
                children: [
                  n.icon,
                  /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { children: n.label })
                ]
              },
              n.id
            );
          }) }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dps-nav-ctl", "data-dps-nav-ctl": "1", children: [
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
              "button",
              {
                type: "button",
                className: "dps-nav-ctl-btn",
                "data-dps-nav-toggle": navCollapsed ? "collapsed" : "expanded",
                "aria-expanded": navCollapsed ? "false" : "true",
                title: navCollapsed ? `\u5C55\u5F00\u5168\u90E8\u5BFC\u822A\u884C\uFF08\u5F53\u524D\u53EA\u663E\u793A\u4E0A\u9762 ${NAV_VISIBLE_WHEN_COLLAPSED} \u884C\uFF0C\u542B\u7B2C\u4E09\u65B9\u300C\u4EFB\u52A1\u770B\u677F\u300D\u5165\u53E3\uFF09` : `\u6536\u8D77\u5BFC\u822A\u884C\uFF08\u53EA\u4FDD\u7559\u4E0A\u9762 ${NAV_VISIBLE_WHEN_COLLAPSED} \u884C\uFF09`,
                onClick: toggleNavCollapsed,
                children: navCollapsed ? NAV_TOGGLE_EXPAND : NAV_TOGGLE_COLLAPSE
              }
            ),
            navOrderCustom ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
              "button",
              {
                type: "button",
                className: "dps-nav-ctl-btn",
                "data-dps-nav-restore": "1",
                title: "\u628A\u5BFC\u822A\u884C\u987A\u5E8F\u6062\u590D\u4E3A\u672C\u63D2\u4EF6\u9ED8\u8BA4\u987A\u5E8F\uFF08\u672C\u673A\u504F\u597D\uFF0C\u7ACB\u5373\u751F\u6548\uFF09",
                onClick: restoreNavOrder,
                children: NAV_RESTORE_DEFAULT
              }
            ) : null
          ] })
        ]
      }
    ),
    conversations !== null && conversations !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dps-conv", "data-dps-conversations": "1", "aria-label": "\u4F1A\u8BDD\u5217\u8868", children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dps-conv-h", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { children: "\u4F1A\u8BDD\u5217\u8868" }),
        convSnap.ready && convRows.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dps-conv-n", "data-dps-conv-count": convRows.length, children: convRows.length }) : null,
        convBackground.known ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
          "button",
          {
            type: "button",
            className: "dps-conv-toggle",
            "data-dps-conv-bg-toggle": backgroundShow ? "show" : "hide",
            "aria-pressed": backgroundShow,
            title: backgroundShow ? "\u540E\u53F0\u4EFB\u52A1\u4F1A\u8BDD\u5F53\u524D\u53EF\u89C1\uFF08\u70B9\u6B64\u9690\u85CF\uFF09" : "\u540E\u53F0\u4EFB\u52A1\u4F1A\u8BDD\u5F53\u524D\u5DF2\u9690\u85CF\uFF1B\u4F1A\u8BDD\u672A\u88AB\u5220\u9664\uFF0C\u53EF\u5728\u4EFB\u52A1\u2192\u6267\u884C\u5386\u53F2\u6253\u5F00",
            onClick: () => setBackgroundShow((v) => !v),
            children: backgroundShow ? CONV_BACKGROUND_TOGGLE_HIDE : CONV_BACKGROUND_TOGGLE_SHOW
          }
        ) : null
      ] }),
      !convSnap.ready ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dps-conv-empty", "data-dps-conv-state": "loading", children: "\u6B63\u5728\u8BFB\u53D6\u5B98\u65B9\u4F1A\u8BDD\u2026" }) : convRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dps-conv-empty", "data-dps-conv-state": "empty", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { children: CONV_EMPTY_TEXT }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("button", { type: "button", className: "dps-conv-cta", "data-dps-conv-cta": "1", onClick: goHome, children: CONV_EMPTY_CTA })
      ] }) : /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_jsx_runtime4.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("ul", { className: "dps-conv-list", children: convModel.shown.map((row) => {
          const active = convSnap.currentId !== void 0 && convSnap.currentId === row.id;
          const menuOpen = menuOpenId === row.id;
          const unseenDone = !active && convTrack.unseen.has(row.id);
          const interruptedUnread = interrupts.unreadSessions.has(row.id);
          const dotState = conversationDotState(row, pendingBySession, unseenDone, interruptedUnread);
          const dotNote = conversationDotNote(dotState, pendingBySession.get(row.id));
          return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(
            "li",
            {
              className: "dps-conv-item",
              "data-conv-menu-open": menuOpen ? "true" : void 0,
              children: [
                /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(
                  "button",
                  {
                    type: "button",
                    className: "dps-conv-row",
                    "data-dps-conv-row": "1",
                    "data-conv-id": row.id,
                    "data-conv-active": active ? "true" : "false",
                    "aria-current": active ? "true" : void 0,
                    title: `${row.title}${row.cwd !== void 0 ? `\uFF5C\u5DE5\u4F5C\u533A ${row.cwd}` : ""}\uFF5C\u6253\u5F00\u8BE5\u5B98\u65B9\u4F1A\u8BDD`,
                    onClick: () => {
                      setMenuOpenId(null);
                      setConvTrack((prev) => markConversationSeen(prev, row.id));
                      void markInterruptRead("session", row.id).then((res) => {
                        if (!res.ok) return;
                        setInterrupts((prev) => clearUnread(prev, "session", row.id));
                      });
                      openConversationRow(row.id);
                    },
                    children: [
                      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("span", { className: "dps-conv-title", children: [
                        row.title,
                        dotState === "idle" ? null : /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
                          "span",
                          {
                            className: `dps-conv-state ${CONVERSATION_DOT_CLASS[dotState]}`,
                            "data-conv-state": dotState,
                            "aria-label": dotNote,
                            title: dotNote
                          }
                        )
                      ] }),
                      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dps-conv-time", children: relativeTime(row.updatedAt, convNow) })
                    ]
                  }
                ),
                /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dps-conv-actions", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
                  SessionActionsMenu,
                  {
                    title: row.title,
                    open: menuOpen,
                    onOpenChange: (next) => setMenuOpenId(next ? row.id : null),
                    onRename: () => beginSessionRename(row),
                    onFork: () => forkSessionRow(row),
                    onArchive: () => archiveSessionRow(row),
                    onProject: hasProjectBridge(typeof window === "undefined" ? null : window) ? () => beginProjectAssign(row) : void 0
                  }
                ) })
              ]
            },
            row.id
          );
        }) }),
        convModel.hiddenCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
          "button",
          {
            type: "button",
            className: "dps-conv-more",
            "data-dps-conv-expand": "1",
            onClick: () => setConvExpanded(true),
            children: convModel.expandLabel
          }
        ) : convExpanded && convRows.length > DEFAULT_VISIBLE ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
          "button",
          {
            type: "button",
            className: "dps-conv-more",
            "data-dps-conv-collapse": "1",
            onClick: () => setConvExpanded(false),
            children: "\u6536\u8D77"
          }
        ) : null
      ] }),
      convModel.archiveUnknown ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dps-conv-note", "data-dps-conv-archive-unknown": "1", children: CONV_ARCHIVE_UNKNOWN_NOTE }) : null,
      convFiltered.backgroundUnknown ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dps-conv-note", "data-dps-conv-bg-unknown": "1", children: CONV_BACKGROUND_UNKNOWN_NOTE }) : null,
      convFiltered.hiddenBackground > 0 ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dps-conv-note", "data-dps-conv-bg-hidden": convFiltered.hiddenBackground, children: convBackgroundHiddenNote(convFiltered.hiddenBackground) }) : null,
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dps-conv-note", "data-dps-conv-scope": "1", children: CONV_SCOPE_NOTE }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        SessionRenameDialog,
        {
          open: renameTarget !== null,
          draft: renameDraft,
          renaming,
          blocked: renameBlocked,
          error: renameError,
          onDraft: (value) => {
            setRenameDraft(value);
            setRenameError(null);
          },
          onConfirm: confirmSessionRename,
          onClose: closeSessionRename
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        ProjectAssignDialog,
        {
          open: projectTarget !== null && projectData !== null,
          sessionTitle: projectTarget?.title ?? "",
          data: projectData ?? { ok: false, reason: "\u9879\u76EE\u6570\u636E\u672A\u8BFB\u53D6" },
          draftId: projectDraftId,
          error: projectError,
          onPick: (id) => {
            setProjectDraftId(id);
            setProjectError(null);
          },
          onConfirm: confirmProjectAssign,
          onUnassign: unassignProjectAssign,
          onClose: closeProjectAssign
        }
      )
    ] }) : null,
    notice ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dps-mm", "data-dps-nav-notice-host": "1", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dps-mm-notice", "data-dps-nav-notice": "1", children: notice }) }) : null
  ] }) });
}

// src/workstation/personal-sidebar/src/client/thoughtdagSwitch.ts
var TABBAR_CLASS = "dps-tabbar";
var TABBAR_ATTR = "data-dps-tabbar";
var SWITCH_CLASS = "dsh-td-switch";
var OVERLAY_CLASS = "dsh-td-overlay";
var OVERLAY_OPEN_ATTR = "data-dps-overlay-open";
var BACK_ATTR = "data-dps-back";
var TASK_BOARD_LABEL = "\u4EFB\u52A1\u770B\u677F";
var findTaskBoardRow = () => {
  for (const el of document.querySelectorAll("button")) {
    if ((el.textContent ?? "").trim() === TASK_BOARD_LABEL) return el;
  }
  return null;
};
var resolveAnchor = () => {
  const row = findTaskBoardRow();
  if (row !== null && row.parentElement !== null) return { host: row.parentElement, before: row };
  const root = document.querySelector(".dps-root");
  if (root !== null) return { host: root, before: root.firstElementChild };
  return null;
};
var overlayShown = () => {
  const ov = document.querySelector(`.${OVERLAY_CLASS}`);
  return ov !== null && !ov.hidden;
};
var returnToDialog = () => {
  const dialog = document.querySelector(`.${SWITCH_CLASS} [data-view="dialog"]`);
  if (dialog !== null) dialog.click();
};
function adoptThoughtSwitcher() {
  let stopped = false;
  let scheduled = false;
  let observer = null;
  let home = null;
  const restoreHome = (sw, bar) => {
    const original = home;
    if (original !== null && original.parent.isConnected) {
      const next = original.next !== null && original.next.parentNode === original.parent ? original.next : null;
      original.parent.insertBefore(sw, next);
      return;
    }
    if (bar === null || sw.parentElement === bar) document.body.appendChild(sw);
  };
  const enterFloating = (bar) => {
    if (bar.parentElement !== document.body) document.body.appendChild(bar);
    if (bar.hasAttribute(OVERLAY_OPEN_ATTR)) return;
    bar.setAttribute(OVERLAY_OPEN_ATTR, "1");
    const back = document.createElement("button");
    back.type = "button";
    back.className = "dps-td-back";
    back.setAttribute(BACK_ATTR, "1");
    back.setAttribute("aria-label", "\u8FD4\u56DE\u5BF9\u8BDD");
    back.textContent = "\u2190 \u8FD4\u56DE\u5BF9\u8BDD";
    back.addEventListener("click", returnToDialog);
    bar.appendChild(back);
  };
  const exitFloating = (bar) => {
    if (!bar.hasAttribute(OVERLAY_OPEN_ATTR)) return;
    bar.removeAttribute(OVERLAY_OPEN_ATTR);
    const back = bar.querySelector(`[${BACK_ATTR}]`);
    if (back !== null) {
      back.removeEventListener("click", returnToDialog);
      back.remove();
    }
  };
  const place = () => {
    const sw = document.querySelector(`.${SWITCH_CLASS}`);
    const existing = document.querySelector(`[${TABBAR_ATTR}]`);
    if (sw === null) {
      existing?.remove();
      return;
    }
    if (home === null && sw.parentElement !== null && !sw.parentElement.hasAttribute(TABBAR_ATTR)) {
      home = { parent: sw.parentElement, next: sw.nextSibling };
    }
    const overlay = overlayShown();
    if (document.querySelector(".dps-root") === null) {
      if (overlay && existing !== null) {
        if (sw.parentElement === existing) restoreHome(sw, existing);
        exitFloating(existing);
        existing.remove();
        return;
      }
      if (existing !== null) {
        if (sw.parentElement === existing) restoreHome(sw, existing);
        existing.remove();
      }
      return;
    }
    if (overlay) {
      let bar2 = existing;
      if (bar2 === null) {
        bar2 = document.createElement("div");
        bar2.className = TABBAR_CLASS;
        bar2.setAttribute(TABBAR_ATTR, "1");
        document.body.appendChild(bar2);
      }
      if (sw.parentElement !== bar2) bar2.appendChild(sw);
      enterFloating(bar2);
      return;
    }
    const anchor = resolveAnchor();
    if (anchor === null) return;
    let bar = existing;
    if (bar === null) {
      bar = document.createElement("div");
      bar.className = TABBAR_CLASS;
      bar.setAttribute(TABBAR_ATTR, "1");
      anchor.host.insertBefore(bar, anchor.before);
    } else if (bar.parentElement !== anchor.host || bar.nextElementSibling !== anchor.before) {
      anchor.host.insertBefore(bar, anchor.before);
    }
    exitFloating(bar);
    if (sw.parentElement !== bar) bar.appendChild(sw);
  };
  const schedule = () => {
    if (stopped || scheduled) return;
    scheduled = true;
    const run = () => {
      scheduled = false;
      if (stopped) return;
      try {
        place();
      } catch {
      }
    };
    if (typeof requestAnimationFrame === "function") requestAnimationFrame(run);
    else setTimeout(run, 16);
  };
  try {
    place();
    observer = new MutationObserver(schedule);
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["hidden"]
    });
  } catch {
    return () => {
      stopped = true;
    };
  }
  return () => {
    if (stopped) return;
    stopped = true;
    try {
      observer?.disconnect();
    } catch {
    }
    observer = null;
    try {
      const sw = document.querySelector(`.${SWITCH_CLASS}`);
      const bar = document.querySelector(`[${TABBAR_ATTR}]`);
      if (bar !== null) exitFloating(bar);
      if (sw !== null && bar !== null && sw.parentElement === bar) restoreHome(sw, bar);
      else if (sw !== null && bar === null && home !== null && home.parent.isConnected && sw.parentElement !== home.parent) {
        restoreHome(sw, null);
      }
      bar?.remove();
    } catch {
    }
  };
}

// src/workstation/personal-sidebar/src/client/brand.tsx
var import_react5 = require("react");
var import_jsx_runtime5 = require("react/jsx-runtime");
var FALLBACK_VERSION = "0.1.24";
var FALLBACK_PRODUCT_NAME = "Personal Harness";
var FALLBACK_PRODUCT_VERSION = "V1.2";
var BRAND_TITLE = "Personal Harness";
function productName() {
  return "Personal Harness".length > 0 ? "Personal Harness" : FALLBACK_PRODUCT_NAME;
}
function productVersion() {
  return "V1.2".length > 0 ? "V1.2" : FALLBACK_PRODUCT_VERSION;
}
function brandSubtitle() {
  return `${productName()} \xB7 ${productVersion()}`;
}
function brandVersion() {
  return "0.1.28".length > 0 ? "0.1.28" : FALLBACK_VERSION;
}
function useBrandNeutralizer() {
  const ref = (0, import_react5.useRef)(null);
  (0, import_react5.useEffect)(() => {
    const btn = ref.current?.closest("button") ?? null;
    if (btn === null) return;
    const prevLabel = btn.getAttribute("aria-label");
    const prevTab = btn.getAttribute("tabindex");
    const prevTitle = btn.getAttribute("title");
    const prevPointer = btn.style.pointerEvents;
    const prevCursor = btn.style.cursor;
    btn.setAttribute("aria-label", `${BRAND_TITLE}\uFF5C${brandSubtitle()}\uFF08sidebar ${brandVersion()}\uFF09`);
    btn.setAttribute("tabindex", "-1");
    btn.removeAttribute("title");
    btn.style.pointerEvents = "none";
    btn.style.cursor = "default";
    return () => {
      if (prevLabel === null) btn.removeAttribute("aria-label");
      else btn.setAttribute("aria-label", prevLabel);
      if (prevTab === null) btn.removeAttribute("tabindex");
      else btn.setAttribute("tabindex", prevTab);
      if (prevTitle !== null) btn.setAttribute("title", prevTitle);
      btn.style.pointerEvents = prevPointer;
      btn.style.cursor = prevCursor;
    };
  }, []);
  return ref;
}
function PersonalBrandName() {
  const ref = useBrandNeutralizer();
  const version = brandVersion();
  return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(
    "span",
    {
      className: "dps-brand",
      "data-dps-brand": "1",
      "data-dps-brand-version": version,
      "data-dps-product-version": productVersion(),
      ref,
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dps-brand-title", "data-dps-brand-title": "1", children: BRAND_TITLE }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dps-brand-sub", "data-dps-brand-sub": "1", children: brandSubtitle() })
      ]
    }
  );
}

// src/workstation/personal-sidebar/src/client/index.tsx
var import_jsx_runtime6 = require("react/jsx-runtime");
var inject = ["slots", "sessions"];
var reloadFallback = () => {
  try {
    window.setTimeout(() => {
      try {
        window.location.reload();
      } catch {
      }
    }, 150);
  } catch {
  }
};
var DPS_VERSION = "0.1.28".length > 0 ? "0.1.28" : "0.1.18";
var DPS_SHA = "8838cdb".length > 0 ? "8838cdb" : "dev";
var DIAG_DEBUG_Z = 2147483e3;
var DPS_DEBUG = (() => {
  try {
    return window.localStorage.getItem("dps.debug") === "1";
  } catch {
    return false;
  }
})();
var badge = (phase) => {
  if (!DPS_DEBUG) return;
  try {
    let el = document.getElementById("dps-live-badge");
    if (!el) {
      el = document.createElement("div");
      el.id = "dps-live-badge";
      el.style.cssText = "position:fixed;right:10px;bottom:30px;z-index:" + DIAG_DEBUG_Z + ";font:11px/1.3 system-ui,sans-serif;color:#fff;background:rgba(40,44,60,.85);padding:2px 7px;border-radius:5px;pointer-events:none;";
      document.body.appendChild(el);
    }
    el.textContent = phase;
  } catch {
  }
};
if (DPS_DEBUG) badge("dps:" + DPS_VERSION + " loaded");
function ModeToggle(_props) {
  const mode2 = usePersonalMode();
  const personal = mode2 === "personal";
  return /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)(
    "button",
    {
      type: "button",
      className: "dps-foot-toggle",
      "data-on": personal,
      "aria-pressed": personal,
      title: personal ? "Personal Sidebar \u5DF2\u5F00\u542F \xB7 \u70B9\u51FB\u8FD4\u56DE\u5B98\u65B9\u6D4F\u89C8" : "\u8FDB\u5165 Personal Harness\uFF08\u4E2A\u4EBA\u5DE5\u4F5C\u53F0\uFF09",
      onClick: () => personalMode.set(personal ? "official" : "personal"),
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(SwitcherIcon, { size: 12 }),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { children: personal ? "\u8FD4\u56DE\u5B98\u65B9" : "\u8FDB\u5165 Personal" })
      ]
    }
  );
}
function apply(ctx) {
  try {
    applyInner(ctx);
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    badge("dps\u2717 " + msg.slice(0, 42));
    console.warn("[dsh-personal-sidebar] apply aborted, kept stock UI:", error);
  }
}
function armDiagnostics() {
  try {
    const w = window;
    w.__dshRunSelfCheck = () => buildSelfCheckReport();
  } catch {
  }
  if (!DPS_DEBUG) return;
  try {
    const arm = () => {
      const host = document.getElementById("dps-debug-panel");
      if (host) return;
      const el = document.createElement("div");
      el.id = "dps-debug-panel";
      el.style.cssText = "position:fixed;top:8px;right:8px;z-index:" + DIAG_DEBUG_Z + ";max-width:380px;max-height:72vh;overflow:auto;font:11px/1.5 ui-monospace,SFMono-Regular,Menlo,monospace;color:#dde2ec;background:rgba(28,32,46,.94);border:1px solid rgba(255,255,255,.18);border-radius:8px;padding:7px 10px;pointer-events:auto;user-select:text;white-space:pre-wrap;word-break:break-all;";
      const refresh = () => {
        try {
          const r = buildSelfCheckReport();
          const pkg = r.pkg ?? {};
          const dom = r.dom ?? {};
          const md = r.mainDiag ?? {};
          const lines = [];
          lines.push(`[dps-nav ${DPS_VERSION} ${DPS_SHA}] sidebar\xD7${pkg.sidebarInstances ?? "?"} ws\xD7${pkg.workspaceInstances ?? "?"}`);
          lines.push(`hostReady=${r.hostReady} domHost=${dom.mainHostView ?? "\u2205"}${dom.mainHostError ? " ERROR" : ""}`);
          lines.push(`mainDiag: cur=${md.current ?? "?"} tag=${md.tag ?? "?"} reg=${md.registered ?? "?"} pri=${md.seatPriority ?? "?"}`);
          lines.push(`navRoots=${dom.navRoots ?? "?"} rows=${dom.navRows ?? "?"} dupRows=${dom.duplicateRows ? JSON.stringify(dom.duplicateRows) : "0"}`);
          const scan = dom.labelScan ?? [];
          lines.push(`labelScan=${scan.length}${scan.length > 0 ? " \u2192 " + JSON.stringify(scan.slice(0, 6)) : ""}`);
          const seats = r.seats;
          lines.push(`seats: conv=${JSON.stringify(seats?.conversation ?? "\u2205").slice(0, 140)}`);
          const traces = window.__dshDiag?.traces ?? [];
          const last = traces.slice(-3).map((x) => `${x.kind}:${x.nav ?? ""}${x.ms != null ? `+${x.ms}ms` : ""}${x.detail ? `(${x.detail})` : ""}`);
          lines.push(`trace: ${last.join(" | ") || "\u2014"}`);
          el.textContent = lines.join("\n");
        } catch {
          el.textContent = "dps-debug: refresh error";
        }
      };
      refresh();
      const iv = window.setInterval(refresh, 900);
      el.addEventListener("click", () => {
        try {
          const full = JSON.stringify(buildSelfCheckReport(), null, 1);
          el.textContent = el.textContent === full ? "dps-debug panel\uFF08\u70B9\u51FB\u5237\u65B0\u8BE6\u60C5\uFF09" : full;
        } catch {
        }
      });
      const stop = () => {
        try {
          window.clearInterval(iv);
        } catch {
        }
        try {
          el.remove();
        } catch {
        }
      };
      try {
        window.addEventListener("beforeunload", stop);
      } catch {
      }
      document.body.appendChild(el);
    };
    if (typeof document !== "undefined" && document.body) arm();
    else if (typeof window !== "undefined") window.addEventListener("DOMContentLoaded", arm);
  } catch {
  }
}
function applyInner(ctx) {
  try {
    diagPkgTick("sidebar", DPS_VERSION, DPS_SHA);
  } catch {
  }
  armDiagnostics();
  const slots = ctx?.slots;
  if (!ctx || !slots || typeof slots.inject !== "function") {
    badge("dps no-slots");
    return false;
  }
  let handle = null;
  let mounted = false;
  const sessionsOf = () => {
    try {
      return typeof ctx.get === "function" ? ctx.get("sessions") : void 0;
    } catch {
      return void 0;
    }
  };
  const conversationsOf = () => {
    const listOf = () => {
      try {
        const svc = sessionsOf();
        const list = svc?.list;
        return list && typeof list.getSnapshot === "function" && typeof list.subscribe === "function" ? list : null;
      } catch {
        return null;
      }
    };
    const archiveOf = () => {
      try {
        const svc = typeof ctx.get === "function" ? ctx.get("workspaces") : void 0;
        const list = svc?.list;
        if (!list || typeof list.getSnapshot !== "function") return null;
        const snap = list.getSnapshot();
        return snap !== null && typeof snap === "object" ? snap : null;
      } catch {
        return null;
      }
    };
    return {
      /** 官方会话快照（未就绪 → undefined，UI 说「读取中」而不是「暂无会话」）。 */
      getSnapshot: () => listOf()?.getSnapshot?.() ?? void 0,
      /** 订阅官方 store（会话创建/重命名/继续/归档 → 官方自行推送，无需轮询）。 */
      subscribe: (fn) => {
        try {
          const off = listOf()?.subscribe?.(fn);
          return typeof off === "function" ? off : () => {
          };
        } catch {
          return () => {
          };
        }
      },
      /** 官方归档集（workspaces.list）；null = 源不可读（未知）。 */
      archive: () => archiveOf(),
      /**
       * 订阅官方归档集 store（`workspaces.list.subscribe`；源码证据：官方 ui-workspace
       * 自身即 `this.workspaces.list.subscribe(reconcile)`）。
       * 归档/取消归档由官方推送 → 会话列表即时刷新，**不轮询**。
       * 返回 null = 官方 workspaces 服务（或其 list store）尚不可用 → 调用方**有界**重试。
       */
      subscribeArchive: (fn) => {
        try {
          const svc = typeof ctx.get === "function" ? ctx.get("workspaces") : void 0;
          const list = svc?.list;
          if (!list || typeof list.subscribe !== "function") return null;
          const off = list.subscribe(fn);
          return typeof off === "function" ? off : () => {
          };
        } catch {
          return null;
        }
      },
      /** 打开官方会话（唯一合法路径；不创建会话/不建任务/不重放 prompt）。 */
      open: (sessionId) => {
        try {
          const svc = sessionsOf();
          svc?.open?.(sessionId);
        } catch {
        }
      },
      // -----------------------------------------------------------------------
      // E4-FINAL · Personal「会话列表」复现官方 Session 菜单：三个动作**逐句复用官方 handler**
      // （官方接线源码证据：@deepseek-ai/dsh-client-ui-workspace/lib/client.js:2674-2700）。
      //   rename  → `const session = sessions.binding(id)?.session; if (session===void 0)
      //              throw new Error(\`unknown session "${id}"\`); const r = await session.rename(t);
      //              if (!r.ok) throw new Error(r.error.message)`
      //   fork    → `sessions.fork({sessionId, increaseTitle:true})` → childId（官方随后 sessions.open）
      //   archive → `workspaces.archiveSession(sessionId)`（官方归档真源唯一写路径）
      // 本层**不新增**任何会话状态/归档真源/缓存：调用成功 → 官方 store 自行推送 → 列表刷新。
      // 失败一律**抛出**（不吞、不假装成功），由 UI 如实呈现。
      // -----------------------------------------------------------------------
      rename: async (sessionId, title) => {
        const svc = sessionsOf();
        const session = typeof svc?.binding === "function" ? svc.binding(sessionId)?.session : void 0;
        if (session === void 0 || typeof session.rename !== "function") {
          throw new Error(`unknown session "${sessionId}"`);
        }
        const result = await session.rename(title);
        if (result === void 0 || result.ok !== true) {
          throw new Error(result?.error?.message ?? "\u5B98\u65B9\u4F1A\u8BDD\u91CD\u547D\u540D\u672A\u8FD4\u56DE\u6210\u529F\u7ED3\u679C");
        }
      },
      fork: async (sessionId) => {
        const svc = sessionsOf();
        if (typeof svc?.fork !== "function") throw new Error("\u5B98\u65B9 sessions.fork \u4E0D\u53EF\u7528");
        const child = await svc.fork({ sessionId, increaseTitle: true });
        const childId = typeof child === "string" ? child : child !== null && typeof child === "object" ? child.id : void 0;
        if (typeof childId !== "string" || childId === "") {
          throw new Error("\u5B98\u65B9 sessions.fork \u672A\u8FD4\u56DE\u5B50\u4F1A\u8BDD id");
        }
        return childId;
      },
      /**
       * 归档会话 = **写动作**（官方 `workspaces.archiveSession`）。
       * 命名注意：上面那个 `archive()` 是**只读真源读取**（`workspaces.list.archivedSessionIds`），
       * 两者一字之差但语义相反（读真值 vs 写动作），故此处沿用官方方法名 `archiveSession` 以免混淆。
       * 归档 ≠ 删除：会话本体保留，恢复入口仍在官方侧。
       */
      archiveSession: async (sessionId) => {
        const svc = typeof ctx.get === "function" ? ctx.get("workspaces") : void 0;
        if (typeof svc?.archiveSession !== "function") throw new Error("\u5B98\u65B9 workspaces.archiveSession \u4E0D\u53EF\u7528");
        await svc.archiveSession(sessionId);
      }
    };
  };
  const betterSidebarOf = () => {
    try {
      return typeof ctx.get === "function" ? ctx.get("betterSidebar") : void 0;
    } catch {
      return void 0;
    }
  };
  const setPersonalAttr = (on) => {
    try {
      const root = typeof document !== "undefined" ? document.documentElement : void 0;
      if (!root) return;
      if (on) root.setAttribute("data-dps-personal", "1");
      else root.removeAttribute("data-dps-personal");
    } catch {
    }
  };
  const unmount = () => {
    setPersonalAttr(false);
    if (mounted) {
      let removed = false;
      if (handle) {
        try {
          handle();
          removed = true;
        } catch {
        }
      }
      if (!removed) reloadFallback();
    }
    handle = null;
    mounted = false;
  };
  const pendingOf = () => {
    const storeOf = () => {
      try {
        const svc = typeof ctx.get === "function" ? ctx.get("uiSession") : void 0;
        const p = svc?.pendingInteractions;
        return p && typeof p.getSnapshot === "function" && typeof p.subscribe === "function" ? p : null;
      } catch {
        return null;
      }
    };
    return {
      /** 官方待交互快照（Map<sessionId, PendingApproval|PendingQuestion>）；未就绪 → undefined。 */
      getSnapshot: () => storeOf()?.getSnapshot?.() ?? void 0,
      /** 订阅官方 store（审批出现/消失、提问出现/回答 → 官方推送，无需轮询）。 */
      subscribe: (fn) => {
        try {
          const off = storeOf()?.subscribe?.(fn);
          return typeof off === "function" ? off : () => {
          };
        } catch {
          return () => {
          };
        }
      }
    };
  };
  const mount = () => {
    if (mounted) return;
    setPersonalAttr(true);
    const sessions = sessionsOf();
    try {
      const cleanup = slots.register(
        {
          name: "sidebar.workspaces",
          id: "personal-sidebar-workspaces",
          // Shadow the built-in ui-workspace browser (default priority 0).
          priority: -1e3,
          inject: () => ({
            openSession: (sessionId) => {
              try {
                sessions?.open?.(sessionId);
              } catch {
              }
            },
            switchOfficial: () => {
              personalMode.set("official");
            },
            /** §5/§6：Sidebar 会话列表的 official Session 只读投影 + 官方打开路径。 */
            conversations: conversationsOf(),
            /** 会话行状态点：官方 pendingInteractions（审批/提问，会话级真源）。 */
            pending: pendingOf(),
            betterSidebar: betterSidebarOf()
          })
        },
        PersonalBrowser
      );
      handle = typeof cleanup === "function" ? cleanup : null;
      mounted = handle !== null;
    } catch (error) {
      console.warn("[dsh-personal-sidebar] occupant registration failed:", error);
      handle = null;
      setPersonalAttr(false);
    }
  };
  let brandHandle = null;
  let brandMounted = false;
  const unmountBrand = () => {
    if (!brandMounted) return;
    try {
      brandHandle?.();
    } catch {
    }
    brandHandle = null;
    brandMounted = false;
  };
  const mountBrand = () => {
    if (brandMounted) return;
    try {
      const cleanup = slots.register(
        { name: "sidebar.brand.name", id: "personal-sidebar-brand", priority: -1e3 },
        PersonalBrandName
      );
      brandHandle = typeof cleanup === "function" ? cleanup : null;
      brandMounted = brandHandle !== null;
    } catch (error) {
      console.warn("[dsh-personal-sidebar] brand seat registration failed:", error);
      brandHandle = null;
      brandMounted = false;
    }
  };
  const syncBrand = () => {
    if (personalMode.get() === "personal") mountBrand();
    else unmountBrand();
  };
  const brandLife = () => {
    syncBrand();
    const off = personalMode.subscribe(syncBrand);
    return () => {
      off();
      unmountBrand();
    };
  };
  const sync = () => {
    if (personalMode.get() === "personal") mount();
    else unmount();
  };
  let tabbarHandle = null;
  let tabbarMounted = false;
  const unmountTabbar = () => {
    if (!tabbarMounted) return;
    try {
      tabbarHandle?.();
    } catch {
    }
    tabbarHandle = null;
    tabbarMounted = false;
  };
  const mountTabbar = () => {
    if (tabbarMounted) return;
    try {
      tabbarHandle = adoptThoughtSwitcher();
      tabbarMounted = true;
    } catch (error) {
      console.warn("[dsh-personal-sidebar] thoughtdag switcher adoption failed:", error);
      tabbarHandle = null;
      tabbarMounted = false;
    }
  };
  const syncTabbar = () => {
    if (personalMode.get() === "personal") mountTabbar();
    else unmountTabbar();
  };
  const tabbarLife = () => {
    syncTabbar();
    const off = personalMode.subscribe(syncTabbar);
    return () => {
      off();
      unmountTabbar();
    };
  };
  const injectStyles = () => {
    const el = document.createElement("style");
    el.setAttribute("data-dsh-plugin", "dsh-personal-sidebar");
    el.textContent = CSS;
    document.head.appendChild(el);
    return () => {
      el.remove();
    };
  };
  const errors = [];
  const step = (label, fn) => {
    try {
      return fn();
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      errors.push(`${label}: ${msg}`);
      console.warn("[dsh-personal-sidebar] step failed:", label, error);
      return void 0;
    }
  };
  step("styles", () => {
    if (typeof ctx.effect === "function") return ctx.effect(injectStyles, "dps: styles");
    return injectStyles();
  });
  const seatLife = () => {
    sync();
    const off = personalMode.subscribe(sync);
    return () => {
      off();
      unmount();
    };
  };
  const injectSeat = (name, make, label) => {
    step(label, () => {
      if (typeof ctx.effect === "function") {
        return ctx.effect(() => slots.inject(name, make, label), label + " lifecycle");
      }
      return slots.inject(name, make, label);
    });
  };
  injectSeat("sidebar.workspaces", seatLife, "dps: occupant");
  injectSeat("sidebar.brand.name", brandLife, "dps: brand");
  injectSeat(
    "sidebar.footer.action",
    () => slots.register(
      { name: "sidebar.footer.action", id: "personal-sidebar-toggle", order: 1 },
      (props) => ModeToggle(props)
    ),
    "dps: footer"
  );
  step("tabbar", () => {
    if (typeof ctx.effect === "function") return ctx.effect(tabbarLife, "dps: tabbar");
    return tabbarLife();
  });
  if (errors.length > 0) {
    badge("dps\u2717 " + errors[0].slice(0, 42));
  } else {
    badge("dps:" + DPS_VERSION + " applied");
  }
  return errors.length === 0;
}
return module.exports; } });
