window.__ModuleLoader__.load({ id: 'dsh-personal-hud', factory: (require) => { var module = { exports: {} }; var exports = module.exports;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/workstation/personal-hud/src/client/index.tsx
var index_exports = {};
__export(index_exports, {
  apply: () => apply,
  inject: () => inject
});
module.exports = __toCommonJS(index_exports);
var import_client = require("react-dom/client");

// src/workstation/personal-hud/src/client/hud-ui.tsx
var import_react2 = require("react");

// src/workstation/personal-hud/src/client/store.ts
var import_react = require("react");
var OPEN_KEY = "dsh.hud.open";
var WIDTH_KEY = "dsh.hud.width";
var MIN_W = 260;
var MAX_W = 520;
function readOpen() {
  return false;
}
function readWidth() {
  try {
    const n = Number(window.localStorage.getItem(WIDTH_KEY));
    if (Number.isFinite(n)) return Math.min(MAX_W, Math.max(MIN_W, n));
  } catch {
  }
  return 320;
}
var windowState = { open: readOpen(), width: readWidth() };
var winSubs = /* @__PURE__ */ new Set();
var hudWindow = {
  get() {
    return windowState;
  },
  setOpen(open) {
    if (windowState.open === open) return;
    windowState = { ...windowState, open };
    try {
      window.localStorage.setItem(OPEN_KEY, open ? "1" : "0");
    } catch {
    }
    winSubs.forEach((f) => f());
  },
  setWidth(width) {
    const w = Math.min(MAX_W, Math.max(MIN_W, Math.round(width)));
    if (windowState.width === w) return;
    windowState = { ...windowState, width: w };
    try {
      window.localStorage.setItem(WIDTH_KEY, String(w));
    } catch {
    }
    winSubs.forEach((f) => f());
  },
  subscribe(f) {
    winSubs.add(f);
    return () => {
      winSubs.delete(f);
    };
  }
};
function useHudWindow() {
  return (0, import_react.useSyncExternalStore)(
    (f) => hudWindow.subscribe(f),
    () => hudWindow.get(),
    () => ({ open: false, width: 320 })
  );
}
var INITIAL = {
  ready: false,
  currentId: void 0,
  current: null,
  recent: [],
  modelLabel: "",
  runtime: "connecting"
};
var state = INITIAL;
var feedSubs = /* @__PURE__ */ new Set();
function notify() {
  feedSubs.forEach((f) => f());
}
function rowOf(raw) {
  const r = raw ?? {};
  const id = String(r.id ?? r.sessionId ?? "");
  if (!id) return null;
  const title = typeof r.label === "string" ? r.label : typeof r.title === "string" ? r.title : "";
  return {
    id,
    title: title && title.length > 0 ? title : "\uFF08\u672A\u547D\u540D\u4F1A\u8BDD\uFF09",
    running: r.running === true,
    updatedAt: typeof r.updatedAt === "number" ? r.updatedAt : void 0
  };
}
function parseSnapshot(snap) {
  const s = snap;
  const raw = Array.isArray(s) ? s : Array.isArray(s?.list) ? s.list : Array.isArray(s?.sessions) ? s.sessions : [];
  const rows = raw.map((r) => rowOf(r)).filter((x) => x !== null).filter((x) => x.id !== void 0);
  const currentId = typeof s?.current === "string" ? s.current : typeof s?.selection === "string" ? s.selection : void 0;
  return { rows, currentId };
}
function attachSessionFeed(getSessions) {
  let source = null;
  try {
    const svc = getSessions();
    source = svc?.list ?? null;
  } catch {
    source = null;
  }
  if (!source || typeof source.getSnapshot !== "function" || typeof source.subscribe !== "function") {
    return () => {
    };
  }
  const apply2 = () => {
    try {
      const snap = source.getSnapshot();
      const { rows, currentId } = parseSnapshot(snap);
      const current = rows.find((r) => r.id === currentId) ?? null;
      const next = {
        ready: true,
        currentId,
        current,
        recent: rows.slice(0, 12),
        modelLabel: state.modelLabel,
        // preserved; not sourced in STAGE 2
        runtime: "online"
      };
      state = next;
      notify();
    } catch {
    }
  };
  apply2();
  const off = source.subscribe(apply2);
  return () => {
    try {
      off?.();
    } catch {
    }
  };
}
function useHudState() {
  return (0, import_react.useSyncExternalStore)(
    (f) => {
      feedSubs.add(f);
      return () => {
        feedSubs.delete(f);
      };
    },
    () => state,
    () => INITIAL
  );
}

// src/workstation/personal-hud/src/client/product.ts
var FALLBACK_PRODUCT_NAME = "Personal Harness";
var FALLBACK_PRODUCT_VERSION = "V1.2";
var FALLBACK_COMPONENT_VERSION = "0.1.3";
function productName() {
  return "Personal Harness".length > 0 ? "Personal Harness" : FALLBACK_PRODUCT_NAME;
}
function productVersion() {
  return "V1.2".length > 0 ? "V1.2" : FALLBACK_PRODUCT_VERSION;
}
function hudComponentVersion() {
  return "0.1.3".length > 0 ? "0.1.3" : FALLBACK_COMPONENT_VERSION;
}
var PRODUCT_LABEL = `${productName()} ${productVersion()}`;
var HUD_COMPONENT_VERSION = `hud ${hudComponentVersion()}`;

// src/workstation/personal-workspace/src/client/layering.ts
var LAYERS = {
  /** Official AppFrame in-frame overlay seat (shell.overlay). */
  frameOverlay: 20,
  /** better-sidebar body-level panel host (all Aux panels live inside it). */
  auxHost: 25,
  /** better-sidebar right/bottom workbench panel. */
  auxPanel: 40,
  /** better-sidebar free-floating window. */
  auxFloat: 42,
  /** better-sidebar top-right "＋" toggle cluster. */
  auxToggle: 45,
  /** better-sidebar boundary error banner. */
  auxBoundary: 50,
  /** better-sidebar text-selection popup. */
  auxSelection: 60,
  /**
   * hud status bar & Inspector live between the Aux selection popup (60) and
   * the official Modal (1000): they are always-on chrome that must stay above
   * the workbench panels yet never cover a modal backdrop / toast.
   */
  hudStatus: 450,
  hudInspector: 550,
  /** Official primitives band (body-portaled when they need to escape). */
  popover: 100,
  /**
   * personal-sidebar 的浮动 tabbar（`.dps-tabbar[data-dps-overlay-open]`，浮层打开时置顶）：
   * 必须盖住官方 popover 带（100）与我方 Aux 面板，但**不得**盖住 hud status bar（450）
   * 与官方 Modal（1000）。130 = 逐值保留 2026-09-14 的原值（零行为变化；原为魔数，
   * 违反 smoke-overlay-layering 的「一律 LAYERS.xxx」守则）。
   */
  sidebarTabbarOverlay: 130,
  modal: 1e3,
  toast: 1100
};

// src/workstation/personal-hud/src/client/hud-ui.tsx
var import_jsx_runtime = require("react/jsx-runtime");
var CSS_PH = String.raw`
/* Auto-hide status bar: a 5px bottom hot zone by default (covers nothing);
   hovering it expands the shell to 24px and slides the full bar up. */
.ph-shell {
  position: fixed; left: 0; right: 0; bottom: 0; height: 5px;
  z-index: ${LAYERS.hudStatus}; pointer-events: auto;
  transition: height .14s ease;
}
.ph-shell.ph-on { height: 24px; }
.ph-shell .ph-bar {
  position: absolute; left: 0; right: 0; bottom: 0; height: 24px;
  pointer-events: auto;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 8px;
  font: var(--dsw-font-xxxs-11, 11px);
  color: var(--dsw-alias-label-secondary);
  background: color-mix(in srgb, var(--dsw-alias-bg-layer-1, #111) 92%, transparent);
  border-top: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.25));
  backdrop-filter: blur(6px);
  user-select: none;
  transform: translateY(110%);
  transition: transform .14s ease;
}
.ph-shell.ph-on .ph-bar { transform: translateY(0); }
.ph-seg { display: flex; align-items: center; gap: 10px; min-width: 0; }
.ph-chip { display: inline-flex; align-items: center; gap: 4px; white-space: nowrap; overflow: hidden; }
.ph-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--dsw-alias-border-l2, #666); }
.ph-dot[data-on="true"] { background: var(--dsw-alias-state-business-primary, #3b82f6); }
.ph-dot[data-warn="true"] { background: var(--dsw-alias-state-warn-primary, #eab308); }
.ph-title { color: var(--dsw-alias-label-primary); max-width: 220px; text-overflow: ellipsis; overflow: hidden; }
.ph-muted { color: var(--dsw-alias-label-dimmed); }
.ph-btn {
  pointer-events: auto; cursor: pointer;
  display: inline-flex; align-items: center; gap: 4px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,.35));
  background: transparent; border-radius: 5px;
  padding: 1px 6px;
  font: var(--dsw-font-xxxs-11, 11px);
  color: var(--dsw-alias-label-secondary);
}
.ph-btn:hover { background: var(--dsw-alias-interactive-bg-hover); color: var(--dsw-alias-label-primary); }
.ph-btn[data-on="true"] { color: var(--dsw-alias-brand-primary, var(--dsw-alias-label-primary)); border-color: var(--dsw-alias-brand-primary, inherit); }
.ph-inspector {
  /* v0.1.2: floating card below the top chrome, not a full-height right-edge
     overlay, so it never covers the workbench's top row / collapse control. */
  position: fixed; top: 64px; right: 8px; width: 320px;
  max-height: calc(100vh - 96px);
  z-index: ${LAYERS.hudInspector};
  display: flex; flex-direction: column;
  background: color-mix(in srgb, var(--dsw-alias-bg-layer-1, #15171c) 96%, transparent);
  border: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.25));
  border-radius: 10px;
  backdrop-filter: blur(10px);
  font: var(--dsw-font-xxs-12, 12px);
  color: var(--dsw-alias-label-primary);
  box-shadow: 0 12px 36px rgba(0,0,0,.28);
  overflow: hidden;
}
.ph-resize {
  position: absolute; left: -3px; top: 0; bottom: 0; width: 6px;
  cursor: ew-resize; touch-action: none;
}
.ph-head {
  display: flex; align-items: center; justify-content: space-between;
  padding: 8px 10px 6px;
  border-bottom: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.2));
  flex: 0 0 auto;
}
.ph-head-title { font: var(--dsw-font-xxs-strong-12, 600 12px); letter-spacing: .02em; }
.ph-body { flex: 1 1 auto; overflow-y: auto; padding: 4px 10px 10px; min-height: 0; }
.ph-kbd { font-family: var(--ds-font-family-code, monospace); color: var(--dsw-alias-label-dimmed); }
.ph-group { margin: 8px 0 4px; font: var(--dsw-font-xxxs-strong-11, 600 11px); letter-spacing: .06em; color: var(--dsw-alias-label-tertiary); }
.ph-row { display: flex; align-items: baseline; gap: 6px; padding: 2px 0; }
.ph-row-label { flex: 0 0 76px; color: var(--dsw-alias-label-tertiary); }
.ph-row-value { flex: 1 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--dsw-alias-label-secondary); }
.ph-row-value[data-main="true"] { color: var(--dsw-alias-label-primary); }
.ph-sess { display: flex; align-items: center; gap: 6px; padding: 2px 0; color: var(--dsw-alias-label-secondary); min-width: 0; }
.ph-sess-title { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ph-empty { color: var(--dsw-alias-label-dimmed); padding: 2px 0; }
`;
function dotData(running) {
  return { "data-on": running === true };
}
function Row({ label, value, main, hint }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ph-row", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-row-label", children: label }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-row-value", "data-main": main === true, title: hint, children: value })
  ] });
}
function timeLabel(ts) {
  if (typeof ts !== "number") return "";
  const d = new Date(ts);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
function fmtId(id) {
  return id && id.length > 26 ? `${id.slice(0, 10)}\u2026${id.slice(-6)}` : id ?? "\u2014";
}
function StatusBar() {
  const { open } = useHudWindow();
  const s = useHudState();
  const cur = s.current;
  const [on, setOn] = (0, import_react2.useState)(false);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    "div",
    {
      className: on ? "ph-shell ph-on" : "ph-shell",
      "data-dsh-plugin": "dsh-personal-hud",
      onMouseEnter: () => setOn(true),
      onMouseLeave: () => setOn(false),
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ph-bar", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ph-seg", style: { minWidth: 0 }, children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "ph-chip", title: cur ? `\u4F1A\u8BDD ${cur.id}` : "\u5F53\u524D\u4F1A\u8BDD", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-dot", "data-on": cur?.running === true }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-title", children: cur ? cur.title : "\u65E0\u4F1A\u8BDD" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "ph-chip ph-muted", title: "Agent \u771F\u6E90\u672A\u63A5\u5165\uFF08\u4E0D\u663E\u793A\u5360\u4F4D\u503C\uFF09", children: [
            "Agent \xB7 ",
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-muted", children: "\u2014" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "ph-chip ph-muted", title: "Project \u771F\u6E90\u672A\u63A5\u5165\uFF08\u4E0D\u663E\u793A\u5360\u4F4D\u503C\uFF09", children: [
            "Project \xB7 ",
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-muted", children: "\u2014" })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ph-seg", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-chip ph-muted", title: "\u4E0A\u4E0B\u6587\u5360\u7528\uFF08\u65E0\u771F\u6E90 \u2192 \u5982\u5B9E\u663E\u793A\u672A\u77E5\uFF09", children: "ctx \u2014%" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-chip ph-muted", title: "Token \u901F\u7387\uFF08\u65E0\u771F\u6E90 \u2192 \u5982\u5B9E\u663E\u793A\u672A\u77E5\uFF09", children: "tok \u2014/s" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-chip ph-muted", title: "\u4F1A\u8BDD\u8D39\u7528\uFF08\u65E0\u771F\u6E90 \u2192 \u5982\u5B9E\u663E\u793A\u672A\u77E5\uFF09", children: "\xA5 \u2014" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-chip ph-muted", title: "Git \u72B6\u6001\uFF08\u65E0\u771F\u6E90 \u2192 \u5982\u5B9E\u663E\u793A\u672A\u77E5\uFF09", children: "Git \u2014" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "ph-chip", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-dot", "data-on": s.runtime === "online", "data-warn": s.runtime === "connecting" }),
            "Sync"
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
            "button",
            {
              type: "button",
              className: "ph-btn",
              "data-on": open,
              title: "\u6253\u5F00/\u5173\u95ED Inspector\uFF08\u5FEB\u6377\u952E \u2318I\uFF09",
              onClick: () => hudWindow.setOpen(!open),
              children: [
                "Inspector ",
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-kbd", children: "\u2318I" })
              ]
            }
          )
        ] })
      ] })
    }
  );
}
function Inspector() {
  const { open, width } = useHudWindow();
  const s = useHudState();
  if (!open) return null;
  const cur = s.current;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ph-inspector", style: { width }, "data-dsh-plugin": "dsh-personal-hud", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "div",
      {
        className: "ph-resize",
        title: "\u62D6\u62FD\u8C03\u6574\u5BBD\u5EA6",
        onMouseDown: (e) => {
          e.preventDefault();
          const startX = e.clientX;
          const startW = width;
          const onMove = (ev) => {
            hudWindow.setWidth(startW + (startX - ev.clientX));
          };
          const onUp = () => {
            window.removeEventListener("mousemove", onMove);
            window.removeEventListener("mouseup", onUp);
          };
          window.addEventListener("mousemove", onMove);
          window.addEventListener("mouseup", onUp);
        }
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ph-head", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-head-title", children: "Inspector" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "ph-btn", onClick: () => hudWindow.setOpen(false), title: "\u5173\u95ED", children: "\u2715" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ph-body", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ph-group", children: "\u4F1A\u8BDD" }),
      cur ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "\u6807\u9898", value: cur.title, main: true, hint: cur.id }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "\u4F1A\u8BDD ID", value: fmtId(cur.id), hint: cur.id }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "\u72B6\u6001", value: cur.running ? "\u8FD0\u884C\u4E2D" : "\u7A7A\u95F2", main: true })
      ] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ph-empty", children: "\u6682\u65E0\u5F53\u524D\u4F1A\u8BDD" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ph-group", children: "\u4EA7\u54C1" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "\u4EA7\u54C1\u7248\u672C", value: PRODUCT_LABEL, main: true, hint: "\u4EA7\u54C1\u7248\u672C\uFF08\u4E0E\u7EC4\u4EF6\u7248\u672C\u8BED\u4E49\u4E0D\u540C\uFF09" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "\u7EC4\u4EF6\u7248\u672C", value: HUD_COMPONENT_VERSION, hint: "\u7EC4\u4EF6\u7248\u672C\u4EC5\u7528\u4E8E\u6392\u969C\u6838\u5BF9\uFF1Bsidebar/workspace \u7248\u672C\u89C1\u5DE6\u680F\u8BCA\u65AD\u9762\u677F" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ph-group", children: "\u5DE5\u4F5C\u53F0" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "Agent", value: "\u2014", hint: "Agent \u771F\u6E90\u672A\u63A5\u5165\uFF1A\u4E0D\u663E\u793A\u5360\u4F4D\u540D\uFF08\u672A\u77E5 \u2260 0\uFF09" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "Project", value: "\u2014", hint: "Project \u771F\u6E90\u672A\u63A5\u5165\uFF1A\u4E0D\u663E\u793A\u5360\u4F4D\u540D\uFF08\u9879\u76EE\u6570\u636E\u5728\u300C\u9879\u76EE\u4E2D\u5FC3\u300D\u4E3A\u771F\u6E90\uFF09" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "Task", value: "\u2014", hint: "\u4EFB\u52A1\u771F\u6E90\u5728\u5B98\u65B9\u4EFB\u52A1\u770B\u677F\uFF08\u672C\u9762\u677F\u672A\u63A5\u5165\uFF09" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "Context", value: "\u2014", hint: "\u4E0A\u4E0B\u6587\u5360\u7528/\u538B\u7F29\uFF08\u65E0\u771F\u6E90\uFF09" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "Memory", value: "\u2014", hint: "\u957F\u671F\u8BB0\u5FC6\u89C6\u56FE\uFF08\u65E0\u771F\u6E90\uFF09" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "Tools", value: "\u2014", hint: "\u5F53\u524D\u53EF\u7528\u5DE5\u5177\u96C6\uFF08\u65E0\u771F\u6E90\uFF09" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ph-group", children: "\u6D3B\u52A8" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "Activity", value: "\u2014", hint: "\u56DE\u5408/\u5DE5\u5177\u6D3B\u52A8\u6D41\uFF08\u65E0\u771F\u6E90\uFF09" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "Files", value: "\u2014", hint: "\u6587\u4EF6\u53D8\u66F4\uFF08\u65E0\u771F\u6E90\uFF09" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: "Git", value: "\u2014", hint: "Git \u72B6\u6001\uFF08\u65E0\u771F\u6E90\uFF09" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ph-group", children: "\u6700\u8FD1\u4F1A\u8BDD" }),
      s.recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ph-empty", children: "\uFF08\u65E0\uFF09" }) : s.recent.slice(0, 8).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ph-sess", title: r.id, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-dot", ...dotData(r.running) }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-sess-title", children: r.title }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ph-muted", style: { marginLeft: "auto", flex: "0 0 auto" }, children: timeLabel(r.updatedAt) })
      ] }, r.id)),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ph-empty", style: { marginTop: 6 }, children: "\u771F\u5B9E\u6570\u636E\u9010\u6B65\u63A5\u5165\uFF1A\u4F1A\u8BDD/\u8FD0\u884C\u6001\u6765\u81EA\u5B98\u65B9 Session \u5FEB\u7167\uFF1B\u5176\u4F59\u5B57\u6BB5\u6309 Stage \u89C4\u5212\u8865\u9F50\u3002" })
    ] })
  ] });
}

// src/workstation/personal-hud/src/client/index.tsx
var import_jsx_runtime2 = require("react/jsx-runtime");
var inject = ["sessions"];
var HUD_VERSION = hudComponentVersion();
var hudMounted = false;
function apply(ctx) {
  try {
    applyInner(ctx);
  } catch (error) {
    console.warn("[dsh-personal-hud] apply aborted:", error);
  }
}
function applyInner(ctx) {
  if (typeof window === "undefined" || typeof document === "undefined") return false;
  if (hudMounted) return true;
  const sessionsOf = () => {
    try {
      return typeof ctx.get === "function" ? ctx.get("sessions") : void 0;
    } catch {
      return void 0;
    }
  };
  const mount = () => {
    hudMounted = true;
    const styleEl = document.createElement("style");
    styleEl.setAttribute("data-dsh-plugin", "dsh-personal-hud");
    styleEl.textContent = CSS_PH;
    document.head.appendChild(styleEl);
    const barHost = document.createElement("div");
    barHost.id = "ph-statusbar-host";
    const inspHost = document.createElement("div");
    inspHost.id = "ph-inspector-host";
    document.body.appendChild(barHost);
    document.body.appendChild(inspHost);
    let barRoot = null;
    let inspRoot = null;
    try {
      barRoot = (0, import_client.createRoot)(barHost);
      barRoot.render(/* @__PURE__ */ (0, import_jsx_runtime2.jsx)(StatusBar, {}));
      inspRoot = (0, import_client.createRoot)(inspHost);
      inspRoot.render(/* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Inspector, {}));
    } catch (error) {
      console.warn("[dsh-personal-hud] react render unavailable:", error);
    }
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "i") {
        e.preventDefault();
        hudWindow.setOpen(!hudWindow.get().open);
      }
    };
    window.addEventListener("keydown", onKey);
    const offFeed = attachSessionFeed(sessionsOf);
    return () => {
      hudMounted = false;
      try {
        offFeed();
      } catch {
      }
      window.removeEventListener("keydown", onKey);
      try {
        barRoot?.unmount();
      } catch {
      }
      try {
        inspRoot?.unmount();
      } catch {
      }
      barHost.remove();
      inspHost.remove();
      styleEl.remove();
    };
  };
  if (typeof ctx.effect === "function") {
    ctx.effect(() => mount(), `ph: ${PRODUCT_LABEL} \xB7 hud ${HUD_VERSION}`);
  } else {
    mount();
  }
  return true;
}
return module.exports; } });
