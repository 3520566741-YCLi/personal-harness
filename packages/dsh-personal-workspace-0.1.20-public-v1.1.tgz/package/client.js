window.__ModuleLoader__.load({ id: 'dsh-personal-workspace', factory: (require) => { var module = { exports: {} }; var exports = module.exports;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/workstation/personal-workspace/src/client/index.tsx
var index_exports = {};
__export(index_exports, {
  LAYERS: () => LAYERS,
  NewTaskTab: () => NewTaskTab,
  apply: () => apply,
  clearPendingSessionOrigin: () => clearPendingSessionOrigin,
  inject: () => inject,
  mountIntoBody: () => mountIntoBody,
  navigateMain: () => navigateMain,
  openNewTaskTab: () => openNewTaskTab,
  overlayRootFor: () => overlayRootFor,
  pushNewTaskProject: () => pushNewTaskProject,
  pushNewTaskSession: () => pushNewTaskSession,
  pushStartPrefill: () => pushStartPrefill,
  removeOverlayRoot: () => removeOverlayRoot
});
module.exports = __toCommonJS(index_exports);
var import_react11 = require("react");

// src/workstation/personal-projects/registry.json
var registry_default = {
  $schema: "draft-01",
  note: "Personal Harness public distribution: project seed is intentionally EMPTY. First install starts with a blank user state; add your own projects from the UI.",
  projects: []
};

// src/workstation/personal-registry/src/projects.ts
var STORE_VERSION = 1;
var STORE_KEY = "dsh.personal.projects.v1";
var CHANGE_EVENT = "dsh:personal-projects-changed";
var seedList = Array.isArray(registry_default?.projects) ? registry_default.projects : [];
var seedCache = null;
var listCache = null;
function invalidateProjectSnapshots() {
  listCache = null;
}
function str(v) {
  return typeof v === "string" ? v : "";
}
function projectSeeds() {
  if (seedCache !== null) return seedCache;
  const out = [];
  const now = 0;
  for (const raw of seedList) {
    const id = str(raw.id);
    const name = str(raw.name);
    if (!id || !name) continue;
    const glyph = str(raw.glyph) || name.slice(0, 1);
    out.push({ id, name, description: str(raw.description) || void 0, glyph, seed: true, createdAt: now, updatedAt: now });
  }
  seedCache = out;
  return out;
}
function lsGet() {
  try {
    const w = typeof window !== "undefined" ? window : void 0;
    if (!w || !w.localStorage) return null;
    return w.localStorage.getItem(STORE_KEY);
  } catch {
    return null;
  }
}
function lsSet(value) {
  try {
    const w = typeof window !== "undefined" ? window : void 0;
    if (!w || !w.localStorage) return;
    w.localStorage.setItem(STORE_KEY, value);
  } catch {
  }
}
function parseStored(raw) {
  const empty2 = { projects: [], rels: { taskProject: {}, sessionProject: {}, projectWorkspaces: {} } };
  if (!raw) return empty2;
  try {
    const data = JSON.parse(raw);
    if (data.v !== STORE_VERSION) {
      console.warn("[personal-registry] projects store version mismatch \u2014 ignore stored data");
      return empty2;
    }
    const projects = [];
    if (Array.isArray(data.projects)) {
      for (const rawP of data.projects) {
        const p = rawP ?? {};
        const id = typeof p.id === "string" && p.id ? p.id : "";
        const name = typeof p.name === "string" && p.name ? p.name : "";
        if (!id || !name) continue;
        projects.push({
          id,
          name,
          description: typeof p.description === "string" && p.description ? p.description : void 0,
          glyph: typeof p.glyph === "string" && p.glyph ? p.glyph : name.slice(0, 1),
          seed: p.seed === true,
          createdAt: typeof p.createdAt === "number" ? p.createdAt : 0,
          updatedAt: typeof p.updatedAt === "number" ? p.updatedAt : 0
        });
      }
    }
    const strMap = (v) => {
      const out = {};
      if (v && typeof v === "object") {
        for (const [k, val] of Object.entries(v)) {
          if (typeof val === "string" && val) out[k] = val;
        }
      }
      return out;
    };
    const strListMap = (v) => {
      const out = {};
      if (v && typeof v === "object") {
        for (const [k, val] of Object.entries(v)) {
          if (Array.isArray(val)) {
            const ids = val.filter((x) => typeof x === "string" && x.length > 0);
            if (ids.length > 0) out[k] = ids;
          }
        }
      }
      return out;
    };
    const rels = {
      taskProject: strMap(data.rels?.taskProject),
      sessionProject: strMap(data.rels?.sessionProject),
      projectWorkspaces: strListMap(data.rels?.projectWorkspaces)
    };
    return { projects, rels };
  } catch (error) {
    console.warn("[personal-registry] projects store parse failed \u2014 start empty:", error);
    return empty2;
  }
}
function serialize(state3) {
  return JSON.stringify({ v: STORE_VERSION, projects: state3.projects, rels: state3.rels });
}
var state = parseStored(lsGet());
var subs = /* @__PURE__ */ new Set();
function emit() {
  subs.forEach((f) => {
    try {
      f();
    } catch {
    }
  });
}
function commit(next) {
  state = next;
  invalidateProjectSnapshots();
  lsSet(serialize(state));
  emit();
  try {
    const w = typeof window !== "undefined" ? window : void 0;
    if (w && typeof w.dispatchEvent === "function" && typeof CustomEvent === "function") {
      w.dispatchEvent(new CustomEvent(CHANGE_EVENT));
    }
  } catch {
  }
}
function reloadFromStorage() {
  state = parseStored(lsGet());
  invalidateProjectSnapshots();
  emit();
}
try {
  if (typeof window !== "undefined" && window.addEventListener) {
    window.addEventListener(CHANGE_EVENT, () => reloadFromStorage());
    window.addEventListener("storage", (e) => {
      try {
        if (e.key === STORE_KEY) reloadFromStorage();
      } catch {
      }
    });
  }
} catch {
}
var projectRegistry = {
  subscribe(f) {
    subs.add(f);
    return () => {
      subs.delete(f);
    };
  },
  getState() {
    return state;
  },
  /** 种子 + 用户项目并集（种子在前，用户项目按创建时间升序在后）。
   *  引用稳定：未变更时返回同一数组（可安全用作 React useSyncExternalStore 的 getSnapshot，
   *  见上方 #185 说明）；变更后返回新数组。 */
  listProjects() {
    if (listCache === null) {
      const seeds = projectSeeds();
      const seen = new Set(seeds.map((s) => s.id));
      const users = state.projects.filter((p) => !seen.has(p.id));
      listCache = [...seeds, ...users];
    }
    return listCache;
  },
  projectById(id) {
    return this.listProjects().find((p) => p.id === id);
  },
  // ---- 关系查询（Host 侧 id -> projectId） ----
  projectOfTask(taskId) {
    return state.rels.taskProject[taskId];
  },
  projectOfSession(sessionId) {
    return state.rels.sessionProject[sessionId];
  },
  workspacesOf(projectId) {
    return state.rels.projectWorkspaces[projectId] ?? [];
  },
  projectsOfWorkspace(workspaceId) {
    const out = [];
    for (const p of this.listProjects()) {
      if ((state.rels.projectWorkspaces[p.id] ?? []).includes(workspaceId)) out.push(p);
    }
    return out;
  },
  // ---- 变更（全部 write-through） ----
  createProject(input) {
    const name = input.name.trim();
    if (!name) throw new Error("\u9879\u76EE\u540D\u79F0\u4E0D\u80FD\u4E3A\u7A7A");
    const now = Date.now();
    const id = `p-${now.toString(36)}-${Math.floor(Math.random() * 1e4).toString(36)}`;
    const rec = {
      id,
      name,
      description: input.description?.trim() ? input.description.trim() : void 0,
      glyph: name.slice(0, 1),
      seed: false,
      createdAt: now,
      updatedAt: now
    };
    commit({ projects: [...state.projects, rec], rels: cloneRels(state.rels) });
    return rec;
  },
  /** 改名 / 改描述（仅用户自建项目；种子基础档案在 registry.json 改后重建）。 */
  updateProject(id, patch) {
    if (!state.projects.some((p) => p.id === id)) return;
    const next = state.projects.map((p) => p.id === id ? { ...p, ...patch, updatedAt: Date.now() } : p);
    commit({ projects: next, rels: cloneRels(state.rels) });
  },
  /** 仅用户自建项目可删；删除时清除其全部关系（关联任务/会话回到未分配）。 */
  deleteProject(id) {
    const target = state.projects.find((p) => p.id === id && !p.seed);
    if (!target) return false;
    const rels = cloneRels(state.rels);
    for (const [k, v] of Object.entries(rels.taskProject)) if (v === id) delete rels.taskProject[k];
    for (const [k, v] of Object.entries(rels.sessionProject)) if (v === id) delete rels.sessionProject[k];
    delete rels.projectWorkspaces[id];
    commit({ projects: state.projects.filter((p) => p.id !== id), rels });
    return true;
  },
  // ---- 关系变更 ----
  assignTask(taskId, projectId) {
    const rels = cloneRels(state.rels);
    rels.taskProject[taskId] = projectId;
    commit({ projects: state.projects, rels });
  },
  unassignTask(taskId) {
    const rels = cloneRels(state.rels);
    delete rels.taskProject[taskId];
    commit({ projects: state.projects, rels });
  },
  assignSession(sessionId, projectId) {
    const rels = cloneRels(state.rels);
    rels.sessionProject[sessionId] = projectId;
    commit({ projects: state.projects, rels });
  },
  unassignSession(sessionId) {
    const rels = cloneRels(state.rels);
    delete rels.sessionProject[sessionId];
    commit({ projects: state.projects, rels });
  },
  linkWorkspace(projectId, workspaceId) {
    const rels = cloneRels(state.rels);
    const list = rels.projectWorkspaces[projectId] ?? [];
    if (!list.includes(workspaceId)) rels.projectWorkspaces[projectId] = [...list, workspaceId];
    commit({ projects: state.projects, rels });
  },
  unlinkWorkspace(projectId, workspaceId) {
    const rels = cloneRels(state.rels);
    const list = rels.projectWorkspaces[projectId] ?? [];
    rels.projectWorkspaces[projectId] = list.filter((w) => w !== workspaceId);
    if (rels.projectWorkspaces[projectId].length === 0) delete rels.projectWorkspaces[projectId];
    commit({ projects: state.projects, rels });
  },
  /** 调试/排障：把当前关系快照导出为纯 JSON 字符串（UI 不展示，仅 Advanced/Logs 可用）。 */
  exportSnapshot() {
    return serialize(state);
  }
};
function cloneRels(rels) {
  return {
    taskProject: { ...rels.taskProject },
    sessionProject: { ...rels.sessionProject },
    projectWorkspaces: Object.fromEntries(Object.entries(rels.projectWorkspaces).map(([k, v]) => [k, [...v]]))
  };
}

// src/workstation/personal-agents/registry.json
var registry_default2 = {
  $schema: "draft-01",
  note: "Personal Harness public distribution: agent catalog seed is intentionally EMPTY (agent presets are not part of this distribution).",
  agents: []
};

// src/workstation/personal-registry/src/index.ts
var str2 = (v) => typeof v === "string" ? v : "";
var glyphOf = (raw, name) => {
  const g = str2(raw);
  return g.length > 0 ? g : name.slice(0, 1);
};
function parseAgents(file) {
  const list = Array.isArray(file?.agents) ? file.agents : [];
  const out = [];
  for (const raw of list) {
    const id = str2(raw.id);
    const name = str2(raw.name);
    if (!id || !name) {
      console.warn("[personal-registry] drop invalid agent entry", raw);
      continue;
    }
    out.push({
      id,
      name,
      zh: str2(raw.zh) || name,
      glyph: glyphOf(raw.glyph, name),
      description: str2(raw.description),
      presetId: str2(raw.presetId) || id
    });
  }
  if (list.length === 0) console.warn("[personal-registry] agents catalog empty \u2014 UI will degrade");
  return out;
}
function parseProjects(file) {
  const list = Array.isArray(file?.projects) ? file.projects : [];
  const out = [];
  for (const raw of list) {
    const id = str2(raw.id);
    const name = str2(raw.name);
    if (!id || !name) {
      console.warn("[personal-registry] drop invalid project entry", raw);
      continue;
    }
    const agentIds = Array.isArray(raw.agents) ? raw.agents.filter((a) => typeof a === "string") : [];
    out.push({
      id,
      name,
      zh: str2(raw.zh) || name,
      glyph: glyphOf(raw.glyph, name),
      description: str2(raw.description),
      agentIds
    });
  }
  if (list.length === 0) console.warn("[personal-registry] projects catalog empty \u2014 UI will degrade");
  return out;
}
var AGENT_CATALOG = parseAgents(registry_default2);
var PROJECT_CATALOG = parseProjects(registry_default);

// src/workstation/personal-workspace/src/client/dashboard.tsx
var import_jsx_runtime = require("react/jsx-runtime");
var AGENTS = AGENT_CATALOG.map((a) => a.name);
var PROJECTS = PROJECT_CATALOG.map((p) => [p.name, p.zh]);
var CSS_WS = String.raw`
.dpw-root { padding: 10px 12px; font: var(--dsw-font-xxs-12, 12px); color: var(--dsw-alias-label-primary); user-select: none; }
.dpw-title { font: var(--dsw-font-s-strong-14, 600 13px); margin-bottom: 4px; }
.dpw-sub { color: var(--dsw-alias-label-tertiary); font: var(--dsw-font-xxxs-11, 11px); margin-bottom: 10px; }
.dpw-group { margin: 8px 0 3px; font: var(--dsw-font-xxxs-strong-11, 600 11px); letter-spacing: .06em; color: var(--dsw-alias-label-tertiary); }
.dpw-chip { display: inline-block; border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,.3)); border-radius: 6px; padding: 2px 7px; margin: 2px 4px 2px 0; }
.dpw-row { display: flex; gap: 6px; align-items: baseline; padding: 2px 0; }
.dpw-row b { color: var(--dsw-alias-label-primary); }
.dpw-muted { color: var(--dsw-alias-label-dimmed); }
.dpw-note { margin-top: 10px; border-top: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.2)); padding-top: 8px; color: var(--dsw-alias-label-tertiary); font: var(--dsw-font-xxxs-11, 11px); line-height: 1.6; }
`;

// src/workstation/personal-workspace/src/client/mainview.ts
var MAIN_VIEWS = [
  "conversation",
  "home",
  "task-board",
  "new-task",
  "project-center",
  "project-detail",
  "unassigned",
  "workspace-center",
  "recent"
];
function isMainView(v) {
  return typeof v === "string" && MAIN_VIEWS.includes(v);
}
var MAIN_OPEN_EVENT = "dsh:personal-main-open";
var MAIN_ACK_EVENT = "dsh:personal-main-ack";
var MAIN_STATE_EVENT = "dsh:personal-main-state";
var MAIN_HOST_READY_FLAG = "__dshPersonalMainReady";
var STORAGE_KEY = "dsh.personal.mainview.v1";
var current = "conversation";
var hydrated = false;
var subs2 = /* @__PURE__ */ new Set();
function hydrate() {
  if (hydrated) return;
  hydrated = true;
  if (typeof window === "undefined") return;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (isMainView(raw)) current = raw;
  } catch {
  }
}
function notify() {
  subs2.forEach((fn) => {
    try {
      fn();
    } catch {
    }
  });
}
function persist() {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, current);
  } catch {
  }
}
function broadcastState() {
  if (typeof window === "undefined") return;
  try {
    window.dispatchEvent(new CustomEvent(MAIN_STATE_EVENT, { detail: { view: current } }));
  } catch {
  }
}
function mainViewGet() {
  hydrate();
  return current;
}
function mainViewSubscribe(fn) {
  hydrate();
  subs2.add(fn);
  return () => {
    subs2.delete(fn);
  };
}
function setCurrent(view) {
  current = view;
  persist();
  notify();
  broadcastState();
  publishDiag();
}
function mainViewShow(view) {
  const next = isMainView(view) ? view : "conversation";
  setCurrent(next);
}
function mainViewBackToConversation() {
  setCurrent("conversation");
}
function mainHostOk() {
  if (typeof window === "undefined") return false;
  try {
    return window[MAIN_HOST_READY_FLAG] === true;
  } catch {
    return false;
  }
}
function acknowledge(view, ok, reason, seatPriority2) {
  if (typeof window === "undefined") return;
  try {
    window.dispatchEvent(
      new CustomEvent(MAIN_ACK_EVENT, {
        detail: {
          view,
          ok,
          ...seatPriority2 !== void 0 && seatPriority2 !== null ? { seatPriority: seatPriority2 } : {},
          ...reason ? { reason } : {}
        }
      })
    );
  } catch {
  }
}
var slots = null;
var hostComponent = null;
var disposer = null;
var ready = false;
var CONVERSATION_SEAT = "conversation";
var MAIN_PRIORITY_BASE = -2e3;
var MAIN_PRIORITY_FLOOR = -4096;
var INSTANCE_TAG = "dpw-" + Math.random().toString(36).slice(2, 8);
var seatPriority = MAIN_PRIORITY_BASE;
function tryRegisterAt(priority) {
  if (!ready || !slots || typeof slots.register !== "function" || hostComponent === null) {
    return null;
  }
  try {
    const cleanup = slots.register(
      { name: CONVERSATION_SEAT, priority, registrant: "dsh-personal-workspace" },
      hostComponent
    );
    if (typeof cleanup !== "function") return null;
    return cleanup;
  } catch {
    return null;
  }
}
function disposeOccupant() {
  if (disposer) {
    try {
      disposer();
    } catch {
    }
    disposer = null;
    publishDiag();
  }
}
function publishDiag() {
  if (typeof window === "undefined") return;
  try {
    const g = window.__dshMainDiag;
    const target = g ?? {};
    target.tag = INSTANCE_TAG;
    target.ready = ready;
    target.current = current;
    target.registered = disposer !== null;
    target.seatPriority = disposer !== null ? seatPriority : null;
    target.hostOk = mainHostOk();
    target.updatedAt = Date.now();
    window.__dshMainDiag = g ?? target;
  } catch {
  }
}
function syncOccupant() {
  if (current === "conversation") {
    disposeOccupant();
    return true;
  }
  if (disposer !== null) {
    publishDiag();
    return true;
  }
  let priority = seatPriority;
  for (; ; ) {
    const cleanup = tryRegisterAt(priority);
    if (cleanup !== null) {
      disposer = cleanup;
      seatPriority = priority;
      publishDiag();
      return true;
    }
    if (priority <= MAIN_PRIORITY_FLOOR) {
      console.warn(
        `[dsh-personal-workspace] \u4E2D\u592E\u4E3B\u533A occupant \u6CE8\u518C\u5931\u8D25\uFF08-2000..${MAIN_PRIORITY_FLOOR} \u5747\u88AB\u5360\u7528\uFF0C\u4FDD\u6301\u5B98\u65B9 Conversation\uFF09`
      );
      publishDiag();
      return false;
    }
    priority -= 1;
  }
}
function onOpen(ev) {
  let view;
  try {
    view = ev.detail?.view;
  } catch {
    view = void 0;
  }
  const target = isMainView(view) ? view : "conversation";
  setCurrent(target);
  const ok = syncOccupant();
  acknowledge(target, ok, ok ? void 0 : "\u4E2D\u592E\u4E3B\u533A\u4E0D\u53EF\u7528\uFF08seat \u6CE8\u518C\u5931\u8D25\uFF09\u2014\u2014\u5DF2\u56DE\u9000\u8F85\u52A9\u9762\u677F\u6253\u5F00", ok ? seatPriority : null);
}
function initMainHost(opts) {
  slots = opts.slots;
  hostComponent = opts.host;
  ready = Boolean(slots && typeof slots.register === "function" && hostComponent !== null);
  try {
    ;
    window[MAIN_HOST_READY_FLAG] = ready;
  } catch {
  }
  publishDiag();
  const offSub = mainViewSubscribe(() => {
    syncOccupant();
  });
  const onOpenRef = (ev) => onOpen(ev);
  try {
    window.addEventListener(MAIN_OPEN_EVENT, onOpenRef);
  } catch {
  }
  syncOccupant();
  broadcastState();
  return () => {
    try {
      window.removeEventListener(MAIN_OPEN_EVENT, onOpenRef);
    } catch {
    }
    try {
      offSub();
    } catch {
    }
    disposeOccupant();
    try {
      ;
      window[MAIN_HOST_READY_FLAG] = false;
    } catch {
    }
    slots = null;
    hostComponent = null;
    ready = false;
    seatPriority = MAIN_PRIORITY_BASE;
    publishDiag();
  };
}
var CSS_MAIN_HOST = String.raw`
.dpw-main-host {
  box-sizing: border-box;
  height: 100%;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  background: var(--dsw-alias-bg-base, transparent);
  color: var(--dsw-alias-label-primary, inherit);
}
.dpw-main-error {
  padding: 20px;
  font: 13px/1.7 var(--ds-font-family, system-ui, sans-serif);
  color: var(--dsw-alias-label-tertiary, #9a9aa5);
}
.dpw-main-error code { font-family: var(--ds-font-family-code, monospace); word-break: break-all; }
`;

// src/workstation/personal-workspace/src/client/attention.ts
var ATTENTION_EVENT = "dsh:personal-attention";
var ATTENTION_REQUEST_EVENT = "dsh:personal-attention-request";
var BOARD_OPEN_TASK_EVENT = "dsh:board-open-task";
var EMPTY_ATTENTION = {
  v: 1,
  n: null,
  ready: false,
  hostUp: false,
  items: []
};
function composeAttention(st) {
  const hostUp = st.ready && st.hostReachable;
  if (!hostUp) {
    return {
      v: 1,
      n: null,
      ready: st.ready,
      hostUp: false,
      ...typeof st.hostError === "string" && st.hostError.length > 0 ? { hostError: st.hostError } : {},
      items: []
    };
  }
  const items = st.tasks.filter((p) => p.attention !== null).sort((a, b) => (b.attention?.weight ?? 0) - (a.attention?.weight ?? 0)).map((p) => ({
    id: p.task.id,
    label: p.task.title || "\uFF08\u672A\u547D\u540D\u4EFB\u52A1\uFF09",
    reason: p.attention?.label ?? "\u9700\u8981\u5904\u7406",
    kind: p.attention?.kind ?? "unknown",
    weight: p.attention?.weight ?? 0
  }));
  return { v: 1, n: items.length, ready: true, hostUp: true, items };
}
function canBus() {
  return typeof window !== "undefined" && typeof window.dispatchEvent === "function" && typeof window.addEventListener === "function" && typeof window.removeEventListener === "function" && typeof CustomEvent === "function";
}
function bindAttentionFeed(reconcile) {
  let disposed = false;
  let lastJson = "";
  let off = null;
  const snapshot = () => {
    try {
      return composeAttention(reconcile.getState());
    } catch {
      return EMPTY_ATTENTION;
    }
  };
  const emit2 = (force) => {
    if (disposed || !canBus()) return;
    const payload = snapshot();
    const json = JSON.stringify(payload);
    if (!force && json === lastJson) return;
    lastJson = json;
    try {
      window.dispatchEvent(new CustomEvent(ATTENTION_EVENT, { detail: payload }));
    } catch {
    }
  };
  const onRequest = () => emit2(true);
  try {
    off = reconcile.subscribe(() => emit2(false));
  } catch {
    off = null;
  }
  try {
    window.addEventListener(ATTENTION_REQUEST_EVENT, onRequest);
  } catch {
  }
  emit2(true);
  return () => {
    disposed = true;
    try {
      off?.();
    } catch {
    }
    try {
      window.removeEventListener(ATTENTION_REQUEST_EVENT, onRequest);
    } catch {
    }
  };
}
function bindBoardOpenTask(handler) {
  if (!canBus()) return () => {
  };
  const onEvent = (ev) => {
    try {
      const detail = ev.detail;
      const id = detail?.taskId;
      if (typeof id === "string" && id.length > 0) handler(id);
    } catch {
    }
  };
  try {
    window.addEventListener(BOARD_OPEN_TASK_EVENT, onEvent);
  } catch {
    return () => {
    };
  }
  return () => {
    try {
      window.removeEventListener(BOARD_OPEN_TASK_EVENT, onEvent);
    } catch {
    }
  };
}

// src/workstation/personal-workspace/src/client/home.tsx
var import_react3 = require("react");

// src/workstation/personal-workspace/src/client/projection.ts
var TASK_PERMISSIONS = ["read-only", "workspace-write", "danger-full-access"];
function isTaskPermission(value) {
  return typeof value === "string" && TASK_PERMISSIONS.includes(value);
}
var TASK_STATUSES = ["backlog", "todo", "running", "done", "failed"];
function isTaskStatus(value) {
  return typeof value === "string" && TASK_STATUSES.includes(value);
}
function str3(v) {
  return typeof v === "string" && v.length > 0 ? v : void 0;
}
function num(v) {
  return typeof v === "number" && Number.isFinite(v) ? v : void 0;
}
function optNum(v) {
  const n = num(v);
  return n !== void 0 && n >= 0 ? n : void 0;
}
function isExecutionResult(v) {
  return v === "succeeded" || v === "failed" || v === "cancelled";
}
function parseExecution(raw) {
  const r = raw ?? {};
  const id = str3(r.id);
  if (id === void 0) return null;
  const startedAt = num(r.startedAt);
  if (startedAt === void 0) return null;
  return {
    id,
    ...str3(r.sessionId) !== void 0 ? { sessionId: str3(r.sessionId) } : {},
    startedAt,
    ...optNum(r.endedAt) !== void 0 ? { endedAt: optNum(r.endedAt) } : {},
    ...isExecutionResult(r.result) ? { result: r.result } : {},
    ...str3(r.error) !== void 0 ? { error: str3(r.error) } : {}
  };
}
function parseSchedule(raw) {
  if (raw === null || typeof raw !== "object") return void 0;
  const r = raw;
  const cron = str3(r.cron);
  if (cron === void 0) return void 0;
  const nextRunAt = num(r.nextRunAt);
  const lastTriggeredAt = num(r.lastTriggeredAt);
  return {
    enabled: r.enabled === true,
    cron,
    ...nextRunAt !== void 0 ? { nextRunAt } : {},
    ...lastTriggeredAt !== void 0 ? { lastTriggeredAt } : {}
  };
}
function parseTaskRecord(raw) {
  const r = raw ?? {};
  const id = str3(r.id);
  const title = str3(r.title);
  if (id === void 0 || title === void 0) return null;
  const status = isTaskStatus(r.status) ? r.status : void 0;
  const createdAt = num(r.createdAt);
  if (status === void 0 || createdAt === void 0) return null;
  const executions = Array.isArray(r.executions) ? r.executions.map(parseExecution).filter((e) => e !== null) : [];
  const updatedAt = optNum(r.updatedAt) ?? createdAt;
  const schedule = parseSchedule(r.schedule);
  return {
    id,
    title,
    description: str3(r.description) ?? "",
    prompt: str3(r.prompt) ?? title,
    status,
    createdAt,
    updatedAt,
    executions,
    ...str3(r.workspaceId) !== void 0 ? { workspaceId: str3(r.workspaceId) } : {},
    ...str3(r.mode) !== void 0 ? { mode: str3(r.mode) } : {},
    ...isTaskPermission(r.permission) ? { permission: r.permission } : {},
    ...str3(r.model) !== void 0 ? { model: str3(r.model) } : {},
    ...num(r.permissionConfirmedAt) !== void 0 ? { permissionConfirmedAt: num(r.permissionConfirmedAt) } : {},
    ...optNum(r.archivedAt) !== void 0 ? { archivedAt: optNum(r.archivedAt) } : {},
    ...schedule !== void 0 ? { schedule } : {},
    ...str3(r.error) !== void 0 ? { error: str3(r.error) } : {}
  };
}
var PERMISSION_RANK = {
  "read-only": 0,
  "workspace-write": 1,
  "danger-full-access": 2
};
function effectivePermission(task) {
  return task.permission;
}
function exceedsSessionDefault(permission, sessionDefault) {
  if (permission === void 0 || sessionDefault === void 0) return false;
  return (PERMISSION_RANK[permission] ?? -1) > (PERMISSION_RANK[sessionDefault] ?? -1);
}
function requiresConfirmation(task, sessionDefault) {
  return exceedsSessionDefault(effectivePermission(task), sessionDefault) && task.permissionConfirmedAt === void 0;
}
function latestExecution(task) {
  if (task.executions.length === 0) return void 0;
  return task.executions[task.executions.length - 1];
}
function hasOpenExecution(task) {
  return task.executions.some((e) => e.endedAt === void 0);
}
function archivedSetOf(ids) {
  return new Set(ids ?? []);
}
function sessionAttachOf(task, sessionRows, archived) {
  const execution = latestExecution(task);
  const sessionId = execution?.sessionId;
  if (sessionId === void 0) return void 0;
  const row = sessionRows.get(sessionId);
  return {
    sessionId,
    ...row?.running !== void 0 ? { running: row.running } : {},
    archived: archived.has(sessionId),
    ...row?.title !== void 0 ? { title: row.title } : {},
    ...row?.updatedAt !== void 0 ? { updatedAt: row.updatedAt } : {}
  };
}
function attentionOf(task, sessionDefault) {
  if (task.archivedAt !== void 0) return null;
  if (requiresConfirmation(task, sessionDefault)) {
    return {
      kind: "confirm-permission",
      weight: 40,
      label: "\u6743\u9650\u7ED1\u5B9A\u5F85\u786E\u8BA4\uFF08\u9AD8\u4E8E\u4F1A\u8BDD\u9ED8\u8BA4\uFF09",
      target: "confirm-permission"
    };
  }
  if (task.error !== void 0 && task.error !== "") {
    return { kind: "task-error", weight: 30, label: task.error, target: "task-detail" };
  }
  const execution = latestExecution(task);
  if (execution !== void 0 && execution.endedAt !== void 0 && execution.result === "failed") {
    const label = execution.error !== void 0 && execution.error !== "" ? execution.error : "\u6700\u8FD1\u4E00\u6B21\u6267\u884C\u5931\u8D25";
    return { kind: "failed", weight: 20, label, target: "task-detail" };
  }
  if (execution !== void 0 && execution.endedAt !== void 0 && execution.result === void 0) {
    return { kind: "unknown-failure", weight: 10, label: "\u6267\u884C\u5DF2\u7ED3\u675F\u4F46\u7F3A\u5C11\u7ED3\u679C", target: "task-detail" };
  }
  return null;
}
function capabilitiesOf(task, sessionDefault) {
  const open = hasOpenExecution(task);
  const archived = task.archivedAt !== void 0;
  const pendingConfirm = requiresConfirmation(task, sessionDefault);
  const attach = latestExecution(task);
  const running = task.status === "running" || open;
  const settledDone = task.status === "done" || task.status === "failed";
  return {
    openConversation: attach?.sessionId !== void 0 && attach.sessionId !== "",
    // 官方 run/rerun 语义：archived→拒绝；running/open→拒绝；确认门→拒绝
    run: !archived && !running && !pendingConfirm && task.status !== "running",
    rerun: !archived && !running && !pendingConfirm && settledDone,
    // stop 语义：有 open execution 且已绑定 session → 会话可被 cancel（真实能力）；
    // UI 层 D3 还要求 probe sessions/remote cancel 可达性后才启用按钮。
    stop: open && attach?.sessionId !== void 0,
    // delete：宿主拒绝 running/open（镜像）；D4 在 UI 上对 running 追加引导文案。
    delete: !archived && !running,
    archive: !archived && settledDone && !open,
    restore: archived,
    confirmPermission: pendingConfirm,
    moveBacklog: canMoveManually(task, "backlog"),
    moveTodo: canMoveManually(task, "todo")
  };
}
function canMoveManually(task, to) {
  if (task.archivedAt !== void 0) return false;
  if (hasOpenExecution(task) || task.status === "running") return false;
  if (to !== "backlog" && to !== "todo") return false;
  return task.status !== to;
}
function archiveTruthOf(input) {
  if (input === null || input === void 0) return { known: false, ids: /* @__PURE__ */ new Set() };
  const raw = input.archivedSessionIds;
  if (!Array.isArray(raw) || input.workspacesSource === false) {
    return { known: false, ids: /* @__PURE__ */ new Set() };
  }
  return { known: true, ids: new Set(raw.filter((x) => typeof x === "string")) };
}
function archiveNoteOf(truth) {
  return truth.known ? "" : "\u5F52\u6863\u72B6\u6001\u672A\u77E5\uFF1A\u5B98\u65B9 workspaces\uFF08\u5F52\u6863\u6765\u6E90\uFF09\u5F53\u524D\u4E0D\u53EF\u8BFB \u2014\u2014 \u672C\u9875\u4E0D\u4F1A\u628A\u4F1A\u8BDD\u8BEF\u5224\u4E3A\u300C\u672A\u5F52\u6863\u300D\uFF0C\u4E5F\u4E0D\u9690\u85CF\u4EFB\u4F55\u884C\uFF1B\u6062\u590D\u6765\u6E90\u540E\u81EA\u52A8\u751F\u6548\u3002";
}
function projectBoard(input) {
  const archived = archivedSetOf(input.archivedSessionIds);
  const sessionRows = /* @__PURE__ */ new Map();
  for (const row of input.sessions ?? []) {
    if (row?.id) sessionRows.set(row.id, row);
  }
  const tasks = (input.tasks ?? []).map(parseTaskRecord).filter((t) => t !== null);
  return tasks.map((task) => {
    const attach = sessionAttachOf(task, sessionRows, archived);
    const attention = attentionOf(task, input.sessionDefaultPermission);
    return {
      task,
      ...attach !== void 0 ? { attach } : {},
      attention,
      caps: capabilitiesOf(task, input.sessionDefaultPermission),
      taskArchived: task.archivedAt !== void 0
    };
  });
}
function sessionRowsOf(snapshot) {
  const s = snapshot ?? {};
  const byId = s.byId;
  if (byId !== null && typeof byId === "object" && !Array.isArray(byId)) {
    return Object.values(byId).map((row) => sessionRowOf(row)).filter((r) => r !== null);
  }
  const raw = Array.isArray(s) ? s : Array.isArray(s.list) ? s.list : Array.isArray(s.sessions) ? s.sessions : [];
  return raw.map(sessionRowOf).filter((r) => r !== null);
}
function sessionRowOf(raw) {
  const r = raw ?? {};
  const id = typeof r.id === "string" ? r.id : typeof r.sessionId === "string" ? r.sessionId : void 0;
  if (id === void 0 || id === "") return null;
  return {
    id,
    ...typeof r.title === "string" && r.title.length > 0 ? { title: r.title } : {},
    ...typeof r.displayTitle === "string" && r.displayTitle.length > 0 ? { displayTitle: r.displayTitle } : {},
    ...typeof r.label === "string" && r.label.length > 0 ? { title: r.label } : {},
    ...r.running === true || r.running === false ? { running: r.running } : {},
    ...typeof r.updatedAt === "number" && Number.isFinite(r.updatedAt) ? { updatedAt: r.updatedAt } : {}
  };
}
function sessionDisplayName(row) {
  const t = row?.displayTitle ?? row?.title;
  return t !== void 0 && t !== "" ? t : "\uFF08\u672A\u547D\u540D\u4F1A\u8BDD\uFF09";
}
function groupBoard(projected) {
  const active = [];
  const archived = [];
  for (const p of projected) {
    if (p.taskArchived) archived.push(p);
    else active.push(p);
  }
  return { active, archived };
}

// src/workstation/personal-workspace/src/client/selectors.tsx
var import_react = require("react");

// src/workstation/personal-workspace/src/client/taskboard.ts
var TASK_BOARD_API_PREFIX = "/api/task-board";
var REQUEST_TIMEOUT_MS = 15e3;
function uuid() {
  try {
    const c = globalThis.crypto;
    if (c && typeof c.randomUUID === "function") return c.randomUUID();
  } catch {
  }
  return `personal-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
function optString(v) {
  return typeof v === "string" && v.length > 0 ? v : void 0;
}
function optNum2(v) {
  return typeof v === "number" && Number.isFinite(v) ? v : void 0;
}
function parseScheduler(value) {
  const s = value ?? {};
  const out = {};
  const tz = optString(s.timeZone);
  const ledgerId = optString(s.ledgerId);
  const err = optString(s.error);
  if (tz !== void 0) out.timeZone = tz;
  if (ledgerId !== void 0) out.ledgerId = ledgerId;
  if (err !== void 0) out.error = err;
  return Object.keys(out).length === 0 ? void 0 : out;
}
function parsePower(value) {
  const s = value ?? {};
  const out = {};
  if (typeof s.phase === "string") out.phase = s.phase;
  if (s.enabled === true || s.enabled === false) out.enabled = s.enabled;
  const running = optNum2(s.runningSessions);
  if (running !== void 0) out.runningSessions = running;
  const err = optString(s.lastError);
  if (err !== void 0) out.lastError = err;
  return Object.keys(out).length === 0 ? void 0 : out;
}
function parseSnapshot(value) {
  const s = value ?? {};
  const tasks = Array.isArray(s.tasks) ? s.tasks.map(parseTaskRecord).filter((t) => t !== null) : [];
  return {
    schemaVersion: typeof s.schemaVersion === "number" ? s.schemaVersion : void 0,
    revision: typeof s.revision === "number" ? s.revision : 0,
    tasks,
    sessionDefaultPermission: isTaskPermission(s.sessionDefaultPermission) ? s.sessionDefaultPermission : void 0,
    scheduler: parseScheduler(s.scheduler),
    power: parsePower(s.power),
    error: typeof s.error === "string" ? s.error : void 0
  };
}
async function readJson(response) {
  let body;
  try {
    body = await response.json();
  } catch {
    throw new Error(`\u4EFB\u52A1\u677F\u670D\u52A1\u54CD\u5E94\u5F02\u5E38\uFF08HTTP ${response.status}\uFF09`);
  }
  if (!response.ok) throw new Error(body?.error ?? `\u4EFB\u52A1\u677F\u8BF7\u6C42\u5931\u8D25\uFF08HTTP ${response.status}\uFF09`);
  return body;
}
var TaskBoardClient = class {
  prefix;
  initiator;
  constructor(prefix = TASK_BOARD_API_PREFIX, initiator = () => void 0) {
    this.prefix = prefix;
    this.initiator = initiator;
  }
  async state() {
    const response = await this.request(`${this.prefix}/state`, { cache: "no-store" });
    return parseSnapshot(await readJson(response));
  }
  /** create → 返回新快照（含新建任务行）。 */
  async create(input) {
    const action = { kind: "create", id: uuid(), input };
    return this.action(action);
  }
  /** run → 请求宿主启动执行（高于会话默认权限的绑定会被宿主拒绝并返回错误体）。 */
  async run(taskId) {
    return this.action({ kind: "run", taskId });
  }
  /** rerun → 宿主对已 settle 任务重新规划并执行。 */
  async rerun(taskId) {
    return this.action({ kind: "rerun", taskId });
  }
  /** delete → 宿主拒绝 running/open execution（E4-FIX D4 的 Host 权威判据）。 */
  async delete(taskId) {
    return this.action({ kind: "delete", taskId });
  }
  /** archive → 仅 settled（done/failed）可归档（官方 task-archive）。 */
  async archive(taskId) {
    return this.action({ kind: "archive", taskId });
  }
  /** restore → 恢复已归档任务（官方支持）。 */
  async restore(taskId) {
    return this.action({ kind: "restore", taskId });
  }
  /** move → 手动移列（官方仅 backlog/todo 目标合法）。 */
  async move(taskId, status) {
    return this.action({ kind: "move", taskId, status });
  }
  /** confirm-permission → 人工放行高于会话默认的权限绑定（宿主权威）。 */
  async confirmPermission(taskId) {
    return this.action({ kind: "confirm-permission", taskId });
  }
  /** set-schedule → 启用/停用/改周期（官方权威：enable 即按本地时间算下次执行）。 */
  async setSchedule(taskId, patch) {
    return this.action({ kind: "set-schedule", taskId, patch });
  }
  /** 便捷：停用定期（保留 cron，官方 enabled=false）。 */
  async disableSchedule(taskId) {
    return this.action({ kind: "set-schedule", taskId, patch: { enabled: false } });
  }
  /** 便捷：以指定 cron 启用定期。 */
  async enableSchedule(taskId, cron) {
    return this.action({ kind: "set-schedule", taskId, patch: { enabled: true, cron } });
  }
  /** 任意 action（信封封装 + initiator 审计戳）。 */
  async action(action) {
    const initiator = this.initiator();
    const envelope = { requestId: uuid(), action, ...initiator === void 0 || initiator === "" ? {} : { initiator } };
    const response = await this.request(`${this.prefix}/action`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(envelope)
    });
    return parseSnapshot(await readJson(response));
  }
  /**
   * 订阅 Host 事件（官方同款：SSE + visibilitychange）。SSE 帧不带任务列表，
   * 只作「有变化」信号 —— 调用方决定是否重拉 state()（revision 比对）。
   * 返回释放函数；EventSource 不可用时退化为仅 visibilitychange。
   */
  subscribe(listener) {
    let events = null;
    try {
      if (typeof EventSource !== "undefined") {
        events = new EventSource(`${this.prefix}/events`);
        events.onmessage = (message) => {
          try {
            const parsed = JSON.parse(message.data);
            if (parsed === null || typeof parsed !== "object" || typeof parsed.revision !== "number") {
              listener();
              return;
            }
            listener({ revision: parsed.revision, scheduler: parsed.scheduler, power: parsed.power });
          } catch {
            listener();
          }
        };
      }
    } catch {
      events = null;
    }
    const onVisible = () => {
      if (typeof document !== "undefined" && document.visibilityState === "visible") listener();
    };
    if (typeof document !== "undefined") document.addEventListener("visibilitychange", onVisible);
    return () => {
      try {
        events?.close();
      } catch {
      }
      if (typeof document !== "undefined") document.removeEventListener("visibilitychange", onVisible);
    };
  }
  async request(url, init) {
    const controller = new AbortController();
    const timer = globalThis.setTimeout(() => {
      controller.abort();
    }, REQUEST_TIMEOUT_MS);
    try {
      return await fetch(url, { ...init, signal: controller.signal });
    } catch (error) {
      const aborted = controller.signal.aborted;
      if (aborted) throw new Error("\u4EFB\u52A1\u677F\u670D\u52A1\u54CD\u5E94\u8D85\u65F6\uFF0815s\uFF09\u2014\u2014\u53EF\u80FD\u5BBF\u4E3B\u672A\u8FD0\u884C\uFF0C\u8BF7\u5237\u65B0\u91CD\u8BD5");
      const message = error instanceof Error ? error.message : String(error);
      throw new Error(`\u65E0\u6CD5\u8FDE\u63A5\u4EFB\u52A1\u677F\u670D\u52A1\uFF1A${message}`);
    } finally {
      globalThis.clearTimeout(timer);
    }
  }
};

// src/workstation/personal-workspace/src/client/selectors.tsx
var import_jsx_runtime2 = require("react/jsx-runtime");
var subscribeProjects = (f) => projectRegistry.subscribe(f);
var getProjects = () => projectRegistry.listProjects();
function useProjects() {
  return (0, import_react.useSyncExternalStore)(subscribeProjects, getProjects, getProjects);
}
var CSS_SELECTORS = String.raw`
.dpsel{display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
.dpsel-k{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);flex:none;}
.dpsel-s{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:6px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.05)) 60%,transparent);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-12,12px);padding:2px 6px;max-width:210px;}
.dpsel-form{display:flex;gap:6px;align-items:center;flex-wrap:wrap;width:100%;}
.dpsel-in{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.35));border-radius:6px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.05)) 50%,transparent);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-12,12px);padding:4px 8px;min-width:120px;box-sizing:border-box;}
.dpsel-in:focus{border-color:rgba(120,150,255,.6);outline:none;}
.dpsel-btn{border:1px solid rgba(120,150,255,.5);border-radius:6px;background:rgba(120,150,255,.12);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-12,12px);padding:3px 10px;cursor:pointer;}
.dpsel-btn:hover{background:rgba(120,150,255,.22);}
.dpsel-link{border:none;background:transparent;color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxs-12,12px);cursor:pointer;padding:2px 4px;}
.dpsel-link:hover{color:var(--dsw-alias-label-primary,#e8e8ec);}
.dpsel-err{color:#e08585;font:var(--dsw-font-xxxs-11,11px);}
`;
var UNASSIGNED = "__unassigned__";
var NEW_ITEM = "__new__";
var PERM_LABEL = {
  "read-only": "\u53EA\u8BFB\uFF08read-only\uFF09",
  "workspace-write": "\u5DE5\u4F5C\u533A\u53EF\u5199\uFF08workspace-write\uFF09",
  "danger-full-access": "\u5371\u9669\uFF08danger-full-access\uFF09"
};
function ProjectSelect({ value, onChange, hint }) {
  const [newOpen, setNewOpen] = (0, import_react.useState)(false);
  const [name, setName] = (0, import_react.useState)("");
  const [desc, setDesc] = (0, import_react.useState)("");
  const [busy, setBusy] = (0, import_react.useState)(false);
  const [err, setErr] = (0, import_react.useState)(null);
  const projects = useProjects();
  const cur = value ?? UNASSIGNED;
  const pick = (v) => {
    if (v === NEW_ITEM) {
      setNewOpen(true);
      return;
    }
    onChange(v === UNASSIGNED ? null : v);
  };
  const create = () => {
    const n = name.trim();
    if (!n) {
      setErr("\u9879\u76EE\u540D\u79F0\u4E0D\u80FD\u4E3A\u7A7A");
      return;
    }
    setBusy(true);
    setErr(null);
    try {
      const rec = projectRegistry.createProject({ name: n, description: desc.trim() || void 0 });
      onChange(rec.id);
      setNewOpen(false);
      setName("");
      setDesc("");
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "dpsel", "data-dpsel-project": "1", children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("label", { className: "dpsel-k", htmlFor: "dpsel-project", children: "Project" }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("select", { id: "dpsel-project", className: "dpsel-s", value: cur, onChange: (e) => pick(e.target.value), "aria-label": "\u9879\u76EE", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("option", { value: UNASSIGNED, children: "\u4E0D\u5C5E\u4E8E\u9879\u76EE" }),
      projects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("option", { value: p.id, children: [
        p.glyph ? `${p.glyph} ` : "",
        p.name
      ] }, p.id)),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("option", { value: NEW_ITEM, children: "\uFF0B \u65B0\u5EFA\u9879\u76EE\u2026" })
    ] }),
    hint ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "dpsel-k", children: hint }) : null,
    newOpen ? /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "dpsel-form", "data-dpsel-new-project": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        "input",
        {
          className: "dpsel-in",
          placeholder: "\u9879\u76EE\u540D\u79F0 *",
          value: name,
          autoFocus: true,
          onChange: (e) => setName(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") create();
          },
          "aria-label": "\u65B0\u9879\u76EE\u540D\u79F0"
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        "input",
        {
          className: "dpsel-in",
          placeholder: "\u63CF\u8FF0\uFF08\u53EF\u9009\uFF09",
          value: desc,
          onChange: (e) => setDesc(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") create();
          },
          "aria-label": "\u65B0\u9879\u76EE\u63CF\u8FF0"
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("button", { type: "button", className: "dpsel-btn", onClick: create, disabled: busy, children: busy ? "\u521B\u5EFA\u4E2D\u2026" : "\u521B\u5EFA" }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("button", { type: "button", className: "dpsel-link", onClick: () => setNewOpen(false), children: "\u53D6\u6D88" }),
      err ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "dpsel-err", children: err }) : null
    ] }) : null
  ] });
}
function AgentSelect({ value, onChange, options, unavailableReason }) {
  const blocked = typeof unavailableReason === "string" && unavailableReason.length > 0;
  const items = options ?? AGENT_CATALOG.map((a) => ({ id: a.id, label: `${a.name}\uFF08${a.zh}\uFF09` }));
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "dpsel", "data-dpsel-agent": "1", children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("label", { className: "dpsel-k", htmlFor: "dpsel-agent", children: "Agent" }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(
      "select",
      {
        id: "dpsel-agent",
        className: "dpsel-s",
        value: value ?? "",
        disabled: blocked,
        onChange: (e) => onChange(e.target.value === "" ? null : e.target.value),
        "aria-label": "\u6267\u884C Agent",
        "aria-invalid": blocked ? true : void 0,
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("option", { value: "", children: "\u81EA\u52A8\uFF08\u5B98\u65B9\u9ED8\u8BA4\uFF09" }),
          items.map((a) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("option", { value: a.id, children: a.label }, a.id))
        ]
      }
    ),
    blocked ? /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "dpsel-k", "data-dpsel-agent-state": "unavailable", children: [
      "\u4E0D\u53EF\u7528\uFF1A",
      unavailableReason
    ] }) : null
  ] });
}
function PermissionSelect({ value, onChange, options, unavailableReason }) {
  const blocked = typeof unavailableReason === "string" && unavailableReason.length > 0;
  const items = options ?? TASK_PERMISSIONS.map((id) => ({ id: String(id), label: PERM_LABEL[id] }));
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "dpsel", "data-dpsel-perm": "1", children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("label", { className: "dpsel-k", htmlFor: "dpsel-perm", children: "Permission" }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(
      "select",
      {
        id: "dpsel-perm",
        className: "dpsel-s",
        value: value ?? "",
        disabled: blocked,
        onChange: (e) => onChange(e.target.value === "" ? null : e.target.value),
        "aria-label": "\u6743\u9650\u6863",
        "aria-invalid": blocked ? true : void 0,
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("option", { value: "", children: "\u5B98\u65B9\u9ED8\u8BA4" }),
          items.map((p) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("option", { value: p.id, children: p.label }, p.id))
        ]
      }
    ),
    blocked ? /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "dpsel-k", "data-dpsel-perm-state": "unavailable", children: [
      "\u4E0D\u53EF\u7528\uFF1A",
      unavailableReason
    ] }) : null
  ] });
}
function WorkspaceSelect({ value, onChange, items, ready: ready2, probing }) {
  const cur = value ?? "";
  const disabled = !ready2 || items.length === 0;
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "dpsel", "data-dpsel-ws": "1", children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("label", { className: "dpsel-k", htmlFor: "dpsel-ws", children: "Workspace" }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(
      "select",
      {
        id: "dpsel-ws",
        className: "dpsel-s",
        value: cur,
        disabled,
        onChange: (e) => onChange(e.target.value === "" ? null : e.target.value),
        "aria-label": "\u5DE5\u4F5C\u533A",
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("option", { value: "", children: "\u81EA\u52A8\uFF08\u5F53\u524D/\u6700\u8FD1\uFF09" }),
          items.map((w) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("option", { value: w.workspaceId, children: w.title }, w.workspaceId))
        ]
      }
    ),
    !ready2 ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "dpsel-k", "data-dpsel-ws-state": probing ? "probing" : "unavailable", children: probing ? "\u5DE5\u4F5C\u533A\u6570\u636E\u8BFB\u53D6\u4E2D\u2026\uFF08\u81EA\u52A8\u91CD\u8BD5\u4E2D\uFF09" : "\u5B98\u65B9\u5DE5\u4F5C\u533A\u80FD\u529B\u4E0D\u53EF\u7528\uFF08\u672C\u73AF\u5883\u672A\u63D0\u4F9B\uFF0C\u7EDD\u4E0D\u4F2A\u9020\u76EE\u5F55\uFF09" }) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "dpsel-k", children: "\u6682\u65E0\u53EF\u7528\u5DE5\u4F5C\u533A\uFF08\u8BF7\u5148\u5728\u5B98\u65B9\u754C\u9762\u6DFB\u52A0\uFF09" }) : null
  ] });
}

// src/workstation/personal-workspace/src/client/workspace-catalog.ts
var import_react2 = require("react");
var EMPTY = { ready: false, items: [], archivedSessionIds: [] };
var state2 = EMPTY;
var subs3 = /* @__PURE__ */ new Set();
function notify2() {
  subs3.forEach((f) => {
    try {
      f();
    } catch {
    }
  });
}
var str4 = (v) => typeof v === "string" ? v : "";
function parseSnapshot2(snapshot) {
  const s = snapshot ?? {};
  const items = [];
  if (Array.isArray(s.items)) {
    for (const raw of s.items) {
      const r = raw ?? {};
      const workspaceId = str4(r.workspaceId) || str4(r.id);
      const path = str4(r.path);
      if (!workspaceId) continue;
      const sessionIds = Array.isArray(r.sessionIds) ? r.sessionIds.filter((x) => typeof x === "string") : [];
      const base = path.length > 0 ? path.split("/").filter(Boolean).pop() ?? path : workspaceId;
      const title = str4(r.title) || str4(r.name) || base;
      items.push({
        workspaceId,
        path,
        title,
        sessionIds,
        createdAt: typeof r.createdAt === "number" ? r.createdAt : void 0,
        updatedAt: typeof r.updatedAt === "number" ? r.updatedAt : void 0
      });
    }
  }
  const archived = Array.isArray(s.archivedSessionIds) ? s.archivedSessionIds.filter((x) => typeof x === "string") : [];
  state2 = {
    ready: true,
    items,
    archivedSessionIds: archived,
    phase: str4(s.phase) || void 0,
    error: str4(s.error) || void 0
  };
  notify2();
}
var detach = null;
var RETRY_INTERVAL_MS = 500;
var RETRY_MAX_ATTEMPTS = 24;
var retryTimer = null;
var retryAttempts = 0;
var retryAttach = null;
var retryCleanup = null;
function retrySetInterval(fn, ms) {
  const w = typeof window !== "undefined" ? window : null;
  try {
    if (w && typeof w.setInterval === "function") return w.setInterval(fn, ms);
    if (typeof setInterval === "function") return setInterval(fn, ms);
  } catch {
  }
  return null;
}
function retryClearInterval(id) {
  const w = typeof window !== "undefined" ? window : null;
  try {
    if (w && typeof w.clearInterval === "function") w.clearInterval(id);
    else if (typeof clearInterval === "function") clearInterval(id);
  } catch {
  }
}
function stopRetry() {
  if (retryTimer !== null) {
    retryClearInterval(retryTimer);
    retryTimer = null;
  }
  retryAttempts = 0;
}
function onVisibilityRetry() {
  if (retryAttach === null || state2.ready) return;
  retryAttempts = 0;
  if (retryAttach()) stopRetry();
}
function runRetryAttempt() {
  if (retryAttach === null) return false;
  if (retryAttach()) {
    stopRetry();
    return true;
  }
  return false;
}
function scheduleRetry() {
  if (retryTimer !== null) return;
  const tick = () => {
    retryAttempts += 1;
    if (runRetryAttempt()) return;
    if (retryAttempts >= RETRY_MAX_ATTEMPTS) {
      stopRetry();
      state2 = {
        ready: false,
        items: [],
        archivedSessionIds: [],
        probing: false,
        error: `\u5B98\u65B9 workspaces \u670D\u52A1\u5728 ${RETRY_INTERVAL_MS * RETRY_MAX_ATTEMPTS / 1e3}s \u91CD\u8BD5\u7A97\u53E3\u5185\u672A\u5C31\u7EEA`
      };
      notify2();
    }
  };
  const id = retrySetInterval(tick, RETRY_INTERVAL_MS);
  if (id !== null) retryTimer = id;
  else retryTimer = null;
}
function bindWorkspaceCatalog(getWorkspaces) {
  const tryAttach = () => {
    let svc = null;
    try {
      svc = getWorkspaces();
    } catch {
      return false;
    }
    const list = svc?.list;
    if (!list || typeof list.getSnapshot !== "function" || typeof list.subscribe !== "function") {
      return false;
    }
    const apply2 = () => {
      try {
        parseSnapshot2(list.getSnapshot());
      } catch {
      }
    };
    try {
      apply2();
      const off = list.subscribe(apply2);
      detach = typeof off === "function" ? off : null;
    } catch {
      return false;
    }
    return true;
  };
  const cleanup = () => {
    stopRetry();
    retryAttach = null;
    retryCleanup = null;
    try {
      detach?.();
    } catch {
    }
    detach = null;
    state2 = EMPTY;
  };
  if (tryAttach()) {
    return cleanup;
  }
  state2 = { ready: false, items: [], archivedSessionIds: [], probing: true };
  notify2();
  retryAttempts = 0;
  retryAttach = () => {
    if (!tryAttach()) return false;
    state2 = { ...state2, ready: true, probing: false, error: void 0 };
    notify2();
    return true;
  };
  scheduleRetry();
  if (typeof document !== "undefined" && typeof document.addEventListener === "function") {
    document.addEventListener("visibilitychange", onVisibilityRetry);
    retryCleanup = () => {
      try {
        document.removeEventListener("visibilitychange", onVisibilityRetry);
      } catch {
      }
    };
  }
  return () => {
    retryCleanup?.();
    cleanup();
  };
}
function retryWorkspaceCatalogNow() {
  if (state2.ready) return true;
  if (retryAttach === null) return false;
  if (!state2.probing) {
    state2 = { ...state2, probing: true, error: void 0 };
    notify2();
  }
  stopRetry();
  if (runRetryAttempt()) return true;
  scheduleRetry();
  return false;
}
function useWorkspaceCatalog() {
  return (0, import_react2.useSyncExternalStore)(subscribeWorkspaceCatalog, () => state2, () => EMPTY);
}
function subscribeWorkspaceCatalog(f) {
  subs3.add(f);
  return () => {
    subs3.delete(f);
  };
}
function workspaceCatalogSnapshot() {
  return state2;
}

// src/workstation/personal-workspace/src/client/session-bindings.ts
var getCtx = null;
var getSessions = null;
function bindSessionBindings(ctx, sessions) {
  getCtx = () => ctx;
  getSessions = sessions;
  return () => {
    getCtx = null;
    getSessions = null;
  };
}
var str5 = (v) => typeof v === "string" ? v : "";
function remoteNamespace(name) {
  try {
    const ctx = getCtx?.();
    const remote = ctx?.remote;
    const ns = remote?.[name];
    if (ns && typeof ns === "object") return ns;
    const viaGet = typeof ctx?.get === "function" ? ctx.get(`remote.${name}`) : void 0;
    if (viaGet && typeof viaGet === "object") return viaGet;
  } catch {
  }
  return null;
}
function sessionFace(sessionId) {
  try {
    const svc = getSessions?.();
    const b = svc?.binding?.(sessionId);
    const s = b?.session;
    if (s && typeof s === "object") return s;
  } catch {
  }
  return null;
}
function parseRoster(value) {
  const raw = Array.isArray(value) ? value : Array.isArray(value?.presets) ? value.presets : [];
  const out = [];
  for (const item of raw) {
    const r = item ?? {};
    const id = str5(r.id) || str5(r.name);
    if (!id) continue;
    out.push({
      id,
      label: str5(r.name) || str5(r.title) || id,
      ...str5(r.description) ? { detail: str5(r.description) } : {}
    });
  }
  return out;
}
async function listAgentPresets() {
  const ns = remoteNamespace("agentPresets");
  if (ns === null || typeof ns.list !== "function") {
    return { ok: false, reason: "\u5B98\u65B9 agentPresets \u8FDC\u7A0B\u670D\u52A1\u4E0D\u53EF\u7528\uFF08capability limitation\uFF09" };
  }
  try {
    const res = await ns.list();
    if (res?.ok === false) {
      const code = str5(res.error?.code);
      if (code === "gateway/invocation-unavailable") {
        return { ok: false, reason: "\u5BBF\u4E3B\u672A\u66B4\u9732 agentPresets\uFF08gateway/invocation-unavailable\uFF09" };
      }
      return { ok: false, reason: str5(res.error?.message) || "\u8BFB\u53D6 Agent \u9884\u8BBE\u6E05\u5355\u5931\u8D25" };
    }
    const items = parseRoster(res?.value);
    if (items.length === 0) {
      return { ok: false, reason: "\u5BBF\u4E3B\u672A\u63D0\u4F9B\u53EF\u7528\u7684\u5B98\u65B9 Agent \u9884\u8BBE\u6E05\u5355" };
    }
    return { ok: true, items };
  } catch (error) {
    return { ok: false, reason: error instanceof Error ? error.message : String(error) };
  }
}
async function applyAgentPreset(sessionId, presetId) {
  const ns = remoteNamespace("agentPresets");
  if (ns === null || typeof ns.select !== "function") {
    return { ok: false, reason: "\u5B98\u65B9 agentPresets.select \u4E0D\u53EF\u7528\uFF08capability limitation\uFF09" };
  }
  try {
    const res = await ns.select(sessionId, presetId);
    if (res?.ok === false) {
      const code = str5(res.error?.code);
      const msg = str5(res.error?.message) || "\u5B98\u65B9\u62D2\u7EDD";
      if (code === "agent-preset/locked") {
        return { ok: false, reason: `\u4F1A\u8BDD\u5DF2\u5F00\u59CB\u7B2C\u4E00\u8F6E\uFF0CAgent \u9884\u8BBE\u56FA\u5B9A\uFF08${msg}\uFF09` };
      }
      return { ok: false, reason: `${code || "error"}: ${msg}` };
    }
    return { ok: true };
  } catch (error) {
    return { ok: false, reason: error instanceof Error ? error.message : String(error) };
  }
}
function permSnapshot(sessionId) {
  const face = sessionFace(sessionId);
  const projections = face?.projections;
  try {
    const snap = projections?.faceOf?.("permissions")?.getSnapshot?.();
    if (snap && typeof snap === "object") return snap;
  } catch {
  }
  return null;
}
function listPermissionPresets(sessionId) {
  let target = str5(sessionId);
  if (!target) {
    try {
      const svc = getSessions?.();
      target = str5(svc?.list?.getSnapshot?.().current);
    } catch {
      target = "";
    }
  }
  if (!target) {
    return { ok: false, reason: "\u5F53\u524D\u6CA1\u6709\u5B98\u65B9\u4F1A\u8BDD\u53EF\u8BFB\u53D6\u6743\u9650\u6295\u5F71\uFF08\u521B\u5EFA\u9996\u4E2A\u4F1A\u8BDD\u540E\u5373\u53EF\u679A\u4E3E\uFF09" };
  }
  const snap = permSnapshot(target);
  if (snap === null) {
    return { ok: false, reason: "\u5B98\u65B9 permissions \u4F1A\u8BDD\u6295\u5F71\u4E0D\u53EF\u7528\uFF08capability limitation\uFF09" };
  }
  const raw = Array.isArray(snap.options) ? snap.options : [];
  const items = [];
  for (const item of raw) {
    const r = item ?? {};
    const id = str5(r.value) || str5(r.id);
    if (!id || id === "custom") continue;
    items.push({
      id,
      label: str5(r.name) || id,
      ...str5(r.description) ? { detail: str5(r.description) } : {}
    });
  }
  if (items.length === 0) {
    return { ok: false, reason: "\u5B98\u65B9\u6743\u9650\u6295\u5F71\u672A\u8FD4\u56DE\u53EF\u5207\u6362\u9884\u8BBE" };
  }
  return { ok: true, items, current: str5(snap.currentValue) || void 0 };
}
async function applyPermissionPreset(sessionId, presetId) {
  const face = sessionFace(sessionId);
  const command = face?.command;
  if (typeof command !== "function") {
    return { ok: false, reason: "\u5B98\u65B9\u4F1A\u8BDD\u547D\u4EE4\u901A\u9053\u4E0D\u53EF\u7528\uFF08sessions.binding().session.command \u7F3A\u5931\uFF09" };
  }
  try {
    const res = await command.call(face, `/permission ${presetId}`);
    if (res?.ok === false) {
      return { ok: false, reason: `${str5(res.error?.code) || "error"}: ${str5(res.error?.message) || "\u547D\u4EE4\u88AB\u62D2"}` };
    }
    if (res?.value?.matched !== true) {
      return { ok: false, reason: "\u5BBF\u4E3B\u672A\u63D0\u4F9B\u5B98\u65B9 /permission \u547D\u4EE4" };
    }
    const after = permSnapshot(sessionId);
    if (after === null) return { ok: true, note: "\u547D\u4EE4\u5DF2\u88AB\u5B98\u65B9\u63A5\u53D7\uFF1B\u6295\u5F71\u4E0D\u53EF\u8BFB\uFF0C\u672A\u505A\u8BFB\u56DE\u6821\u9A8C" };
    const current2 = str5(after.currentValue);
    if (current2 === presetId) return { ok: true };
    return {
      ok: false,
      reason: `\u547D\u4EE4\u5DF2\u88AB\u5B98\u65B9\u63A5\u53D7\uFF0C\u4F46\u5B98\u65B9\u6295\u5F71\u5F53\u524D\u503C\u4ECD\u4E3A\u300C${current2 || "\u672A\u77E5"}\u300D\uFF08\u53EF\u80FD\u88AB\u5BBF\u4E3B\u7B56\u7565\u8986\u76D6\uFF09`
    };
  } catch (error) {
    return { ok: false, reason: error instanceof Error ? error.message : String(error) };
  }
}

// src/workstation/personal-workspace/src/client/home.tsx
var import_jsx_runtime3 = require("react/jsx-runtime");
var CSS_HOME = String.raw`
.dhm-root{display:flex;flex-direction:column;gap:14px;padding:12px 14px 18px;font:var(--dsw-font-xxs-12,12px);color:var(--dsw-alias-label-primary,#e8e8ec);user-select:none;}
.dhm-h{font:var(--dsw-font-s-strong-14,600 14px);margin:0;color:var(--dsw-alias-label-primary,#e8e8ec);}
.dhm-sec{display:flex;flex-direction:column;gap:7px;}
.dhm-k{font:var(--dsw-font-xxxs-strong-11,600 11px);letter-spacing:.04em;color:var(--dsw-alias-label-tertiary,#9a9aa5);}
.dhm-row{display:flex;align-items:center;gap:8px;padding:6px 8px;border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.28));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 45%,transparent);width:100%;text-align:left;color:inherit;font:inherit;cursor:pointer;}
.dhm-row:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.1)) 60%,transparent);}
.dhm-row.attn{border-color:rgba(240,180,60,.5);}
.dhm-row.err{border-color:rgba(235,90,90,.45);}
.dhm-dot{width:7px;height:7px;border-radius:50%;flex:none;background:#37c871;}
.dhm-dot.idle{background:var(--dsw-alias-label-dimmed,#6a6a74);}
.dhm-dot.amber{background:#e8b64c;}
.dhm-dot.red{background:#e85a5a;}
.dhm-t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.dhm-sub{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);white-space:nowrap;}
.dhm-act{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.28));border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxs-12,12px);padding:2px 9px;cursor:pointer;flex:none;}
.dhm-act:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 60%,transparent);}
.dhm-empty{color:var(--dsw-alias-label-dimmed,#8f8f99);font:var(--dsw-font-xxs-12,12px);padding:2px 0;}
.dhm-badge{display:inline-flex;align-items:center;gap:4px;color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);border:1px dashed var(--dsw-alias-border-l2,rgba(128,128,128,.25));border-radius:20px;padding:1px 8px;align-self:flex-start;}
.dhm-badge.warn{border-color:rgba(240,180,60,.4);color:#e0b96a;}
.dhm-in{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.35));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.05)) 50%,transparent);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-12,12px);padding:7px 10px;width:100%;box-sizing:border-box;outline:none;}
.dhm-in:focus{border-color:rgba(120,150,255,.6);}
.dhm-in::placeholder{color:var(--dsw-alias-label-dimmed,#7c7c88);}
.dhm-line{display:flex;gap:8px;align-items:center;}
.dhm-go{border:1px solid rgba(120,150,255,.55);border-radius:8px;background:rgba(120,150,255,.14);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-strong-12,600 12px);padding:6px 16px;cursor:pointer;flex:none;}
.dhm-go:hover{background:rgba(120,150,255,.22);}
.dhm-chip{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:20px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxxs-11,11px);padding:2px 10px;cursor:pointer;}
.dhm-chip:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 60%,transparent);}
.dhm-note{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);line-height:1.55;border-left:2px solid rgba(120,150,255,.4);padding:2px 0 2px 8px;}
.dhm-proj{display:flex;flex-direction:column;gap:2px;min-width:0;}
.dhm-pname{display:flex;align-items:baseline;gap:6px;min-width:0;}
.dhm-pname b{color:var(--dsw-alias-label-primary,#e8e8ec);white-space:nowrap;}
.dhm-pzh{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);white-space:nowrap;}
.dhm-pdesc{color:var(--dsw-alias-label-secondary,#c8c8d0);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.dhm-pchips{display:flex;gap:4px;margin-top:3px;flex-wrap:wrap;}
.dhm-pchip{font:var(--dsw-font-xxxs-11,11px);color:var(--dsw-alias-label-tertiary,#9a9aa5);border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));border-radius:4px;padding:0 5px;}
.dhm-sec-title{margin-top:2px;}
.dhm-meta{display:flex;gap:5px;align-items:center;min-width:0;}
.dhm-tag{display:inline-flex;align-items:center;font:var(--dsw-font-xxxs-11,11px);border-radius:4px;padding:1px 5px;white-space:nowrap;flex:none;}
.dhm-tag.perm{background:rgba(240,180,60,.14);color:#e8b64c;border:1px solid rgba(240,180,60,.35);}
.dhm-tag.fail{background:rgba(235,90,90,.14);color:#ff8a8a;}
.dhm-tag.arch{color:var(--dsw-alias-label-tertiary,#9a9aa5);border:1px dashed var(--dsw-alias-border-l2,rgba(128,128,128,.3));}
.dhm-tag.ok{background:rgba(55,200,113,.12);color:#37c871;}
.dhm-tag.run{background:rgba(120,150,255,.14);color:#8aa4ff;}
.dhm-tag.prj{background:rgba(150,120,255,.12);color:#b49bff;border:1px solid rgba(150,120,255,.3);}
.dhm-err{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
`;
var EMPTY_FEED = { ready: false, rows: [] };
var feed = EMPTY_FEED;
var feedSubs = /* @__PURE__ */ new Set();
function notifyFeed() {
  feedSubs.forEach((f) => f());
}
function rowOf(raw) {
  const id = String(raw.id ?? "");
  if (!id) return null;
  const title = typeof raw.title === "string" && raw.title.length > 0 ? raw.title : typeof raw.displayTitle === "string" && raw.displayTitle.length > 0 ? raw.displayTitle : "\uFF08\u672A\u547D\u540D\u4F1A\u8BDD\uFF09";
  return {
    id,
    title,
    running: raw.running === true,
    updatedAt: typeof raw.updatedAt === "number" ? raw.updatedAt : void 0
  };
}
function attachFeed(getSessions2) {
  let source = null;
  try {
    const svc = getSessions2();
    source = svc?.list ?? null;
  } catch {
    source = null;
  }
  if (!source || typeof source.getSnapshot !== "function" || typeof source.subscribe !== "function") {
    feed = { ready: false, rows: [] };
    notifyFeed();
    return () => {
    };
  }
  const apply2 = () => {
    try {
      const snap = source.getSnapshot();
      const rows = sessionRowsOf(snap).map((r) => rowOf(r)).filter((x) => x !== null).slice(0, 40);
      feed = { ready: true, rows };
      notifyFeed();
    } catch {
    }
  };
  apply2();
  const off = source.subscribe(apply2);
  return () => {
    try {
      off?.();
    } catch {
    }
  };
}
var openSessionFn = null;
var lastReceipt = null;
var createConversationFn = null;
function bindHomeServices(getSessions2, openSession, onCreateConversation) {
  openSessionFn = openSession;
  createConversationFn = onCreateConversation ?? null;
  return attachFeed(getSessions2);
}
function useHomeFeed() {
  return (0, import_react3.useSyncExternalStore)(
    (f) => {
      feedSubs.add(f);
      return () => {
        feedSubs.delete(f);
      };
    },
    () => feed,
    () => EMPTY_FEED
  );
}
async function createConversationInProject(draft, projectId) {
  const fn = createConversationFn;
  if (fn === null) {
    return { ok: false, message: "\u4F1A\u8BDD\u521B\u5EFA\u670D\u52A1\u6682\u4E0D\u53EF\u7528\uFF08\u672A\u7ED1\u5B9A\u5B98\u65B9\u94FE\u8DEF\uFF09\u2014\u2014\u8BF7\u5230\u4E3B\u9875 Quick Start \u5F00\u59CB\u3002" };
  }
  try {
    return await fn(draft, { projectId, agentId: null, permission: null });
  } catch (error) {
    return { ok: false, message: error instanceof Error ? error.message : String(error) };
  }
}
var homeReconcile = null;
var openTaskBoardFn = null;
var EMPTY_TASKS = {
  ready: false,
  hostReachable: false,
  revision: 0,
  tasks: [],
  archivedSessionIds: [],
  sessionsSource: false,
  workspacesSource: false
};
function bindHomeTaskSource(reconcile, openTaskBoard) {
  homeReconcile = reconcile;
  openTaskBoardFn = openTaskBoard;
  return () => {
    homeReconcile = null;
    openTaskBoardFn = null;
  };
}
function useHomeTaskState() {
  return (0, import_react3.useSyncExternalStore)(
    (f) => {
      const r = homeReconcile;
      if (!r) return () => {
      };
      return r.subscribe(f);
    },
    () => homeReconcile?.getState() ?? EMPTY_TASKS,
    () => EMPTY_TASKS
  );
}
var ago = (ts) => {
  if (!ts || !Number.isFinite(ts)) return "";
  const s = Math.max(1, Math.round((Date.now() - ts) / 1e3));
  if (s < 60) return s + " \u79D2\u524D";
  const m = Math.round(s / 60);
  if (m < 60) return m + " \u5206\u949F\u524D";
  const h = Math.round(m / 60);
  if (h < 24) return h + " \u5C0F\u65F6\u524D";
  return Math.round(h / 24) + " \u5929\u524D";
};
function runningTasksOf(state3) {
  if (!state3.ready || !state3.hostReachable) return [];
  return state3.tasks.filter((p) => p.task.status === "running" || p.task.executions.some((e) => e.endedAt === void 0));
}
function attentionRowsOf(state3) {
  if (!state3.ready || !state3.hostReachable) return [];
  return state3.tasks.filter((p) => p.attention !== null).sort((a, b) => (b.attention?.weight ?? 0) - (a.attention?.weight ?? 0)).slice(0, 10);
}
function recentDoneOf(state3) {
  if (!state3.ready || !state3.hostReachable) return [];
  return state3.tasks.filter((p) => p.task.status === "done" && !p.taskArchived).sort((a, b) => b.task.updatedAt - a.task.updatedAt).slice(0, 5);
}
var QUICK_CHIPS = ["\u7EE7\u7EED\u4E0A\u6B21\u7684\u4E8B", "\u68C0\u67E5\u8FDB\u5EA6", "\u7814\u7A76\u4E00\u4E2A\u4E3B\u9898", "\u5904\u7406\u6536\u5C3E"];
function attentionTag(p) {
  const a = p.attention;
  if (a === null) return null;
  switch (a.kind) {
    case "confirm-permission":
      return { dot: "amber", cls: "perm", text: "\u786E\u8BA4\u6743\u9650" };
    case "failed":
      return { dot: "red", cls: "fail", text: "\u6267\u884C\u5931\u8D25" };
    case "task-error":
      return { dot: "red", cls: "fail", text: "\u4EFB\u52A1\u9519\u8BEF" };
    default:
      return { dot: "red", cls: "fail", text: "\u9700\u5904\u7406" };
  }
}
function execSummary(p) {
  const ex = p.task.executions[p.task.executions.length - 1];
  if (ex === void 0) return "";
  if (ex.endedAt === void 0) return "\u6267\u884C\u4E2D";
  if (ex.result === "succeeded") return "\u6210\u529F";
  if (ex.result === "cancelled") return "\u5DF2\u53D6\u6D88";
  if (ex.result === "failed") return "\u5931\u8D25";
  return "\u5DF2\u7ED3\u675F";
}
function HomeView() {
  const feed2 = useHomeFeed();
  const tasks = useHomeTaskState();
  const wsCat = useWorkspaceCatalog();
  const projects = useProjects();
  const inputRef = (0, import_react3.useRef)(null);
  const [text, setText] = (0, import_react3.useState)("");
  const [projectId, setProjectId] = (0, import_react3.useState)(null);
  const [workspaceId, setWorkspaceId] = (0, import_react3.useState)(null);
  const [agentSel, setAgentSel] = (0, import_react3.useState)(null);
  const [permSel, setPermSel] = (0, import_react3.useState)(null);
  const [busy, setBusy] = (0, import_react3.useState)(false);
  const [notice, setNotice] = (0, import_react3.useState)(null);
  const [receipt, setReceipt] = (0, import_react3.useState)(lastReceipt);
  const [agentOpts, setAgentOpts] = (0, import_react3.useState)(null);
  const [agentReason, setAgentReason] = (0, import_react3.useState)(null);
  const [permOpts, setPermOpts] = (0, import_react3.useState)(null);
  const [permReason, setPermReason] = (0, import_react3.useState)(null);
  (0, import_react3.useEffect)(() => {
    let alive = true;
    void (async () => {
      const roster = await listAgentPresets();
      if (!alive) return;
      if (roster.ok) {
        setAgentOpts(roster.items);
        setAgentReason(null);
      } else {
        setAgentOpts(null);
        setAgentReason(roster.reason);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);
  (0, import_react3.useEffect)(() => {
    const r = listPermissionPresets();
    if (r.ok) {
      setPermOpts(r.items);
      setPermReason(null);
    } else {
      setPermOpts(null);
      setPermReason(r.reason);
    }
  }, [feed2.rows.length]);
  const archivedSet2 = new Set(tasks.archivedSessionIds);
  const hostDown = tasks.ready && !tasks.hostReachable;
  const runningTasks = runningTasksOf(tasks);
  const runningSessions = feed2.rows.filter((r) => r.running);
  const recentSessions = feed2.rows.filter((r) => !r.running && !archivedSet2.has(r.id)).sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0)).slice(0, 5);
  const attention = attentionRowsOf(tasks);
  const recentDone = recentDoneOf(tasks);
  const openSess = (id) => {
    try {
      openSessionFn?.(id);
    } catch {
    }
  };
  const openBoardAt2 = (taskId) => {
    try {
      openTaskBoardFn?.(taskId);
    } catch {
    }
  };
  const projNameOf = (projectId2) => projectId2 ? projects.find((p) => p.id === projectId2)?.name : void 0;
  const taskProjName = (taskId) => projNameOf(projectRegistry.projectOfTask(taskId));
  const sessProjName = (sessionId) => projNameOf(projectRegistry.projectOfSession(sessionId));
  const submit = async () => {
    const t = text.trim();
    if (!t) {
      inputRef.current?.focus();
      return;
    }
    setBusy(true);
    setNotice(null);
    try {
      const fn = createConversationFn;
      if (fn === null) {
        let copiedOk = false;
        try {
          if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
            await navigator.clipboard.writeText(t);
            copiedOk = true;
          }
        } catch {
          copiedOk = false;
        }
        setNotice(
          copiedOk ? "\u4F1A\u8BDD\u521B\u5EFA\u670D\u52A1\u6682\u4E0D\u53EF\u7528\uFF1A\u76EE\u6807\u6587\u672C\u5DF2\u590D\u5236\uFF0C\u8BF7\u5728\u4F1A\u8BDD\u8F93\u5165\u6846 \u2318V \u7C98\u8D34\u5F00\u59CB\u3002" : "\u4F1A\u8BDD\u521B\u5EFA\u670D\u52A1\u6682\u4E0D\u53EF\u7528\uFF0C\u4E14\u672A\u80FD\u81EA\u52A8\u590D\u5236\uFF1A\u8BF7\u624B\u52A8\u9009\u4E2D\u76EE\u6807\u6587\u672C\u590D\u5236\u3002"
        );
        return;
      }
      const res = await fn(t, { projectId, workspaceId, agentId: agentSel, permission: permSel });
      if (res.ok) {
        setText("");
        const r = {
          at: Date.now(),
          message: res.message && res.message.length > 0 ? res.message : "\u5DF2\u521B\u5EFA\u5E76\u6253\u5F00\u65B0\u4F1A\u8BDD\u3002",
          sessionId: res.sessionId ?? null,
          failed: res.failed === true
        };
        lastReceipt = r;
        setReceipt(r);
        if (r.failed) setNotice(r.message);
      } else {
        const r = { at: Date.now(), message: res.message || "\u4F1A\u8BDD\u521B\u5EFA\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002", sessionId: null, failed: true };
        lastReceipt = r;
        setReceipt(r);
        setNotice(r.message);
      }
    } catch (error) {
      setNotice(error instanceof Error ? error.message : String(error));
    } finally {
      setBusy(false);
    }
  };
  const fill = (chip) => {
    setText(chip + " \u2026");
    inputRef.current?.focus();
  };
  const scrollToStart = () => {
    try {
      inputRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      inputRef.current?.focus();
    } catch {
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dhm-root", "data-dsh-plugin": "dsh-personal-workspace", "data-e4fix-home": "1", children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("section", { className: "dhm-sec", "data-dps-home-quickstart": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-h", children: "Quick Start" }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dhm-line", children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
          "input",
          {
            ref: inputRef,
            className: "dhm-in",
            value: text,
            placeholder: "\u7528\u4E00\u53E5\u8BDD\u544A\u8BC9\u5B83\u4F60\u60F3\u505A\u4EC0\u4E48\u2026",
            onChange: (e) => setText(e.target.value),
            onKeyDown: (e) => {
              if (e.key === "Enter") submit();
            },
            "aria-label": "\u76EE\u6807\u8F93\u5165"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "dhm-go", onClick: submit, disabled: busy, children: busy ? "\u521B\u5EFA\u4E2D\u2026" : "\u5F00\u59CB" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dhm-line", style: { flexWrap: "wrap" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(ProjectSelect, { value: projectId, onChange: setProjectId }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(WorkspaceSelect, { value: workspaceId, onChange: setWorkspaceId, items: wsCat.items, ready: wsCat.ready, probing: wsCat.probing })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dhm-line", style: { flexWrap: "wrap" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
          AgentSelect,
          {
            value: agentSel,
            onChange: setAgentSel,
            options: agentOpts ?? void 0,
            unavailableReason: agentReason ?? void 0
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
          PermissionSelect,
          {
            value: permSel,
            onChange: setPermSel,
            options: permOpts ?? void 0,
            unavailableReason: permReason ?? void 0
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-k", "data-dhm-bind-state": agentReason === null && permReason === null ? "ready" : "limited", children: agentReason === null && permReason === null ? "\uFF08\u521B\u5EFA\u540E\u7ECF\u5B98\u65B9\u901A\u9053\u5373\u65F6\u751F\u6548\uFF09" : "\uFF08\u90E8\u5206\u80FD\u529B\u4E0D\u53EF\u7528\uFF0C\u89C1\u63A7\u4EF6\u65C1\u539F\u56E0\uFF09" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-line", style: { flexWrap: "wrap" }, children: QUICK_CHIPS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "dhm-chip", onClick: () => fill(c), children: c }, c)) }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dhm-note", "data-dhm-semantics": "conversation", children: [
        "\u4E3B\u9875 = ",
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("b", { children: "\u521B\u5EFA\u5E76\u5F00\u59CB\u4E00\u6BB5\u5B98\u65B9 Conversation" }),
        "\uFF08\u4E0D\u662F Task\uFF09\uFF1A\u70B9\u300C\u5F00\u59CB\u300D\u2192 \u5B98\u65B9 sessions.create \u2192 \uFF08\u53EF\u9009\uFF09Agent \u9884\u8BBE\u7ECF\u5B98\u65B9 agentPresets.select \u7ED1\u5B9A\u3001\u6743\u9650\u9884\u8BBE\u7ECF\u5B98\u65B9 /permission \u547D\u4EE4\u5E94\u7528\u5E76\u8BFB\u56DE\u6821\u9A8C \u2192 \u6253\u5F00\u8BE5\u4F1A\u8BDD\u5E76\u628A\u76EE\u6807\u6587\u672C\u586B\u5165\u8F93\u5165\u6846\u3002\u4EFB\u4E00\u9879\u88AB\u5B98\u65B9\u62D2\u7EDD\uFF0C\u90FD\u4F1A\u5728\u4E0B\u65B9\u5982\u5B9E\u62A5\u544A\uFF1B\u9700\u8981\u88AB\u7BA1\u7406/\u8C03\u5EA6/\u8FFD\u8E2A\u7684\u6B63\u5F0F\u5DE5\u4F5C \u2192 \u4FA7\u680F\u300C\uFF0B \u65B0\u4EFB\u52A1\u300D\u3002"
      ] }),
      notice ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-note", role: "status", "data-dhm-notice": "1", children: notice }) : null,
      receipt ? /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(
        "div",
        {
          className: "dhm-note",
          role: "status",
          "data-dhm-receipt": receipt.failed ? "failed" : "ok",
          style: receipt.failed ? { borderLeftColor: "rgba(255,120,120,.7)" } : void 0,
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("b", { children: receipt.failed ? "\u4E0A\u4E00\u6B65\u6709\u672A\u751F\u6548\u7684\u7ED1\u5B9A" : "\u4E0A\u4E00\u6B21\u521B\u5EFA\u56DE\u6267" }),
            "\uFF1A",
            receipt.message,
            receipt.sessionId ? /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_jsx_runtime3.Fragment, { children: [
              " ",
              /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
                "button",
                {
                  type: "button",
                  className: "dhm-chip",
                  "data-dhm-open-created": "1",
                  onClick: () => {
                    try {
                      openSessionFn?.(receipt.sessionId);
                    } catch {
                    }
                  },
                  children: "\u6253\u5F00\u8BE5\u4F1A\u8BDD"
                }
              ),
              " "
            ] }) : null,
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
              "button",
              {
                type: "button",
                className: "dhm-chip",
                "data-dhm-receipt-dismiss": "1",
                onClick: () => {
                  lastReceipt = null;
                  setReceipt(null);
                  setNotice(null);
                },
                children: "\u77E5\u9053\u4E86"
              }
            )
          ]
        }
      ) : null
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("section", { className: "dhm-sec", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-k", children: "AI \u6B63\u5728\u505A\u4EC0\u4E48 \xB7 Running" }),
      hostDown ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-badge warn", children: "\u4EFB\u52A1\u677F\u5BBF\u4E3B\u4E0D\u53EF\u8FBE \u2014\u2014 \u4EE5\u4E0B\u4E3A\u5B98\u65B9\u8FD0\u884C\u4E2D\u4F1A\u8BDD\uFF08\u964D\u7EA7\u89C6\u56FE\uFF09" }) : null,
      runningTasks.length > 0 ? runningTasks.slice(0, 6).map((p) => {
        const pname = taskProjName(p.task.id);
        return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("button", { type: "button", className: "dhm-row", onClick: () => openBoardAt2(p.task.id), title: "\u5728\u4EFB\u52A1\u677F\u67E5\u770B/\u63A7\u5236", children: [
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-dot", title: "\u8FD0\u884C\u4E2D" }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-t", children: p.task.title }),
          pname ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-tag prj", children: pname }) : null,
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-sub", children: ago(p.task.updatedAt) }),
          p.attach?.archived ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-tag arch", children: "\u4F1A\u8BDD\u5DF2\u5F52\u6863" }) : null,
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-sub", children: "\u6267\u884C\u4E2D" }),
          p.attach?.sessionId !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
            "span",
            {
              className: "dhm-act",
              role: "button",
              tabIndex: 0,
              onClick: (e) => {
                e.stopPropagation();
                openSess(p.attach.sessionId);
              },
              onKeyDown: (e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  e.stopPropagation();
                  openSess(p.attach.sessionId);
                }
              },
              children: "\u4F1A\u8BDD"
            }
          ) : null
        ] }, p.task.id);
      }) : !feed2.ready ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-empty", children: "\u4F1A\u8BDD\u6570\u636E\u6682\u4E0D\u53EF\u7528\uFF0C\u5237\u65B0\u91CD\u8BD5\u3002" }) : runningSessions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dhm-empty", children: [
        "\u5F53\u524D\u6CA1\u6709\u6B63\u5728\u6267\u884C\u7684\u4EFB\u52A1\u3002",
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "dhm-chip", style: { marginLeft: 8 }, onClick: scrollToStart, children: "\u5F00\u59CB\u4E00\u4EF6\u4E8B" })
      ] }) : runningSessions.slice(0, 6).map((s) => {
        const pname = sessProjName(s.id);
        return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dhm-row", children: [
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-dot", title: "\u8FD0\u884C\u4E2D" }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-t", children: s.title }),
          pname ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-tag prj", children: pname }) : null,
          s.updatedAt ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-sub", children: ago(s.updatedAt) }) : null,
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "dhm-act", onClick: () => openSess(s.id), children: "\u6253\u5F00\u4F1A\u8BDD" })
        ] }, s.id);
      })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("section", { className: "dhm-sec", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-k", children: "\u9700\u8981\u4F60\u5904\u7406 \xB7 Needs Attention" }),
      hostDown ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-empty", children: "\u4EFB\u52A1\u677F\u5BBF\u4E3B\u4E0D\u53EF\u8FBE\uFF0C\u6682\u65F6\u65E0\u6CD5\u8BFB\u53D6\u5F85\u5904\u7406\u4E8B\u9879\u3002" }) : attention.length === 0 ? tasks.ready ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-empty", children: "\u6682\u65E0\u53EF\u5904\u7406\u4E8B\u9879\u3002" }) : /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-empty", children: "\u6B63\u5728\u8BFB\u53D6\u4EFB\u52A1\u677F\u2026" }) : attention.map((p) => {
        const tag = attentionTag(p);
        const pname = taskProjName(p.task.id);
        return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(
          "button",
          {
            type: "button",
            className: `dhm-row attn${tag?.cls === "fail" ? " err" : ""}`,
            onClick: () => openBoardAt2(p.task.id),
            title: "\u6253\u5F00\u4EFB\u52A1\u677F\u5904\u7406",
            children: [
              /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: `dhm-dot ${tag?.dot ?? "amber"}` }),
              /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-t", children: p.task.title }),
              pname ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-tag prj", children: pname }) : null,
              tag ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: `dhm-tag ${tag.cls}`, children: tag.text }) : null,
              /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-err", children: p.attention?.label ?? "" })
            ]
          },
          p.task.id
        );
      })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("section", { className: "dhm-sec", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-k dhm-sec-title", children: "\u6700\u8FD1\u5B8C\u6210 \xB7 Done" }),
      hostDown ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-empty", children: "\u4EFB\u52A1\u677F\u5BBF\u4E3B\u4E0D\u53EF\u8FBE\uFF0C\u6682\u65F6\u65E0\u6CD5\u8BFB\u53D6\u6700\u8FD1\u5B8C\u6210\u3002" }) : !tasks.ready ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-empty", children: "\u6B63\u5728\u8BFB\u53D6\u4EFB\u52A1\u677F\u2026" }) : recentDone.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-empty", children: "\u8FD8\u6CA1\u6709\u5DF2\u5B8C\u6210\u7684\u4EFB\u52A1\u3002" }) : recentDone.map((p) => {
        const pname = taskProjName(p.task.id);
        return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("button", { type: "button", className: "dhm-row", onClick: () => openBoardAt2(p.task.id), children: [
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-tag ok", children: "\u5B8C\u6210" }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-t", children: p.task.title }),
          pname ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-tag prj", children: pname }) : null,
          /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("span", { className: "dhm-sub", children: [
            ago(p.task.updatedAt),
            " \xB7 ",
            execSummary(p)
          ] })
        ] }, p.task.id);
      })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("section", { className: "dhm-sec", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-k dhm-sec-title", children: "\u6700\u8FD1\u4F1A\u8BDD \xB7 \u53EF\u7EE7\u7EED" }),
      !feed2.ready ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "dhm-empty", children: "\u4F1A\u8BDD\u6570\u636E\u6682\u4E0D\u53EF\u7528\uFF0C\u5237\u65B0\u91CD\u8BD5\u3002" }) : recentSessions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dhm-empty", children: [
        "\u8FD8\u6CA1\u6709\u53EF\u7EE7\u7EED\u7684\u4F1A\u8BDD\u8BB0\u5F55\u3002",
        archivedSet2.size > 0 ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-badge", style: { marginLeft: 8 }, children: "\u5DF2\u5F52\u6863\u4F1A\u8BDD\u4E0D\u5217\u5728\u6700\u8FD1" }) : null
      ] }) : recentSessions.map((s) => {
        const pname = sessProjName(s.id);
        return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "dhm-row", children: [
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-dot idle" }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-t", children: s.title }),
          pname ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-tag prj", children: pname }) : null,
          s.updatedAt ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "dhm-sub", children: ago(s.updatedAt) }) : null,
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "dhm-act", onClick: () => openSess(s.id), children: "\u7EE7\u7EED" })
        ] }, s.id);
      }),
      archivedSet2.size > 0 ? /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("span", { className: "dhm-badge", "data-home-archived-note": "1", children: [
        "\u5B98\u65B9\u5DF2\u5F52\u6863\u4F1A\u8BDD N=",
        archivedSet2.size,
        "\uFF08\u4E0D\u5728\u300C\u6700\u8FD1\u4F1A\u8BDD\u300D/Running \u663E\u793A\uFF0C\u4EFB\u52A1\u72B6\u6001\u4E0D\u53D7\u5F71\u54CD\uFF09"
      ] }) : null
    ] })
  ] });
}

// src/workstation/personal-workspace/src/client/newtask.tsx
var import_react4 = require("react");

// src/workstation/personal-workspace/src/client/recommend.ts
var AGENT_KEYWORDS = [
  {
    id: "hardware",
    keywords: ["\u4E32\u53E3", "\u5BC4\u5B58\u5668", "\u786C\u4EF6", "\u70E7\u5F55", "\u9A71\u52A8", "\u5355\u7247\u673A", "\u5D4C\u5165\u5F0F", "\u56FA\u4EF6", "gpio", "i2c", "uart", "esp32", "esp", "arduino", "m5stack", "stm32", "\u793A\u6CE2\u5668", "\u7535\u8DEF"]
  },
  {
    id: "designer",
    keywords: ["\u89C6\u89C9", "ui", "ux", "\u539F\u578B", "\u6D77\u62A5", "\u8BBE\u8BA1", "\u56FE\u6807", "\u63D2\u753B", "\u7A3F", "\u6392\u7248", "\u8BBE\u8BA1\u7A3F"]
  },
  {
    id: "coder",
    keywords: ["\u4EE3\u7801", "\u5199", "\u6539", "\u5B9E\u73B0", "\u7F16\u7A0B", "\u91CD\u6784", "\u4FEE\u590D", "\u4FEE\u4E00\u4E0B", "bug", "\u8C03\u8BD5", "git", "\u7EC8\u7AEF", "\u811A\u672C", "\u90E8\u7F72", "\u6D4B\u8BD5", "\u7F16\u8BD1", "code", "implement", "build", "test", "\u81EA\u52A8\u5316"]
  },
  {
    id: "research",
    keywords: ["\u67E5", "\u8C03\u7814", "\u641C\u7D22", "research", "\u65B9\u6848", "\u5BF9\u6BD4", "\u5F00\u6E90", "\u5F15\u7528", "\u6587\u732E", "\u8D44\u6599", "\u6765\u6E90", "\u4E86\u89E3\u4E0B", "\u8BC4\u4F30"]
  },
  {
    id: "study",
    keywords: ["\u5B66\u4E60", "\u8BB2\u89E3", "\u603B\u7ED3", "\u6559\u7A0B", "\u8BFE\u7A0B", "\u9605\u8BFB", "\u7B14\u8BB0", "\u590D\u4E60", "\u7EC3\u4E60", "\u77E5\u8BC6\u5361", "study", "learn", "summar"]
  }
];
var AGENT_PRIORITY = ["coder", "research", "study", "hardware", "designer", "general"];
function scoreAgent(text) {
  const t = String(text ?? "").toLowerCase();
  if (t === "") return AGENT_CATALOG.map((a) => ({ id: a.id, hits: 0 }));
  return AGENT_CATALOG.map((a) => {
    const rule = AGENT_KEYWORDS.find((r) => r.id === a.id);
    const hits = (rule?.keywords ?? []).reduce((n, k) => n + (t.includes(k.toLowerCase()) ? 1 : 0), 0);
    return { id: a.id, hits };
  });
}
function recommendAgentId(text) {
  const scored = scoreAgent(text).filter((s) => s.hits > 0);
  if (scored.length === 0) {
    const general = AGENT_CATALOG.find((a) => a.id === "general");
    return general?.id ?? AGENT_CATALOG[0]?.id ?? "general";
  }
  const best = Math.max(...scored.map((s) => s.hits));
  const top = scored.filter((s) => s.hits === best);
  if (top.length === 1) return top[0].id;
  for (const id of AGENT_PRIORITY) {
    if (top.some((s) => s.id === id)) return id;
  }
  return top[0].id;
}
var READ_ONLY_TOKENS = ["\u67E5", "\u641C\u7D22", "\u770B\u770B", "\u8BFB\u4E00\u4E0B", "\u627E\u8D44\u6599", "\u7FFB\u8BD1", "\u4FE1\u606F", "\u4E86\u89E3\u4E00\u4E0B", "\u8C03\u7814", "\u5BF9\u6BD4", "\u5F15\u7528", "\u641C\u7D22\u4E00\u4E0B", "\u9605\u8BFB", "\u67E5\u8BE2", "\u8BFB\u53D6"];
var WRITE_TOKENS = ["\u5199", "\u6539", "\u66F4\u65B0", "\u521B\u5EFA", "\u65B0\u5EFA", "\u5220\u9664", "\u4FEE\u590D", "\u90E8\u7F72", "\u5B89\u88C5", "\u914D\u7F6E", "\u63D0\u4EA4", "\u63A8\u9001", "\u6574\u7406", "\u79FB\u52A8", "\u91CD\u547D\u540D", "\u751F\u6210", "\u5236\u4F5C", "\u8BBE\u7F6E", "\u91CD\u6784", "\u63D0\u4EA4\u4EE3\u7801", "\u53D1\u5E03", "\u4FDD\u5B58"];
function guessPermission(text) {
  const t = String(text ?? "").toLowerCase();
  const read = READ_ONLY_TOKENS.reduce((n, k) => n + (t.includes(k.toLowerCase()) ? 1 : 0), 0);
  const write = WRITE_TOKENS.reduce((n, k) => n + (t.includes(k.toLowerCase()) ? 1 : 0), 0);
  if (read > 0 && write === 0) return { permission: "read-only", confident: true };
  if (write > 0 && read === 0) return { permission: "workspace-write", confident: true };
  return { permission: "workspace-write", confident: false };
}
function catalogAgents() {
  return AGENT_CATALOG;
}

// src/workstation/personal-workspace/src/client/schedule.ts
function isValidRecurrenceRule(rule) {
  if (rule === null || typeof rule !== "object") return false;
  if (rule.frequency !== "daily" && rule.frequency !== "weekly" && rule.frequency !== "monthly") return false;
  if (!Number.isInteger(rule.hour) || rule.hour < 0 || rule.hour > 23) return false;
  if (!Number.isInteger(rule.minute) || rule.minute < 0 || rule.minute > 59) return false;
  if (rule.frequency === "weekly") {
    const days = rule.weekdays ?? [];
    if (days.length === 0) return false;
    const sorted = [...new Set(days)].sort((a, b) => a - b);
    if (sorted.some((d) => !Number.isInteger(d) || d < 1 || d > 7)) return false;
    if (sorted.length !== days.length) return false;
    return true;
  }
  if (rule.frequency === "monthly") {
    const d = rule.dayOfMonth;
    if (!Number.isInteger(d) || d < 1 || d > 31) return false;
  }
  return true;
}
function wdToCron(wd) {
  return wd === 7 ? 0 : wd;
}
function wdFromCron(v) {
  return v === 0 ? 7 : v;
}
function pad2(n) {
  return n < 10 ? `0${n}` : String(n);
}
function ruleToCron(rule) {
  if (!isValidRecurrenceRule(rule)) return null;
  const hh = `${rule.minute} ${rule.hour}`;
  if (rule.frequency === "daily") return `${hh} * * *`;
  if (rule.frequency === "weekly") {
    const days = [...new Set((rule.weekdays ?? []).map(wdToCron))].sort((a, b) => a - b).join(",");
    return `${hh} * * ${days}`;
  }
  return `${hh} ${rule.dayOfMonth} * *`;
}
function parseCronShape(cron) {
  if (typeof cron !== "string") return null;
  const fields = cron.trim().split(/\s+/);
  if (fields.length !== 5) return null;
  const [min, hour, dom, month, dow] = fields;
  if (!/^\d+$/.test(min) || !/^\d+$/.test(hour)) return null;
  const minute = Number(min);
  const hr = Number(hour);
  if (minute < 0 || minute > 59 || hr < 0 || hr > 23) return null;
  if (month !== "*") return null;
  if (dom === "*" && dow === "*") return { frequency: "daily", hour: hr, minute };
  if (dom === "*" && dow !== "*") {
    if (!/^[\d,]+$/.test(dow)) return null;
    const nums = dow.split(",").map(Number);
    if (nums.some((d) => !Number.isInteger(d) || d < 0 || d > 7)) return null;
    const weekdays = [...new Set(nums.map(wdFromCron))].sort((a, b) => a - b);
    if (weekdays.length === 0) return null;
    return { frequency: "weekly", weekdays, hour: hr, minute };
  }
  if (/^\d+$/.test(dom) && dow === "*") {
    const dayOfMonth = Number(dom);
    if (dayOfMonth < 1 || dayOfMonth > 31) return null;
    return { frequency: "monthly", dayOfMonth, hour: hr, minute };
  }
  return null;
}
var WEEKDAY_NAMES = ["\u5468\u4E00", "\u5468\u4E8C", "\u5468\u4E09", "\u5468\u56DB", "\u5468\u4E94", "\u5468\u516D", "\u5468\u65E5"];
function hhmm(hour, minute) {
  return `${pad2(hour)}:${pad2(minute)}`;
}
function describeRule(rule) {
  if (!isValidRecurrenceRule(rule)) return null;
  const time = hhmm(rule.hour, rule.minute);
  if (rule.frequency === "daily") return `\u6BCF\u5929 ${time}`;
  if (rule.frequency === "weekly") {
    const names = (rule.weekdays ?? []).map((d) => WEEKDAY_NAMES[d - 1]).join("\u3001");
    return `\u6BCF${names} ${time}`;
  }
  return `\u6BCF\u6708 ${rule.dayOfMonth} \u53F7 ${time}`;
}
function describeCron(cron) {
  const shape = parseCronShape(cron);
  if (shape === null) return null;
  const rule = {
    frequency: shape.frequency,
    ...shape.weekdays !== void 0 ? { weekdays: shape.weekdays } : {},
    ...shape.dayOfMonth !== void 0 ? { dayOfMonth: shape.dayOfMonth } : {},
    hour: shape.hour,
    minute: shape.minute
  };
  return describeRule(rule);
}
function dateAt(y, mo, day, hour, minute) {
  return new Date(y, mo, day, hour, minute, 0, 0).getTime();
}
function dayParts(ms) {
  const d = new Date(ms);
  return { y: d.getFullYear(), mo: d.getMonth(), day: d.getDate() };
}
function dayMatches(shape, y, mo, day) {
  const dow = (new Date(y, mo, day, 12, 0, 0, 0).getDay() + 6) % 7 + 1;
  if (shape.frequency === "weekly") return (shape.weekdays ?? []).includes(dow);
  if (shape.frequency === "monthly") return day === shape.dayOfMonth;
  return true;
}
function cronInstantsBetween(cron, afterMs, uptoMs, limit = 400) {
  const shape = parseCronShape(cron);
  if (shape === null) return [];
  const out = [];
  const start = dayParts(afterMs);
  const maxDay = Math.floor((uptoMs - afterMs) / 864e5) + 400;
  for (let offset = 0; offset < maxDay; offset += 1) {
    if (out.length >= limit) break;
    const cur = new Date(start.y, start.mo, start.day + offset, 0, 0, 0, 0);
    if (cur.getTime() > uptoMs) break;
    const y = cur.getFullYear();
    const mo = cur.getMonth();
    const day = cur.getDate();
    if (!dayMatches(shape, y, mo, day)) continue;
    const t = dateAt(y, mo, day, shape.hour, shape.minute);
    if (t > afterMs && t <= uptoMs) out.push(t);
  }
  return out;
}
function isAnalyzableCron(cron) {
  return typeof cron === "string" && parseCronShape(cron) !== null;
}
var EXECUTION_MATCH_WINDOW_MS = 10 * 6e4;
function summarizeMissed(cron, refBase, now, executions, ackedTimes = [], uncertain = false) {
  if (!isAnalyzableCron(cron)) return { analyzable: false, missed: [], expected: 0, executed: 0, uncertain: false };
  if (!(now > refBase)) return { analyzable: true, missed: [], expected: 0, executed: 0, uncertain };
  const instants = cronInstantsBetween(cron, refBase, now, 366);
  const acked = new Set(ackedTimes);
  const missed = [];
  let executed = 0;
  for (const t of instants) {
    const hit = (executions ?? []).some((e) => {
      const s = e.startedAt;
      return typeof s === "number" && Math.abs(s - t) <= EXECUTION_MATCH_WINDOW_MS;
    });
    if (hit) {
      executed += 1;
      continue;
    }
    if (!acked.has(t)) missed.push(t);
  }
  return {
    analyzable: true,
    missed,
    expected: instants.length,
    executed,
    uncertain
  };
}

// src/workstation/personal-workspace/src/client/task-model.ts
var PERSONAL_TASKS_STORE_KEY = "dsh.personal.tasks.v1";
var PERSONAL_TASKS_STORE_VERSION = 1;
function memory() {
  return { v: PERSONAL_TASKS_STORE_VERSION, armedAt: {}, missedAcks: {}, originSessions: {} };
}
function isData(v) {
  if (v === null || typeof v !== "object") return false;
  const d = v;
  if (d.v !== PERSONAL_TASKS_STORE_VERSION) return false;
  if (d.armedAt === null || typeof d.armedAt !== "object") return false;
  if (d.missedAcks !== void 0 && (d.missedAcks === null || typeof d.missedAcks !== "object")) return false;
  if (d.originSessions !== void 0 && (d.originSessions === null || typeof d.originSessions !== "object")) return false;
  return true;
}
function parse(raw) {
  if (raw === null || raw === "") return memory();
  try {
    const parsed = JSON.parse(raw);
    if (!isData(parsed)) return memory();
    const armedAt = {};
    for (const [k, v] of Object.entries(parsed.armedAt)) {
      if (typeof v === "number" && Number.isFinite(v)) armedAt[k] = v;
    }
    const missedAcks = {};
    for (const [k, arr] of Object.entries(parsed.missedAcks)) {
      if (!Array.isArray(arr)) continue;
      const times = arr.filter((x) => typeof x === "number" && Number.isFinite(x)).sort((a, b) => a - b);
      if (times.length > 0) missedAcks[k] = times;
    }
    const originSessions = {};
    for (const [k, v] of Object.entries(parsed.originSessions ?? {})) {
      const o = v;
      if (o !== null && typeof o === "object" && typeof o.sessionId === "string" && o.sessionId !== "" && typeof o.at === "number" && Number.isFinite(o.at)) {
        originSessions[k] = {
          sessionId: o.sessionId,
          ...typeof o.title === "string" && o.title !== "" ? { title: o.title } : {},
          at: o.at
        };
      }
    }
    return { v: PERSONAL_TASKS_STORE_VERSION, armedAt, missedAcks, originSessions };
  } catch {
    return memory();
  }
}
var PersonalTasksStore = class {
  mem = null;
  useStorage;
  constructor() {
    this.useStorage = typeof localStorage !== "undefined" && localStorage !== null;
    if (!this.useStorage) this.mem = memory();
  }
  read() {
    if (!this.useStorage) return this.mem ?? memory();
    try {
      return parse(localStorage.getItem(PERSONAL_TASKS_STORE_KEY));
    } catch {
      return memory();
    }
  }
  write(next) {
    if (!this.useStorage) {
      this.mem = next;
      return;
    }
    try {
      localStorage.setItem(PERSONAL_TASKS_STORE_KEY, JSON.stringify(next));
    } catch {
    }
  }
  /** 登记：该任务被本层启用/创建为定期任务（时刻 ms；缺省 now）。 */
  markArmed(taskId, at = Date.now()) {
    if (typeof taskId !== "string" || taskId === "") return;
    const d = this.read();
    if (typeof d.armedAt[taskId] !== "number" || d.armedAt[taskId] > at) d.armedAt[taskId] = at;
    this.write(d);
  }
  armedAtOf(taskId) {
    const at = this.read().armedAt[taskId];
    return typeof at === "number" ? at : void 0;
  }
  /** 用户把错过时刻标为已处理。 */
  ackMissed(taskId, at) {
    if (typeof taskId !== "string" || taskId === "" || !Number.isFinite(at)) return;
    const d = this.read();
    const list = [...d.missedAcks[taskId] ?? [], at].filter((x) => Number.isFinite(x)).sort((a, b) => a - b);
    const uniq = [...new Set(list)];
    d.missedAcks[taskId] = uniq;
    this.write(d);
  }
  isMissedAcked(taskId, at) {
    return (this.read().missedAcks[taskId] ?? []).includes(at);
  }
  missedAcksOf(taskId) {
    return this.read().missedAcks[taskId] ?? [];
  }
  /** 任务删除/归档时清理（避免长期累积）。 */
  clearFor(taskId) {
    const d = this.read();
    let changed = false;
    if (d.armedAt[taskId] !== void 0) {
      delete d.armedAt[taskId];
      changed = true;
    }
    if (d.missedAcks[taskId] !== void 0) {
      delete d.missedAcks[taskId];
      changed = true;
    }
    if (d.originSessions[taskId] !== void 0) {
      delete d.originSessions[taskId];
      changed = true;
    }
    if (changed) this.write(d);
  }
  /** TASK-7：登记来源会话引用（originating session 映射；不复制正文）。 */
  markOrigin(taskId, origin) {
    if (typeof taskId !== "string" || taskId === "" || origin === null || typeof origin !== "object") return;
    if (typeof origin.sessionId !== "string" || origin.sessionId === "") return;
    const d = this.read();
    d.originSessions[taskId] = {
      sessionId: origin.sessionId,
      ...typeof origin.title === "string" && origin.title !== "" ? { title: origin.title } : {},
      at: Number.isFinite(origin.at) ? origin.at : Date.now()
    };
    this.write(d);
  }
  originOf(taskId) {
    const o = this.read().originSessions[taskId];
    return o !== void 0 ? { ...o } : void 0;
  }
};
var personalTasksStore = new PersonalTasksStore();

// src/workstation/personal-workspace/src/client/task-extras.ts
var TASK_EXTRAS_STORE_KEY = "dsh.personal.taskextras.v1";
var TASK_EXTRAS_STORE_VERSION = 1;
function empty() {
  return { v: TASK_EXTRAS_STORE_VERSION, byTask: {} };
}
function str6(v) {
  return typeof v === "string" ? v : "";
}
function num2(v, fallback = 0) {
  return typeof v === "number" && Number.isFinite(v) ? v : fallback;
}
function parseRecord(taskId, v) {
  if (v === null || typeof v !== "object") return null;
  const o = v;
  const engine = o.engine === "ai" ? "ai" : "rules";
  return {
    taskId,
    original: str6(o.original),
    notes: str6(o.notes),
    deliverable: str6(o.deliverable),
    constraints: str6(o.constraints),
    background: str6(o.background),
    dueAt: str6(o.dueAt),
    duePhrase: str6(o.duePhrase),
    engine,
    engineDetail: str6(o.engineDetail),
    recognizedAt: num2(o.recognizedAt),
    savedAt: num2(o.savedAt)
  };
}
function parse2(raw) {
  if (raw === null || raw === "") return empty();
  try {
    const parsed = JSON.parse(raw);
    if (parsed === null || typeof parsed !== "object") return empty();
    const d = parsed;
    if (d.v !== TASK_EXTRAS_STORE_VERSION) return empty();
    const byTaskRaw = d.byTask;
    if (byTaskRaw === null || typeof byTaskRaw !== "object") return empty();
    const byTask = {};
    for (const [taskId, rec] of Object.entries(byTaskRaw)) {
      if (taskId === "") continue;
      const parsedRec = parseRecord(taskId, rec);
      if (parsedRec !== null && (parsedRec.original !== "" || parsedRec.notes !== "" || parsedRec.deliverable !== "" || parsedRec.constraints !== "" || parsedRec.background !== "" || parsedRec.dueAt !== "")) {
        byTask[taskId] = parsedRec;
      }
    }
    return { v: TASK_EXTRAS_STORE_VERSION, byTask };
  } catch {
    return empty();
  }
}
var TaskExtrasStore = class {
  mem = null;
  useStorage;
  constructor() {
    this.useStorage = typeof localStorage !== "undefined" && localStorage !== null;
    if (!this.useStorage) this.mem = { v: TASK_EXTRAS_STORE_VERSION, byTask: {} };
  }
  read() {
    if (!this.useStorage) return this.mem ?? empty();
    try {
      return parse2(localStorage.getItem(TASK_EXTRAS_STORE_KEY));
    } catch {
      return empty();
    }
  }
  write(next) {
    if (!this.useStorage) {
      this.mem = next;
      return;
    }
    try {
      localStorage.setItem(TASK_EXTRAS_STORE_KEY, JSON.stringify(next));
    } catch {
    }
  }
  /** 保存（同 taskId 覆盖；只保留用户真的填了东西的记录）。 */
  save(rec) {
    if (typeof rec.taskId !== "string" || rec.taskId === "") return;
    const empty2 = rec.original === "" && rec.notes === "" && rec.deliverable === "" && rec.constraints === "" && rec.background === "" && rec.dueAt === "";
    const d = this.read();
    if (empty2) {
      if (d.byTask[rec.taskId] !== void 0) {
        delete d.byTask[rec.taskId];
        this.write(d);
      }
      return;
    }
    d.byTask[rec.taskId] = {
      taskId: rec.taskId,
      original: str6(rec.original),
      notes: str6(rec.notes),
      deliverable: str6(rec.deliverable),
      constraints: str6(rec.constraints),
      background: str6(rec.background),
      dueAt: str6(rec.dueAt),
      duePhrase: str6(rec.duePhrase),
      engine: rec.engine === "ai" ? "ai" : "rules",
      engineDetail: str6(rec.engineDetail),
      recognizedAt: num2(rec.recognizedAt, Date.now()),
      savedAt: num2(rec.savedAt, Date.now())
    };
    this.write(d);
  }
  get(taskId) {
    if (typeof taskId !== "string" || taskId === "") return void 0;
    const rec = this.read().byTask[taskId];
    return rec !== void 0 ? { ...rec } : void 0;
  }
  /** 全部记录（按 savedAt 降序；UI 只用它回显「本页创建过的任务」，不做看板）。 */
  list() {
    return Object.values(this.read().byTask).slice().sort((a, b) => b.savedAt - a.savedAt);
  }
  clear(taskId) {
    const d = this.read();
    if (d.byTask[taskId] === void 0) return;
    delete d.byTask[taskId];
    this.write(d);
  }
};
var taskExtrasStore = new TaskExtrasStore();

// src/workstation/personal-workspace/src/client/parser.ts
var WEEKDAY_MAP = {
  \u4E00: 1,
  \u4E8C: 2,
  \u4E09: 3,
  \u56DB: 4,
  \u4E94: 5,
  \u516D: 6,
  \u65E5: 7,
  \u5929: 7
};
function norm(s) {
  return s.replace(/\s+/g, "").toLowerCase();
}
function periodBias(period, hour) {
  if (period === void 0) return hour;
  if (period === "\u65E9\u4E0A" || period === "\u4E0A\u5348") return hour >= 12 ? hour - 12 : hour;
  if (period === "\u4E2D\u5348") return hour === 12 ? 12 : hour < 7 ? hour + 12 : hour;
  if (period === "\u4E0B\u5348") return hour < 12 ? hour + 12 : hour;
  if (period === "\u665A\u4E0A") return hour < 6 ? hour + 12 : hour < 12 ? hour + 12 : hour;
  return hour;
}
function parseClock(text) {
  const t = norm(text);
  const colon = t.match(/(\d{1,2}):(\d{1,2})/);
  if (colon !== null) {
    const h = Number(colon[1]);
    const m = Number(colon[2]);
    if (h >= 0 && h <= 23 && m >= 0 && m <= 59) return [h, m];
    return null;
  }
  const period = t.indexOf("\u65E9\u4E0A") >= 0 ? "\u65E9\u4E0A" : t.indexOf("\u4E0A\u5348") >= 0 ? "\u4E0A\u5348" : t.indexOf("\u4E2D\u5348") >= 0 ? "\u4E2D\u5348" : t.indexOf("\u4E0B\u5348") >= 0 ? "\u4E0B\u5348" : t.indexOf("\u665A\u4E0A") >= 0 ? "\u665A\u4E0A" : void 0;
  const hm = t.match(/(?:(?:早|上|中|下|晚)(?:上|午)?)?(\d{1,2})点(?:(\d{1,2})分?|半)?/);
  if (hm === null || hm[1] === void 0) return null;
  const raw = Number(hm[1]);
  if (raw < 0 || raw > 24) return null;
  const minute = hm[2] !== void 0 ? Number(hm[2]) : hm[0].indexOf("\u534A") >= 0 ? 30 : 0;
  if (minute < 0 || minute > 59) return null;
  return [periodBias(period, raw), minute];
}
function recognizeFrequency(src) {
  const s = norm(src);
  if (/(?:每天|每日|每晚|天天)/.test(s)) {
    const m = s.match(/(?:每天|每日|每晚|天天)/);
    return { rule: { frequency: "daily" }, recog: m[0] === "\u6BCF\u665A" ? "\u6BCF\u665A" : "\u6BCF\u5929" };
  }
  const weekly = s.match(/每?周|每?星期/);
  if (weekly !== null) {
    const segStart = weekly.index + weekly[0].length;
    const seg = s.slice(segStart);
    const days = [];
    const run = seg.match(/^[一二三四五六日天\d][一二三四五六日天\d,，、]*/);
    if (run !== null) {
      for (const ch of run[0]) {
        const d = WEEKDAY_MAP[ch];
        if (d !== void 0 && !days.includes(d)) days.push(d);
      }
      const fromNumbers = run[0].match(/\d/g);
      if (fromNumbers !== null) for (const n of fromNumbers) {
        const v = Number(n);
        if (v >= 1 && v <= 7 && !days.includes(v)) days.push(v);
      }
    }
    if (days.length > 0) return { rule: { frequency: "weekly", weekdays: days.sort((a, b) => a - b) }, recog: "\u6BCF\u5468" };
    return { rule: { frequency: "weekly", weekdays: void 0 }, recog: "\u6BCF\u5468" };
  }
  const monthly = s.match(/(?:每月|每个月)/);
  if (monthly !== null) {
    const seg = s.slice(monthly.index + monthly[0].length);
    const dom = seg.match(/(\d{1,2})\s*[号日]/);
    if (dom !== null) {
      const v = Number(dom[1]);
      if (v >= 1 && v <= 31) return { rule: { frequency: "monthly", dayOfMonth: v }, recog: "\u6BCF\u6708" };
    }
    const bare = seg.match(/^(\d{1,2})(?=[点:：]|$)/);
    if (bare !== null && Number(bare[1]) <= 31) return { rule: { frequency: "monthly", dayOfMonth: Number(bare[1]) }, recog: "\u6BCF\u6708" };
    return { rule: { frequency: "monthly", dayOfMonth: void 0 }, recog: "\u6BCF\u6708" };
  }
  return null;
}
function findClock(src) {
  return parseClock(norm(src));
}
var PERM_WORDS = [
  { re: /完全权限|全权限|完整权限|完全控制/, perm: "danger-full-access", label: "\u5B8C\u5168\u6743\u9650" },
  { re: /可写|写入|修改文件|读写|工作区写入/, perm: "workspace-write", label: "\u5DE5\u4F5C\u533A\u5199\u5165" },
  { re: /只读|仅查看|只读权限|只看/, perm: "read-only", label: "\u53EA\u8BFB" }
];
function findWorkspaceName(src) {
  const m = src.match(/(?:在|放到|放进|使用)\s*「([^」]{1,24})」\s*(?:工作区|项目)?|(?:工作区|项目)\s*[：:]\s*「?([^「」\s，。,。]{1,24})/);
  if (m === null) return null;
  const name = m[1] ?? m[2];
  if (name === void 0 || name.trim() === "") return null;
  return { name: name.trim(), recog: m[0] };
}
function splitSections(body) {
  const out = {};
  const lines = body.split("\n");
  let context = [];
  let input = [];
  let output = [];
  let constraints = [];
  let bucket = "context";
  const heads = {
    \u80CC\u666F: "context",
    \u4E0A\u4E0B\u6587: "context",
    \u76EE\u6807: "context",
    \u8F93\u5165: "input",
    \u6750\u6599: "input",
    \u8F93\u51FA: "output",
    \u4EA7\u51FA: "output",
    \u7ED3\u679C: "output",
    \u7EA6\u675F: "constraints",
    \u6CE8\u610F: "constraints",
    \u8981\u6C42: "constraints"
  };
  for (const line of lines) {
    const t = line.trim();
    if (t === "") continue;
    const head = t.replace(/^[-*#\d.、]+/, "").split(/[：:]/)[0].trim();
    if (heads[head] !== void 0) {
      bucket = heads[head];
      const rest = t.slice(t.indexOf("\uFF1A") >= 0 ? t.indexOf("\uFF1A") + 1 : t.indexOf(":") >= 0 ? t.indexOf(":") + 1 : head.length).trim();
      if (rest !== "") ;
      else continue;
      if (bucket === "context") context.push(rest);
      else if (bucket === "input") input.push(rest);
      else if (bucket === "output") output.push(rest);
      else constraints.push(rest);
      continue;
    }
    if (bucket === "context") context.push(t);
    else if (bucket === "input") input.push(t);
    else if (bucket === "output") output.push(t);
    else constraints.push(t);
  }
  if (context.length > 0) out.context = context.join("\uFF1B");
  if (input.length > 0) out.input = input.join("\uFF1B");
  if (output.length > 0) out.output = output.join("\uFF1B");
  if (constraints.length > 0) out.constraints = constraints.join("\uFF1B");
  return out;
}
function parseTaskText(raw) {
  const src = raw.trim();
  const notes = [];
  const missing = [];
  const firstLine = src.split("\n")[0] ?? "";
  const titleSource = firstLine.replace(/^(请|帮我|麻烦|请帮我)\s*/, "").replace(/[。！？!?，,]$/, "");
  const title = titleSource.length > 0 ? titleSource.slice(0, 28) : "\u672A\u547D\u540D\u4EFB\u52A1";
  const prompt = src;
  const sections = splitSections(src);
  const descLines = (sections.context ?? "") !== "" ? [`\u80CC\u666F\uFF1A${sections.context}`, ...sections.output !== void 0 ? [`\u4EA7\u51FA\uFF1A${sections.output}`] : [], ...sections.constraints !== void 0 ? [`\u7EA6\u675F\uFF1A${sections.constraints}`] : []] : [];
  const description = descLines.join("\n") || void 0;
  let permission;
  for (const w of PERM_WORDS) {
    if (w.re.test(src)) {
      permission = w.perm;
      notes.push(`\u8BC6\u522B\u5230\u6743\u9650\u8BCD\u300C${w.label}\u300D`);
      break;
    }
  }
  const ws = findWorkspaceName(src);
  if (ws !== null) {
    notes.push(`\u8BC6\u522B\u5230\u6267\u884C\u4F4D\u7F6E\u63D0\u793A\u300C${ws.name}\u300D\uFF08\u5982\u4E0E\u5B98\u65B9\u5DE5\u4F5C\u533A\u4E0D\u7B26\u53EF\u5FFD\u7565\uFF09`);
  }
  const freq = recognizeFrequency(src);
  if (freq !== null) {
    const clock = findClock(src);
    const rule = { frequency: freq.rule.frequency, ...freq.rule };
    if (clock !== null) {
      rule.hour = clock[0];
      rule.minute = clock[1];
    } else {
      missing.push("\u91CD\u590D\u65F6\u95F4");
    }
    if (rule.frequency === "weekly" && (rule.weekdays === void 0 || rule.weekdays.length === 0)) missing.push("\u6BCF\u5468\u7684\u661F\u671F\u51E0");
    if (rule.frequency === "monthly" && rule.dayOfMonth === void 0) missing.push("\u6BCF\u6708\u51E0\u53F7");
    notes.push(`\u8BC6\u522B\u5230\u91CD\u590D\u5468\u671F\u300C${freq.recog}\u300D` + (rule.hour !== void 0 ? `\uFF08\u65F6\u95F4 ${String(rule.hour).padStart(2, "0")}:${String(rule.minute).padStart(2, "0")}\uFF09` : "\uFF0C\u4F46\u672A\u7ED9\u51FA\u5177\u4F53\u65F6\u95F4"));
    return {
      draft: {
        kind: missing.length === 0 ? "recurring" : "ask",
        title,
        prompt,
        ...description !== void 0 ? { description } : {},
        recurrence: rule,
        ...permission !== void 0 ? { permission } : {},
        ...ws !== null ? { workspaceName: ws.name } : {},
        ...Object.keys(sections).length > 0 ? { sections } : {}
      },
      notes,
      missing
    };
  }
  notes.push("\u672A\u8BC6\u522B\u5230\u91CD\u590D\u5468\u671F\u8BCD \u2192 \u6309\u5355\u6B21\u4EFB\u52A1\u5904\u7406");
  if (title === "\u672A\u547D\u540D\u4EFB\u52A1") missing.push("\u4EFB\u52A1\u6807\u9898");
  return {
    draft: {
      kind: "single",
      title,
      prompt,
      ...description !== void 0 ? { description } : {},
      ...permission !== void 0 ? { permission } : {},
      ...ws !== null ? { workspaceName: ws.name } : {},
      ...Object.keys(sections).length > 0 ? { sections } : {}
    },
    notes,
    missing
  };
}

// src/workstation/personal-workspace/src/client/draft.ts
var NEED_REASON = {
  goal: "\u9700\u8981\u8865\u5145\u4EFB\u52A1\u76EE\u6807\uFF1A\u8FD9\u662F\u552F\u4E00\u5FC5\u586B\u9879 \u2014\u2014 \u8BF7\u63CF\u8FF0\u8981\u8BA9 Harness \u505A\u4EC0\u4E48\u3002",
  deliverable: "\u9700\u8981\u8865\u5145\u4EA4\u4ED8\u7269\uFF1A\u76EE\u524D\u65E0\u6CD5\u5224\u65AD\u5B8C\u6210\u540E\u8981\u4EA4\u7ED9\u4F60\u4EC0\u4E48\u3002",
  dueAt: "\u9700\u8981\u8865\u5145\u622A\u6B62\u65F6\u95F4\uFF1A\u4F60\u63D0\u5230\u4E86\u65F6\u95F4\u654F\u611F\u4E8B\u9879\uFF0C\u4F46\u6CA1\u6709\u7ED9\u51FA\u65F6\u95F4\u3002",
  dueAtUnclear: "\u9700\u8981\u8865\u5145\u622A\u6B62\u65F6\u95F4\uFF1A\u4F60\u63D0\u5230\u7684\u65F6\u95F4\u8BF4\u6CD5\u65E0\u6CD5\u6362\u7B97\u6210\u5177\u4F53\u65E5\u671F\uFF08\u4F8B\u5982\u300C\u5C3D\u5FEB\u300D\u300C\u4E0B\u5468\u300D\u6CA1\u6709\u6307\u5B9A\u54EA\u5929\uFF09\u3002",
  recurrence: "\u9700\u8981\u8865\u5145\u91CD\u590D\u89C4\u5219\uFF1A\u4F60\u63D0\u5230\u4E86\u91CD\u590D\u6267\u884C\uFF0C\u4F46\u6CA1\u6709\u7ED9\u51FA\u6267\u884C\u65F6\u95F4\u3002"
};
var ENGINE_DETAIL_RULES = "\u672C\u5730\u89C4\u5219\u8BC6\u522B\uFF08\u672A\u4F7F\u7528\u6A21\u578B\uFF1B\u9010\u5B57\u642C\u8FD0\u539F\u6587\uFF0C\u4E0D\u505A\u751F\u6210\uFF09";
var ENGINE_DETAIL_AI_UNAVAILABLE = "AI \u4E0D\u53EF\u7528 \u2192 \u5DF2\u9000\u56DE\u672C\u5730\u89C4\u5219\u8BC6\u522B";
var SENTENCE_SPLIT = /[。！？；\n]+/;
var CLAUSE_SPLIT = /[，,、]+/;
var DELIVERABLE_MARKERS = [
  "\u7ED9\u6211",
  "\u53D1\u6211",
  "\u4EA4\u4ED8",
  "\u4EA7\u51FA",
  "\u8F93\u51FA",
  "\u63D0\u4F9B",
  "\u8FD4\u56DE",
  "\u505A\u6210",
  "\u5199\u6210",
  "\u6574\u7406\u6210",
  "\u6C47\u603B\u6210",
  "\u751F\u6210"
];
var CONSTRAINT_MARKERS = [
  "\u9884\u7B97",
  "\u4E0D\u8D85\u8FC7",
  "\u4EE5\u5185",
  "\u4E0D\u8981",
  "\u4E0D\u80FD",
  "\u5FC5\u987B",
  "\u53EA\u80FD",
  "\u9650\u5236",
  "\u683C\u5F0F",
  "\u5B57\u6570",
  "\u7528\u4E2D\u6587",
  "\u7528\u82F1\u6587",
  "\u65F6\u957F",
  "\u7981\u6B62",
  "\u6700\u591A",
  "\u81F3\u5C11",
  "\u4F4E\u4E8E",
  "\u9AD8\u4E8E",
  "\u5305\u90AE",
  "\u514D",
  "\u9700\u7B26\u5408",
  "\u52A1\u5FC5"
];
var BACKGROUND_MARKERS = ["\u80CC\u666F", "\u56E0\u4E3A", "\u7531\u4E8E", "\u76EE\u524D", "\u5F53\u524D", "\u6700\u8FD1\u6211", "\u6211\u5728", "\u60C5\u51B5\u662F", "\u539F\u56E0\u662F", "\u4E3A\u4E86"];
var ACTION_MARKERS = [
  "\u5E2E\u6211",
  "\u8BF7",
  "\u9700\u8981",
  "\u8981",
  "\u505A",
  "\u5199",
  "\u67E5",
  "\u627E",
  "\u6574\u7406",
  "\u8C03\u7814",
  "\u603B\u7ED3",
  "\u68C0\u67E5",
  "\u751F\u6210",
  "\u5206\u6790",
  "\u4F18\u5316",
  "\u4FEE\u590D",
  "\u521B\u5EFA",
  "\u642D\u5EFA",
  "\u8BBE\u8BA1",
  "\u5BF9\u6BD4",
  "\u7FFB\u8BD1",
  "\u8BA1\u7B97",
  "\u89C4\u5212",
  "\u6E05\u7406",
  "\u5907\u4EFD",
  "\u5B89\u88C5",
  "\u914D\u7F6E"
];
var VAGUE_MARKERS = [
  "\u5F04\u4E00\u4E0B",
  "\u641E\u4E00\u4E0B",
  "\u770B\u770B",
  "\u770B\u4E00\u4E0B",
  "\u4F18\u5316\u4E00\u4E0B",
  "\u5904\u7406\u4E00\u4E0B",
  "\u6574\u7406\u4E00\u4E0B",
  "\u5F04\u597D",
  "\u641E\u5B9A",
  "\u7814\u7A76\u4E00\u4E0B",
  "\u4E86\u89E3\u4E00\u4E0B",
  "\u5B8C\u5584\u4E00\u4E0B",
  "\u6539\u8FDB\u4E00\u4E0B",
  "\u641E\u5B9A\u5B83",
  "\u5F04\u4E00\u4E0B\u90A3\u4E2A"
];
var DUE_MARKERS = [
  "\u4E4B\u524D",
  "\u524D\u5B8C\u6210",
  "\u524D\u7ED9",
  "\u622A\u6B62",
  "\u5C3D\u5FEB",
  "\u5C3D\u65E9",
  "\u8FD1\u671F",
  "\u672C\u5468",
  "\u8FD9\u5468",
  "\u4E0B\u5468",
  "\u4E0B\u4E0B\u5468",
  "\u6708\u5E95",
  "\u6708\u521D",
  "\u4ECA\u5929",
  "\u660E\u5929",
  "\u540E\u5929",
  "\u5927\u540E\u5929",
  "\u6708",
  "\u53F7",
  "\u65E5",
  "\u5929\u5185",
  "\u5468\u5185",
  "\u5185\u5B8C\u6210"
];
var RECURRENCE_MARKERS = /(每天|每日|每晚|天天|每周|每星期|每礼拜|每月|每个月)/;
function has(text, marker) {
  return text.indexOf(marker) >= 0;
}
function hasAny(text, markers) {
  return markers.some((m) => has(text, m));
}
function clausesOf(text) {
  const out = [];
  for (const sentence of text.split(SENTENCE_SPLIT)) {
    for (const raw of sentence.split(CLAUSE_SPLIT)) {
      const c = raw.trim();
      if (c !== "") out.push(c);
    }
  }
  return out;
}
function sectionExtras(section, clauses) {
  const s = (section ?? "").trim();
  if (s === "") return [];
  const out = [];
  for (const piece of s.split("\uFF1B")) {
    const t = piece.trim();
    if (t === "") continue;
    if (clauses.some((c) => c.indexOf(t) >= 0)) continue;
    if (out.some((o) => o.indexOf(t) >= 0)) continue;
    out.push(t);
  }
  return out;
}
var WEEKDAY_CN = { \u4E00: 1, \u4E8C: 2, \u4E09: 3, \u56DB: 4, \u4E94: 5, \u516D: 6, \u65E5: 7, \u5929: 7 };
var DUE_TAILS = ["\u4E4B\u524D", "\u4EE5\u524D", "\u4E4B\u5185", "\u4EE5\u5185", "\u524D", "\u5185"];
function withTail(text, m) {
  const rest = text.slice((m.index ?? 0) + m[0].length);
  for (const tail of DUE_TAILS) if (rest.startsWith(tail)) return m[0] + tail;
  return m[0];
}
function startOfDay(d) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0);
}
function addDays(d, n) {
  const x = new Date(d.getTime());
  x.setDate(x.getDate() + n);
  return x;
}
function isoWeekday(d) {
  const w = d.getDay();
  return w === 0 ? 7 : w;
}
function lastDayOfMonth(d) {
  return new Date(d.getFullYear(), d.getMonth() + 1, 0, 0, 0, 0, 0);
}
function fmt(d, withTime) {
  const p = (n) => n < 10 ? `0${n}` : String(n);
  const day = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  return withTime ? `${day} ${p(d.getHours())}:${p(d.getMinutes())}` : day;
}
function extractDue(raw, now = /* @__PURE__ */ new Date()) {
  const text = raw.replace(/\s+/g, "");
  const clock = text.match(/(\d{1,2})[:：](\d{2})/) ?? text.match(/(早上|上午|中午|下午|晚上)?(\d{1,2})点(半|(\d{1,2})分?)?/);
  let hour = null;
  let minute = 0;
  if (clock !== null) {
    if (clock[0].indexOf(":") >= 0 || clock[0].indexOf("\uFF1A") >= 0) {
      hour = Number(clock[1]);
      minute = Number(clock[2]);
    } else {
      const period = clock[1];
      let h = Number(clock[2]);
      if (clock[3] === "\u534A") minute = 30;
      else if (typeof clock[4] === "string" && clock[4] !== "") minute = Number(clock[4]);
      if (period === "\u4E0B\u5348" || period === "\u665A\u4E0A") h = h < 12 ? h + 12 : h;
      else if (period === "\u4E2D\u5348") h = h === 12 ? 12 : h < 7 ? h + 12 : h;
      else if (period === "\u65E9\u4E0A" || period === "\u4E0A\u5348") h = h >= 12 ? h - 12 : h;
      hour = h;
    }
    if (hour !== null && (hour < 0 || hour > 23 || minute < 0 || minute > 59)) hour = null;
  }
  const withClock = (d) => hour === null ? startOfDay(d) : new Date(d.getFullYear(), d.getMonth(), d.getDate(), hour, minute, 0, 0);
  const base = startOfDay(now);
  const abs = text.match(/(大后天|后天|明天|明日|今天|今日)/);
  if (abs !== null) {
    const offset = abs[1] === "\u5927\u540E\u5929" ? 3 : abs[1] === "\u540E\u5929" ? 2 : abs[1] === "\u660E\u5929" || abs[1] === "\u660E\u65E5" ? 1 : 0;
    return { phrase: withTail(text, abs), at: withClock(addDays(base, offset)), hasTime: hour !== null, vague: false };
  }
  const md = text.match(/(\d{1,2})月(\d{1,2})[日号]/);
  if (md !== null) {
    const month = Number(md[1]);
    const day = Number(md[2]);
    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      let year = now.getFullYear();
      const candidate = new Date(year, month - 1, day, 0, 0, 0, 0);
      if (candidate.getTime() < base.getTime()) year += 1;
      return { phrase: withTail(text, md), at: withClock(new Date(year, month - 1, day, 0, 0, 0, 0)), hasTime: hour !== null, vague: false };
    }
  }
  const wd = text.match(/(下下周|下周|本周|这周|周|星期)([一二三四五六日天])/);
  if (wd !== null) {
    const prefix = wd[1];
    const target = WEEKDAY_CN[wd[2]];
    if (target !== void 0) {
      const cur = isoWeekday(base);
      let delta = target - cur;
      if (prefix === "\u4E0B\u5468") delta += 7;
      else if (prefix === "\u4E0B\u4E0B\u5468") delta += 14;
      else if (delta < 0) delta += prefix === "\u672C\u5468" || prefix === "\u8FD9\u5468" ? 0 : 7;
      const d = addDays(base, delta < 0 ? 0 : delta);
      return { phrase: withTail(text, wd), at: withClock(d), hasTime: hour !== null, vague: false };
    }
  }
  const rel = text.match(/([一二三四五六七八九十\d]{1,3})(天|日|周|个?星期)(内|后|之内|以内)/);
  if (rel !== null) {
    const n = cnNumber(rel[1]);
    if (n !== null) {
      const days = rel[2] === "\u5929" || rel[2] === "\u65E5" ? n : n * 7;
      return { phrase: rel[0], at: withClock(addDays(base, days)), hasTime: hour !== null, vague: false };
    }
  }
  if (has(text, "\u6708\u5E95") || has(text, "\u6708\u672B")) {
    return { phrase: has(text, "\u6708\u5E95") ? "\u6708\u5E95" : "\u6708\u672B", at: withClock(lastDayOfMonth(base)), hasTime: hour !== null, vague: false };
  }
  const vague = ["\u5C3D\u5FEB", "\u5C3D\u65E9", "\u8FD1\u671F", "\u6700\u8FD1", "\u8FD9\u51E0\u5929", "\u8FC7\u51E0\u5929", "\u6709\u7A7A", "\u65B9\u4FBF\u65F6"];
  const hitVague = vague.find((w) => has(text, w));
  if (hitVague !== void 0) return { phrase: hitVague, at: null, hasTime: false, vague: true };
  for (const w of ["\u4E0B\u5468", "\u4E0B\u4E0B\u5468", "\u672C\u5468", "\u8FD9\u5468", "\u6708\u5E95", "\u6708\u672B"]) {
    if (has(text, w)) return { phrase: w, at: null, hasTime: false, vague: false };
  }
  return null;
}
function cnNumber(s) {
  if (/^\d+$/.test(s)) return Number(s);
  const map = { \u4E00: 1, \u4E8C: 2, \u4E24: 2, \u4E09: 3, \u56DB: 4, \u4E94: 5, \u516D: 6, \u4E03: 7, \u516B: 8, \u4E5D: 9, \u5341: 10 };
  if (s.length === 1) return map[s] ?? null;
  if (s === "\u5341\u4E00") return 11;
  if (s === "\u5341\u4E8C") return 12;
  return null;
}
function recognizeByRules(raw, opts = {}) {
  const original = String(raw ?? "");
  const text = original.trim();
  const now = opts.now ?? /* @__PURE__ */ new Date();
  const notes = [];
  const parsed = parseTaskText(text);
  const clauses = clausesOf(text);
  const due = extractDue(text, now);
  const constraintClauses = [];
  const deliverableClauses = [];
  const backgroundClauses = [];
  const rest = [];
  for (const c of clauses) {
    if (hasAny(c, CONSTRAINT_MARKERS)) constraintClauses.push(c);
    else if (hasAny(c, DELIVERABLE_MARKERS)) deliverableClauses.push(c);
    else if (hasAny(c, BACKGROUND_MARKERS)) backgroundClauses.push(c);
    else rest.push(c);
  }
  const goalClause = rest.find((c) => hasAny(c, ACTION_MARKERS)) ?? rest[0] ?? "";
  const goalIndex = goalClause === "" ? -1 : rest.indexOf(goalClause);
  const leftover = rest.filter((_, i) => i !== goalIndex);
  let goal = goalClause;
  if (due !== null && due.phrase !== "" && goal.startsWith(due.phrase)) {
    goal = goal.slice(due.phrase.length).replace(/^[，,]/, "").trim();
    notes.push(`\u4EFB\u52A1\u76EE\u6807\u5DF2\u53BB\u6389\u5F00\u5934\u7684\u65F6\u95F4\u77ED\u8BED\u300C${due.phrase}\u300D\uFF08\u8BE5\u77ED\u8BED\u8BB0\u5165\u300C\u622A\u6B62\u65F6\u95F4\u300D\uFF09`);
  }
  const background = backgroundClauses.join("\uFF1B");
  const constraints = constraintClauses.join("\uFF1B");
  const deliverableExtra = sectionExtras(parsed.draft.sections?.output, clauses);
  const deliverable = [...deliverableClauses, ...deliverableExtra].join("\uFF1B");
  const notesField = leftover.join("\uFF1B");
  const projects = opts.projects ?? [];
  let projectId = null;
  const flat = text.replace(/\s+/g, "").toLowerCase();
  let bestLen = 0;
  for (const p of projects) {
    const name = p.name.replace(/\s+/g, "").toLowerCase();
    if (name === "" || !flat.includes(name)) continue;
    if (name.length > bestLen) {
      bestLen = name.length;
      projectId = p.id;
    }
  }
  if (projectId !== null) notes.push(`\u9879\u76EE\u5F52\u5C5E\u547D\u4E2D\u539F\u6587\u4E2D\u7684\u9879\u76EE\u540D\uFF1A${projects.find((p) => p.id === projectId)?.name ?? projectId}`);
  const recurrenceDeclared = RECURRENCE_MARKERS.test(text);
  let recurrence = null;
  const pr = recurrenceDeclared ? parsed.draft.recurrence : void 0;
  if (pr !== void 0) {
    recurrence = {
      frequency: pr.frequency,
      ...pr.weekdays !== void 0 ? { weekdays: pr.weekdays } : {},
      ...pr.dayOfMonth !== void 0 ? { dayOfMonth: pr.dayOfMonth } : {},
      hour: pr.hour ?? 20,
      minute: pr.minute ?? 0
    };
    notes.push(`\u8BC6\u522B\u5230\u91CD\u590D\u6267\u884C\uFF1A${parsed.notes.join("\uFF1B") || parsed.draft.recurrence !== void 0 ? "\u6765\u81EA\u539F\u6587\u7684\u5468\u671F\u8BF4\u6CD5" : ""}`.trim());
  }
  if (recurrenceDeclared) {
    for (const n of parsed.notes) if (notes.indexOf(n) < 0) notes.push(n);
  }
  const needs = [];
  if (goal.trim() === "") needs.push({ key: "goal", reason: NEED_REASON.goal });
  const vagueGoal = hasAny(text, VAGUE_MARKERS);
  const explicitOutput = deliverableClauses.length > 0 || deliverableExtra.length > 0;
  if (goal.trim() !== "" && !explicitOutput && (vagueGoal || text.replace(/\s+/g, "").length < 10)) {
    needs.push({ key: "deliverable", reason: NEED_REASON.deliverable });
  }
  const dueMentioned = due !== null || hasAny(text, DUE_MARKERS);
  if (dueMentioned && (due === null || due.at === null)) {
    const vagueOnly = due !== null && due.at === null && due.vague;
    needs.push({ key: "dueAt", reason: vagueOnly ? NEED_REASON.dueAt : NEED_REASON.dueAtUnclear });
  }
  const recurrenceTimeMissing = pr !== void 0 && (pr.hour === void 0 || pr.minute === void 0);
  const recurrenceIncomplete = pr !== void 0 && (recurrenceTimeMissing || pr.frequency === "weekly" && (pr.weekdays ?? []).length === 0 || pr.frequency === "monthly" && pr.dayOfMonth === void 0);
  if (recurrenceIncomplete) needs.push({ key: "recurrence", reason: NEED_REASON.recurrence });
  const fields = {
    goal,
    background,
    deliverable,
    dueAt: due !== null && due.at !== null ? fmt(due.at, due.hasTime) : "",
    duePhrase: due !== null ? due.phrase : "",
    projectId,
    recurrence,
    recurrenceTimeMissing,
    constraints,
    notes: notesField,
    original
  };
  return { fields, needs, notes, engine: "rules", engineDetail: ENGINE_DETAIL_RULES };
}
function str7(v) {
  return typeof v === "string" ? v.trim() : "";
}
function squish(s) {
  return s.replace(/[\s，,。.；;：:、！!？?（）()「」“”"'\-—]/g, "").toLowerCase();
}
function groundAiDraft(ai, raw, opts = {}) {
  const rules = recognizeByRules(raw, opts);
  const base = rules.fields;
  const original = base.original;
  const flat = squish(original);
  const notes = [];
  const dropped = [];
  const pick = (key, value) => {
    if (value === "") return "";
    const sq = squish(value);
    if (sq.length >= 4 && flat.includes(sq)) return value;
    if (sq.length < 4 && sq !== "" && flat.includes(sq)) return value;
    dropped.push(key);
    return "";
  };
  const goal = pick("goal", str7(ai.goal)) || base.goal;
  const background = pick("background", str7(ai.background)) || base.background;
  const deliverable = pick("deliverable", str7(ai.deliverable)) || base.deliverable;
  const constraints = pick("constraints", str7(ai.constraints)) || base.constraints;
  const notesField = pick("notes", str7(ai.notes)) || base.notes;
  const dueRaw = str7(ai.dueAt);
  let dueAt = base.dueAt;
  if (dueRaw !== "") {
    const explicit = extractDue(original, opts.now ?? /* @__PURE__ */ new Date());
    const computed = explicit !== null && explicit.at !== null ? fmt(explicit.at, explicit.hasTime) : "";
    if (computed !== "" && squish(dueRaw) === squish(computed)) dueAt = computed;
    else {
      dropped.push("dueAt");
      notes.push("\u539F\u6587\u6CA1\u6709\u53EF\u6362\u7B97\u7684\u663E\u5F0F\u65F6\u95F4\u77ED\u8BED \u2192 AI \u7ED9\u51FA\u7684\u622A\u6B62\u65F6\u95F4\u672A\u88AB\u91C7\u7528\uFF08\u9632\u6B62\u51ED\u7A7A\u8865\u65E5\u671F\uFF09");
    }
  }
  if (dropped.length > 0) notes.push(`\u4EE5\u4E0B AI \u5B57\u6BB5\u5728\u539F\u6587\u4E2D\u627E\u4E0D\u5230\u51FA\u5904\uFF0C\u5DF2\u4E22\u5F03\uFF08\u4E0D\u7F16\u9020\uFF09\uFF1A${[...new Set(dropped)].join("\u3001")}`);
  return { fields: { ...base, goal, background, deliverable, constraints, notes: notesField, dueAt }, notes, dropped };
}
var TITLE_MAX = 48;
function titleOfDraft(goal, fallback = "\u65B0\u4EFB\u52A1") {
  const first = String(goal ?? "").split("\n")[0].trim();
  if (first === "") return fallback;
  return first.length > TITLE_MAX ? `${first.slice(0, TITLE_MAX)}\u2026` : first;
}
function composeDescription(f) {
  const lines = [];
  if (f.goal.trim() !== "") lines.push(`\u4EFB\u52A1\u76EE\u6807\uFF1A${f.goal.trim()}`);
  if (f.background.trim() !== "") lines.push(`\u80CC\u666F\u4E0E\u8865\u5145\u8BF4\u660E\uFF1A${f.background.trim()}`);
  if (f.deliverable.trim() !== "") lines.push(`\u9884\u671F\u4EA4\u4ED8\u7269\uFF1A${f.deliverable.trim()}`);
  if (f.dueAt.trim() !== "") {
    const phrase = f.duePhrase.trim() !== "" ? `\uFF08\u539F\u6587\uFF1A${f.duePhrase.trim()}\uFF09` : "";
    lines.push(`\u622A\u6B62\u65F6\u95F4\uFF1A${f.dueAt.trim()}${phrase}`);
  }
  if (f.constraints.trim() !== "") lines.push(`\u7EA6\u675F\u4E0E\u6CE8\u610F\u4E8B\u9879\uFF1A${f.constraints.trim()}`);
  if (f.notes.trim() !== "") lines.push(`\u5907\u6CE8\uFF1A${f.notes.trim()}`);
  if (f.original.trim() !== "") lines.push(`\u539F\u59CB\u9700\u6C42\uFF08\u9010\u5B57\uFF09\uFF1A
${f.original.trim()}`);
  return lines.join("\n");
}
function composePrompt(f) {
  const lines = [];
  if (f.goal.trim() !== "") lines.push(`\u3010\u4EFB\u52A1\u76EE\u6807\u3011${f.goal.trim()}`);
  if (f.deliverable.trim() !== "") lines.push(`\u3010\u9884\u671F\u4EA4\u4ED8\u7269\u3011${f.deliverable.trim()}`);
  if (f.dueAt.trim() !== "") {
    const phrase = f.duePhrase.trim() !== "" ? `\uFF08\u539F\u6587\uFF1A${f.duePhrase.trim()}\uFF09` : "";
    lines.push(`\u3010\u622A\u6B62\u65F6\u95F4\u3011${f.dueAt.trim()}${phrase}`);
  }
  if (f.constraints.trim() !== "") lines.push(`\u3010\u7EA6\u675F\u4E0E\u6CE8\u610F\u4E8B\u9879\u3011${f.constraints.trim()}`);
  if (f.background.trim() !== "") lines.push(`\u3010\u80CC\u666F\u3011${f.background.trim()}`);
  if (f.notes.trim() !== "") lines.push(`\u3010\u5907\u6CE8\u3011${f.notes.trim()}`);
  const head = lines.join("\n");
  if (f.original.trim() === "") return head;
  const tail = `\u3010\u539F\u59CB\u9700\u6C42\uFF08\u9010\u5B57\uFF0C\u672A\u6539\u5199\uFF09\u3011
${f.original.trim()}`;
  return head === "" ? tail : `${head}

${tail}`;
}
function buildTaskPayload(fields) {
  return {
    title: titleOfDraft(fields.goal),
    description: composeDescription(fields),
    prompt: composePrompt(fields)
  };
}
function draftEdited(recognized, current2) {
  if (recognized === null) return false;
  const keys = ["goal", "background", "deliverable", "dueAt", "constraints", "notes"];
  for (const k of keys) {
    if (String(recognized[k] ?? "").trim() !== String(current2[k] ?? "").trim()) return true;
  }
  if ((recognized.projectId ?? null) !== (current2.projectId ?? null)) return true;
  if (recognized.recurrenceTimeMissing !== current2.recurrenceTimeMissing) return true;
  const a = recognized.recurrence;
  const b = current2.recurrence;
  if (a === null !== (b === null)) return true;
  if (a !== null && b !== null) {
    if (a.frequency !== b.frequency || a.hour !== b.hour || a.minute !== b.minute) return true;
    if (JSON.stringify(a.weekdays ?? []) !== JSON.stringify(b.weekdays ?? [])) return true;
    if ((a.dayOfMonth ?? 0) !== (b.dayOfMonth ?? 0)) return true;
  }
  return false;
}
function liveNeeds(needs, fields) {
  return needs.filter((n) => {
    switch (n.key) {
      case "goal":
        return fields.goal.trim() === "";
      case "deliverable":
        return fields.deliverable.trim() === "";
      case "dueAt":
        return fields.dueAt.trim() === "";
      case "recurrence":
        return fields.recurrenceTimeMissing || fields.recurrence !== null && !isValidRecurrenceRule(fields.recurrence);
      default:
        return false;
    }
  });
}

// src/workstation/personal-workspace/src/client/newtask.tsx
var import_jsx_runtime4 = require("react/jsx-runtime");
var CSS_NEWTASK = String.raw`
.dnt-root{display:flex;flex-direction:column;gap:12px;padding:12px 14px 18px;font:var(--dsw-font-xxs-12,12px);color:var(--dsw-alias-label-primary,#e8e8ec);user-select:none;}
.dnt-h{font:var(--dsw-font-s-strong-14,600 14px);margin:0;color:var(--dsw-alias-label-primary,#e8e8ec);}
.dnt-k{font:var(--dsw-font-xxxs-strong-11,600 11px);letter-spacing:.04em;color:var(--dsw-alias-label-tertiary,#9a9aa5);}
.dnt-line{display:flex;gap:8px;align-items:center;}
.dnt-in{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.35));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.05)) 50%,transparent);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-12,12px);padding:7px 10px;width:100%;box-sizing:border-box;outline:none;}
.dnt-in:focus{border-color:rgba(120,150,255,.6);}
.dnt-in::placeholder{color:var(--dsw-alias-label-dimmed,#7c7c88);}
.dnt-in[aria-invalid="true"]{border-color:rgba(235,90,90,.75);background:color-mix(in srgb,rgba(235,90,90,.10) 60%,transparent);}
.dnt-origin{display:flex;align-items:center;gap:8px;flex-wrap:wrap;border:1px solid rgba(120,150,255,.35);border-radius:8px;background:color-mix(in srgb,rgba(120,150,255,.10) 60%,transparent);padding:6px 9px;}
.dnt-origin-k{font:var(--dsw-font-xxxs-strong-11,600 11px);color:var(--dsw-alias-label-secondary,#c8c8d0);}
.dnt-origin-t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-primary,#e8e8ec);}
.dnt-origin-x{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.35));border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxxs-11,11px);padding:2px 8px;cursor:pointer;}
.dnt-req{margin-left:6px;padding:1px 6px;border-radius:999px;border:1px solid rgba(235,90,90,.45);color:#eb5a5a;font:var(--dsw-font-xxs-12,12px);}
.dnt-go[data-dnt-invalid="1"]:not(:disabled){border-color:rgba(235,90,90,.55);color:#f0a0a0;}
.dnt-go{border:1px solid rgba(120,150,255,.55);border-radius:8px;background:rgba(120,150,255,.14);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-strong-12,600 12px);padding:6px 16px;cursor:pointer;flex:none;}
.dnt-go:hover{background:rgba(120,150,255,.22);}
.dnt-go:disabled{opacity:.55;cursor:default;}
.dnt-chip{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:20px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxxs-11,11px);padding:2px 10px;cursor:pointer;}
.dnt-chip:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 60%,transparent);}
.dnt-card{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 40%,transparent);padding:8px 10px;display:flex;flex-direction:column;gap:5px;}
.dnt-pair{display:flex;gap:8px;align-items:baseline;}
.dnt-plabel{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);width:74px;flex:none;}
.dnt-pvalue{color:var(--dsw-alias-label-secondary,#c8c8d0);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.dnt-pvalue b{color:var(--dsw-alias-label-primary,#e8e8ec);font-weight:600;}
.dnt-select{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:6px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.05)) 60%,transparent);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-12,12px);padding:2px 6px;}
.dnt-adv summary{cursor:pointer;color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);}
.dnt-adv[open] summary{margin-bottom:6px;}
.dnt-advrow{display:flex;gap:8px;align-items:center;margin-bottom:6px;flex-wrap:wrap;}
.dnt-note{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);line-height:1.55;border-left:2px solid rgba(120,150,255,.4);padding:2px 0 2px 8px;}
.dnt-ok{color:var(--dsw-alias-label-primary,#e8e8ec);border:1px solid rgba(55,200,113,.45);background:rgba(55,200,113,.1);border-radius:8px;padding:7px 10px;font:var(--dsw-font-xxs-12,12px);line-height:1.55;}
.dnt-warn{border:1px solid rgba(240,180,60,.5);background:rgba(240,180,60,.1);border-radius:8px;padding:7px 10px;font:var(--dsw-font-xxs-12,12px);line-height:1.55;color:var(--dsw-alias-label-primary,#e8e8ec);}
.dnt-err{border:1px solid rgba(235,90,90,.5);background:rgba(235,90,90,.1);border-radius:8px;padding:7px 10px;font:var(--dsw-font-xxs-12,12px);line-height:1.55;color:var(--dsw-alias-label-primary,#e8e8ec);}
.dnt-foot{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:2px;}
.dnt-link{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxs-12,12px);padding:2px 9px;cursor:pointer;}
.dnt-link:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 60%,transparent);}
/* ---- 2026-09-10「自然语言创建任务」新增：顶部大输入框 + 紧凑草稿确认区 ---- */
.dnt-hint{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);}
.dnt-topline{align-items:flex-start;gap:8px;}
.dnt-topline>textarea{flex:1;min-width:0;resize:vertical;line-height:1.6;font:var(--dsw-font-xxs-12,12px);}
.dnt-actions{display:flex;flex-direction:column;gap:6px;flex:none;align-items:stretch;}
.dnt-actions>button{white-space:nowrap;}
.dnt-draft{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 34%,transparent);padding:10px 12px;display:flex;flex-direction:column;gap:8px;}
.dnt-dhead{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font:var(--dsw-font-s-strong-14,600 14px);color:var(--dsw-alias-label-primary,#e8e8ec);}
.dnt-edited{border:1px solid rgba(120,150,255,.45);border-radius:999px;padding:1px 8px;font:var(--dsw-font-xxxs-11,11px);color:#a9c0ff;}
.dnt-field{display:flex;flex-direction:column;gap:3px;}
.dnt-field-row{flex-direction:row;align-items:center;gap:8px;flex-wrap:wrap;}
.dnt-flabel{font:var(--dsw-font-xxxs-strong-11,600 11px);letter-spacing:.04em;color:var(--dsw-alias-label-tertiary,#9a9aa5);}
.dnt-field textarea,.dnt-field input{resize:vertical;}
.dnt-needinput{border-color:rgba(235,140,60,.8);background:color-mix(in srgb,rgba(235,140,60,.10) 60%,transparent);}
.dnt-needline{display:flex;gap:6px;align-items:baseline;margin-top:-4px;}
.dnt-needtag{border:1px solid rgba(235,140,60,.6);border-radius:999px;padding:0 6px;color:#f0a860;font:var(--dsw-font-xxxs-11,11px);flex:none;}
.dnt-needreason{color:#f0b070;font:var(--dsw-font-xxxs-11,11px);line-height:1.5;}
.dnt-needul{margin:4px 0 0;padding-left:18px;line-height:1.6;}
.dnt-engine{display:flex;gap:8px;align-items:baseline;flex-wrap:wrap;border-left:2px solid rgba(120,150,255,.4);padding:2px 0 2px 8px;}
.dnt-engine b{color:var(--dsw-alias-label-primary,#e8e8ec);font-weight:600;}
.dnt-engine>span{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);}
.dnt-original pre,.dnt-pre{margin:4px 0 0;padding:6px 8px;border-radius:6px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.08)) 55%,transparent);color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxxs-11,11px);white-space:pre-wrap;word-break:break-word;max-height:160px;overflow:auto;}
.dnt-more{align-self:flex-start;border:1px dashed var(--dsw-alias-border-l2,rgba(128,128,128,.35));border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxxs-11,11px);padding:3px 10px;cursor:pointer;}
.dnt-more:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 60%,transparent);}
.dnt-advbox{display:flex;flex-direction:column;gap:2px;border-top:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.22));padding-top:8px;}
`;
var prefillListeners = /* @__PURE__ */ new Set();
var lastPrefill = "";
function subscribeStartPrefill(listener) {
  prefillListeners.add(listener);
  if (lastPrefill !== "") {
    try {
      listener(lastPrefill);
    } catch {
    }
  }
  return () => {
    prefillListeners.delete(listener);
  };
}
function pushStartPrefill(text) {
  lastPrefill = text;
  prefillListeners.forEach((fn) => {
    try {
      fn(text);
    } catch {
    }
  });
}
var sessionOriginListeners = /* @__PURE__ */ new Set();
var lastSessionOrigin = null;
function subscribeStartSession(listener) {
  sessionOriginListeners.add(listener);
  if (lastSessionOrigin !== null) {
    try {
      listener(lastSessionOrigin);
    } catch {
    }
  }
  return () => {
    sessionOriginListeners.delete(listener);
  };
}
function pushNewTaskSession(origin) {
  if (origin === null || typeof origin !== "object" || typeof origin.sessionId !== "string" || origin.sessionId === "") return;
  lastSessionOrigin = { sessionId: origin.sessionId, ...origin.title ? { title: origin.title } : {} };
  sessionOriginListeners.forEach((fn) => {
    try {
      fn(lastSessionOrigin);
    } catch {
    }
  });
}
function clearPendingSessionOrigin() {
  lastSessionOrigin = null;
  sessionOriginListeners.forEach((fn) => {
    try {
      fn(null);
    } catch {
    }
  });
}
var NEWTASK_PROJECT_EVENT = "dsh:newtask-preset-project";
var lastProjectPreset = null;
var projectPresetListeners = /* @__PURE__ */ new Set();
function consumeProjectPreset() {
  const id = lastProjectPreset;
  lastProjectPreset = null;
  return id;
}
function pushNewTaskProject(projectId) {
  lastProjectPreset = projectId;
  projectPresetListeners.forEach((fn) => {
    try {
      fn(projectId);
    } catch {
    }
  });
  try {
    if (typeof window !== "undefined" && typeof CustomEvent === "function") {
      window.dispatchEvent(new CustomEvent(NEWTASK_PROJECT_EVENT, { detail: projectId }));
    }
  } catch {
  }
}
var EXAMPLES = ["\u5E2E\u6211\u5199\u4E00\u4E2A Python \u811A\u672C", "\u8C03\u7814\u4E00\u4E0B M5Stack \u751F\u6001", "\u603B\u7ED3\u8FD9\u4EFD\u5B66\u4E60\u8D44\u6599", "\u68C0\u67E5\u4E00\u4E0B\u5DE5\u4F5C\u533A"];
async function copyText(text) {
  try {
    if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
  }
  return false;
}
var client = new TaskBoardClient();
var AI_UNAVAILABLE_NOTE = "\u672C\u673A\u6CA1\u6709\u53EF\u7528\u7684\u300C\u4E00\u6B21\u6027\u6A21\u578B\u8C03\u7528\u300D\u80FD\u529B\uFF1A\u5BA2\u6237\u7AEF\u63D2\u4EF6\u53EA\u80FD\u901A\u8FC7\u4F1A\u8BDD\u4F7F\u7528\u6A21\u578B\uFF0C\u800C\u8BC6\u522B\u9636\u6BB5\u6309\u8981\u6C42**\u4E0D\u521B\u5EFA\u4F1A\u8BDD** \u2192 \u672C\u6B21\u8BC6\u522B\u672A\u4F7F\u7528 AI\u3002";
function NewTaskTab(props = {}) {
  const aiRecognize = props.aiRecognize;
  const inputRef = (0, import_react4.useRef)(null);
  const [text, setText] = (0, import_react4.useState)("");
  const [phase, setPhase] = (0, import_react4.useState)("idle");
  const [recognition, setRecognition] = (0, import_react4.useState)(null);
  const [fields, setFields] = (0, import_react4.useState)(null);
  const [recognizedFields, setRecognizedFields] = (0, import_react4.useState)(null);
  const [showMore, setShowMore] = (0, import_react4.useState)(false);
  const [attempted, setAttempted] = (0, import_react4.useState)(false);
  const [agentSel, setAgentSel] = (0, import_react4.useState)(null);
  const [permSel, setPermSel] = (0, import_react4.useState)(null);
  const [workspaceSel, setWorkspaceSel] = (0, import_react4.useState)(null);
  const [projectSel, setProjectSel] = (0, import_react4.useState)(null);
  const projectTouchedRef = (0, import_react4.useRef)(false);
  const [busy, setBusy] = (0, import_react4.useState)(false);
  const [outcome, setOutcome] = (0, import_react4.useState)(null);
  const [copied, setCopied] = (0, import_react4.useState)(false);
  const [pendingOrigin, setPendingOrigin] = (0, import_react4.useState)(null);
  (0, import_react4.useEffect)(() => subscribeStartSession((origin) => {
    setPendingOrigin(origin);
  }), []);
  const projects = useProjects();
  const wsCat = useWorkspaceCatalog();
  const resetDraft = () => {
    setPhase("idle");
    setRecognition(null);
    setFields(null);
    setRecognizedFields(null);
    setShowMore(false);
  };
  (0, import_react4.useEffect)(() => subscribeStartPrefill((next) => {
    setText(next);
    setAgentSel(null);
    setPermSel(null);
    setWorkspaceSel(null);
    setOutcome(null);
    setCopied(false);
    setAttempted(false);
    resetDraft();
  }), []);
  (0, import_react4.useEffect)(() => {
    const preset = consumeProjectPreset();
    if (preset !== null) {
      setProjectSel(preset);
      projectTouchedRef.current = true;
    }
    const onProject = (e) => {
      const id = e.detail ?? null;
      setProjectSel(id);
      projectTouchedRef.current = true;
      setOutcome(null);
    };
    const offLocal = (() => {
      projectPresetListeners.add(onProject);
      return () => projectPresetListeners.delete(onProject);
    })();
    if (typeof window !== "undefined" && window.addEventListener) {
      window.addEventListener(NEWTASK_PROJECT_EVENT, onProject);
      return () => {
        offLocal();
        window.removeEventListener(NEWTASK_PROJECT_EVENT, onProject);
      };
    }
    return offLocal;
  }, []);
  const trimmed = text.trim();
  const agents = catalogAgents();
  const permissionGuess = trimmed !== "" ? guessPermission(trimmed) : null;
  const agent = agentSel ?? recommendAgentId(trimmed);
  const permission = permSel ?? (permissionGuess !== null ? permissionGuess.permission : null);
  const projectOptions = (0, import_react4.useMemo)(() => projects.map((p) => ({ id: p.id, name: p.name })), [projects]);
  const needs = (0, import_react4.useMemo)(
    () => recognition !== null && fields !== null ? liveNeeds(recognition.needs, fields) : [],
    [recognition, fields]
  );
  const needOf = (key) => needs.find((n) => n.key === key);
  const blocked = needs.length > 0;
  const payload = (0, import_react4.useMemo)(() => fields !== null ? buildTaskPayload(fields) : null, [fields]);
  const edited = fields !== null && recognizedFields !== null ? draftEdited(recognizedFields, fields) : false;
  const recurrenceRule = fields !== null ? fields.recurrence : null;
  const cron = recurrenceRule !== null ? ruleToCron(recurrenceRule) : null;
  const permLabel = {
    "read-only": "\u53EA\u8BFB\uFF08read-only\uFF09",
    "workspace-write": "\u5DE5\u4F5C\u533A\u53EF\u5199\uFF08workspace-write\uFF09",
    "danger-full-access": "\u5371\u9669\uFF08danger-full-access\uFF09"
  };
  const WEEK = ["\u4E00", "\u4E8C", "\u4E09", "\u56DB", "\u4E94", "\u516D", "\u65E5"];
  const HOURS = Array.from({ length: 24 }, (_, i) => i);
  const MINUTES = Array.from({ length: 60 }, (_, i) => i);
  const patchField = (key, value) => {
    setFields((prev) => prev === null ? prev : { ...prev, [key]: value });
    setOutcome(null);
  };
  const focusTarget = () => {
    try {
      inputRef.current?.focus();
    } catch {
    }
  };
  const recognize = async () => {
    setAttempted(true);
    if (trimmed === "") {
      setOutcome({ kind: "error", message: NEED_REASON.goal });
      focusTarget();
      return;
    }
    setPhase("recognizing");
    setOutcome(null);
    setCopied(false);
    const rules = recognizeByRules(trimmed, { projects: projectOptions });
    let result = rules;
    if (typeof aiRecognize === "function") {
      try {
        const raw = await aiRecognize(trimmed);
        const grounded = groundAiDraft(raw ?? {}, trimmed, { projects: projectOptions });
        result = {
          fields: grounded.fields,
          // 「需要补充」由**接地后的**字段重算：模型没提到 = 不因为模型一句话就逼用户填表。
          needs: rules.needs,
          notes: [...grounded.notes, ...rules.notes],
          engine: "ai",
          engineDetail: "AI \u8BC6\u522B\uFF08\u6A21\u578B\u7531\u5BBF\u4E3B\u63D0\u4F9B\uFF09"
        };
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        result = { ...rules, aiUnavailableReason: `AI \u8BC6\u522B\u8C03\u7528\u5931\u8D25\uFF08${message}\uFF09\u2192 ${ENGINE_DETAIL_AI_UNAVAILABLE}` };
      }
    } else {
      result = { ...rules, aiUnavailableReason: AI_UNAVAILABLE_NOTE };
    }
    setRecognition(result);
    setFields(result.fields);
    setRecognizedFields(result.fields);
    if (!projectTouchedRef.current) setProjectSel(result.fields.projectId);
    setPhase("ready");
  };
  const attachOrigin = (taskId) => {
    const o = pendingOrigin;
    if (o !== null) {
      try {
        personalTasksStore.markOrigin(taskId, { sessionId: o.sessionId, ...o.title ? { title: o.title } : {}, at: Date.now() });
      } catch {
      }
    }
    setPendingOrigin(null);
    clearPendingSessionOrigin();
  };
  const createTask = async (start) => {
    setAttempted(true);
    if (fields === null) {
      setOutcome({ kind: "error", message: "\u8BF7\u5148\u70B9\u300C\u8BC6\u522B\u4EFB\u52A1\u300D\u751F\u6210\u8349\u7A3F\uFF08\u8BC6\u522B\u9636\u6BB5\u4E0D\u4F1A\u521B\u5EFA\u4F1A\u8BDD\uFF09\u3002" });
      return;
    }
    if (blocked) {
      setOutcome({ kind: "error", message: `\u8BF7\u5148\u8865\u9F50\u9AD8\u4EAE\u9879\uFF1A${needs.map((n) => n.reason).join("\uFF1B")}` });
      return;
    }
    const built = buildTaskPayload(fields);
    if (built.title.trim() === "") {
      setOutcome({ kind: "error", message: NEED_REASON.goal });
      return;
    }
    if (recurrenceRule !== null && cron === null) {
      setOutcome({ kind: "error", message: NEED_REASON.recurrence });
      return;
    }
    setBusy(true);
    setOutcome(null);
    setCopied(false);
    try {
      const snapshot = await client.state();
      if (!snapshot || snapshot.error) throw new Error(snapshot?.error ?? "\u4EFB\u52A1\u677F\u670D\u52A1\u8FD4\u56DE\u5F02\u5E38");
      const sessionDefault = snapshot.sessionDefaultPermission ?? "read-only";
      const effective = permission ?? "workspace-write";
      const created = await client.create({
        title: built.title,
        description: built.description,
        prompt: built.prompt,
        mode: agent ?? void 0,
        permission: effective,
        ...cron !== null ? { schedule: { enabled: true, cron } } : {},
        ...workspaceSel !== null && workspaceSel.length > 0 ? { workspaceId: workspaceSel } : {}
      });
      const row = latestCreated(created.tasks);
      if (row === void 0) {
        throw new Error("\u4EFB\u52A1\u5DF2\u8BF7\u6C42\u4F46\u5BBF\u4E3B\u672A\u8FD4\u56DE\u4EFB\u52A1\u884C\uFF0C\u8BF7\u5230\u5B98\u65B9\u4EFB\u52A1\u677F\u67E5\u770B\u6216\u91CD\u8BD5\u3002");
      }
      attachOrigin(row.id);
      let extras = null;
      try {
        taskExtrasStore.save({
          taskId: row.id,
          original: fields.original,
          notes: fields.notes,
          deliverable: fields.deliverable,
          constraints: fields.constraints,
          background: fields.background,
          dueAt: fields.dueAt,
          duePhrase: fields.duePhrase,
          engine: recognition?.engine ?? "rules",
          engineDetail: recognition?.engineDetail ?? ENGINE_DETAIL_RULES,
          recognizedAt: Date.now()
        });
        extras = taskExtrasStore.get(row.id) ?? null;
      } catch {
        extras = null;
      }
      let relationNote = null;
      if (projectSel !== null) {
        try {
          projectRegistry.assignTask(row.id, projectSel);
        } catch (error) {
          const msg = error instanceof Error ? error.message : String(error);
          relationNote = `\u9879\u76EE\u5F52\u5C5E\u672A\u80FD\u5199\u5165\uFF08\u4EFB\u52A1\u672C\u8EAB\u5DF2\u521B\u5EFA\uFF09\uFF1A${msg}`;
        }
      }
      if (cron !== null) personalTasksStore.markArmed(row.id, Date.now());
      if (!start) {
        setOutcome({ kind: "created", task: row, projectId: projectSel, relationNote, extras, recurring: cron !== null });
        return;
      }
      if (exceedsSessionDefault(effective, sessionDefault)) {
        setOutcome({ kind: "need-confirm", task: row, permission: effective, projectId: projectSel, relationNote });
        return;
      }
      const afterRun = await client.run(row.id);
      const ranRow = afterRun.tasks.find((t) => t.id === row.id) ?? row;
      const lastExec = ranRow.executions.length > 0 ? ranRow.executions[ranRow.executions.length - 1] : void 0;
      setOutcome({ kind: "launched", task: ranRow, projectId: projectSel, relationNote, extras, executionSessionId: lastExec?.sessionId ?? null });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setOutcome({ kind: "error", message });
    } finally {
      setBusy(false);
    }
  };
  const fallbackGoOfficial = async () => {
    const ok = await copyText(fields !== null ? fields.original : trimmed);
    setCopied(ok);
  };
  const needLine = (key) => {
    const need = needOf(key);
    if (need === void 0) return null;
    return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-needline", "data-dnt-need": key, children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-needtag", children: "\u9700\u8981\u8865\u5145" }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-needreason", "data-dnt-need-reason": key, children: need.reason })
    ] });
  };
  const fieldClass = (key) => needOf(key) !== void 0 ? "dnt-in dnt-needinput" : "dnt-in";
  return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-root", "data-dsh-plugin": "dsh-personal-workspace", "data-e4-panel": "1", children: [
    /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-h", children: [
      "\u4F60\u60F3\u8BA9 Harness \u505A\u4EC0\u4E48\uFF1F",
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-req", "data-dnt-required": "1", children: "\u5FC5\u586B" }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-hint", style: { marginLeft: 8 }, children: "\u7528\u81EA\u7136\u8BED\u8A00\u628A\u9700\u6C42\u8BB2\u6E05\u695A\u5C31\u884C\uFF1B\u70B9\u300C\u8BC6\u522B\u4EFB\u52A1\u300D\u540E\u5148\u751F\u6210\u8349\u7A3F\uFF0C\u786E\u8BA4\u65E0\u8BEF\u518D\u521B\u5EFA\u3002" })
    ] }),
    pendingOrigin !== null ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-origin", "data-dnt-origin": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-origin-k", children: "\u6765\u6E90\u4F1A\u8BDD" }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-origin-t", title: pendingOrigin.title ?? pendingOrigin.sessionId, children: pendingOrigin.title ?? pendingOrigin.sessionId }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-note", style: { borderLeft: "none", padding: 0 }, children: "\u4EC5\u4F5C\u4E3A\u6765\u6E90\u5F15\u7528\u767B\u8BB0\uFF08\u4E0D\u590D\u5236\u4F1A\u8BDD\u5185\u5BB9\u3001\u672A\u505A\u81EA\u52A8\u8BC6\u522B\uFF09\uFF1B\u4EFB\u52A1\u6B63\u6587 = \u4F60\u5728\u4E0B\u9762\u5199\u7684\u5185\u5BB9\u3002" }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        "button",
        {
          type: "button",
          className: "dnt-origin-x",
          "data-dnt-origin-clear": "1",
          onClick: () => {
            setPendingOrigin(null);
            clearPendingSessionOrigin();
          },
          children: "\u53D6\u6D88\u5F15\u7528"
        }
      )
    ] }) : null,
    /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-line dnt-topline", children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        "textarea",
        {
          ref: inputRef,
          className: fieldClass("goal"),
          "data-dnt-target": "1",
          "data-dnt-field": "original",
          rows: 3,
          value: text,
          placeholder: "\u50CF\u804A\u5929\u4E00\u6837\u628A\u9700\u6C42\u8BB2\u5B8C\uFF0C\u4F8B\u5982\uFF1A\u4E0B\u5468\u4E09\u524D\u5E2E\u6211\u6574\u7406\u4E00\u4EFD\u56E2\u961F\u5468\u4F1A\u7684\u8BAE\u9898\u6E05\u5355\uFF0C\u5E76\u7ED9\u51FA\u4E00\u4EFD\u53EF\u76F4\u63A5\u53D1\u9001\u7684\u4F1A\u8BAE\u9080\u8BF7\u3002",
          onChange: (e) => {
            setText(e.target.value);
            setOutcome(null);
            if (phase === "ready") resetDraft();
          },
          onKeyDown: (e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              if (phase === "ready") void createTask(true);
              else void recognize();
            }
          },
          "aria-label": "\u81EA\u7136\u8BED\u8A00\u4EFB\u52A1\u63CF\u8FF0",
          "aria-required": "true",
          "aria-invalid": attempted && trimmed === "" ? "true" : "false",
          "aria-describedby": "dnt-reason",
          required: true
        }
      ),
      phase === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-actions", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
          "button",
          {
            type: "button",
            className: "dnt-go",
            "data-dnt-create-run": "1",
            "data-dnt-submit": "1",
            "data-dnt-invalid": blocked ? "1" : "0",
            title: blocked ? needs.map((n) => n.reason).join("\uFF1B") : "\u521B\u5EFA\u771F\u5B9E\u4EFB\u52A1\uFF0C\u5E76\u8BA9\u5BBF\u4E3B\u5EFA\u7ACB\u6267\u884C\u4F1A\u8BDD\u540E\u5F00\u59CB\u6267\u884C",
            onClick: () => void createTask(true),
            disabled: busy || blocked,
            children: busy ? "\u521B\u5EFA\u4E2D\u2026" : "\u521B\u5EFA\u5E76\u5F00\u59CB"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
          "button",
          {
            type: "button",
            className: "dnt-link",
            "data-dnt-create-only": "1",
            title: blocked ? needs.map((n) => n.reason).join("\uFF1B") : "\u53EA\u521B\u5EFA\u771F\u5B9E\u4EFB\u52A1\u4E0E\u5B57\u6BB5\uFF0C\u4E0D\u542F\u52A8\u4EFB\u4F55\u4F1A\u8BDD",
            onClick: () => void createTask(false),
            disabled: busy || blocked,
            children: "\u4EC5\u521B\u5EFA\u4EFB\u52A1"
          }
        )
      ] }) : /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        "button",
        {
          type: "button",
          className: "dnt-go",
          "data-dnt-recognize": "1",
          "data-dnt-submit": "1",
          "data-dnt-invalid": attempted && trimmed === "" ? "1" : "0",
          onClick: () => void recognize(),
          disabled: busy || phase === "recognizing",
          children: phase === "recognizing" ? "\u8BC6\u522B\u4E2D\u2026" : "\u8BC6\u522B\u4EFB\u52A1"
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-line", style: { flexWrap: "wrap" }, children: [
      EXAMPLES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        "button",
        {
          type: "button",
          className: "dnt-chip",
          onClick: () => {
            setText(c);
            resetDraft();
            setOutcome(null);
          },
          children: c
        },
        c
      )),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-note", style: { borderLeft: "none", padding: 0 }, children: "\u793A\u4F8B\u53EA\u586B\u5165\u8F93\u5165\u6846\uFF0C\u4E0D\u4F1A\u81EA\u52A8\u8BC6\u522B\uFF0C\u4E5F\u4E0D\u521B\u5EFA\u4EFB\u4F55\u4E1C\u897F\u3002" })
    ] }),
    attempted && trimmed === "" ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-err", id: "dnt-reason", role: "alert", "data-dnt-blocked": "1", children: [
      "\u8FD8\u4E0D\u80FD\u8BC6\u522B\uFF1A",
      NEED_REASON.goal
    ] }) : null,
    phase === "ready" && blocked ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-warn", "data-dnt-blocked": "1", "data-dnt-needlist": "1", role: "alert", children: [
      "\u8FD8\u6709\u9700\u8981\u8865\u5145\u7684\u4FE1\u606F\uFF0C\u8865\u9F50\u540E\u300C\u521B\u5EFA\u5E76\u5F00\u59CB / \u4EC5\u521B\u5EFA\u4EFB\u52A1\u300D\u624D\u53EF\u7528\uFF1A",
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("ul", { className: "dnt-needul", children: needs.map((n) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("li", { children: n.reason }, n.key)) })
    ] }) : null,
    recognition !== null ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-engine", "data-dnt-engine": recognition.engine, "data-dnt-engine-line": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-k", children: "\u8BC6\u522B\u5F15\u64CE" }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("b", { children: recognition.engine === "ai" ? "AI \u8BC6\u522B" : "\u672C\u5730\u89C4\u5219\u8BC6\u522B" }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { children: recognition.engineDetail }),
      recognition.aiUnavailableReason !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-note", "data-dnt-ai-unavailable": "1", style: { borderLeft: "none", padding: 0 }, children: recognition.aiUnavailableReason }) : null,
      recognition.notes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("details", { className: "dnt-adv", "data-dnt-recog-notes": "1", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("summary", { children: [
          "\u8BC6\u522B\u4F9D\u636E\uFF08",
          recognition.notes.length,
          "\uFF09"
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("ul", { className: "dnt-needul", children: recognition.notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("li", { children: n }, n)) })
      ] }) : null
    ] }) : null,
    fields !== null ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-draft", "data-dnt-draft": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-dhead", children: [
        "\u4EFB\u52A1\u8349\u7A3F",
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-hint", children: "\uFF08\u8BC6\u522B\u7ED3\u679C\u53EF\u4EFB\u610F\u4FEE\u6539\uFF1B\u53EA\u6709\u300C\u4EFB\u52A1\u76EE\u6807\u300D\u5FC5\u586B\uFF09" }),
        edited ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-edited", "data-dnt-edited": "1", children: "\u5DF2\u6309\u4F60\u7684\u7F16\u8F91\u91CD\u5EFA\u6267\u884C\u6307\u4EE4" }) : null
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("label", { className: "dnt-flabel", htmlFor: "dnt-f-goal", children: "\u4EFB\u52A1\u76EE\u6807" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
          "textarea",
          {
            id: "dnt-f-goal",
            className: fieldClass("goal"),
            "data-dnt-field": "goal",
            rows: 2,
            value: fields.goal,
            onChange: (e) => patchField("goal", e.target.value)
          }
        )
      ] }),
      needLine("goal"),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("label", { className: "dnt-flabel", htmlFor: "dnt-f-background", children: "\u80CC\u666F\u4E0E\u8865\u5145\u8BF4\u660E" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
          "textarea",
          {
            id: "dnt-f-background",
            className: "dnt-in",
            "data-dnt-field": "background",
            rows: 2,
            value: fields.background,
            placeholder: "\u539F\u6587\u6CA1\u63D0\u5230\u5C31\u7559\u7A7A\uFF08\u4E0D\u505A\u4EFB\u4F55\u8865\u5199\uFF09",
            onChange: (e) => patchField("background", e.target.value)
          }
        )
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("label", { className: "dnt-flabel", htmlFor: "dnt-f-deliverable", children: "\u9884\u671F\u4EA4\u4ED8\u7269" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
          "textarea",
          {
            id: "dnt-f-deliverable",
            className: fieldClass("deliverable"),
            "data-dnt-field": "deliverable",
            rows: 2,
            value: fields.deliverable,
            placeholder: "\u5B8C\u6210\u540E\u4F60\u8981\u62FF\u5230\u4EC0\u4E48\uFF08\u539F\u6587\u6CA1\u63D0\u5230\u5C31\u7559\u7A7A\uFF09",
            onChange: (e) => patchField("deliverable", e.target.value)
          }
        )
      ] }),
      needLine("deliverable"),
      fields.dueAt !== "" || needOf("dueAt") !== void 0 || showMore ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_jsx_runtime4.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-field", children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("label", { className: "dnt-flabel", htmlFor: "dnt-f-due", children: "\u622A\u6B62\u65F6\u95F4" }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
            "input",
            {
              id: "dnt-f-due",
              className: fieldClass("dueAt"),
              "data-dnt-field": "dueAt",
              value: fields.dueAt,
              placeholder: "YYYY-MM-DD \u6216 YYYY-MM-DD HH:mm\uFF08\u7559\u7A7A = \u6CA1\u6709\u622A\u6B62\u65F6\u95F4\uFF09",
              onChange: (e) => patchField("dueAt", e.target.value)
            }
          ),
          fields.duePhrase !== "" ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("span", { className: "dnt-hint", "data-dnt-due-phrase": "1", children: [
            "\u539F\u6587\u8BF4\u6CD5\uFF1A",
            fields.duePhrase
          ] }) : null
        ] }),
        needLine("dueAt")
      ] }) : null,
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-field dnt-field-row", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-flabel", children: "\u9879\u76EE\u5F52\u5C5E" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
          ProjectSelect,
          {
            value: projectSel,
            onChange: (id) => {
              setProjectSel(id);
              projectTouchedRef.current = true;
              setOutcome(null);
            },
            hint: projectSel === null && fields.projectId !== null ? "\u8BC6\u522B\u547D\u4E2D\u539F\u6587\u91CC\u7684\u9879\u76EE\u540D" : void 0
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-hint", "data-dnt-project-note": "1", children: projectSel === null ? "\u6682\u4E0D\u5F52\u7C7B\uFF08\u53EF\u968F\u65F6\u6539\uFF09" : "\u521B\u5EFA\u540E\u5199\u5165\u771F\u5B9E\u9879\u76EE\u5173\u7CFB\u5C42" })
      ] }),
      recurrenceRule !== null || needOf("recurrence") !== void 0 || showMore ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-field", "data-tk-kind": "1", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-flabel", children: "\u91CD\u590D\u89C4\u5219" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-line", style: { flexWrap: "wrap" }, children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
            "button",
            {
              type: "button",
              className: "dnt-chip",
              style: recurrenceRule === null ? { borderColor: "rgba(120,150,255,.6)", color: "#e8e8ec" } : void 0,
              onClick: () => patchField("recurrence", null),
              children: "\u5355\u6B21\uFF08\u4E0D\u91CD\u590D\uFF09"
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
            "button",
            {
              type: "button",
              className: "dnt-chip",
              style: recurrenceRule !== null ? { borderColor: "rgba(120,150,255,.6)", color: "#e8e8ec" } : void 0,
              onClick: () => patchField("recurrence", recurrenceRule ?? { frequency: "daily", hour: 20, minute: 0 }),
              children: "\u5B9A\u671F\uFF08\u5230\u70B9\u6267\u884C\uFF09"
            }
          ),
          recurrenceRule !== null ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_jsx_runtime4.Fragment, { children: ["daily", "weekly", "monthly"].map((f) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
            "button",
            {
              type: "button",
              className: "dnt-chip",
              style: recurrenceRule.frequency === f ? { borderColor: "rgba(120,150,255,.6)", color: "#e8e8ec" } : void 0,
              onClick: () => patchField("recurrence", {
                frequency: f,
                ...f === "weekly" ? { weekdays: recurrenceRule.frequency === "weekly" ? recurrenceRule.weekdays ?? [1] : [1] } : {},
                ...f === "monthly" ? { dayOfMonth: recurrenceRule.frequency === "monthly" ? recurrenceRule.dayOfMonth ?? 1 : 1 } : {},
                hour: recurrenceRule.hour,
                minute: recurrenceRule.minute
              }),
              children: f === "daily" ? "\u6BCF\u5929" : f === "weekly" ? "\u6BCF\u5468" : "\u6BCF\u6708"
            },
            f
          )) }) : null
        ] }),
        recurrenceRule !== null ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { "data-tk-recurring-editor": "1", children: [
          recurrenceRule.frequency === "weekly" ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-line", style: { flexWrap: "wrap" }, children: [
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-k", children: "\u661F\u671F\u51E0" }),
            WEEK.map((name, i) => {
              const day = i + 1;
              const active = (recurrenceRule.weekdays ?? []).includes(day);
              return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(
                "button",
                {
                  type: "button",
                  className: "dnt-chip",
                  style: active ? { borderColor: "rgba(120,150,255,.6)", color: "#e8e8ec" } : void 0,
                  onClick: () => {
                    const days = [...recurrenceRule.weekdays ?? []];
                    const at = days.indexOf(day);
                    if (at >= 0) days.splice(at, 1);
                    else days.push(day);
                    patchField("recurrence", { ...recurrenceRule, weekdays: days.sort((a, b) => a - b) });
                  },
                  children: [
                    "\u5468",
                    name
                  ]
                },
                day
              );
            })
          ] }) : null,
          recurrenceRule.frequency === "monthly" ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-line", children: [
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-k", children: "\u6BCF\u6708" }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
              "select",
              {
                className: "dnt-select",
                value: recurrenceRule.dayOfMonth ?? 1,
                onChange: (e) => patchField("recurrence", { ...recurrenceRule, dayOfMonth: Number(e.target.value) }),
                "aria-label": "\u6BCF\u6708\u51E0\u53F7",
                children: Array.from({ length: 31 }, (_, i) => i + 1).map((d) => /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("option", { value: d, children: [
                  d,
                  " \u53F7"
                ] }, d))
              }
            )
          ] }) : null,
          /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-line", children: [
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-k", children: "\u65F6\u95F4" }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
              "select",
              {
                className: "dnt-select",
                value: recurrenceRule.hour,
                onChange: (e) => patchField("recurrence", { ...recurrenceRule, hour: Number(e.target.value) }),
                "aria-label": "\u5C0F\u65F6",
                children: HOURS.map((h) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("option", { value: h, children: (h < 10 ? "0" : "") + h }, h))
              }
            ),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { children: ":" }),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
              "select",
              {
                className: "dnt-select",
                value: recurrenceRule.minute,
                onChange: (e) => patchField("recurrence", { ...recurrenceRule, minute: Number(e.target.value) }),
                "aria-label": "\u5206\u949F",
                children: MINUTES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("option", { value: m, children: (m < 10 ? "0" : "") + m }, m))
              }
            ),
            /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("span", { className: "dnt-hint", children: [
              "\u6267\u884C\u8BA1\u5212\uFF1A",
              describeRule(recurrenceRule) ?? "\u89C4\u5219\u4E0D\u5B8C\u6574"
            ] })
          ] }),
          fields.recurrenceTimeMissing ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-hint", "data-dnt-recur-time-missing": "1", children: "\u539F\u6587\u53EA\u8BF4\u4E86\u300C\u91CD\u590D\u300D\uFF0C\u6CA1\u7ED9\u65F6\u95F4 \u2014\u2014 \u4E0A\u9762\u7684\u65F6\u95F4\u9ED8\u8BA4\u503C**\u5C1A\u672A\u786E\u8BA4**\uFF0C\u8BF7\u9009\u4E00\u4E2A\u6216\u6539\u6210\u5355\u6B21\u3002" }) : null,
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-hint", children: "\u5B9A\u671F\u4EFB\u52A1\u4EC5\u5728 DeepSeek Harness \u8FD0\u884C\u65F6\u6267\u884C\uFF1B\u5173\u7740\u5E94\u7528\u65F6\u9519\u8FC7\u7684\u5230\u70B9\u4E0D\u4F1A\u8865\u8DD1\uFF08\u53EF\u5728\u4EFB\u52A1\u677F\u8865\u6267\u884C\uFF09\u3002" })
        ] }) : null
      ] }) : null,
      needLine("recurrence"),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("label", { className: "dnt-flabel", htmlFor: "dnt-f-constraints", children: "\u7EA6\u675F\u4E0E\u6CE8\u610F\u4E8B\u9879" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
          "textarea",
          {
            id: "dnt-f-constraints",
            className: "dnt-in",
            "data-dnt-field": "constraints",
            rows: 2,
            value: fields.constraints,
            placeholder: "\u9884\u7B97 / \u683C\u5F0F / \u5FC5\u987B\u6216\u7981\u6B62\u7684\u505A\u6CD5\uFF08\u539F\u6587\u6CA1\u63D0\u5230\u5C31\u7559\u7A7A\uFF09",
            onChange: (e) => patchField("constraints", e.target.value)
          }
        )
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-field", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("label", { className: "dnt-flabel", htmlFor: "dnt-f-notes", children: "\u5907\u6CE8" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
          "textarea",
          {
            id: "dnt-f-notes",
            className: "dnt-in",
            "data-dnt-field": "notes",
            rows: 2,
            value: fields.notes,
            placeholder: "\u539F\u6587\u91CC\u6CA1\u5F52\u5165\u4E0A\u9762\u5B57\u6BB5\u7684\u53E5\u5B50\uFF08\u9010\u5B57\u4FDD\u7559\uFF0C\u4E0D\u505A\u751F\u6210\u5F0F\u603B\u7ED3\uFF09",
            onChange: (e) => patchField("notes", e.target.value)
          }
        )
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("details", { className: "dnt-adv dnt-original", "data-dnt-original": "1", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("summary", { children: "\u539F\u59CB\u9700\u6C42\uFF08\u9010\u5B57\u4FDD\u7559\uFF0C\u53EF\u5C55\u5F00\u6838\u5BF9\uFF09" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("pre", { className: "dnt-pre", "data-dnt-original-text": "1", children: fields.original })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        "button",
        {
          type: "button",
          className: "dnt-more",
          "data-dnt-more": "1",
          onClick: () => setShowMore((v) => !v),
          children: showMore ? "\u6536\u8D77\u8865\u5145\u9009\u9879" : "\u8865\u5145\u9009\u9879\uFF08\u622A\u6B62\u65F6\u95F4 / \u91CD\u590D\u89C4\u5219 / Agent / \u6743\u9650 / \u5DE5\u4F5C\u533A\uFF09"
        }
      ),
      showMore ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-advbox", "data-dnt-more-box": "1", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-advrow", children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("label", { className: "dnt-plabel", htmlFor: "dnt-agent", children: "Agent" }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("select", { id: "dnt-agent", className: "dnt-select", value: agent ?? "", onChange: (e) => setAgentSel(e.target.value), children: agents.map((a) => /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("option", { value: a.id, children: [
            a.name,
            "\uFF08",
            a.zh,
            "\uFF09"
          ] }, a.id)) }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-hint", children: "\u4EFB\u52A1\u7531\u5BBF\u4E3B\u5728\u72EC\u7ACB\u4F1A\u8BDD\u4E2D\u6267\u884C\uFF1B\u6A21\u578B\u6CBF\u7528\u5BBF\u4E3B\u9ED8\u8BA4\u3002" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-advrow", children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("label", { className: "dnt-plabel", htmlFor: "dnt-perm", children: "\u6743\u9650\u6863" }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
            "select",
            {
              id: "dnt-perm",
              className: "dnt-select",
              value: permission ?? "workspace-write",
              onChange: (e) => setPermSel(e.target.value),
              children: TASK_PERMISSIONS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("option", { value: id, children: permLabel[id] }, id))
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-hint", children: "\u9AD8\u4E8E\u5BBF\u4E3B\u4F1A\u8BDD\u9ED8\u8BA4\u7684\u6863\u4F4D\uFF0C\u5BBF\u4E3B\u4F1A\u62D2\u7EDD\u81EA\u52A8\u6267\u884C\uFF0C\u9700\u5230\u5B98\u65B9\u4EFB\u52A1\u677F\u4EBA\u5DE5\u300C\u786E\u8BA4\u6743\u9650\u7ED1\u5B9A\u300D\u3002" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-advrow", children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(WorkspaceSelect, { value: workspaceSel, onChange: setWorkspaceSel, items: wsCat.items, ready: wsCat.ready, probing: wsCat.probing }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-hint", children: workspaceSel === null ? "\u672A\u9009 = \u6CBF\u7528\u5BBF\u4E3B\u9ED8\u8BA4\u5DE5\u4F5C\u533A" : "\u4EFB\u52A1\u5C06\u5728\u8BE5\u5DE5\u4F5C\u533A\u6267\u884C" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-advrow", children: [
          /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-plabel", children: "\u5EFA\u8BAE Agent / \u6743\u9650" }),
          /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("span", { className: "dnt-hint", children: [
            agents.find((a) => a.id === agent)?.name ?? agent ?? "\u2014",
            " \xB7",
            " ",
            permission !== null ? permLabel[permission] : "\u6309\u4F1A\u8BDD\u9ED8\u8BA4",
            permissionGuess !== null ? "\uFF08\u7531\u76EE\u6807\u6587\u672C\u63A8\u65AD\uFF0C\u53EF\u6539\uFF09" : ""
          ] })
        ] })
      ] }) : null,
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("details", { className: "dnt-adv", "data-dnt-payload": "1", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("summary", { children: "\u5C06\u5199\u5165\u4EFB\u52A1\u7684\u5185\u5BB9\uFF08\u63CF\u8FF0 / \u6267\u884C\u6307\u4EE4\uFF09" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dnt-pre", "data-dnt-payload-description": "1", children: payload !== null ? payload.description : "" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dnt-k", style: { marginTop: 6 }, children: "\u6267\u884C\u6307\u4EE4\uFF08\u552F\u4E00\u4F1A\u53D1\u7ED9\u6267\u884C\u4F1A\u8BDD\u7684\u6B63\u6587\uFF09" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dnt-pre", "data-dnt-payload-prompt": "1", children: payload !== null ? payload.prompt : "" }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-hint", children: "\u5B98\u65B9\u4EFB\u52A1\u6CA1\u6709\u300C\u622A\u6B62\u65F6\u95F4/\u4EA4\u4ED8\u7269/\u7EA6\u675F/\u5907\u6CE8\u300D\u5B57\u6BB5\uFF0C\u5B83\u4EEC\u4F1A\u5199\u8FDB\u4E0A\u9762\u8FD9\u6BB5\u63CF\u8FF0\u4E0E\u6267\u884C\u6307\u4EE4\uFF1B\u9010\u5B57\u539F\u6587\u4E5F\u9644\u5728\u6267\u884C\u6307\u4EE4\u91CC\u3002" })
      ] })
    ] }) : null,
    outcome !== null ? outcome.kind === "launched" ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-ok", "data-e4-result": "launched", "data-dnt-result": "launched", children: [
      "\u5DF2\u521B\u5EFA\u5E76\u8BF7\u6C42\u6267\u884C \u2713 \u5B98\u65B9 Host \u5DF2\u63A5\u53D7\u6267\u884C\u8BF7\u6C42\uFF0C\u5E76\u5728\u72EC\u7ACB\u4F1A\u8BDD\u4E2D\u542F\u52A8\u672C\u4EFB\u52A1\u3002",
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { style: { marginTop: 4 }, children: [
        "\u4EFB\u52A1\uFF1A",
        outcome.task.title
      ] }),
      outcome.projectId !== null ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { style: { marginTop: 4 }, children: [
        "\u5DF2\u5F52\u5165\u9879\u76EE\uFF1A",
        projectNameOf(outcome.projectId, projects)
      ] }) : null,
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { style: { marginTop: 4 }, "data-dnt-exec-session": "1", children: [
        "\u6267\u884C\u4F1A\u8BDD\uFF1A",
        outcome.executionSessionId !== null ? outcome.executionSessionId : "\u5BBF\u4E3B\u5C1A\u672A\u56DE\u5199 sessionId\uFF08\u7A0D\u540E\u53EF\u5728\u4EFB\u52A1\u8BE6\u60C5\u770B\u5230\uFF09"
      ] }),
      outcome.relationNote !== null ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dnt-warn", style: { marginTop: 4 }, children: outcome.relationNote }) : null
    ] }) : outcome.kind === "created" ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-ok", "data-e4-result": "created", "data-dnt-result": "created", children: [
      "\u5DF2\u521B\u5EFA\u4EFB\u52A1 \u2713\uFF08\u672A\u542F\u52A8\u6267\u884C\u3001\u672A\u521B\u5EFA\u4F1A\u8BDD",
      outcome.recurring ? "\uFF1B\u5DF2\u6309\u5468\u671F\u89C4\u5219\u6302\u53F7\uFF0C\u5230\u70B9\u7531\u5BBF\u4E3B\u6267\u884C" : "",
      "\uFF09",
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { style: { marginTop: 4 }, children: [
        "\u4EFB\u52A1\uFF1A",
        outcome.task.title
      ] }),
      outcome.projectId !== null ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { style: { marginTop: 4 }, children: [
        "\u5DF2\u5F52\u5165\u9879\u76EE\uFF1A",
        projectNameOf(outcome.projectId, projects)
      ] }) : null,
      outcome.relationNote !== null ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dnt-warn", style: { marginTop: 4 }, children: outcome.relationNote }) : null
    ] }) : outcome.kind === "need-confirm" ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-warn", "data-e4-result": "need-confirm", "data-dnt-result": "need-confirm", children: [
      "\u4EFB\u52A1\u5DF2\u521B\u5EFA\uFF0C\u4F46\u6743\u9650\u6863\uFF08",
      permLabel[outcome.permission],
      "\uFF09\u9AD8\u4E8E\u4F1A\u8BDD\u9ED8\u8BA4 \u2014\u2014 \u5BBF\u4E3B\u62D2\u7EDD\u81EA\u52A8\u6267\u884C\uFF0C\u9700\u4EBA\u5DE5\u786E\u8BA4\u3002 \u8BF7\u5230\u5B98\u65B9\u4EFB\u52A1\u770B\u677F\u627E\u5230\u4EFB\u52A1\u300C",
      outcome.task.title,
      "\u300D\u2192 \u70B9\u300C\u786E\u8BA4\u6743\u9650\u7ED1\u5B9A\u300D\uFF0C\u786E\u8BA4\u540E\u5373\u81EA\u52A8\u5F00\u59CB\u6267\u884C\u3002",
      outcome.projectId !== null ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { style: { marginTop: 4 }, children: [
        "\u5DF2\u5F52\u5165\u9879\u76EE\uFF1A",
        projectNameOf(outcome.projectId, projects)
      ] }) : null,
      outcome.relationNote !== null ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { style: { marginTop: 4 }, children: outcome.relationNote }) : null
    ] }) : /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-err", "data-e4-result": "error", "data-dnt-result": "error", children: [
      outcome.message,
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("div", { className: "dnt-foot", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("button", { type: "button", className: "dnt-link", onClick: () => void fallbackGoOfficial(), children: copied ? "\u5DF2\u590D\u5236 \u2713" : "\u590D\u5236\u539F\u59CB\u9700\u6C42\uFF0C\u524D\u5F80\u5B98\u65B9 New Task" }) })
    ] }) : null,
    outcome !== null && (outcome.kind === "created" || outcome.kind === "launched") && outcome.extras !== null ? /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-note", "data-dnt-extras": "1", children: [
      "\u672C\u673A\u8865\u5145\u5B57\u6BB5\u5DF2\u4FDD\u5B58\uFF08Personal \u5C42\uFF0C\u5237\u65B0\u540E\u4ECD\u5728\uFF09\uFF1A\u539F\u59CB\u9700\u6C42 ",
      outcome.extras.original.length,
      " \u5B57 \xB7 \u5907\u6CE8",
      " ",
      outcome.extras.notes !== "" ? "\u6709" : "\u65E0",
      " \xB7 \u4EA4\u4ED8\u7269 ",
      outcome.extras.deliverable !== "" ? "\u6709" : "\u65E0",
      " \xB7 \u622A\u6B62",
      " ",
      outcome.extras.dueAt !== "" ? outcome.extras.dueAt : "\u672A\u8BBE",
      " \xB7 \u8BC6\u522B\u5F15\u64CE",
      " ",
      outcome.extras.engine === "ai" ? "AI" : "\u672C\u5730\u89C4\u5219",
      "\u3002"
    ] }) : null,
    /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "dnt-foot", style: { marginTop: 4 }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-k", children: "\u5B98\u65B9\u517C\u5BB9" }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("button", { type: "button", className: "dnt-link", onClick: () => void fallbackGoOfficial(), children: copied ? "\u5DF2\u590D\u5236 \u2713" : "\u7528\u5B98\u65B9 New Task \u6253\u5F00" }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "dnt-note", style: { borderLeft: "none", padding: 0 }, children: "\uFF08\u590D\u5236\u539F\u59CB\u9700\u6C42\u540E\uFF0C\u7ECF\u300C\u8FD4\u56DE\u5B98\u65B9\u300D\u2192 \u5B98\u65B9 \uFF0B\u65B0\u4EFB\u52A1 \u7C98\u8D34\u4F7F\u7528\uFF09" })
    ] })
  ] });
}
function latestCreated(rows) {
  if (rows.length === 0) return void 0;
  let best = rows[0];
  for (const r of rows) {
    if ((r.createdAt ?? 0) > (best.createdAt ?? 0)) best = r;
  }
  return best;
}
function projectNameOf(projectId, projects) {
  return projects.find((p) => p.id === projectId)?.name ?? projectId;
}

// src/workstation/personal-workspace/src/client/project-center.tsx
var import_react6 = require("react");

// src/workstation/personal-workspace/src/client/project-detail.tsx
var import_react5 = require("react");

// src/workstation/personal-workspace/src/client/relations.ts
function unassignedOf(rows, projectOf) {
  return rows.filter((r) => projectOf(r.id) === void 0);
}
function unassignedCounts(tasks, sessions, lookup) {
  const t = unassignedOf(tasks, (id) => lookup.projectOfTask(id)).length;
  const s = unassignedOf(sessions, (id) => lookup.projectOfSession(id)).length;
  return { tasks: t, sessions: s, all: t + s };
}
function rebindTargets(projects, currentProjectId) {
  return projects.filter((p) => p.id !== currentProjectId);
}
function rebindTask(writer, taskId, targetProjectId, projectName) {
  if (typeof taskId !== "string" || taskId === "") return { ok: false, message: "\u4EFB\u52A1 id \u4E3A\u7A7A\uFF0C\u65E0\u6CD5\u6539\u6302\uFF08\u672A\u505A\u4EFB\u4F55\u53D8\u66F4\uFF09\u3002" };
  try {
    if (targetProjectId === null) {
      writer.unassignTask(taskId);
      return { ok: true, message: "\u5DF2\u79FB\u51FA\u9879\u76EE\uFF08\u4EFB\u52A1\u56DE\u5230\u300C\u672A\u5F52\u5165\u9879\u76EE\u300D\uFF0C\u5B98\u65B9\u4EFB\u52A1\u672C\u8EAB\u4E0E\u72B6\u6001\u4E0D\u53D8\uFF09\u3002" };
    }
    writer.assignTask(taskId, targetProjectId);
    const name = projectName?.(targetProjectId) ?? targetProjectId;
    return { ok: true, message: `\u5DF2\u5F52\u5165\u300C${name}\u300D\uFF08\u4EC5 Personal \u5173\u7CFB\u5C42\uFF0C\u672A\u6539\u52A8\u5B98\u65B9\u4EFB\u52A1\u6570\u636E\uFF09\u3002` };
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    return { ok: false, message: `\u6539\u6302\u5931\u8D25\uFF1A${reason}\uFF08\u5173\u7CFB\u672A\u53D8\u66F4\uFF09` };
  }
}
function rebindSession(writer, sessionId, targetProjectId, projectName) {
  if (typeof sessionId !== "string" || sessionId === "") return { ok: false, message: "\u4F1A\u8BDD id \u4E3A\u7A7A\uFF0C\u65E0\u6CD5\u6539\u6302\uFF08\u672A\u505A\u4EFB\u4F55\u53D8\u66F4\uFF09\u3002" };
  try {
    if (targetProjectId === null) {
      writer.unassignSession(sessionId);
      return { ok: true, message: "\u5DF2\u79FB\u51FA\u9879\u76EE\uFF08\u4F1A\u8BDD\u56DE\u5230\u300C\u672A\u5F52\u5165\u9879\u76EE\u300D\uFF1B\u5B98\u65B9\u4F1A\u8BDD\u4E0E\u5176\u5F52\u6863\u72B6\u6001\u4E0D\u53D8\uFF09\u3002" };
    }
    writer.assignSession(sessionId, targetProjectId);
    const name = projectName?.(targetProjectId) ?? targetProjectId;
    return { ok: true, message: `\u4F1A\u8BDD\u5DF2\u5F52\u5165\u300C${name}\u300D\uFF08\u4EC5 Personal \u5173\u7CFB\u5C42\uFF0C\u5B98\u65B9\u4F1A\u8BDD\u4E0D\u53D7\u5F71\u54CD\uFF09\u3002` };
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    return { ok: false, message: `\u6539\u6302\u5931\u8D25\uFF1A${reason}\uFF08\u5173\u7CFB\u672A\u53D8\u66F4\uFF09` };
  }
}
var RELATION_NOTE = "\u9879\u76EE\u5F52\u5C5E\u662F Personal \u5173\u7CFB\u5C42\uFF1A\u6539\u6302/\u89E3\u9664\u53EA\u5F71\u54CD\u4E2A\u4EBA\u89C6\u56FE\uFF0C\u4E0D\u4F1A\u4FEE\u6539\u5B98\u65B9\u4F1A\u8BDD\u6216\u4EFB\u52A1\u7684\u6570\u636E\u4E0E\u72B6\u6001\u3002";

// src/workstation/personal-workspace/src/client/taskui.ts
function scheduleChipOf(schedule) {
  if (schedule === void 0 || schedule === null) return null;
  const detail = isAnalyzableCron(schedule.cron) ? describeCron(schedule.cron) : null;
  if (schedule.enabled) return { label: "\u5B9A\u671F", tone: "on", detail };
  return { label: "\u5B9A\u671F(\u5DF2\u505C\u7528)", tone: "off", detail };
}
function recurringEnabledOf(schedule) {
  return schedule !== void 0 && schedule !== null && schedule.enabled === true;
}
function execResultView(execution) {
  if (execution === void 0 || execution === null) return null;
  if (execution.endedAt === void 0) return { kind: "running", text: "\u6267\u884C\u4E2D" };
  switch (execution.result) {
    case "succeeded":
      return { kind: "succeeded", text: "\u6210\u529F" };
    case "failed":
      return { kind: "failed", text: "\u5931\u8D25" };
    case "cancelled":
      return { kind: "cancelled", text: "\u5DF2\u53D6\u6D88" };
    default:
      return { kind: "unknown", text: "\u5DF2\u7ED3\u675F" };
  }
}
function latestExecutionOf(executions) {
  if (!Array.isArray(executions) || executions.length === 0) return void 0;
  return executions[executions.length - 1];
}
function execHistorySummary(executions) {
  const list = Array.isArray(executions) ? executions : [];
  const out = { total: list.length, succeeded: 0, failed: 0, cancelled: 0, running: 0 };
  for (const e of list) {
    if (e.endedAt === void 0) {
      out.running += 1;
    } else if (e.result === "succeeded") {
      out.succeeded += 1;
    } else if (e.result === "failed") {
      out.failed += 1;
    } else if (e.result === "cancelled") {
      out.cancelled += 1;
    }
  }
  return out;
}
function executionHistoryRows(executions) {
  if (!Array.isArray(executions)) return [];
  return [...executions].sort((a, b) => b.startedAt - a.startedAt);
}

// src/workstation/personal-workspace/src/client/project-detail.tsx
var import_jsx_runtime5 = require("react/jsx-runtime");
var CSS_PROJECT_DETAIL = String.raw`
.dpd-root{display:flex;flex-direction:column;gap:12px;padding:12px 14px 18px;font:var(--dsw-font-xxs-12,12px);color:var(--dsw-alias-label-primary,#e8e8ec);user-select:none;}
.dpd-h{font:var(--dsw-font-s-strong-14,600 14px);margin:0;color:var(--dsw-alias-label-primary,#e8e8ec);display:flex;align-items:center;gap:8px;}
.dpd-back{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.28));border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxs-12,12px);padding:1px 8px;cursor:pointer;flex:none;}
.dpd-back:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 60%,transparent);}
.dpd-k{font:var(--dsw-font-xxxs-strong-11,600 11px);letter-spacing:.04em;color:var(--dsw-alias-label-tertiary,#9a9aa5);}
.dpd-sec{display:flex;flex-direction:column;gap:6px;}
.dpd-empty{color:var(--dsw-alias-label-dimmed,#8f8f99);font:var(--dsw-font-xxs-12,12px);padding:2px 0;}
.dpd-note{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);line-height:1.55;border-left:2px solid rgba(120,150,255,.4);padding:2px 0 2px 8px;}
.dpd-row{display:flex;align-items:center;gap:8px;padding:6px 8px;border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.28));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 45%,transparent);width:100%;text-align:left;color:inherit;font:inherit;cursor:pointer;}
.dpd-row:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.1)) 60%,transparent);}
.dpd-t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.dpd-sub{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);white-space:nowrap;}
.dpd-dot{width:7px;height:7px;border-radius:50%;flex:none;background:#37c871;}
.dpd-dot.idle{background:var(--dsw-alias-label-dimmed,#6a6a74);}
.dpd-dot.red{background:#e85a5a;}
.dpd-tag{display:inline-flex;align-items:center;font:var(--dsw-font-xxxs-11,11px);border-radius:4px;padding:1px 5px;white-space:nowrap;flex:none;}
.dpd-tag.run{background:rgba(120,150,255,.14);color:#8aa4ff;}
.dpd-tag.done{background:rgba(55,200,113,.12);color:#37c871;}
.dpd-tag.fail{background:rgba(235,90,90,.14);color:#ff8a8a;}
.dpd-tag.arch{color:var(--dsw-alias-label-tertiary,#9a9aa5);border:1px dashed var(--dsw-alias-border-l2,rgba(128,128,128,.3));}
.dpd-tag.perm{background:rgba(240,180,60,.14);color:#e8b64c;border:1px solid rgba(240,180,60,.35);}
.dpd-act{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.28));border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxs-12,12px);padding:2px 9px;cursor:pointer;flex:none;}
.dpd-act:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 60%,transparent);}
.dpd-line{display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
.dpd-in{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.35));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.05)) 50%,transparent);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-12,12px);padding:6px 10px;width:100%;box-sizing:border-box;outline:none;}
.dpd-in:focus{border-color:rgba(120,150,255,.6);}
.dpd-go{border:1px solid rgba(120,150,255,.55);border-radius:8px;background:rgba(120,150,255,.14);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-strong-12,600 12px);padding:5px 14px;cursor:pointer;flex:none;}
.dpd-go:hover{background:rgba(120,150,255,.22);}
.dpd-go:disabled{opacity:.55;cursor:default;}
.dpd-card{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 40%,transparent);padding:8px 10px;display:flex;flex-direction:column;gap:5px;}
.dpd-glyph{color:var(--dsw-alias-label-secondary,#c8c8d0);flex:none;}
.dpd-meta{display:flex;flex-wrap:wrap;gap:6px;margin-top:2px;}
.dpd-count{font:var(--dsw-font-xxxs-11,11px);color:var(--dsw-alias-label-tertiary,#9a9aa5);border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));border-radius:4px;padding:0 6px;}
.dpd-count b{color:var(--dsw-alias-label-secondary,#c8c8d0);font-weight:600;}
.dpd-actrow{display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
.dpd-sel{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:6px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.05)) 60%,transparent);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-12,12px);padding:2px 6px;max-width:240px;}
.dpd-msg{border:1px solid rgba(55,200,113,.4);background:rgba(55,200,113,.08);border-radius:8px;padding:6px 10px;font:var(--dsw-font-xxs-12,12px);line-height:1.5;color:var(--dsw-alias-label-primary,#e8e8ec);}
.dpd-msg.err{border-color:rgba(235,90,90,.45);background:rgba(235,90,90,.08);}
`;
var detailProjectId = null;
var projectSubs = /* @__PURE__ */ new Set();
function notifyProject() {
  projectSubs.forEach((f) => {
    try {
      f();
    } catch {
    }
  });
}
function setDetailProjectId(id) {
  detailProjectId = id;
  notifyProject();
}
function useDetailProjectId() {
  return (0, import_react5.useSyncExternalStore)(
    (f) => {
      projectSubs.add(f);
      return () => {
        projectSubs.delete(f);
      };
    },
    () => detailProjectId,
    () => null
  );
}
var EMPTY_DETAIL = { ready: false, rows: [], archivedIds: [] };
var detailSessions = EMPTY_DETAIL;
var sessionSubs = /* @__PURE__ */ new Set();
function notifySessions() {
  sessionSubs.forEach((f) => {
    try {
      f();
    } catch {
    }
  });
}
function drowOf(r, archived) {
  const id = String(r.id ?? "");
  if (!id) return null;
  const title = sessionDisplayName(r);
  return { id, title, running: r.running === true, updatedAt: r.updatedAt, archived: archived.has(id) };
}
function bindProjectDetailSessions(getSessions2, getArchived) {
  const offs = [];
  let lastArchived = [];
  try {
    const svc = getSessions2();
    const source = svc?.list ?? null;
    if (source && typeof source.getSnapshot === "function" && typeof source.subscribe === "function") {
      const apply2 = () => {
        try {
          const archived = archivedSet(lastArchived);
          const rows = sessionRowsOf(source.getSnapshot()).map((r) => drowOf(r, archived)).filter((x) => x !== null).sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0));
          detailSessions = { ready: true, rows, archivedIds: [...lastArchived] };
          notifySessions();
        } catch {
        }
      };
      apply2();
      const off = source.subscribe(apply2);
      if (typeof off === "function") offs.push(off);
    } else {
      detailSessions = { ...detailSessions, ready: false, rows: [] };
      notifySessions();
    }
  } catch {
    detailSessions = { ...detailSessions, ready: false, rows: [] };
    notifySessions();
  }
  const pushArchived = () => {
    try {
      const next = getArchived();
      if (next === lastArchived) return;
      lastArchived = next;
      const archived = archivedSet(next);
      detailSessions = {
        ...detailSessions,
        rows: detailSessions.rows.map((r) => ({ ...r, archived: archived.has(r.id) })),
        archivedIds: [...next]
      };
      notifySessions();
    } catch {
    }
  };
  pushArchived();
  return () => {
    for (const off of offs) {
      try {
        off();
      } catch {
      }
    }
  };
}
function refreshProjectDetailArchived(getArchived) {
  try {
    const next = getArchived();
    const archived = archivedSet(next);
    detailSessions = { ...detailSessions, rows: detailSessions.rows.map((r) => ({ ...r, archived: archived.has(r.id) })), archivedIds: [...next] };
    notifySessions();
  } catch {
  }
}
function useProjectDetailSessions() {
  return (0, import_react5.useSyncExternalStore)(
    (f) => {
      sessionSubs.add(f);
      return () => {
        sessionSubs.delete(f);
      };
    },
    () => detailSessions,
    () => EMPTY_DETAIL
  );
}
function archivedSet(ids) {
  return new Set(ids ?? []);
}
var openSessionFn2 = null;
var openTaskBoardFn2 = null;
var openProjectCenterFn = null;
var openNewTaskPanelFn = null;
var openWorkspaceCenterFn = null;
function bindProjectDetailActions(actions) {
  openSessionFn2 = actions.openSession;
  openTaskBoardFn2 = actions.openTaskBoard;
  openProjectCenterFn = actions.openProjectCenter;
  openNewTaskPanelFn = actions.openNewTaskPanel;
  openWorkspaceCenterFn = actions.openWorkspaceCenter;
  return () => {
    openSessionFn2 = null;
    openTaskBoardFn2 = null;
    openProjectCenterFn = null;
    openNewTaskPanelFn = null;
    openWorkspaceCenterFn = null;
  };
}
var ago2 = (ts) => {
  if (!ts || !Number.isFinite(ts)) return "";
  const s = Math.max(1, Math.round((Date.now() - ts) / 1e3));
  if (s < 60) return s + " \u79D2\u524D";
  const m = Math.round(s / 60);
  if (m < 60) return m + " \u5206\u949F\u524D";
  const h = Math.round(m / 60);
  if (h < 24) return h + " \u5C0F\u65F6\u524D";
  return Math.round(h / 24) + " \u5929\u524D";
};
var statusLabel = {
  backlog: "\u5F85\u529E",
  todo: "\u5F85\u529E",
  running: "\u8FD0\u884C\u4E2D",
  done: "\u5B8C\u6210",
  failed: "\u5931\u8D25"
};
function ProjectDetailView() {
  const projectId = useDetailProjectId();
  const projects = useProjects();
  const project = projectId ? projects.find((p) => p.id === projectId) : void 0;
  const tasks = useHomeTaskState();
  const sessions = useProjectDetailSessions();
  const wsCat = useWorkspaceCatalog();
  const [convText, setConvText] = (0, import_react5.useState)("");
  const [convBusy, setConvBusy] = (0, import_react5.useState)(false);
  const [convMsg, setConvMsg] = (0, import_react5.useState)(null);
  const [linkTaskId, setLinkTaskId] = (0, import_react5.useState)("");
  const [linkSessionId, setLinkSessionId] = (0, import_react5.useState)("");
  const [linkWorkspaceId, setLinkWorkspaceId] = (0, import_react5.useState)("");
  const [linkMsg, setLinkMsg] = (0, import_react5.useState)(null);
  const archiveTruth = archiveTruthOf({ archivedSessionIds: tasks.archivedSessionIds, workspacesSource: tasks.workspacesSource });
  const projTasks = (0, import_react5.useMemo)(() => {
    if (!projectId) return [];
    return tasks.tasks.filter((p) => projectRegistry.projectOfTask(p.task.id) === projectId);
  }, [tasks.tasks, projectId]);
  const projSessions = (0, import_react5.useMemo)(() => {
    if (!projectId) return [];
    return sessions.rows.filter((s) => projectRegistry.projectOfSession(s.id) === projectId);
  }, [sessions.rows, projectId]);
  const projWorkspaceIds = projectId ? projectRegistry.workspacesOf(projectId) : [];
  const projWorkspaces = projWorkspaceIds.map((wid) => wsCat.items.find((w) => w.workspaceId === wid)).filter((w) => w !== void 0);
  const unassignedTasks = tasks.tasks.filter((p) => projectRegistry.projectOfTask(p.task.id) === void 0 && p.task.status !== "done" && !p.taskArchived);
  const unassignedSessions = sessions.rows.filter((s) => projectRegistry.projectOfSession(s.id) === void 0 && !s.archived);
  const unlinkedWorkspaces = wsCat.items.filter((w) => !projWorkspaceIds.includes(w.workspaceId));
  const activity = (0, import_react5.useMemo)(() => {
    const items = [];
    for (const p of projTasks) {
      items.push({ at: p.task.updatedAt, text: p.task.title, tag: statusLabel[p.task.status] ?? p.task.status, kind: "task" });
    }
    for (const s of projSessions) {
      items.push({ at: s.updatedAt ?? 0, text: s.title, tag: s.archived ? "\u5F52\u6863" : s.running ? "\u8FD0\u884C\u4E2D" : "\u4F1A\u8BDD", kind: "session" });
    }
    return items.filter((i) => i.at > 0).sort((a, b) => b.at - a.at).slice(0, 8);
  }, [projTasks, projSessions]);
  if (!projectId) {
    return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-root", "data-dsh-plugin": "dsh-personal-workspace", "data-dpd-empty": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", children: "\u5C1A\u672A\u6253\u5F00\u4EFB\u4F55\u9879\u76EE\u3002\u8BF7\u5230\u300C\u9879\u76EE\u300D\u9762\u677F\u9009\u62E9\u4E00\u4E2A\u9879\u76EE\u67E5\u770B\u8BE6\u60C5\u3002" }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-line", children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("button", { type: "button", className: "dpd-go", onClick: () => openProjectCenterFn?.(), children: "\u53BB\u9879\u76EE\u4E2D\u5FC3" }) })
    ] });
  }
  if (!project) {
    return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-root", "data-dsh-plugin": "dsh-personal-workspace", "data-dpd-gone": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", children: "\u8BE5\u9879\u76EE\u5DF2\u4E0D\u5B58\u5728\uFF08\u53EF\u80FD\u5DF2\u88AB\u5220\u9664\uFF09\u3002" }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-line", children: /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("button", { type: "button", className: "dpd-go", onClick: () => openProjectCenterFn?.(), children: "\u53BB\u9879\u76EE\u4E2D\u5FC3" }) })
    ] });
  }
  const runNewConversation = async () => {
    const t = convText.trim();
    if (!t) return;
    setConvBusy(true);
    setConvMsg(null);
    try {
      const res = await createConversationInProject(t, project.id);
      if (res.ok) {
        setConvText("");
        setConvMsg(res.message && res.message.length > 0 ? res.message : "\u5DF2\u5728\u8BE5\u9879\u76EE\u4E0B\u6253\u5F00\u65B0\u4F1A\u8BDD\u3002");
      } else {
        setConvMsg(res.message || "\u4F1A\u8BDD\u521B\u5EFA\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002");
      }
    } catch (e) {
      setConvMsg(e instanceof Error ? e.message : String(e));
    } finally {
      setConvBusy(false);
    }
  };
  const doLinkTask = () => {
    if (!linkTaskId || !projectId) return;
    try {
      projectRegistry.assignTask(linkTaskId, projectId);
      setLinkTaskId("");
      setLinkMsg("\u4EFB\u52A1\u5DF2\u5F52\u5165\u8BE5\u9879\u76EE\u3002");
    } catch (e) {
      setLinkMsg(e instanceof Error ? e.message : String(e));
    }
  };
  const doLinkSession = () => {
    if (!linkSessionId || !projectId) return;
    try {
      projectRegistry.assignSession(linkSessionId, projectId);
      setLinkSessionId("");
      setLinkMsg("\u4F1A\u8BDD\u5DF2\u5F52\u5165\u8BE5\u9879\u76EE\u3002");
    } catch (e) {
      setLinkMsg(e instanceof Error ? e.message : String(e));
    }
  };
  const doLinkWorkspace = () => {
    if (!linkWorkspaceId || !projectId) return;
    try {
      projectRegistry.linkWorkspace(projectId, linkWorkspaceId);
      setLinkWorkspaceId("");
      setLinkMsg("\u5DE5\u4F5C\u533A\u5DF2\u5173\u8054\u5230\u8BE5\u9879\u76EE\u3002");
    } catch (e) {
      setLinkMsg(e instanceof Error ? e.message : String(e));
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-root", "data-dsh-plugin": "dsh-personal-workspace", "data-dpd-detail": "1", "data-project-id": project.id, children: [
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-line", children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("button", { type: "button", className: "dpd-back", onClick: () => openProjectCenterFn?.(), title: "\u8FD4\u56DE\u9879\u76EE\u4E2D\u5FC3", children: "\u2039 \u9879\u76EE" }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("span", { className: "dpd-h", children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-glyph", children: project.glyph }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { children: project.name }),
        project.seed ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-tag arch", style: { borderStyle: "dashed" }, children: "\u5185\u7F6E" }) : null
      ] })
    ] }),
    project.description ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-note", style: { borderLeft: "none", paddingLeft: 0 }, children: project.description }) : null,
    archiveNoteOf(archiveTruth) !== "" ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-note", "data-dpd-archive-unknown": "1", style: { borderLeftColor: "rgba(235,170,90,.5)" }, children: archiveNoteOf(archiveTruth) }) : null,
    /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-note", "data-dpd-relation-note": "1", style: { borderLeftColor: "rgba(120,150,255,.4)" }, children: RELATION_NOTE }),
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-meta", children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("span", { className: "dpd-count", children: [
        "\u4EFB\u52A1 ",
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("b", { children: projTasks.length })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("span", { className: "dpd-count", children: [
        "\u4F1A\u8BDD ",
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("b", { children: projSessions.length })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("span", { className: "dpd-count", children: [
        "\u5DE5\u4F5C\u533A ",
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("b", { children: projWorkspaces.length })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("section", { className: "dpd-sec", "data-dpd-actions": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-k", children: "\u5F00\u59CB\u65B0\u4E1C\u897F" }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-actrow", children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
          "button",
          {
            type: "button",
            className: "dpd-go",
            onClick: () => {
              pushNewTaskProject(project.id);
              openNewTaskPanelFn?.();
            },
            "data-dpd-new-task": "1",
            children: "\uFF0B \u5728\u6B64\u9879\u76EE\u65B0\u5EFA\u4EFB\u52A1"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-sub", children: "\u6253\u5F00\u300C\u65B0\u4EFB\u52A1\u300D\u5E76\u5DF2\u9009\u4E2D\u8BE5\u9879\u76EE" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-card", "data-dpd-new-conv": "1", children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-sub", children: "\u5728\u8BE5\u9879\u76EE\u4E0B\u5F00\u59CB\u4E00\u6BB5\u65B0\u4F1A\u8BDD\uFF08\u5B98\u65B9\u94FE\u8DEF\uFF0C\u521B\u5EFA\u5373\u5F52\u5165\u9879\u76EE\uFF09" }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-line", children: [
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
            "input",
            {
              className: "dpd-in",
              placeholder: "\u7528\u4E00\u53E5\u8BDD\u544A\u8BC9\u5B83\u4F60\u60F3\u505A\u4EC0\u4E48\u2026",
              value: convText,
              onChange: (e) => setConvText(e.target.value),
              onKeyDown: (e) => {
                if (e.key === "Enter") void runNewConversation();
              },
              "aria-label": "\u8BE5\u9879\u76EE\u4E0B\u7684\u65B0\u4F1A\u8BDD\u76EE\u6807"
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("button", { type: "button", className: "dpd-go", onClick: () => void runNewConversation(), disabled: convBusy, children: convBusy ? "\u521B\u5EFA\u4E2D\u2026" : "\u5F00\u59CB" })
        ] }),
        convMsg ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: `dpd-msg${convMsg.startsWith("\u4F1A\u8BDD\u521B\u5EFA\u5931\u8D25") || convMsg.includes("\u5931\u8D25") ? " err" : ""}`, role: "status", children: convMsg }) : null
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("section", { className: "dpd-sec", "data-dpd-tasks": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-k", children: [
        "\u4EFB\u52A1 \xB7 ",
        projTasks.length
      ] }),
      tasks.ready && !tasks.hostReachable ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", children: "\u4EFB\u52A1\u677F\u5BBF\u4E3B\u4E0D\u53EF\u8FBE\uFF0C\u65E0\u6CD5\u8BFB\u53D6\u8BE5\u9879\u76EE\u7684\u4EFB\u52A1\u3002" }) : !tasks.ready ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", children: "\u6B63\u5728\u8BFB\u53D6\u4EFB\u52A1\u677F\u2026" }) : projTasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", children: "\u8BE5\u9879\u76EE\u8FD8\u6CA1\u6709\u4EFB\u52A1\u3002\u70B9\u4E0A\u65B9\u300C\u5728\u6B64\u9879\u76EE\u65B0\u5EFA\u4EFB\u52A1\u300D\uFF0C\u6216\u5728\u4EFB\u52A1\u677F\u4E0A\u628A\u4EFB\u52A1\u5F52\u5165\u8BE5\u9879\u76EE\u3002" }) : projTasks.slice(0, 20).map((p) => {
        const latestRun = latestExecutionOf(p.task.executions);
        const latestView = execResultView(latestRun);
        const runSessionId = latestRun?.sessionId;
        const origin = personalTasksStore.originOf(p.task.id);
        const refSessionId = runSessionId ?? origin?.sessionId;
        return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-row", children: [
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: `dpd-dot${p.task.status === "running" ? "" : p.task.attention !== null ? " red" : " idle"}` }),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-t", children: p.task.title }),
          p.attach?.archived || p.taskArchived ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-tag arch", children: "\u5F52\u6863" }) : null,
          p.attention?.kind === "confirm-permission" ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-tag perm", children: "\u9700\u786E\u8BA4\u6743\u9650" }) : null,
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-sub", children: statusLabel[p.task.status] ?? p.task.status }),
          latestView !== null ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
            "span",
            {
              className: `dpd-tag ${latestView.kind === "running" ? "run" : latestView.kind === "succeeded" ? "done" : latestView.kind === "failed" ? "fail" : "arch"}`,
              "data-dpd-task-result": "1",
              title: "\u6700\u8FD1\u4E00\u6B21\u6267\u884C\u7ED3\u679C\uFF08\u5B98\u65B9\u6267\u884C\u8BB0\u5F55\u6458\u8981\uFF1B\u5B8C\u6574\u5386\u53F2\u5728\u4EFB\u52A1\u677F\u8BE6\u60C5\uFF09",
              children: latestView.text
            }
          ) : null,
          origin !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-tag arch", "data-dpd-task-origin": "1", title: `\u7531\u4F1A\u8BDD\u300C${origin.title ?? "\u5B98\u65B9\u4F1A\u8BDD"}\u300D\u521B\u5EFA\uFF08\u5185\u5BB9\u4FDD\u7559\u5728\u5B98\u65B9\u4F1A\u8BDD\uFF09`, children: "\u6E90\u81EA\u4F1A\u8BDD" }) : null,
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-sub", children: ago2(p.task.updatedAt) }),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
            "span",
            {
              className: "dpd-act",
              role: "button",
              tabIndex: 0,
              "data-dpd-task-open": "1",
              onClick: (e) => {
                e.stopPropagation();
                openTaskBoardFn2?.(p.task.id);
              },
              onKeyDown: (e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  e.stopPropagation();
                  openTaskBoardFn2?.(p.task.id);
                }
              },
              children: "\u4EFB\u52A1\u677F"
            }
          ),
          refSessionId !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
            "span",
            {
              className: "dpd-act",
              role: "button",
              tabIndex: 0,
              "data-dpd-task-ref-session": "1",
              title: origin !== void 0 && runSessionId === void 0 ? "\u6253\u5F00\u521B\u5EFA\u8BE5\u4EFB\u52A1\u7684\u6765\u6E90\u4F1A\u8BDD" : "\u6253\u5F00\u6700\u8FD1\u4E00\u6B21\u6267\u884C\u6240\u5728\u7684\u5B98\u65B9\u4F1A\u8BDD",
              onClick: (e) => {
                e.stopPropagation();
                openSessionFn2?.(refSessionId);
              },
              onKeyDown: (e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  e.stopPropagation();
                  openSessionFn2?.(refSessionId);
                }
              },
              children: origin !== void 0 && runSessionId === void 0 ? "\u6765\u6E90" : "\u6267\u884C\u4F1A\u8BDD"
            }
          ) : null,
          /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(
            "select",
            {
              className: "dpd-sel",
              "data-dpd-task-rebind": "1",
              "aria-label": `\u628A\u4EFB\u52A1\u300C${p.task.title}\u300D\u6539\u6302\u5230\u5176\u4ED6\u9879\u76EE`,
              value: "",
              onClick: (e) => e.stopPropagation(),
              onChange: (e) => {
                const target = e.target.value;
                if (target === "") return;
                const r = rebindTask(projectRegistry, p.task.id, target, (pid) => projects.find((x) => x.id === pid)?.name);
                setLinkMsg(r.message);
              },
              children: [
                /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("option", { value: "", children: "\u6539\u6302\u5230\u2026" }),
                rebindTargets(projects, projectId).map((x) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("option", { value: x.id, children: [
                  x.glyph,
                  " ",
                  x.name
                ] }, x.id))
              ]
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
            "span",
            {
              className: "dpd-act",
              role: "button",
              tabIndex: 0,
              "data-dpd-task-unassign": "1",
              onClick: (e) => {
                e.stopPropagation();
                try {
                  projectRegistry.unassignTask(p.task.id);
                  setLinkMsg("\u4EFB\u52A1\u5DF2\u79FB\u51FA\u8BE5\u9879\u76EE\uFF08\u56DE\u5230\u672A\u5F52\u5165\uFF09\u3002");
                } catch (err) {
                  setLinkMsg(err instanceof Error ? err.message : String(err));
                }
              },
              onKeyDown: (e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  e.stopPropagation();
                  try {
                    projectRegistry.unassignTask(p.task.id);
                    setLinkMsg("\u4EFB\u52A1\u5DF2\u79FB\u51FA\u8BE5\u9879\u76EE\uFF08\u56DE\u5230\u672A\u5F52\u5165\uFF09\u3002");
                  } catch (err) {
                    setLinkMsg(err instanceof Error ? err.message : String(err));
                  }
                }
              },
              children: "\u79FB\u51FA"
            }
          )
        ] }, p.task.id);
      }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-card", "data-dpd-link-task": "1", children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-sub", children: "Link Existing Task\uFF1A\u628A\u4EFB\u52A1\u677F\u4E0A\u7684\u672A\u5F52\u5165\u4EFB\u52A1\u5173\u8054\u8FDB\u6765" }),
        unassignedTasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", children: "\u6CA1\u6709\u53EF\u5173\u8054\u7684\u672A\u5F52\u5165\u4EFB\u52A1\uFF08\u4EFB\u52A1\u677F\u5DF2\u7A7A\u6216\u90FD\u5DF2\u5F52\u5165\u9879\u76EE\uFF09\u3002" }) : /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-line", children: [
          /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("select", { className: "dpd-sel", value: linkTaskId, onChange: (e) => setLinkTaskId(e.target.value), "aria-label": "\u9009\u62E9\u8981\u5173\u8054\u7684\u4EFB\u52A1", children: [
            /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("option", { value: "", children: "\u9009\u62E9\u4EFB\u52A1\u2026" }),
            unassignedTasks.slice(0, 50).map((p) => /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("option", { value: p.task.id, children: p.task.title }, p.task.id))
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("button", { type: "button", className: "dpd-go", onClick: doLinkTask, disabled: !linkTaskId, children: "\u5173\u8054" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("section", { className: "dpd-sec", "data-dpd-conversations": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-k", children: [
        "\u4F1A\u8BDD \xB7 ",
        projSessions.length
      ] }),
      !sessions.ready ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", children: "\u4F1A\u8BDD\u6570\u636E\u6682\u4E0D\u53EF\u7528\uFF0C\u5237\u65B0\u91CD\u8BD5\u3002" }) : projSessions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", children: "\u8BE5\u9879\u76EE\u8FD8\u6CA1\u6709\u4F1A\u8BDD\u3002\u53EF\u70B9\u4E0A\u65B9\u300C\u5F00\u59CB\u65B0\u4F1A\u8BDD\u300D\uFF0C\u6216\u628A\u5DF2\u6709\u4F1A\u8BDD\u5173\u8054\u8FDB\u6765\u3002" }) : projSessions.slice(0, 20).map((s) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-row", children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: `dpd-dot${s.running ? "" : s.archived ? " idle" : " idle"}` }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-t", children: s.title }),
        s.archived ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-tag arch", children: "\u5DF2\u5F52\u6863" }) : null,
        s.running ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-sub", children: "\u8FD0\u884C\u4E2D" }) : null,
        s.updatedAt ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-sub", children: ago2(s.updatedAt) }) : null,
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
          "span",
          {
            className: "dpd-act",
            role: "button",
            tabIndex: 0,
            onClick: (e) => {
              e.stopPropagation();
              openSessionFn2?.(s.id);
            },
            onKeyDown: (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                e.stopPropagation();
                openSessionFn2?.(s.id);
              }
            },
            children: "\u6253\u5F00"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(
          "select",
          {
            className: "dpd-sel",
            "data-dpd-conv-rebind": "1",
            "aria-label": `\u628A\u4F1A\u8BDD\u300C${s.title}\u300D\u6539\u6302\u5230\u5176\u4ED6\u9879\u76EE`,
            value: "",
            onClick: (e) => e.stopPropagation(),
            onChange: (e) => {
              const target = e.target.value;
              if (target === "") return;
              const r = rebindSession(projectRegistry, s.id, target, (pid) => projects.find((x) => x.id === pid)?.name);
              setLinkMsg(r.message);
            },
            children: [
              /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("option", { value: "", children: "\u6539\u6302\u5230\u2026" }),
              rebindTargets(projects, projectId).map((x) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("option", { value: x.id, children: [
                x.glyph,
                " ",
                x.name
              ] }, x.id))
            ]
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
          "span",
          {
            className: "dpd-act",
            role: "button",
            tabIndex: 0,
            onClick: (e) => {
              e.stopPropagation();
              try {
                projectRegistry.unassignSession(s.id);
                setLinkMsg("\u4F1A\u8BDD\u5DF2\u79FB\u51FA\u8BE5\u9879\u76EE\u3002");
              } catch (err) {
                setLinkMsg(err instanceof Error ? err.message : String(err));
              }
            },
            onKeyDown: (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                e.stopPropagation();
                try {
                  projectRegistry.unassignSession(s.id);
                  setLinkMsg("\u4F1A\u8BDD\u5DF2\u79FB\u51FA\u8BE5\u9879\u76EE\u3002");
                } catch (err) {
                  setLinkMsg(err instanceof Error ? err.message : String(err));
                }
              }
            },
            children: "\u79FB\u51FA"
          }
        )
      ] }, s.id)),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-card", "data-dpd-link-conv": "1", children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-sub", children: "Link Existing Conversation\uFF1A\u628A\u5DF2\u6709\u4F1A\u8BDD\u5173\u8054\u8FDB\u8BE5\u9879\u76EE" }),
        unassignedSessions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", children: "\u6CA1\u6709\u53EF\u5173\u8054\u7684\u672A\u5F52\u5165\u4F1A\u8BDD\uFF08\u5B98\u65B9\u4F1A\u8BDD\u90FD\u5DF2\u5F52\u5165\u9879\u76EE\uFF0C\u6216\u6570\u636E\u672A\u5C31\u7EEA\uFF09\u3002" }) : /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-line", children: [
          /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("select", { className: "dpd-sel", value: linkSessionId, onChange: (e) => setLinkSessionId(e.target.value), "aria-label": "\u9009\u62E9\u8981\u5173\u8054\u7684\u4F1A\u8BDD", children: [
            /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("option", { value: "", children: "\u9009\u62E9\u4F1A\u8BDD\u2026" }),
            unassignedSessions.slice(0, 50).map((s) => /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("option", { value: s.id, children: s.title }, s.id))
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("button", { type: "button", className: "dpd-go", onClick: doLinkSession, disabled: !linkSessionId, children: "\u5173\u8054" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("section", { className: "dpd-sec", "data-dpd-workspaces": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-k", children: [
        "\u5DE5\u4F5C\u533A \xB7 ",
        projWorkspaces.length
      ] }),
      projWorkspaces.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", children: "\u8BE5\u9879\u76EE\u5C1A\u672A\u5173\u8054\u5DE5\u4F5C\u533A\u3002\u5173\u8054\u540E\u53EF\u5728\u300C\u5DE5\u4F5C\u533A\u300D\u9762\u677F\u67E5\u770B AI \u5728\u8FD9\u4E9B\u771F\u5B9E\u76EE\u5F55\u91CC\u5DE5\u4F5C\u3002" }) : projWorkspaces.map((w) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-row static", children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-dot idle" }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-t", children: w.title }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-sub", children: w.path }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-sub", children: w.sessionIds.length > 0 ? `${w.sessionIds.length} \u4F1A\u8BDD` : "0 \u4F1A\u8BDD" }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
          "span",
          {
            className: "dpd-act",
            role: "button",
            tabIndex: 0,
            "data-dpd-ws-center": "1",
            onClick: (e) => {
              e.stopPropagation();
              try {
                openWorkspaceCenterFn?.();
              } catch {
              }
            },
            onKeyDown: (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                e.stopPropagation();
                try {
                  openWorkspaceCenterFn?.();
                } catch {
                }
              }
            },
            children: "\u5DE5\u4F5C\u533A"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
          "span",
          {
            className: "dpd-act",
            role: "button",
            tabIndex: 0,
            onClick: (e) => {
              e.stopPropagation();
              try {
                projectRegistry.unlinkWorkspace(project.id, w.workspaceId);
                setLinkMsg("\u5DF2\u89E3\u9664\u8BE5\u5DE5\u4F5C\u533A\u5173\u8054\u3002");
              } catch (err) {
                setLinkMsg(err instanceof Error ? err.message : String(err));
              }
            },
            onKeyDown: (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                e.stopPropagation();
                try {
                  projectRegistry.unlinkWorkspace(project.id, w.workspaceId);
                  setLinkMsg("\u5DF2\u89E3\u9664\u8BE5\u5DE5\u4F5C\u533A\u5173\u8054\u3002");
                } catch (err) {
                  setLinkMsg(err instanceof Error ? err.message : String(err));
                }
              }
            },
            children: "\u89E3\u9664"
          }
        )
      ] }, w.workspaceId)),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-card", "data-dpd-link-ws": "1", children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-sub", children: "Link Workspace\uFF1A\u5173\u8054\u4E00\u4E2A\u5B98\u65B9\u771F\u5B9E\u5DE5\u4F5C\u533A\u76EE\u5F55" }),
        !wsCat.ready ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", "data-dpd-ws-state": wsCat.probing ? "probing" : "unavailable", children: wsCat.probing ? "\u5DE5\u4F5C\u533A\u6570\u636E\u8BFB\u53D6\u4E2D\u2026\uFF08\u6B63\u5728\u63A2\u6D4B\u5B98\u65B9 workspaces \u670D\u52A1\uFF09" : "\u5B98\u65B9\u5DE5\u4F5C\u533A\u80FD\u529B\u4E0D\u53EF\u7528\uFF08capability limitation\uFF09\uFF1A\u672C\u73AF\u5883\u672A\u63D0\u4F9B workspaces \u670D\u52A1\uFF0C\u6545\u65E0\u6CD5\u5173\u8054\u771F\u5B9E\u5DE5\u4F5C\u533A\uFF1B\u4E0D\u4F1A\u4F2A\u9020\u76EE\u5F55\u3002" }) : unlinkedWorkspaces.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", children: "\u6240\u6709\u5B98\u65B9\u5DE5\u4F5C\u533A\u90FD\u5DF2\u5173\u8054\u5230\u8BE5\u9879\u76EE\uFF08\u6216\u5F53\u524D\u6CA1\u6709\u53EF\u7528\u5DE5\u4F5C\u533A\uFF09\u3002" }) : /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-line", children: [
          /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("select", { className: "dpd-sel", value: linkWorkspaceId, onChange: (e) => setLinkWorkspaceId(e.target.value), "aria-label": "\u9009\u62E9\u8981\u5173\u8054\u7684\u5DE5\u4F5C\u533A", children: [
            /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("option", { value: "", children: "\u9009\u62E9\u5DE5\u4F5C\u533A\u2026" }),
            unlinkedWorkspaces.map((w) => /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("option", { value: w.workspaceId, children: w.title }, w.workspaceId))
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("button", { type: "button", className: "dpd-go", onClick: doLinkWorkspace, disabled: !linkWorkspaceId, children: "\u5173\u8054" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("section", { className: "dpd-sec", "data-dpd-activity": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-k", children: "\u6700\u8FD1\u6D3B\u52A8 \xB7 Activity" }),
      activity.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-empty", children: "\u8BE5\u9879\u76EE\u8FD8\u6CA1\u6709\u53EF\u5C55\u793A\u7684\u6D3B\u52A8\u3002" }) : activity.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "dpd-row", children: [
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: `dpd-dot${a.kind === "task" ? a.tag === "\u8FD0\u884C\u4E2D" ? "" : " idle" : " idle"}` }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-t", children: a.text }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-tag", children: a.kind === "task" ? "\u4EFB\u52A1" : "\u4F1A\u8BDD" }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-sub", children: a.tag }),
        /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("span", { className: "dpd-sub", children: ago2(a.at) })
      ] }, `${a.kind}-${i}-${a.at}`))
    ] }),
    linkMsg ? /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-msg", role: "status", "data-dpd-link-msg": "1", children: linkMsg }) : null,
    /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "dpd-note", children: "\u9879\u76EE\u5173\u8054\u7684\u662F Host \u4FA7\u771F\u5B9E id\uFF1B\u4EFB\u52A1/\u4F1A\u8BDD/\u5DE5\u4F5C\u533A\u672C\u4F53\u53CA\u5176\u72B6\u6001\u4E00\u5F8B\u4EE5\u5B98\u65B9\u4E3A\u51C6\uFF0C\u672C\u9879\u76EE\u53EA\u505A\u5F52\u7C7B\uFF08\u53EF\u5728\u4E0A\u65B9\u79FB\u51FA/\u5173\u8054\u8C03\u6574\uFF09\u3002" })
  ] });
}

// src/workstation/personal-workspace/src/client/project-center.tsx
var import_jsx_runtime6 = require("react/jsx-runtime");
var CSS_PROJECT_CENTER = String.raw`
.dpc-root{display:flex;flex-direction:column;gap:12px;padding:12px 14px 18px;font:var(--dsw-font-xxs-12,12px);color:var(--dsw-alias-label-primary,#e8e8ec);user-select:none;}
.dpc-h{font:var(--dsw-font-s-strong-14,600 14px);margin:0;color:var(--dsw-alias-label-primary,#e8e8ec);}
.dpc-k{font:var(--dsw-font-xxxs-strong-11,600 11px);letter-spacing:.04em;color:var(--dsw-alias-label-tertiary,#9a9aa5);}
.dpc-card{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 40%,transparent);padding:8px 10px;display:flex;flex-direction:column;gap:5px;}
.dpc-sec{display:flex;flex-direction:column;gap:6px;}
.dpc-empty{color:var(--dsw-alias-label-dimmed,#8f8f99);font:var(--dsw-font-xxs-12,12px);padding:2px 0;}
.dpc-note{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);line-height:1.55;border-left:2px solid rgba(120,150,255,.4);padding:2px 0 2px 8px;}
.dpc-row{display:flex;align-items:center;gap:8px;padding:6px 8px;border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.28));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 45%,transparent);width:100%;text-align:left;color:inherit;font:inherit;cursor:pointer;}
.dpc-row:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.1)) 60%,transparent);}
.dpc-row.static{cursor:default;}
.dpc-glyph{width:18px;text-align:center;flex:none;color:var(--dsw-alias-label-secondary,#c8c8d0);}
.dpc-main{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px;}
.dpc-name{display:flex;align-items:baseline;gap:6px;min-width:0;}
.dpc-name b{color:var(--dsw-alias-label-primary,#e8e8ec);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.dpc-seed{font:var(--dsw-font-xxxs-11,11px);color:var(--dsw-alias-label-tertiary,#9a9aa5);border:1px dashed var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:4px;padding:0 5px;flex:none;}
.dpc-desc{color:var(--dsw-alias-label-secondary,#c8c8d0);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.dpc-meta{display:flex;gap:6px;align-items:center;margin-top:2px;flex-wrap:wrap;}
.dpc-count{font:var(--dsw-font-xxxs-11,11px);color:var(--dsw-alias-label-tertiary,#9a9aa5);border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));border-radius:4px;padding:0 6px;white-space:nowrap;}
.dpc-count b{color:var(--dsw-alias-label-secondary,#c8c8d0);font-weight:600;}
.dpc-arrow{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxs-12,12px);flex:none;}
.dpc-newbtn{border:1px solid rgba(120,150,255,.5);border-radius:6px;background:rgba(120,150,255,.1);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-12,12px);padding:3px 10px;cursor:pointer;align-self:flex-start;}
.dpc-newbtn:hover{background:rgba(120,150,255,.2);}
.dpc-in{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.35));border-radius:6px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.05)) 50%,transparent);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-12,12px);padding:4px 8px;min-width:140px;box-sizing:border-box;width:100%;}
.dpc-in:focus{border-color:rgba(120,150,255,.6);outline:none;}
.dpc-newline{display:flex;gap:8px;align-items:center;}
.dpc-act{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.28));border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxs-12,12px);padding:2px 9px;cursor:pointer;flex:none;}
.dpc-act:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 60%,transparent);}
.dpc-tag{display:inline-flex;align-items:center;font:var(--dsw-font-xxxs-11,11px);border-radius:4px;padding:1px 5px;white-space:nowrap;flex:none;}
.dpc-tag.run{background:rgba(120,150,255,.14);color:#8aa4ff;}
.dpc-tag.attn{background:rgba(240,180,60,.14);color:#e8b64c;border:1px solid rgba(240,180,60,.3);}
.dpc-tag.done{background:rgba(55,200,113,.12);color:#37c871;}
`;
var ago3 = (ts) => {
  if (!ts || !Number.isFinite(ts)) return "";
  const s = Math.max(1, Math.round((Date.now() - ts) / 1e3));
  if (s < 60) return s + " \u79D2\u524D";
  const m = Math.round(s / 60);
  if (m < 60) return m + " \u5206\u949F\u524D";
  const h = Math.round(m / 60);
  if (h < 24) return h + " \u5C0F\u65F6\u524D";
  return Math.round(h / 24) + " \u5929\u524D";
};
function isActive(p, archived) {
  void archived;
  if (p.taskArchived) return false;
  if (p.task.status === "done") return false;
  const open = p.task.status === "running" || p.task.executions.some((e) => e.endedAt === void 0);
  if (p.attach?.archived && !open) return false;
  return true;
}
function ProjectCenterView() {
  const projects = useProjects();
  const tasks = useHomeTaskState();
  const inputRef = (0, import_react6.useRef)(null);
  const [newOpen, setNewOpen] = (0, import_react6.useState)(false);
  const [name, setName] = (0, import_react6.useState)("");
  const [desc, setDesc] = (0, import_react6.useState)("");
  const [busyNew, setBusyNew] = (0, import_react6.useState)(false);
  const [newErr, setNewErr] = (0, import_react6.useState)(null);
  const [notice, setNotice] = (0, import_react6.useState)(null);
  const archivedSet2 = new Set(tasks.archivedSessionIds);
  const hostDown = tasks.ready && !tasks.hostReachable;
  const sessions = useProjectDetailSessions();
  const counts = unassignedCounts(
    tasks.tasks.map((p) => ({ id: p.task.id })),
    sessions.rows.map((s) => ({ id: s.id })),
    { projectOfTask: (id) => projectRegistry.projectOfTask(id), projectOfSession: (id) => projectRegistry.projectOfSession(id) }
  );
  const countsByProject = /* @__PURE__ */ new Map();
  const unassigned = [];
  for (const p of tasks.tasks) {
    const pid = projectRegistry.projectOfTask(p.task.id);
    if (pid === void 0) {
      if (isActive(p, archivedSet2)) unassigned.push(p);
      continue;
    }
    const c = countsByProject.get(pid) ?? { active: 0, all: 0 };
    c.all += 1;
    if (isActive(p, archivedSet2)) c.active += 1;
    countsByProject.set(pid, c);
  }
  unassigned.sort((a, b) => b.task.updatedAt - a.task.updatedAt);
  const create = () => {
    const n = name.trim();
    if (!n) {
      setNewErr("\u9879\u76EE\u540D\u79F0\u4E0D\u80FD\u4E3A\u7A7A");
      return;
    }
    setBusyNew(true);
    setNewErr(null);
    try {
      const rec = projectRegistry.createProject({ name: n, description: desc.trim() || void 0 });
      setNotice(`\u5DF2\u521B\u5EFA\u9879\u76EE\u300C${rec.name}\u300D\u3002\u70B9\u51FB\u5361\u7247\u8FDB\u5165\u8BE6\u60C5\u540E\u53EF\u5173\u8054\u4EFB\u52A1/\u4F1A\u8BDD/\u5DE5\u4F5C\u533A\u3002`);
      setNewOpen(false);
      setName("");
      setDesc("");
    } catch (e) {
      setNewErr(e instanceof Error ? e.message : String(e));
    } finally {
      setBusyNew(false);
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "dpc-root", "data-dsh-plugin": "dsh-personal-workspace", "data-dpc-project-center": "1", children: [
    /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "dpc-h", children: "\u9879\u76EE \xB7 Project Center" }),
    /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("section", { className: "dpc-sec", "data-dpc-projects": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "dpc-k", children: [
        "\u6211\u7684\u9879\u76EE\uFF08",
        projects.length,
        "\uFF09"
      ] }),
      projects.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "dpc-empty", children: "\u8FD8\u6CA1\u6709\u9879\u76EE\u3002\u65B0\u5EFA\u4E00\u4E2A\uFF0C\u628A\u957F\u671F\u5728\u505A\u7684\u4E8B\u60C5\u653E\u8FDB\u6765\u3002" }) : projects.map((p) => {
        const c = countsByProject.get(p.id) ?? { active: 0, all: 0 };
        const wsCount = projectRegistry.workspacesOf(p.id).length;
        return /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)(
          "button",
          {
            type: "button",
            className: "dpc-row",
            "data-dpc-project-row": "1",
            "data-project-id": p.id,
            onClick: () => openProjectDetail(p.id),
            title: "\u6253\u5F00\u9879\u76EE\u8BE6\u60C5\uFF08\u4EFB\u52A1/\u4F1A\u8BDD/\u5DE5\u4F5C\u533A/\u6D3B\u52A8 + \u5173\u8054\u64CD\u4F5C\uFF09",
            children: [
              /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-glyph", children: p.glyph ?? "\xB7" }),
              /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("span", { className: "dpc-main", children: [
                /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("span", { className: "dpc-name", children: [
                  /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("b", { children: p.name }),
                  p.seed ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-seed", children: "\u5185\u7F6E" }) : null
                ] }),
                p.description ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-desc", children: p.description }) : null,
                /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("span", { className: "dpc-meta", children: [
                  /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("span", { className: "dpc-count", children: [
                    "\u4EFB\u52A1 ",
                    /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("b", { children: c.active }),
                    c.all !== c.active ? /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("span", { children: [
                      " / ",
                      c.all
                    ] }) : null
                  ] }),
                  /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("span", { className: "dpc-count", children: [
                    "\u5DE5\u4F5C\u533A ",
                    /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("b", { children: wsCount })
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-arrow", children: "\u203A" })
            ]
          },
          p.id
        );
      }),
      !newOpen ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("button", { type: "button", className: "dpc-newbtn", onClick: () => setNewOpen(true), "data-dpc-new-open": "1", children: "\uFF0B \u65B0\u5EFA\u9879\u76EE" }) : /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("span", { className: "dpc-card", "data-dpc-new-form": "1", children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
          "input",
          {
            ref: inputRef,
            className: "dpc-in",
            placeholder: "\u9879\u76EE\u540D\u79F0 *",
            value: name,
            autoFocus: true,
            onChange: (e) => setName(e.target.value),
            onKeyDown: (e) => {
              if (e.key === "Enter") create();
            },
            "aria-label": "\u65B0\u9879\u76EE\u540D\u79F0"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
          "input",
          {
            className: "dpc-in",
            placeholder: "\u4E00\u53E5\u8BDD\u63CF\u8FF0\uFF08\u53EF\u9009\uFF09",
            value: desc,
            onChange: (e) => setDesc(e.target.value),
            onKeyDown: (e) => {
              if (e.key === "Enter") create();
            },
            "aria-label": "\u65B0\u9879\u76EE\u63CF\u8FF0"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("span", { className: "dpc-newline", children: [
          /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("button", { type: "button", className: "dpc-newbtn", onClick: create, disabled: busyNew, children: busyNew ? "\u521B\u5EFA\u4E2D\u2026" : "\u521B\u5EFA\u9879\u76EE" }),
          /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("button", { type: "button", className: "dpc-act", onClick: () => setNewOpen(false), children: "\u53D6\u6D88" })
        ] }),
        newErr ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "dpc-empty", children: newErr }) : null
      ] }),
      notice ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "dpc-note", role: "status", "data-dpc-notice": "1", children: notice }) : null
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("section", { className: "dpc-sec", "data-dpc-unassigned": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("div", { className: "dpc-k", children: [
        "\u672A\u5F52\u5165\u9879\u76EE \xB7 Unassigned\uFF08\u4EFB\u52A1 ",
        tasks.ready ? counts.tasks : "\u672A\u77E5",
        " \xB7 \u4F1A\u8BDD ",
        sessions.ready ? counts.sessions : "\u672A\u77E5",
        "\uFF09"
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)(
        "button",
        {
          type: "button",
          className: "dpc-row",
          "data-dpc-unassigned-entry": "1",
          onClick: () => {
            if (openUnassignedFn === null) {
              setNotice("\u300C\u672A\u5206\u914D\u300D\u89C6\u56FE\u5F53\u524D\u4E0D\u53EF\u7528\uFF08\u4E2D\u592E\u4E3B\u533A\u672A\u5C31\u7EEA\uFF09\u2014\u2014 \u53EF\u5148\u5728\u4EFB\u52A1\u677F\u4E0A\u5904\u7406\u3002");
              return;
            }
            openUnassignedFn();
          },
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-glyph", children: "\uFF0A" }),
            /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("span", { className: "dpc-main", children: [
              /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-name", children: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("b", { children: "\u67E5\u770B\u672A\u5206\u914D" }) }),
              /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-desc", children: "\u628A\u672A\u5F52\u5165\u9879\u76EE\u7684\u4EFB\u52A1/\u4F1A\u8BDD\u5F52\u5165\u67D0\u4E2A\u9879\u76EE\uFF08\u5173\u7CFB\u5C42\u64CD\u4F5C\uFF0C\u4E0D\u6539\u5B98\u65B9\u6570\u636E\uFF09" })
            ] }),
            /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-act", children: "\u6253\u5F00" })
          ]
        }
      ),
      hostDown ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "dpc-empty", children: "\u4EFB\u52A1\u677F\u5BBF\u4E3B\u4E0D\u53EF\u8FBE\uFF0C\u6682\u65F6\u65E0\u6CD5\u8BFB\u53D6\u672A\u5F52\u7C7B\u4EFB\u52A1\u3002" }) : !tasks.ready ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "dpc-empty", children: "\u6B63\u5728\u8BFB\u53D6\u4EFB\u52A1\u677F\u2026" }) : unassigned.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "dpc-empty", children: "\u4EFB\u52A1\u677F\u4E0A\u7684\u6D3B\u8DC3\u4EFB\u52A1\u90FD\u5DF2\u5F52\u5165\u9879\u76EE\uFF08\u6216\u6682\u65E0\u4EFB\u52A1\uFF09\u3002" }) : unassigned.slice(0, 8).map((p) => {
        const statusTag = p.task.status === "running" ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-tag run", children: "\u8FD0\u884C\u4E2D" }) : p.attention !== null ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-tag attn", children: "\u9700\u5904\u7406" }) : null;
        return /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)(
          "button",
          {
            type: "button",
            className: "dpc-row",
            "data-dpc-unassigned-row": "1",
            onClick: () => openBoardAt(p.task.id),
            title: "\u5728\u4EFB\u52A1\u677F\u67E5\u770B/\u5F52\u7C7B",
            children: [
              /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)("span", { className: "dpc-main", style: { flexDirection: "row", alignItems: "center", gap: 8 }, children: [
                /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-name", style: { flex: 1 }, children: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("b", { children: p.task.title }) }),
                statusTag,
                /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-note", style: { borderLeft: "none", padding: 0 }, children: ago3(p.task.updatedAt) })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("span", { className: "dpc-act", children: "\u4EFB\u52A1\u677F" })
            ]
          },
          p.task.id
        );
      }),
      /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { className: "dpc-note", children: "\u5DF2\u5F52\u5165\u9879\u76EE\u7684\u4EFB\u52A1\u5728\u5404\u9879\u76EE\u5361\u7247\u8BA1\u6570\uFF1B\u5728\u4EFB\u52A1\u677F\u4E0A\uFF08\u6216\u9879\u76EE\u8BE6\u60C5 IA2-6\uFF09\u53EF\u91CD\u65B0\u5F52\u7C7B\u3002" })
    ] })
  ] });
}
var openTaskBoardFn3 = null;
var openProjectDetailFn = null;
var openUnassignedFn = null;
function bindProjectCenterAction(openTaskBoard) {
  openTaskBoardFn3 = openTaskBoard;
  return () => {
    openTaskBoardFn3 = null;
  };
}
function bindProjectCenterUnassigned(openUnassigned) {
  openUnassignedFn = openUnassigned;
  return () => {
    openUnassignedFn = null;
  };
}
function bindProjectCenterDetail(openProjectDetail2) {
  openProjectDetailFn = openProjectDetail2;
  return () => {
    openProjectDetailFn = null;
  };
}
function openBoardAt(taskId) {
  try {
    openTaskBoardFn3?.(taskId);
  } catch {
  }
}
function openProjectDetail(projectId) {
  try {
    openProjectDetailFn?.(projectId);
  } catch {
  }
}

// src/workstation/personal-workspace/src/client/recent.tsx
var import_react7 = require("react");
var import_jsx_runtime7 = require("react/jsx-runtime");
var CSS_RECENT = String.raw`
.drc-root{display:flex;flex-direction:column;gap:12px;padding:12px 14px 18px;font:var(--dsw-font-xxs-12,12px);color:var(--dsw-alias-label-primary,#e8e8ec);user-select:none;}
.drc-h{font:var(--dsw-font-s-strong-14,600 14px);margin:0;color:var(--dsw-alias-label-primary,#e8e8ec);}
.drc-sub{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);}
.drc-row{display:flex;align-items:center;gap:8px;width:100%;border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.28));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 45%,transparent);padding:6px 8px;text-align:left;color:inherit;font:inherit;cursor:pointer;}
.drc-row:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.1)) 60%,transparent);}
.drc-dot{width:7px;height:7px;border-radius:50%;flex:none;background:#37c871;}
.drc-dot.idle{background:var(--dsw-alias-label-dimmed,#6a6a74);}
.drc-t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.drc-time{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);white-space:nowrap;flex:none;}
.drc-act{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.28));border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxs-12,12px);padding:2px 9px;cursor:pointer;flex:none;}
.drc-act:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 60%,transparent);}
.drc-empty{color:var(--dsw-alias-label-dimmed,#8f8f99);font:var(--dsw-font-xxs-12,12px);padding:2px 0;line-height:1.5;}
.drc-badge{display:inline-flex;align-items:center;gap:4px;color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);border:1px dashed var(--dsw-alias-border-l2,rgba(128,128,128,.25));border-radius:20px;padding:1px 8px;align-self:flex-start;}
.drc-badge.warn{border-color:rgba(240,180,60,.4);color:#e0b96a;}
.drc-note{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);line-height:1.55;border-left:2px solid rgba(120,150,255,.4);padding:2px 0 2px 8px;}
`;
var EMPTY_STATE = { ready: false, rows: [], archivedIds: [], archiveKnown: false, archiveReady: false };
var recentState = EMPTY_STATE;
var subs4 = /* @__PURE__ */ new Set();
function notify3() {
  subs4.forEach((f) => {
    try {
      f();
    } catch {
    }
  });
}
function rowOf2(r) {
  const id = String(r.id ?? "");
  if (!id) return null;
  const title = r.displayTitle ?? r.title ?? "";
  return { id, title: title.length > 0 ? title : "\uFF08\u672A\u547D\u540D\u4F1A\u8BDD\uFF09", running: r.running === true, updatedAt: r.updatedAt };
}
function applySessions(snapshot) {
  const rows = sessionRowsOf(snapshot).map(rowOf2).filter((x) => x !== null).sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0)).slice(0, 200);
  recentState = { ...recentState, ready: true, rows };
  notify3();
}
function applyArchive(truth) {
  recentState = { ...recentState, archiveReady: true, archiveKnown: truth.known, archivedIds: [...truth.ids] };
  notify3();
}
var openSessionFn3 = null;
var createTaskFn = null;
function bindRecentServices(getSessions2, reconcile, openSession, openNewTask) {
  openSessionFn3 = openSession;
  createTaskFn = openNewTask ?? null;
  const offs = [];
  try {
    const svc = getSessions2();
    const source = svc?.list ?? null;
    if (source && typeof source.getSnapshot === "function" && typeof source.subscribe === "function") {
      const apply2 = () => {
        try {
          applySessions(source.getSnapshot());
        } catch {
        }
      };
      apply2();
      const off = source.subscribe(apply2);
      if (typeof off === "function") offs.push(off);
    } else {
      recentState = { ...recentState, ready: false, rows: [] };
      notify3();
    }
  } catch {
    recentState = { ...recentState, ready: false, rows: [] };
    notify3();
  }
  if (reconcile) {
    const push = () => {
      try {
        const st = reconcile.getState();
        applyArchive(archiveTruthOf({ archivedSessionIds: st.archivedSessionIds, workspacesSource: st.workspacesSource }));
      } catch {
      }
    };
    push();
    offs.push(reconcile.subscribe(push));
  }
  return () => {
    for (const off of offs) {
      try {
        off();
      } catch {
      }
    }
    openSessionFn3 = null;
    createTaskFn = null;
  };
}
function useRecentState() {
  return (0, import_react7.useSyncExternalStore)(
    (f) => {
      subs4.add(f);
      return () => {
        subs4.delete(f);
      };
    },
    () => recentState,
    () => EMPTY_STATE
  );
}
var ago4 = (ts) => {
  if (!ts || !Number.isFinite(ts)) return "";
  const s = Math.max(1, Math.round((Date.now() - ts) / 1e3));
  if (s < 60) return s + " \u79D2\u524D";
  const m = Math.round(s / 60);
  if (m < 60) return m + " \u5206\u949F\u524D";
  const h = Math.round(m / 60);
  if (h < 24) return h + " \u5C0F\u65F6\u524D";
  return Math.round(h / 24) + " \u5929\u524D";
};
function RecentView() {
  const state3 = useRecentState();
  const archived = new Set(state3.archivedIds);
  const shown = (state3.archiveKnown ? state3.rows.filter((r) => !archived.has(r.id)) : state3.rows).slice(0, 14);
  const open = (id) => {
    try {
      openSessionFn3?.(id);
    } catch {
    }
  };
  const makeTask = (s) => {
    try {
      pushNewTaskSession({ sessionId: s.id, title: s.title });
      createTaskFn?.();
    } catch {
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { className: "drc-root", "data-dsh-plugin": "dsh-personal-workspace", "data-dsh-recent": "1", children: [
    /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("div", { className: "drc-h", children: "\u6700\u8FD1" }),
      /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("div", { className: "drc-sub", children: "\u5B98\u65B9\u771F\u6E90 \xB7 \u5DF2\u5F52\u6863\u4F1A\u8BDD\u4E0D\u5217\u5728\u6B64\uFF08\u4EFB\u52A1\u72B6\u6001\u4EE5\u5BBF\u4E3B\u4E3A\u51C6\uFF09" })
    ] }),
    !state3.ready ? /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("div", { className: "drc-empty", children: "\u4F1A\u8BDD\u6570\u636E\u6682\u4E0D\u53EF\u7528\uFF0C\u5237\u65B0\u91CD\u8BD5\u3002" }) : shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { className: "drc-empty", children: [
      "\u8FD8\u6CA1\u6709\u53EF\u7EE7\u7EED\u7684\u4F1A\u8BDD\u8BB0\u5F55\u3002",
      archived.size > 0 ? /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", { className: "drc-badge", style: { marginLeft: 8 }, children: "\u5DF2\u5F52\u6863\u4F1A\u8BDD\u4E0D\u5217\u5728\u6700\u8FD1" }) : null
    ] }) : shown.map((s) => /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { className: "drc-row", role: "button", tabIndex: 0, onClick: () => open(s.id), onKeyDown: (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        open(s.id);
      }
    }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", { className: `drc-dot${s.running ? "" : " idle"}` }),
      /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", { className: "drc-t", children: s.title }),
      s.running ? /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", { className: "drc-time", children: "\u8FD0\u884C\u4E2D" }) : null,
      s.updatedAt ? /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", { className: "drc-time", children: ago4(s.updatedAt) }) : null,
      !s.running ? /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(
        "button",
        {
          type: "button",
          className: "drc-act",
          title: "\u4ECE\u8BE5\u4F1A\u8BDD\u65B0\u5EFA\u4EFB\u52A1\uFF08\u5185\u5BB9\u7559\u5728\u5B98\u65B9\u4F1A\u8BDD\uFF1B\u8BF7\u8865\u5199\u5177\u4F53\u8981\u505A\u7684\u4E8B\uFF09",
          onClick: (e) => {
            e.stopPropagation();
            makeTask(s);
          },
          children: "\u5EFA\u4EFB\u52A1"
        }
      ) : null,
      /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", { className: "drc-act", "aria-hidden": "true", children: "\u6253\u5F00" })
    ] }, s.id)),
    state3.archiveReady && !state3.archiveKnown ? /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", { className: "drc-badge warn", "data-recent-archive-unknown": "1", children: archiveNoteOf({ known: false, ids: /* @__PURE__ */ new Set() }) }) : state3.archiveReady && archived.size > 0 ? /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("span", { className: "drc-badge warn", "data-recent-archived-note": "1", children: [
      "\u5B98\u65B9\u5DF2\u5F52\u6863\u4F1A\u8BDD N=",
      archived.size,
      "\uFF08\u4E0D\u5728\u672C\u5217\u8868\u663E\u793A\uFF1B\u5230\u300C\u5B98\u65B9\u4F1A\u8BDD\u6D4F\u89C8\u300D\u67E5\u770B/\u6062\u590D\uFF0C\u4EFB\u52A1\u72B6\u6001\u4E0D\u53D7\u5F71\u54CD\uFF09"
    ] }) : null,
    /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("div", { className: "drc-note", children: "\u8981\u5F00\u59CB\u65B0\u7684\u4F1A\u8BDD\uFF1A\u56DE\u300C\u4E3B\u9875\u300D\u7528 Quick Start \u8F93\u5165\u4F60\u60F3\u505A\u7684\u4E8B\uFF08\u53EF\u6307\u5B9A \u9879\u76EE/\u5DE5\u4F5C\u533A/Agent/\u6743\u9650\uFF09\u3002" })
  ] });
}

// src/workstation/personal-workspace/src/client/boardguard.ts
function startBoardGuard() {
  if (typeof window === "undefined" || typeof document === "undefined") return () => {
  };
  const hidden = /* @__PURE__ */ new Set();
  let interval = 0;
  const boardActive = () => {
    try {
      if (document.documentElement?.hasAttribute("data-dsh-taskboard-active")) return true;
    } catch {
    }
    try {
      const btn = Array.from(document.querySelectorAll("button")).find((b) => {
        if (!(b.textContent ?? "").includes("\u65B0\u5EFA\u4EFB\u52A1")) return false;
        const r = b.getBoundingClientRect();
        return r.width > 0 && r.height > 0;
      });
      return !!btn;
    } catch {
      return false;
    }
  };
  const restoreOne = (el) => {
    try {
      if (el.style.getPropertyValue("display") === "none") el.style.display = "";
    } catch {
    }
    hidden.delete(el);
  };
  const restoreAll = () => {
    hidden.forEach(restoreOne);
    hidden.clear();
  };
  const intersects = (a, b) => a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
  const sweep = () => {
    try {
      if (!boardActive()) {
        restoreAll();
        return;
      }
      const boardEl = document.querySelector("[data-dsh-taskboard-view]");
      const boardRect = boardEl?.getBoundingClientRect();
      if (!boardRect || boardRect.width <= 0 || boardRect.height <= 0) {
        restoreAll();
        return;
      }
      const clusters = Array.from(document.querySelectorAll("[data-dsh-toggle-cluster]"));
      const toHide = [];
      const toShow = Array.from(hidden);
      for (const cl of clusters) {
        if (hidden.has(cl)) continue;
        const r = cl.getBoundingClientRect();
        if (r.width <= 0 || r.height <= 0) continue;
        if (intersects(r, boardRect)) toHide.push(cl);
      }
      if (toShow.length === 0 && toHide.length === 0) return;
      for (const el of toShow) restoreOne(el);
      for (const el of toHide) {
        try {
          el.style.setProperty("display", "none");
          hidden.add(el);
        } catch {
        }
      }
    } catch {
    }
  };
  const scheduleSweep = (ms) => {
    try {
      window.clearTimeout(window.__dph_timer);
    } catch {
    }
    try {
      const t = window.setTimeout(() => {
        sweep();
        try {
          window.clearInterval(interval);
        } catch {
        }
        interval = window.setInterval(sweep, 1200);
      }, ms);
      window.__dph_timer = t;
    } catch {
    }
  };
  let mo = null;
  try {
    mo = new MutationObserver(() => scheduleSweep(120));
    mo.observe(document.body, { childList: true, subtree: true, attributes: false });
  } catch {
  }
  scheduleSweep(400);
  return () => {
    try {
      mo?.disconnect();
    } catch {
    }
    try {
      window.clearInterval(interval);
    } catch {
    }
    restoreAll();
  };
}

// src/workstation/personal-workspace/src/client/reconcile.ts
var INITIAL = {
  ready: false,
  hostReachable: false,
  revision: 0,
  tasks: [],
  archivedSessionIds: [],
  sessionsSource: false,
  workspacesSource: false
};
var TaskReconcile = class {
  deps;
  state = { ...INITIAL };
  subs = /* @__PURE__ */ new Set();
  disposers = [];
  bound = false;
  fetchInFlight = null;
  lastSnapshot = null;
  hostRevisionSeen = 0;
  sessionsAvail = null;
  workspacesAvail = null;
  constructor(deps) {
    this.deps = deps;
  }
  getState() {
    return this.state;
  }
  subscribe(fn) {
    this.subs.add(fn);
    return () => {
      this.subs.delete(fn);
    };
  }
  notify() {
    for (const fn of [...this.subs]) {
      try {
        fn();
      } catch {
      }
    }
  }
  bind() {
    if (this.bound) return this.dispose.bind(this);
    this.bound = true;
    const offS = this.safeSubscribe(this.deps.sessionsList, () => this.reproject());
    const offW = this.safeSubscribe(this.deps.workspacesList, () => this.reproject());
    const offH = this.safeSubscribeHost();
    if (offS !== void 0) this.disposers.push(offS);
    if (offW !== void 0) this.disposers.push(offW);
    if (offH !== void 0) this.disposers.push(offH);
    this.reproject();
    void this.refresh();
    return this.dispose.bind(this);
  }
  dispose() {
    for (const d of this.disposers.splice(0)) {
      try {
        d();
      } catch {
      }
    }
    this.bound = false;
    this.subs.clear();
  }
  safeSubscribe(store, fn) {
    try {
      if (store && typeof store.subscribe === "function") return store.subscribe(fn);
    } catch {
    }
    return void 0;
  }
  safeSubscribeHost() {
    try {
      const off = this.deps.subscribeHost?.((event) => {
        if (event?.revision !== void 0 && event.revision !== this.hostRevisionSeen) {
          void this.refresh();
        } else if (event === void 0) {
          void this.refresh();
        }
      });
      return off;
    } catch {
      return void 0;
    }
  }
  /** 手动 reconcile（mount / 用户刷新）：重拉 Host + 重投影。 */
  refresh() {
    return this.fetchHostState();
  }
  /** 直接应用一份 Host 快照（action 的返回体）——不重复 GET。 */
  ingest(snapshot) {
    this.lastSnapshot = snapshot;
    this.hostRevisionSeen = snapshot.revision ?? 0;
    const tasks = this.project(snapshot);
    const archivedSessionIds = this.readArchived();
    this.state = {
      ...this.state,
      ready: true,
      hostReachable: true,
      revision: snapshot.revision ?? 0,
      hostError: void 0,
      tasks,
      archivedSessionIds,
      sessionsSource: this.sessionsAvail === true,
      workspacesSource: this.workspacesAvail === true
    };
    this.notify();
  }
  async fetchHostState() {
    if (this.fetchInFlight !== null) return this.fetchInFlight;
    const run = async () => {
      try {
        const snapshot = await this.deps.fetchHost();
        this.lastSnapshot = snapshot;
        this.hostRevisionSeen = snapshot.revision ?? 0;
        const tasks = this.project(snapshot);
        const archivedSessionIds = this.readArchived();
        this.state = {
          ...this.state,
          ready: true,
          hostReachable: true,
          revision: snapshot.revision ?? 0,
          hostError: void 0,
          tasks,
          archivedSessionIds,
          sessionsSource: this.sessionsAvail === true,
          workspacesSource: this.workspacesAvail === true
        };
      } catch (error) {
        const archivedSessionIds = this.readArchived();
        this.state = {
          ...this.state,
          hostReachable: false,
          hostError: error instanceof Error ? error.message : String(error),
          archivedSessionIds,
          sessionsSource: this.sessionsAvail === true,
          workspacesSource: this.workspacesAvail === true
        };
      }
      this.notify();
    };
    this.fetchInFlight = run();
    try {
      await this.fetchInFlight;
    } finally {
      this.fetchInFlight = null;
    }
  }
  /** 用最近快照重投影（sessions/workspaces 变化时）。 */
  reproject() {
    const snapshot = this.lastSnapshot;
    if (snapshot === null) return;
    const tasks = this.project(snapshot);
    const archivedSessionIds = this.readArchived();
    this.state = {
      ...this.state,
      tasks,
      archivedSessionIds,
      sessionsSource: this.sessionsAvail === true,
      workspacesSource: this.workspacesAvail === true
    };
    this.notify();
  }
  project(snapshot) {
    const sessions = this.readSessions();
    const archived = this.readArchived();
    const input = {
      tasks: snapshot.tasks,
      sessions,
      archivedSessionIds: archived,
      sessionDefaultPermission: snapshot.sessionDefaultPermission
    };
    return projectBoard(input);
  }
  readSessions() {
    try {
      const snap = this.deps.sessionsList?.getSnapshot();
      if (snap === void 0 || snap === null) {
        this.markSource("sessions", false);
        return [];
      }
      this.markSource("sessions", true);
      return sessionRowsOf(snap);
    } catch {
      this.markSource("sessions", false);
      return [];
    }
  }
  readArchived() {
    try {
      const snap = this.deps.workspacesList?.getSnapshot();
      const s = snap ?? {};
      const ids = s.archivedSessionIds;
      if (!Array.isArray(ids)) {
        this.markSource("workspaces", false);
        return [];
      }
      this.markSource("workspaces", true);
      return ids.filter((x) => typeof x === "string");
    } catch {
      this.markSource("workspaces", false);
      return [];
    }
  }
  /** 只记录源可用性（state 组装点在 emit 时统一写入 sessionsSource/workspacesSource）。 */
  markSource(key, available) {
    if (key === "sessions") this.sessionsAvail = available;
    if (key === "workspaces") this.workspacesAvail = available;
  }
};

// src/workstation/personal-workspace/src/client/unassigned.tsx
var import_react8 = require("react");
var import_jsx_runtime8 = require("react/jsx-runtime");
var CSS_UNASSIGNED = String.raw`
.dun-root{display:flex;flex-direction:column;gap:12px;padding:12px 14px 18px;font:var(--dsw-font-xxs-12,12px);color:var(--dsw-alias-label-primary,#e8e8ec);user-select:none;}
.dun-h{font:var(--dsw-font-s-strong-14,600 14px);margin:0;}
.dun-k{font:var(--dsw-font-xxxs-strong-11,600 11px);letter-spacing:.04em;color:var(--dsw-alias-label-tertiary,#9a9aa5);}
.dun-sec{display:flex;flex-direction:column;gap:6px;}
.dun-row{display:flex;align-items:center;gap:8px;padding:6px 8px;border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.28));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 45%,transparent);}
.dun-main{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.dun-tag{font:var(--dsw-font-xxxs-11,11px);color:var(--dsw-alias-label-tertiary,#9a9aa5);border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));border-radius:4px;padding:0 6px;flex:none;}
.dun-sel{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.35));border-radius:6px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.05)) 60%,transparent);color:var(--dsw-alias-label-primary,#e8e8ec);font:var(--dsw-font-xxs-12,12px);padding:2px 6px;max-width:190px;flex:none;}
.dun-note{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);line-height:1.55;border-left:2px solid rgba(120,150,255,.4);padding:2px 0 2px 8px;}
.dun-empty{color:var(--dsw-alias-label-dimmed,#8f8f99);padding:2px 0;}
.dun-msg{font:var(--dsw-font-xxxs-11,11px);color:var(--dsw-alias-label-secondary,#c8c8d0);}
.dun-count{font:var(--dsw-font-xxxs-11,11px);color:var(--dsw-alias-label-tertiary,#9a9aa5);border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));border-radius:4px;padding:0 6px;}
`;
function UnassignedView() {
  const projects = useProjects();
  const tasks = useHomeTaskState();
  const sessions = useProjectDetailSessions();
  const [msg, setMsg] = (0, import_react8.useState)(null);
  const taskRows = (0, import_react8.useMemo)(
    () => unassignedOf(tasks.tasks.map((p) => ({ id: p.task.id, title: p.task.title, status: p.task.status, updatedAt: p.task.updatedAt, archived: p.taskArchived })), (id) => projectRegistry.projectOfTask(id)),
    [tasks.tasks]
  );
  const sessionRows = (0, import_react8.useMemo)(
    () => unassignedOf(sessions.rows.map((s) => ({ id: s.id, title: s.title, archived: s.archived, running: s.running, updatedAt: s.updatedAt })), (id) => projectRegistry.projectOfSession(id)),
    [sessions.rows]
  );
  const counts = (0, import_react8.useMemo)(
    () => unassignedCounts(
      tasks.tasks.map((p) => ({ id: p.task.id })),
      sessions.rows.map((s) => ({ id: s.id })),
      { projectOfTask: (id) => projectRegistry.projectOfTask(id), projectOfSession: (id) => projectRegistry.projectOfSession(id) }
    ),
    [tasks.tasks, sessions.rows]
  );
  const tasksUnknown = tasks.ready === false && tasks.hostReachable === false && tasks.tasks.length === 0;
  const sessionsUnknown = sessions.ready === false;
  const assign = (kind, id, projectId) => {
    const nameOf = (pid) => projects.find((p) => p.id === pid)?.name;
    const r = kind === "task" ? rebindTask(projectRegistry, id, projectId, nameOf) : rebindSession(projectRegistry, id, projectId, nameOf);
    setMsg(r.message);
  };
  return /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "dun-root", "data-dsh-plugin": "dsh-personal-workspace", "data-dun-view": "1", children: [
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("h2", { className: "dun-h", children: "\u672A\u5206\u914D \xB7 Unassigned" }),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "dun-note", "data-dun-note": "1", children: [
      RELATION_NOTE,
      " \u300C\u672A\u5F52\u5165\u9879\u76EE\u300D\u662F\u5408\u6CD5\u72B6\u6001\uFF1A\u4E0D\u5F52\u5C5E\u4EFB\u4F55\u9879\u76EE\u4E0D\u5F71\u54CD\u5B98\u65B9\u4EFB\u52A1/\u4F1A\u8BDD\u7684\u8FD0\u884C\u4E0E\u72B6\u6001\u3002"
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("section", { className: "dun-sec", "data-dun-tasks": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "dun-k", children: [
        "\u672A\u5F52\u5165\u9879\u76EE\u7684\u4EFB\u52A1",
        tasksUnknown ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "dun-count", "data-dun-unknown": "1", children: " \u672A\u77E5\uFF08\u4EFB\u52A1\u5BBF\u4E3B\u4E0D\u53EF\u8FBE\uFF09" }) : /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("span", { className: "dun-count", children: [
          " ",
          counts.tasks
        ] })
      ] }),
      tasksUnknown ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "dun-empty", children: "\u4EFB\u52A1\u5BBF\u4E3B\u4E0D\u53EF\u8FBE \u2192 \u8BA1\u6570\u4E3A\u300C\u672A\u77E5\u300D\u800C\u975E 0\uFF08\u4E0D\u4F2A\u9020\uFF09\u3002\u8BF7\u5230\u4EFB\u52A1\u770B\u677F\u786E\u8BA4\u5BBF\u4E3B\u72B6\u6001\u540E\u91CD\u8BD5\u3002" }) : taskRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "dun-empty", children: "\u6CA1\u6709\u672A\u5F52\u5165\u9879\u76EE\u7684\u4EFB\u52A1\uFF08\u5168\u90E8\u4EFB\u52A1\u90FD\u5DF2\u5F52\u5165\u9879\u76EE\uFF0C\u6216\u4EFB\u52A1\u677F\u4E3A\u7A7A\uFF09\u3002" }) : taskRows.map((t) => /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "dun-row", "data-dun-task-row": "1", "data-dun-task-id": t.id, children: [
        /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "dun-main", children: t.title }),
        /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "dun-tag", children: t.status }),
        t.archived ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "dun-tag", "data-dun-archived": "1", children: "\u5DF2\u5F52\u6863" }) : null,
        /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)(
          "select",
          {
            className: "dun-sel",
            "aria-label": `\u628A\u4EFB\u52A1\u300C${t.title}\u300D\u5F52\u5165\u9879\u76EE`,
            value: "",
            onChange: (e) => {
              if (e.target.value !== "") assign("task", t.id, e.target.value);
            },
            children: [
              /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("option", { value: "", children: "\u5F52\u5165\u9879\u76EE\u2026" }),
              projects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("option", { value: p.id, children: [
                p.glyph,
                " ",
                p.name
              ] }, p.id))
            ]
          }
        )
      ] }, t.id))
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("section", { className: "dun-sec", "data-dun-sessions": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "dun-k", children: [
        "\u672A\u5F52\u5165\u9879\u76EE\u7684\u4F1A\u8BDD",
        sessionsUnknown ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "dun-count", "data-dun-unknown": "1", children: " \u672A\u77E5\uFF08\u5B98\u65B9\u4F1A\u8BDD\u6E90\u672A\u5C31\u7EEA\uFF09" }) : /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("span", { className: "dun-count", children: [
          " ",
          counts.sessions
        ] })
      ] }),
      sessionsUnknown ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "dun-empty", children: "\u5B98\u65B9\u4F1A\u8BDD\u5FEB\u7167\u5F53\u524D\u4E0D\u53EF\u8BFB \u2192 \u8BA1\u6570\u4E3A\u300C\u672A\u77E5\u300D\u800C\u975E 0\uFF08\u4E0D\u4F2A\u9020\uFF09\u3002" }) : sessionRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "dun-empty", children: "\u6CA1\u6709\u672A\u5F52\u5165\u9879\u76EE\u7684\u4F1A\u8BDD\u3002" }) : sessionRows.map((s) => /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "dun-row", "data-dun-session-row": "1", "data-dun-session-id": s.id, children: [
        /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "dun-main", children: s.title }),
        s.archived ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "dun-tag", children: "\u5F52\u6863" }) : null,
        s.running ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "dun-tag", children: "\u8FD0\u884C\u4E2D" }) : null,
        /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)(
          "select",
          {
            className: "dun-sel",
            "aria-label": `\u628A\u4F1A\u8BDD\u300C${s.title}\u300D\u5F52\u5165\u9879\u76EE`,
            value: "",
            onChange: (e) => {
              if (e.target.value !== "") assign("session", s.id, e.target.value);
            },
            children: [
              /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("option", { value: "", children: "\u5F52\u5165\u9879\u76EE\u2026" }),
              projects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("option", { value: p.id, children: [
                p.glyph,
                " ",
                p.name
              ] }, p.id))
            ]
          }
        )
      ] }, s.id))
    ] }),
    msg !== null ? /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "dun-msg", role: "status", "data-dun-msg": "1", children: msg }) : null
  ] });
}

// src/workstation/personal-workspace/src/client/workspace-center.tsx
var import_react9 = require("react");
var import_jsx_runtime9 = require("react/jsx-runtime");
var CSS_WORKSPACE_CENTER = String.raw`
.dwc-root{display:flex;flex-direction:column;gap:12px;padding:12px 14px 18px;font:var(--dsw-font-xxs-12,12px);color:var(--dsw-alias-label-primary,#e8e8ec);user-select:none;}
.dwc-h{font:var(--dsw-font-s-strong-14,600 14px);margin:0;color:var(--dsw-alias-label-primary,#e8e8ec);}
.dwc-k{font:var(--dsw-font-xxxs-strong-11,600 11px);letter-spacing:.04em;color:var(--dsw-alias-label-tertiary,#9a9aa5);}
.dwc-sec{display:flex;flex-direction:column;gap:6px;}
.dwc-empty{color:var(--dsw-alias-label-dimmed,#8f8f99);font:var(--dsw-font-xxs-12,12px);padding:2px 0;line-height:1.5;}
.dwc-retry{margin-left:6px;padding:1px 8px;font:var(--dsw-font-xxs-12,12px);color:var(--dsw-alias-label-secondary,#c9c9d1);background:transparent;border:1px solid var(--dsw-alias-border-l2,#3a3a42);border-radius:6px;cursor:pointer;}
.dwc-retry:hover{border-color:var(--dsw-alias-border-l3,#55555f);}
.dwc-note{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);line-height:1.55;border-left:2px solid rgba(120,150,255,.4);padding:2px 0 2px 8px;}
.dwc-card{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 40%,transparent);padding:8px 10px;display:flex;flex-direction:column;gap:6px;}
.dwc-row{display:flex;align-items:center;gap:8px;padding:6px 8px;border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.28));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 45%,transparent);width:100%;text-align:left;color:inherit;font:inherit;cursor:pointer;}
.dwc-row:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.1)) 60%,transparent);}
.dwc-row.static{cursor:default;}
.dwc-glyph{width:18px;text-align:center;flex:none;color:var(--dsw-alias-label-secondary,#c8c8d0);}
.dwc-main{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px;}
.dwc-name{display:flex;align-items:center;gap:6px;min-width:0;}
.dwc-name b{color:var(--dsw-alias-label-primary,#e8e8ec);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.dwc-path{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:rtl;text-align:left;}
.dwc-meta{display:flex;flex-wrap:wrap;gap:6px;margin-top:2px;}
.dwc-count{font:var(--dsw-font-xxxs-11,11px);color:var(--dsw-alias-label-tertiary,#9a9aa5);border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));border-radius:4px;padding:0 6px;white-space:nowrap;}
.dwc-count b{color:var(--dsw-alias-label-secondary,#c8c8d0);font-weight:600;}
.dwc-act{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.28));border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxs-12,12px);padding:2px 9px;cursor:pointer;flex:none;}
.dwc-act:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 60%,transparent);}
.dwc-dot{width:7px;height:7px;border-radius:50%;flex:none;background:#37c871;}
.dwc-dot.idle{background:var(--dsw-alias-label-dimmed,#6a6a74);}
.dwc-dot.arch{background:var(--dsw-alias-label-dimmed,#55555e);}
.dwc-t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.dwc-sub{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);white-space:nowrap;flex:none;}
.dwc-tag{display:inline-flex;align-items:center;font:var(--dsw-font-xxxs-11,11px);border-radius:4px;padding:1px 5px;white-space:nowrap;flex:none;}
.dwc-tag.prj{background:rgba(150,120,255,.12);color:#b49bff;border:1px solid rgba(150,120,255,.3);}
.dwc-sessions{border-top:1px dashed var(--dsw-alias-border-l2,rgba(128,128,128,.18));padding-top:4px;display:flex;flex-direction:column;gap:3px;}
`;
var openSessionFn4 = null;
var openFolderFn = null;
var openProjectDetailFn2 = null;
function bindWorkspaceCenterActions(actions) {
  openSessionFn4 = actions.openSession;
  openFolderFn = actions.openFolder;
  openProjectDetailFn2 = actions.openProjectDetail;
  return () => {
    openSessionFn4 = null;
    openFolderFn = null;
    openProjectDetailFn2 = null;
  };
}
var ago5 = (ts) => {
  if (!ts || !Number.isFinite(ts)) return "";
  const s = Math.max(1, Math.round((Date.now() - ts) / 1e3));
  if (s < 60) return s + " \u79D2\u524D";
  const m = Math.round(s / 60);
  if (m < 60) return m + " \u5206\u949F\u524D";
  const h = Math.round(m / 60);
  if (h < 24) return h + " \u5C0F\u65F6\u524D";
  return Math.round(h / 24) + " \u5929\u524D";
};
function WorkspaceCenterView() {
  const wsCat = useWorkspaceCatalog();
  const sessions = useProjectDetailSessions();
  const projects = useProjects();
  const [expanded, setExpanded] = (0, import_react9.useState)(null);
  const [notice, setNotice] = (0, import_react9.useState)(null);
  const sessionById = new Map(sessions.rows.map((s) => [s.id, s]));
  const nameOfProject = (pid) => projects.find((p) => p.id === pid)?.name;
  const openFolder = (path) => {
    if (typeof openFolderFn !== "function") {
      setNotice("\u300C\u6253\u5F00\u771F\u5B9E\u76EE\u5F55\u300D\u4F9D\u8D56 better-sidebar \u7F16\u8F91\u5668\u7A97\u53E3\uFF0C\u5F53\u524D\u4E0D\u53EF\u7528\uFF08\u5DF2\u5728\u754C\u9762\u6807\u6CE8\u53EA\u8BFB\u8DEF\u5F84\uFF09\u3002");
      return;
    }
    setNotice(null);
    openFolderFn(path);
  };
  return /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "dwc-root", "data-dsh-plugin": "dsh-personal-workspace", "data-dwc-workspace-center": "1", children: [
    /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "dwc-h", children: "\u5DE5\u4F5C\u533A \xB7 Workspace Center" }),
    /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "dwc-note", children: "\u8FD9\u91CC\u5C55\u793A AI \u5B9E\u9645\u5DE5\u4F5C\u7684**\u771F\u5B9E\u6587\u4EF6\u73AF\u5883**\uFF08\u5B98\u65B9 Workspace \u6CE8\u518C\u8868\uFF0C\u53EA\u8BFB\u6295\u5F71\uFF09\u3002\u5B98\u65B9\u6CA1\u6709 app \u5185\u6587\u4EF6\u6811 / detail \u9875 \u2014\u2014 \u770B\u771F\u5B9E\u76EE\u5F55\u7528\u6BCF\u9879\u7684\u300C\u6253\u5F00\u771F\u5B9E\u76EE\u5F55\u300D\uFF08better-sidebar \u7F16\u8F91\u5668\u6587\u4EF6\u5939\u7A97\u53E3\uFF09\uFF1B\u6253\u5F00\u5355\u4E2A\u6587\u4EF6\u8D70 \u5BBF\u4E3B\u9ED8\u8BA4\u7A0B\u5E8F\uFF08\u684C\u9762\u7AEF\uFF09\u3002" }),
    !wsCat.ready ? wsCat.probing ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "dwc-empty", "data-dwc-ws-state": "probing", children: "\u5DE5\u4F5C\u533A\u6570\u636E\u8BFB\u53D6\u4E2D\u2026\uFF08\u6B63\u5728\u63A2\u6D4B\u5B98\u65B9 workspaces \u670D\u52A1\uFF0C\u6700\u591A\u81EA\u52A8\u91CD\u8BD5 12s\uFF09" }) : /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "dwc-empty", "data-dwc-ws-state": "unavailable", children: [
      "\u5B98\u65B9 workspaces \u80FD\u529B\u5F53\u524D\u4E0D\u53EF\u7528\uFF08capability limitation\uFF09\uFF1A",
      wsCat.error ?? '\u672C\u73AF\u5883\u672A\u63D0\u4F9B ctx.get("workspaces").list',
      "\u3002\u672C\u9875**\u4E0D\u4F2A\u9020**\u76EE\u5F55\u2014\u2014\u4E0D\u4F1A\u663E\u793A\u4EFB\u4F55\u6A21\u62DF\u5DE5\u4F5C\u533A\uFF1B\u8BF7\u786E\u8BA4\u5B98\u65B9 workspace \u670D\u52A1\u5DF2\u542F\u7528\u540E\u91CD\u8BD5\u3002",
      /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
        "button",
        {
          type: "button",
          className: "dwc-retry",
          "data-dwc-ws-retry": "1",
          onClick: () => {
            const ok = retryWorkspaceCatalogNow();
            setNotice(ok ? null : "\u4ECD\u672A\u63A2\u6D4B\u5230\u5B98\u65B9 workspaces \u670D\u52A1\u3002");
          },
          children: "\u7ACB\u5373\u91CD\u8BD5"
        }
      )
    ] }) : wsCat.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "dwc-empty", children: "\u5F53\u524D\u6CA1\u6709\u53EF\u7528\u5DE5\u4F5C\u533A\uFF1A\u8BF7\u5148\u5728\u5B98\u65B9\u754C\u9762\u6DFB\u52A0\u4E00\u4E2A\u5DE5\u4F5C\u533A\u76EE\u5F55\u3002" }) : wsCat.items.map((w) => {
      const wsSessions = w.sessionIds.map((id) => sessionById.get(id)).filter((s) => s !== void 0);
      const projIds = projectRegistry.projectsOfWorkspace(w.workspaceId).map((p) => p.id);
      const isOpen = expanded === w.workspaceId;
      const hasPath = typeof w.path === "string" && w.path.length > 0;
      return /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)(
        "div",
        {
          className: "dwc-card",
          "data-dwc-ws": "1",
          "data-workspace-id": w.workspaceId,
          "data-dwc-ws-limited": hasPath ? "0" : "1",
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "dwc-row static", style: { padding: 4, border: "none", background: "transparent" }, children: [
              /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "dwc-glyph", children: "\u25A4" }),
              /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("span", { className: "dwc-main", children: [
                /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("span", { className: "dwc-name", children: [
                  /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("b", { children: w.title }),
                  projIds.length > 0 ? projIds.map((pid) => /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
                    "span",
                    {
                      className: "dwc-tag prj",
                      role: "button",
                      tabIndex: 0,
                      "data-dwc-project-chip": "1",
                      title: `\u6253\u5F00\u9879\u76EE\u300C${nameOfProject(pid) ?? pid}\u300D\u8BE6\u60C5`,
                      onClick: (e) => {
                        e.stopPropagation();
                        try {
                          openProjectDetailFn2?.(pid);
                        } catch {
                        }
                      },
                      onKeyDown: (e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          e.stopPropagation();
                          try {
                            openProjectDetailFn2?.(pid);
                          } catch {
                          }
                        }
                      },
                      children: nameOfProject(pid) ?? pid
                    },
                    pid
                  )) : null
                ] }),
                hasPath ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "dwc-path", title: w.path, children: w.path }) : /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "dwc-path", "data-dwc-ws-path-missing": "1", title: "\u5B98\u65B9\u6CE8\u518C\u8868\u672A\u63D0\u4F9B\u8BE5\u5DE5\u4F5C\u533A\u7684\u76EE\u5F55\u8DEF\u5F84", children: "\uFF08\u5B98\u65B9\u672A\u63D0\u4F9B\u76EE\u5F55\u8DEF\u5F84 \xB7 limited\uFF09" }),
                /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("span", { className: "dwc-meta", children: [
                  /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("span", { className: "dwc-count", children: [
                    "\u5B98\u65B9\u4F1A\u8BDD ",
                    /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("b", { children: w.sessionIds.length })
                  ] }),
                  projIds.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("span", { className: "dwc-count", children: [
                    "\u5173\u8054\u9879\u76EE ",
                    /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("b", { children: projIds.length })
                  ] }) : /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "dwc-count", children: "\u672A\u5173\u8054\u9879\u76EE" })
                ] })
              ] }),
              hasPath ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "dwc-act", onClick: () => openFolder(w.path), "data-dwc-open-folder": "1", children: "\u6253\u5F00\u771F\u5B9E\u76EE\u5F55" }) : /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
                "span",
                {
                  className: "dwc-act",
                  "data-dwc-open-folder": "1",
                  "data-dwc-open-folder-disabled": "1",
                  "aria-disabled": "true",
                  title: "\u5B98\u65B9\u6CE8\u518C\u8868\u672A\u63D0\u4F9B\u8BE5\u5DE5\u4F5C\u533A\u7684\u76EE\u5F55\u8DEF\u5F84\uFF0C\u65E0\u6CD5\u6253\u5F00\uFF08\u4E0D\u4F2A\u9020\u8DEF\u5F84\uFF09",
                  children: "\u65E0\u6CD5\u6253\u5F00\u76EE\u5F55\uFF08\u7F3A\u8DEF\u5F84\uFF09"
                }
              ),
              /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
                "span",
                {
                  className: "dwc-act",
                  onClick: () => setExpanded(isOpen ? null : w.workspaceId),
                  "data-dwc-expand": "1",
                  children: isOpen ? "\u6536\u8D77" : "\u4F1A\u8BDD"
                }
              )
            ] }),
            isOpen ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "dwc-sessions", "data-dwc-ws-sessions": "1", children: wsSessions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "dwc-empty", children: "\u8BE5\u5DE5\u4F5C\u533A\u4E0B\u6682\u65E0\u4F1A\u8BDD\u8BB0\u5F55\uFF08\u5B98\u65B9\u4F1A\u8BDD\u6D4F\u89C8\u91CC\u53EF\u67E5\u770B\uFF09\u3002" }) : wsSessions.map((s) => /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "dwc-row static", children: [
              /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: `dwc-dot${s.archived ? " arch" : s.running ? "" : " idle"}` }),
              /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "dwc-t", children: s.title }),
              s.archived ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "dwc-sub", children: "\u5DF2\u5F52\u6863" }) : s.running ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "dwc-sub", children: "\u8FD0\u884C\u4E2D" }) : null,
              s.updatedAt ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "dwc-sub", children: ago5(s.updatedAt) }) : null,
              /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
                "span",
                {
                  className: "dwc-act",
                  role: "button",
                  tabIndex: 0,
                  onClick: (e) => {
                    e.stopPropagation();
                    try {
                      openSessionFn4?.(s.id);
                    } catch {
                    }
                  },
                  children: "\u6253\u5F00"
                }
              )
            ] }, s.id)) }) : null
          ]
        },
        w.workspaceId
      );
    }),
    notice ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "dwc-empty", role: "status", "data-dwc-notice": "1", children: notice }) : null,
    /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "dwc-note", children: "\u5DE5\u4F5C\u533A\u6570\u636E\u6765\u81EA\u5B98\u65B9\uFF08\u53EA\u8BFB\uFF09\u3002\u5728\u672C\u9762\u677F\u5173\u8054\u9879\u76EE\uFF08Link Workspace\uFF09\u2192 \u8BF7\u5230\u300C\u9879\u76EE\u8BE6\u60C5\u300D\u9875\u64CD\u4F5C\uFF1B \u5F52\u6863\u4F1A\u8BDD\u4EE5\u5B98\u65B9\u4E3A\u51C6\uFF08\u5728 Recent/\u5B98\u65B9\u4F1A\u8BDD\u6D4F\u89C8\u67E5\u770B\uFF09\u3002" })
  ] });
}

// src/workstation/personal-workspace/src/client/taskboard-view.tsx
var import_react10 = require("react");
var import_jsx_runtime10 = require("react/jsx-runtime");
var CSS_TASKBOARD = String.raw`
.dtb-root{display:flex;flex-direction:column;gap:10px;padding:10px 12px 16px;font:var(--dsw-font-xxs-12,12px);color:var(--dsw-alias-label-primary,#e8e8ec);user-select:none;min-height:0;}
.dtb-h{font:var(--dsw-font-s-strong-14,600 14px);margin:0;color:var(--dsw-alias-label-primary,#e8e8ec);display:flex;align-items:center;gap:8px;}
.dtb-k{font:var(--dsw-font-xxxs-strong-11,600 11px);letter-spacing:.04em;color:var(--dsw-alias-label-tertiary,#9a9aa5);}
.dtb-toolbar{display:flex;align-items:center;gap:6px;flex-wrap:wrap;}
.dtb-toggle{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:16px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxxs-11,11px);padding:2px 10px;cursor:pointer;}
.dtb-toggle.on{background:rgba(120,150,255,.18);border-color:rgba(120,150,255,.5);color:var(--dsw-alias-label-primary,#e8e8ec);}
.dtb-tag{display:inline-flex;align-items:center;gap:4px;font:var(--dsw-font-xxxs-11,11px);border-radius:4px;padding:1px 6px;white-space:nowrap;}
.dtb-tag.running{background:rgba(55,200,113,.14);color:#37c871;}
.dtb-tag.done{background:rgba(120,150,255,.12);color:#8aa4ff;}
.dtb-tag.failed{background:rgba(235,90,90,.14);color:#ff8a8a;}
.dtb-tag.todo,.dtb-tag.backlog{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 60%,transparent);color:var(--dsw-alias-label-secondary,#c8c8d0);}
.dtb-tag.arch{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 40%,transparent);color:var(--dsw-alias-label-tertiary,#9a9aa5);border:1px dashed var(--dsw-alias-border-l2,rgba(128,128,128,.3));}
.dtb-tag.attention{background:rgba(240,180,60,.14);color:#e8b64c;border:1px solid rgba(240,180,60,.35);}
.dtb-tag.prj{background:rgba(150,120,255,.12);color:#b49bff;border:1px solid rgba(150,120,255,.3);}
.dtb-tag.ws{background:rgba(120,150,255,.12);color:#8aa4ff;border:1px solid rgba(120,150,255,.3);}
.dtb-tag.periodic{background:rgba(120,200,170,.13);color:#6fd6ac;border:1px solid rgba(120,200,170,.32);}
.dtb-tag.off{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 40%,transparent);color:var(--dsw-alias-label-tertiary,#9a9aa5);border:1px dashed var(--dsw-alias-border-l2,rgba(128,128,128,.3));}
.dtb-empty{color:var(--dsw-alias-label-dimmed,#8f8f99);font:var(--dsw-font-xxs-12,12px);padding:2px 0;}
.dtb-badge{display:inline-flex;align-items:center;gap:4px;color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);border:1px dashed var(--dsw-alias-border-l2,rgba(128,128,128,.25));border-radius:20px;padding:1px 8px;align-self:flex-start;}
.dtb-card{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:8px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.05)) 45%,transparent);padding:7px 10px;display:flex;flex-direction:column;gap:5px;text-align:left;cursor:pointer;width:100%;color:inherit;font:inherit;}
.dtb-card:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.1)) 60%,transparent);}
.dtb-cardline{display:flex;align-items:center;gap:6px;min-width:0;}
.dtb-cardtitle{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-primary,#e8e8ec);}
.dtb-sub{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);}
.dtb-group{margin-top:8px;display:flex;flex-direction:column;gap:5px;}
.dtb-sec{display:flex;flex-direction:column;gap:5px;border-top:1px solid var(--dsw-alias-border-l1,rgba(128,128,128,.14));padding-top:8px;}
.dtb-detail{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.34));border-radius:10px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.06)) 55%,transparent);padding:10px 12px;display:flex;flex-direction:column;gap:8px;}
.dtb-dhead{display:flex;align-items:flex-start;gap:8px;justify-content:space-between;}
.dtb-dtitle{font:var(--dsw-font-s-strong-14,600 14px);color:var(--dsw-alias-label-primary,#e8e8ec);margin:0;word-break:break-word;}
.dtb-desc{color:var(--dsw-alias-label-secondary,#c8c8d0);line-height:1.55;word-break:break-word;}
.dtb-prompt{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);line-height:1.5;word-break:break-word;border-left:2px solid rgba(120,150,255,.35);padding:1px 0 1px 8px;max-height:84px;overflow:auto;}
.dtb-kv{display:grid;grid-template-columns:92px 1fr;gap:3px 8px;align-items:baseline;}
.dtb-kv b{color:var(--dsw-alias-label-primary,#e8e8ec);font-weight:600;}
.dtb-acts{display:flex;gap:6px;flex-wrap:wrap;}
.dtb-act{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.3));border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary,#c8c8d0);font:var(--dsw-font-xxs-12,12px);padding:3px 10px;cursor:pointer;}
.dtb-act:hover{background:color-mix(in srgb,var(--dsw-alias-bg-layer-2,rgba(128,128,128,.08)) 70%,transparent);}
.dtb-act:disabled{opacity:.45;cursor:default;}
.dtb-act.stop{border-color:rgba(235,90,90,.45);color:#ff9a9a;background:rgba(235,90,90,.08);}
.dtb-act.stop:hover{background:rgba(235,90,90,.16);}
.dtb-act.confirm{border-color:rgba(240,180,60,.55);color:#f0c46a;background:rgba(240,180,60,.08);}
.dtb-act.confirm:hover{background:rgba(240,180,60,.16);}
.dtb-act.danger{border-color:rgba(235,90,90,.55);color:#ffb0b0;}
.dtb-act.danger:hover{background:rgba(235,90,90,.14);}
.dtb-note{color:var(--dsw-alias-label-tertiary,#9a9aa5);font:var(--dsw-font-xxxs-11,11px);line-height:1.55;border-left:2px solid rgba(120,150,255,.4);padding:2px 0 2px 8px;}
.dtb-note.warn{border-left-color:rgba(240,180,60,.55);}
.dtb-note.err{border-left-color:rgba(235,90,90,.6);color:#ffb4b4;}
.dtb-states{display:flex;gap:6px;flex-wrap:wrap;}
.dtb-st{border:1px solid var(--dsw-alias-border-l2,rgba(128,128,128,.25));border-radius:6px;padding:2px 8px;font:var(--dsw-font-xxxs-11,11px);display:inline-flex;gap:5px;align-items:center;}
.dtb-st b{color:var(--dsw-alias-label-tertiary,#9a9aa5);font-weight:600;}
`;
var ago6 = (ts) => {
  if (!ts || !Number.isFinite(ts)) return "";
  const s = Math.max(1, Math.round((Date.now() - ts) / 1e3));
  if (s < 60) return s + " \u79D2\u524D";
  const m = Math.round(s / 60);
  if (m < 60) return m + " \u5206\u949F\u524D";
  const h = Math.round(m / 60);
  if (h < 24) return h + " \u5C0F\u65F6\u524D";
  return Math.round(h / 24) + " \u5929\u524D";
};
var fmt2 = (ts) => {
  if (!ts || !Number.isFinite(ts)) return "\u2014";
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
};
var STATUS_LABEL = {
  backlog: "\u5F85\u89C4\u5212",
  todo: "\u5F85\u529E",
  running: "\u8FDB\u884C\u4E2D",
  done: "\u5DF2\u5B8C\u6210",
  failed: "\u5DF2\u5931\u8D25"
};
var INITIAL_LOCAL = {
  view: "active",
  selectedId: null,
  confirmDelete: null,
  busyTaskId: null,
  actionError: null,
  notice: null
};
var reconcileStore = null;
var actionClient = null;
function bindTaskBoard(reconcile, client2) {
  reconcileStore = reconcile;
  actionClient = client2;
  return () => {
    reconcileStore = null;
    actionClient = null;
  };
}
function useTaskBoardState() {
  return (0, import_react10.useSyncExternalStore)(
    (f) => {
      const r = reconcileStore;
      if (!r) return () => {
      };
      return r.subscribe(f);
    },
    () => reconcileStore?.getState() ?? EMPTY_STATE2,
    () => EMPTY_STATE2
  );
}
var EMPTY_STATE2 = {
  ready: false,
  hostReachable: false,
  revision: 0,
  tasks: [],
  archivedSessionIds: [],
  sessionsSource: false,
  workspacesSource: false
};
var pendingOpenId = null;
var pendingSubs = /* @__PURE__ */ new Set();
function notifyPending() {
  for (const f of [...pendingSubs]) {
    try {
      f();
    } catch {
    }
  }
}
function requestOpenTask(id) {
  pendingOpenId = id;
  notifyPending();
}
function clearPendingOpen() {
  if (pendingOpenId === null) return;
  pendingOpenId = null;
  notifyPending();
}
function usePendingOpenId() {
  return (0, import_react10.useSyncExternalStore)(
    (f) => {
      pendingSubs.add(f);
      return () => {
        pendingSubs.delete(f);
      };
    },
    () => pendingOpenId,
    () => null
  );
}
function SourceBadges({ state: state3 }) {
  const badges = [];
  if (!state3.hostReachable && state3.ready) {
    badges.push(
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-badge", style: { borderColor: "rgba(235,90,90,.4)", color: "#ffb4b4" }, children: [
        "\u4EFB\u52A1\u677F\u5BBF\u4E3B\u4E0D\u53EF\u8FBE",
        state3.hostError ? `\uFF1A${state3.hostError}` : ""
      ] }, "host")
    );
  } else if (!state3.ready) {
    badges.push(
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-badge", children: "\u6B63\u5728\u8BFB\u53D6\u4EFB\u52A1\u677F\u5BBF\u4E3B\u2026" }, "host")
    );
  }
  if (state3.ready && !state3.workspacesSource) {
    badges.push(
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-badge", children: "\u5F52\u6863\u72B6\u6001\u6E90\u4E0D\u53EF\u7528\uFF08\u4F1A\u8BDD\u5F52\u6863\u6807\u8BB0\u6682\u7F3A\uFF09" }, "ws")
    );
  }
  return /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(import_jsx_runtime10.Fragment, { children: badges });
}
function TaskCardView({ p, onOpen: onOpen2 }) {
  const { task, attach, attention } = p;
  const latest = latestExecutionOf(task.executions);
  const projects = useProjects();
  const wsCat = useWorkspaceCatalog();
  const pid = projectRegistry.projectOfTask(task.id);
  const prjName = pid === void 0 ? void 0 : projects.find((pr) => pr.id === pid)?.name;
  const wsTitle = task.workspaceId === void 0 ? void 0 : wsCat.items.find((w) => w.workspaceId === task.workspaceId)?.title;
  const chip = !p.taskArchived ? scheduleChipOf(task.schedule) : task.schedule?.enabled === true ? scheduleChipOf(task.schedule) : null;
  return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("button", { type: "button", className: "dtb-card", "data-dsh-task-card": task.id, "data-status": task.status, onClick: () => onOpen2(task.id), children: [
    /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-cardline", children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: `dtb-tag ${task.status}`, children: STATUS_LABEL[task.status] ?? task.status }),
      p.taskArchived ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-tag arch", children: "\u4EFB\u52A1\u5DF2\u5F52\u6863" }) : null,
      attach?.archived ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-tag arch", title: "\u8BE5\u4EFB\u52A1\u7684\u6267\u884C\u4F1A\u8BDD\u5728\u5B98\u65B9\u4F1A\u8BDD\u5F52\u6863\u96C6\u4E2D", children: "\u4F1A\u8BDD\u5DF2\u5F52\u6863" }) : null,
      attention !== null ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-tag attention", children: attentionLabel(attention) }) : null,
      chip !== null ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "span",
        {
          className: `dtb-tag ${chip.tone === "on" ? "periodic" : "off"}`,
          "data-tk-chip": "periodic",
          "data-tk-periodic-state": chip.tone,
          title: chip.detail !== null ? `${chip.label} \xB7 ${chip.detail}\uFF08\u5728\u5E94\u7528\u5185\u6309\u5468\u671F\u81EA\u52A8\u6267\u884C\uFF09` : `${chip.label}\uFF08\u5728\u5E94\u7528\u5185\u6309\u5468\u671F\u81EA\u52A8\u6267\u884C\uFF09`,
          children: chip.label
        }
      ) : null
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-cardtitle", children: task.title }),
    task.description !== "" ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", style: { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: task.description }) : null,
    prjName !== void 0 || wsTitle !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-cardline", children: [
      prjName !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-tag prj", "data-dtb-chip": "project", title: `\u8BE5\u9879\u76EE\u4E2D\u7684\u4EFB\u52A1 \xB7 \u70B9\u5361\u7247\u6253\u5F00\u4EFB\u52A1\u677F\u8BE6\u60C5`, children: [
        "\u9879\u76EE \xB7 ",
        prjName
      ] }) : null,
      wsTitle !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-tag ws", "data-dtb-chip": "workspace", title: "\u8BE5\u4EFB\u52A1\u6267\u884C\u7ED1\u5B9A\u7684\u5DE5\u4F5C\u533A", children: [
        "\u5DE5\u4F5C\u533A \xB7 ",
        wsTitle
      ] }) : null
    ] }) : null,
    /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-cardline", children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-sub", children: [
        ago6(task.updatedAt),
        " \u66F4\u65B0"
      ] }),
      latest !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-sub", "data-tk-last-run": "1", children: [
        execResultView(latest)?.text ?? "\u5DF2\u7ED3\u675F",
        task.executions.length > 1 ? ` \xB7 \u5171 ${task.executions.length} \u6B21` : ""
      ] }) : null,
      recurringEnabledOf(task.schedule) && task.schedule?.nextRunAt !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-sub", "data-tk-next-run": "1", children: [
        "\u4E0B\u6B21 ",
        fmt2(task.schedule.nextRunAt)
      ] }) : null,
      attach?.sessionId !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", title: attach.sessionId, children: "\u2301 \u6709\u4F1A\u8BDD" }) : null
    ] })
  ] });
}
function attentionLabel(a) {
  switch (a.kind) {
    case "confirm-permission":
      return "\u5F85\u786E\u8BA4\u6743\u9650";
    case "failed":
    case "task-error":
    case "unknown-failure":
      return "\u9700\u5904\u7406";
  }
}
function Detail({ p, state: state3, local, onBack, runAction, openConversation, onAckMissed }) {
  const { task, attach, attention, caps } = p;
  const latest = task.executions.length > 0 ? task.executions[task.executions.length - 1] : void 0;
  const busy = local.busyTaskId === task.id;
  const hostBusy = () => busy || !state3.hostReachable || !actionClient;
  const exec = (kind) => {
    runAction(kind, task.id);
  };
  const showRunningGuard = !caps.delete && (task.status === "running" || task.executions.some((e) => e.endedAt === void 0));
  const sessionId = latest?.sessionId;
  const origin = personalTasksStore.originOf(task.id);
  const history = executionHistoryRows(task.executions);
  const histSummary = execHistorySummary(task.executions);
  const schedOn = recurringEnabledOf(task.schedule);
  const armedBase = task.schedule !== void 0 ? personalTasksStore.armedAtOf(task.id) : void 0;
  const refBase = task.schedule !== void 0 ? armedBase ?? task.schedule.lastTriggeredAt ?? task.createdAt : task.createdAt;
  const uncertainBase = task.schedule !== void 0 && armedBase === void 0 && task.schedule.lastTriggeredAt === void 0;
  const missedSummary = task.schedule !== void 0 && schedOn ? summarizeMissed(task.schedule.cron, refBase, Date.now(), task.executions, personalTasksStore.missedAcksOf(task.id), uncertainBase) : null;
  return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-detail", "data-dsh-task-detail": task.id, children: [
    /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-dhead", children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("h3", { className: "dtb-dtitle", children: task.title }),
        task.description !== "" ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-desc", children: task.description }) : null
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("button", { type: "button", className: "dtb-act", onClick: onBack, children: "\u8FD4\u56DE\u5217\u8868" })
    ] }),
    task.prompt !== "" && task.prompt !== task.title ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-prompt", title: "\u4EFB\u52A1\u6307\u4EE4\u539F\u6587", children: [
      "Prompt\uFF1A",
      task.prompt
    ] }) : null,
    /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-states", children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-st", children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("b", { children: "\u4EFB\u52A1" }),
        STATUS_LABEL[task.status] ?? task.status,
        p.taskArchived ? "\uFF08\u5DF2\u5F52\u6863\uFF09" : ""
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-st", children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("b", { children: "\u6267\u884C" }),
        executionStateText(latest)
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-st", children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("b", { children: "\u4F1A\u8BDD" }),
        attach === void 0 ? "\u672A\u7ED1\u5B9A" : attach.running === true ? "\u8FD0\u884C\u4E2D" : attach.running === false ? "\u7A7A\u95F2" : attach.archived ? "\u5DF2\u5F52\u6863" : "\u672A\u77E5",
        attach?.archived ? "\uFF08\u5DF2\u5F52\u6863\uFF09" : ""
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-st", children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("b", { children: "\u6CE8\u610F" }),
        attention === null ? "\u65E0" : attentionLabel(attention)
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-kv", children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u4EFB\u52A1 ID" }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", style: { wordBreak: "break-all" }, children: task.id }),
      task.mode ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u6267\u884C Agent" }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", children: task.mode })
      ] }) : null,
      task.permission ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u6743\u9650\u6863" }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-sub", children: [
          task.permission,
          task.permissionConfirmedAt !== void 0 ? "\uFF08\u5DF2\u786E\u8BA4\uFF09" : caps.confirmPermission ? "\uFF08\u5F85\u786E\u8BA4\uFF09" : ""
        ] })
      ] }) : null,
      task.schedule !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u5468\u671F" }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-sub", "data-tk-detail-schedule": "1", children: [
          scheduleChipOf(task.schedule)?.label ?? "\u5B9A\u671F",
          scheduleChipOf(task.schedule)?.detail !== null ? ` \xB7 ${scheduleChipOf(task.schedule)?.detail}` : ""
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u4E0B\u6B21\u6267\u884C" }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", "data-tk-detail-next": "1", children: task.schedule.enabled ? task.schedule.nextRunAt !== void 0 ? fmt2(task.schedule.nextRunAt) : "\u5BBF\u4E3B\u5C1A\u672A\u7ED9\u51FA" : "\u5DF2\u505C\u7528\uFF08\u4E0D\u518D\u5230\u671F\u6267\u884C\uFF09" }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u4E0A\u6B21\u5230\u671F" }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", "data-tk-detail-last": "1", children: task.schedule.lastTriggeredAt !== void 0 ? fmt2(task.schedule.lastTriggeredAt) : "\u2014" })
      ] }) : null,
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u521B\u5EFA\u65F6\u95F4" }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", children: fmt2(task.createdAt) }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u66F4\u65B0\u65F6\u95F4" }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", children: fmt2(task.updatedAt) }),
      task.archivedAt !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u5F52\u6863\u65F6\u95F4" }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", children: fmt2(task.archivedAt) })
      ] }) : null,
      latest !== void 0 && sessionId !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u6267\u884C\u4F1A\u8BDD" }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", style: { wordBreak: "break-all" }, children: sessionId })
      ] }) : null
    ] }),
    task.schedule !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-note", "data-tk-periodic-note": "1", children: "\u5B9A\u671F\u4EFB\u52A1\u7531\u4EFB\u52A1\u677F\u5BBF\u4E3B\u6309\u5468\u671F\u81EA\u52A8\u6267\u884C \u2014\u2014 \u4EC5\u5728 DeepSeek Harness \u8FD0\u884C\u65F6\u624D\u4F1A\u89E6\u53D1\uFF1B \u5E94\u7528\u672A\u8FD0\u884C\u671F\u95F4\u5230\u671F\u7684\u65F6\u523B\u4E0D\u4F1A\u88AB\u81EA\u52A8\u8865\u8DD1\u3002" }) : null,
    missedSummary !== null ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-sec", "data-tk-missed": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-k", children: "\u9519\u8FC7\u7684\u65F6\u95F4" }),
      !missedSummary.analyzable ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-empty", children: "\u8BE5\u4EFB\u52A1\u7684\u5468\u671F\u89C4\u5219\u8F83\u7279\u6B8A\uFF0C\u6682\u65F6\u65E0\u6CD5\u7CBE\u786E\u63A8\u7B97\u9519\u8FC7\u7684\u65F6\u95F4 \u2014\u2014 \u53EF\u770B\u4E0A\u9762\u7684\u6267\u884C\u8BB0\u5F55\u6216\u624B\u52A8\u300C\u8FD0\u884C\u300D\u3002" }) : missedSummary.missed.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-empty", "data-tk-missed-none": "1", children: [
        missedSummary.expected === 0 ? "\u8FD8\u6CA1\u6709\u5230\u8FC7\u6267\u884C\u65F6\u95F4\u3002" : "\u6CA1\u6709\u672A\u5904\u7406\u7684\u9519\u8FC7\u65F6\u95F4\uFF08\u5E94\u6267\u884C\u70B9\u5747\u5DF2\u6267\u884C\u6216\u5DF2\u6807\u4E3A\u5DF2\u5904\u7406\uFF09\u3002",
        missedSummary.uncertain ? "\uFF08\u6309\u4EFB\u52A1\u521B\u5EFA\u65F6\u95F4\u63A8\u7B97\uFF0C\u53EF\u80FD\u4E0D\u7CBE\u786E\uFF09" : ""
      ] }) : /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-empty", children: [
          "\u5B9A\u671F\u4EFB\u52A1\u4EC5\u5728 DeepSeek Harness \u8FD0\u884C\u65F6\u6267\u884C \u2014\u2014 \u5E94\u7528\u672A\u8FD0\u884C\u671F\u95F4\u5230\u671F\u7684\u65F6\u523B\u4E0D\u4F1A\u81EA\u52A8\u8865\u8DD1\uFF0C \u4F1A\u51FA\u73B0\u5728\u8FD9\u91CC\uFF1A\u53EF\u5BF9\u4EFB\u610F\u4E00\u6B21\u300C\u8865\u6267\u884C\u4E00\u6B21\u300D\uFF08\u73B0\u5728\u8FD0\u884C\u4E00\u6B21\uFF09\u6216\u300C\u6807\u4E3A\u5DF2\u5904\u7406\u300D\u3002",
          missedSummary.uncertain ? "\uFF08\u6309\u4EFB\u52A1\u521B\u5EFA\u65F6\u95F4\u63A8\u7B97\uFF0C\u53EF\u80FD\u4E0D\u7CBE\u786E\uFF09" : ""
        ] }),
        missedSummary.missed.map((t) => /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-cardline", "data-tk-missed-row": "1", children: [
          /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-sub", children: [
            "\u5E94\u6267\u884C ",
            fmt2(t)
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
            "button",
            {
              type: "button",
              className: "dtb-act",
              "data-dsh-action": "missed-run",
              disabled: hostBusy(),
              onClick: () => exec("run"),
              children: "\u8865\u6267\u884C\u4E00\u6B21"
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
            "button",
            {
              type: "button",
              className: "dtb-act",
              "data-dsh-action": "missed-ack",
              disabled: busy,
              onClick: () => onAckMissed(task.id, t),
              children: "\u6807\u4E3A\u5DF2\u5904\u7406"
            }
          )
        ] }, t))
      ] })
    ] }) : null,
    origin !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-sec", "data-tk-origin-session": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-k", children: "\u6765\u6E90\u4F1A\u8BDD" }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-cardline", children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-sub", children: [
          "\u8BE5\u4EFB\u52A1\u7531\u4F1A\u8BDD\u300C",
          origin.title ?? "\u5B98\u65B9\u4F1A\u8BDD",
          "\u300D\u521B\u5EFA\u800C\u6765\uFF08\u5185\u5BB9\u4FDD\u7559\u5728\u5B98\u65B9\u4F1A\u8BDD\u4E2D\uFF09"
        ] }),
        caps.openConversation ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
          "button",
          {
            type: "button",
            className: "dtb-act",
            "data-dsh-action": "open-origin-session",
            disabled: busy,
            onClick: () => openConversation(origin.sessionId),
            children: "\u6253\u5F00\u4F1A\u8BDD"
          }
        ) : null
      ] })
    ] }) : null,
    latest !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(ExecutionLine, { execution: latest }) : null,
    history.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-sec", "data-tk-exec-history": "1", children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-k", children: [
        "\u5168\u90E8\u6267\u884C\u8BB0\u5F55 \xB7 \u5171 ",
        histSummary.total,
        " \u6B21",
        histSummary.succeeded > 0 ? ` \xB7 \u6210\u529F ${histSummary.succeeded}` : "",
        histSummary.failed > 0 ? ` \xB7 \u5931\u8D25 ${histSummary.failed}` : "",
        histSummary.cancelled > 0 ? ` \xB7 \u5DF2\u53D6\u6D88 ${histSummary.cancelled}` : "",
        histSummary.running > 0 ? ` \xB7 \u8FDB\u884C\u4E2D ${histSummary.running}` : ""
      ] }),
      history.map((e) => {
        const v = execResultView(e);
        const toneCls = v?.kind === "running" ? "running" : v?.kind === "succeeded" ? "done" : v?.kind === "failed" ? "failed" : "todo";
        return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-cardline", "data-tk-exec-row": "1", children: [
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: `dtb-tag ${toneCls}`, children: v?.text ?? "\u5DF2\u7ED3\u675F" }),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-sub", children: [
            "\u5F00\u59CB ",
            fmt2(e.startedAt),
            e.endedAt !== void 0 ? ` \xB7 \u7ED3\u675F ${fmt2(e.endedAt)}` : " \xB7 \u8FDB\u884C\u4E2D"
          ] }),
          e.error !== void 0 && e.error !== "" ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", style: { color: "#ffb4b4" }, title: e.error, children: "\u5931\u8D25\u539F\u56E0" }) : null,
          caps.openConversation && e.sessionId !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
            "button",
            {
              type: "button",
              className: "dtb-act",
              style: { marginLeft: "auto" },
              disabled: busy,
              onClick: () => openConversation(e.sessionId),
              children: "\u6253\u5F00\u4F1A\u8BDD"
            }
          ) : null
        ] }, e.id);
      })
    ] }) : null,
    latest?.error ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-note err", children: [
      "\u6267\u884C\u9519\u8BEF\uFF08\u5B98\u65B9\u539F\u6837\uFF09\uFF1A",
      latest.error
    ] }) : null,
    task.error ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-note err", children: [
      "\u4EFB\u52A1\u9519\u8BEF\uFF1A",
      task.error
    ] }) : null,
    attention?.kind === "confirm-permission" ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-note warn", children: "\u6743\u9650\u6863\u9AD8\u4E8E\u4F1A\u8BDD\u9ED8\u8BA4\u4E14\u5C1A\u672A\u4EBA\u5DE5\u786E\u8BA4 \u2014\u2014 \u5BBF\u4E3B\u5728\u786E\u8BA4\u524D\u62D2\u7EDD\u6267\u884C\u3002\u70B9\u300C\u786E\u8BA4\u6743\u9650\u7ED1\u5B9A\u300D\u7531\u5B98\u65B9\u653E\u884C\uFF08\u4E0D\u7ED5\u8FC7\u5BBF\u4E3B\u95E8\u63A7\uFF09\u3002" }) : null,
    attention?.kind === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-note warn", children: "\u8BE5\u4EFB\u52A1\u6700\u8FD1\u4E00\u6B21\u6267\u884C\u5DF2\u5931\u8D25\uFF0C\u53EF\u300C\u91CD\u8DD1\u300D\u6216\u5148\u67E5\u770B\u9519\u8BEF\u3002" }) : null,
    /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-acts", children: [
      caps.openConversation && sessionId !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act",
          "data-dsh-action": "open-conversation",
          disabled: busy,
          onClick: () => openConversation(sessionId),
          children: "\u6253\u5F00\u4F1A\u8BDD"
        }
      ) : null,
      caps.confirmPermission ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act confirm",
          "data-dsh-action": "confirm-permission",
          disabled: hostBusy(),
          onClick: () => exec("confirm-permission"),
          children: "\u786E\u8BA4\u6743\u9650\u7ED1\u5B9A"
        }
      ) : null,
      caps.stop ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act stop",
          "data-dsh-action": "stop",
          disabled: busy,
          onClick: () => exec("stop"),
          children: "\u505C\u6B62\u4EFB\u52A1"
        }
      ) : null,
      caps.rerun ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act",
          "data-dsh-action": "rerun",
          disabled: hostBusy(),
          onClick: () => exec("rerun"),
          children: "\u91CD\u8DD1"
        }
      ) : null,
      task.schedule !== void 0 && !p.taskArchived && task.schedule.enabled ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act",
          "data-dsh-action": "disable-schedule",
          "data-tk-schedule-toggle": "1",
          title: "\u505C\u7528\u81EA\u52A8\u5230\u671F\u6267\u884C\uFF08\u4EFB\u52A1\u4E0E\u5386\u53F2\u4FDD\u7559\uFF0C\u4E4B\u540E\u53EF\u518D\u542F\u7528\uFF09",
          disabled: hostBusy(),
          onClick: () => exec("disable-schedule"),
          children: "\u505C\u7528\u5468\u671F"
        }
      ) : null,
      task.schedule !== void 0 && !p.taskArchived && !task.schedule.enabled ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act",
          "data-dsh-action": "enable-schedule",
          "data-tk-schedule-toggle": "1",
          title: "\u542F\u7528\u540E\u7531\u5BBF\u4E3B\u5728\u5E94\u7528\u5185\u6309\u5468\u671F\u81EA\u52A8\u6267\u884C",
          disabled: hostBusy(),
          onClick: () => exec("enable-schedule"),
          children: "\u542F\u7528\u5468\u671F"
        }
      ) : null,
      caps.run ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act",
          "data-dsh-action": "run",
          disabled: hostBusy(),
          onClick: () => exec("run"),
          children: "\u8FD0\u884C"
        }
      ) : null,
      !caps.run && !caps.rerun && caps.moveTodo && !p.taskArchived ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act",
          "data-dsh-action": "move-todo",
          disabled: hostBusy(),
          onClick: () => exec("move-todo"),
          children: "\u79FB\u5230\u5F85\u529E"
        }
      ) : null,
      caps.moveBacklog ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act",
          "data-dsh-action": "move-backlog",
          disabled: hostBusy(),
          onClick: () => exec("move-backlog"),
          children: "\u79FB\u5230\u5F85\u89C4\u5212"
        }
      ) : null,
      caps.archive ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act",
          "data-dsh-action": "archive",
          disabled: hostBusy(),
          onClick: () => exec("archive"),
          children: "\u5F52\u6863"
        }
      ) : null,
      caps.restore ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act",
          "data-dsh-action": "restore",
          disabled: hostBusy(),
          onClick: () => exec("restore"),
          children: "\u6062\u590D"
        }
      ) : null,
      caps.delete ? local.confirmDelete === task.id ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act",
          "data-dsh-action": "delete-cancel",
          disabled: busy,
          onClick: () => exec("cancel-delete"),
          children: "\u53D6\u6D88\u5220\u9664"
        }
      ) : /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
        "button",
        {
          type: "button",
          className: "dtb-act danger",
          "data-dsh-action": "delete",
          disabled: busy,
          onClick: () => exec("delete"),
          children: "\u5220\u9664\u4EFB\u52A1"
        }
      ) : null
    ] }),
    showRunningGuard ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-note warn", "data-dsh-delete-guard": "1", children: "\u4EFB\u52A1\u4ECD\u5728\u8FD0\u884C \u2014\u2014 \u4E0D\u5141\u8BB8\u76F4\u63A5\u5220\u9664\uFF08\u5B98\u65B9\u89C4\u5219\uFF1Arunning task cannot be deleted\uFF09\u3002 \u8BF7\u5148\u300C\u505C\u6B62\u4EFB\u52A1\u300D\uFF0C\u5F85\u5BBF\u4E3B\u5C06\u4EFB\u52A1\u5F52\u4F4D\u540E\u518D\u5220\u9664\u3002" }) : null,
    local.confirmDelete === task.id && caps.delete ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-note warn", "data-dsh-delete-confirm": "1", children: [
      "\u786E\u8BA4\u5220\u9664\u4EFB\u52A1\u300C",
      task.title,
      "\u300D\uFF1F\u6B64\u64CD\u4F5C\u5C06\u5220\u9664\u4EFB\u52A1\u8BB0\u5F55\uFF08\u5B98\u65B9\u8D26\u672C\uFF09\uFF0C\u4E0D\u53EF\u64A4\u9500\u3002",
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-acts", style: { marginTop: 6 }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
          "button",
          {
            type: "button",
            className: "dtb-act danger",
            "data-dsh-action": "delete-confirm",
            disabled: busy,
            onClick: () => exec("delete"),
            children: busy ? "\u5220\u9664\u4E2D\u2026" : "\u786E\u8BA4\u5220\u9664"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("button", { type: "button", className: "dtb-act", onClick: () => exec("cancel-delete"), children: "\u53D6\u6D88" })
      ] })
    ] }) : null,
    local.actionError ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-note err", "data-dsh-action-error": "1", children: [
      "\u64CD\u4F5C\u5931\u8D25\uFF08\u5B98\u65B9\u539F\u6837\uFF09\uFF1A",
      local.actionError
    ] }) : null,
    local.notice ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-note", "data-dsh-action-notice": "1", children: local.notice }) : null,
    busy ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-sub", children: "\u6B63\u5728\u8BF7\u6C42\u5BBF\u4E3B\u2026" }) : null
  ] });
}
function executionStateText(execution) {
  if (execution === void 0) return "\u672A\u6267\u884C";
  if (execution.endedAt === void 0) return "\u6267\u884C\u4E2D";
  if (execution.result === "succeeded") return "\u6210\u529F";
  if (execution.result === "cancelled") return "\u5DF2\u53D6\u6D88";
  if (execution.result === "failed") return "\u5931\u8D25";
  return "\u5DF2\u7ED3\u675F";
}
function ExecutionLine({ execution }) {
  return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-sec", style: { borderTop: "none", paddingTop: 0 }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-k", children: "\u6700\u8FD1\u4E00\u6B21\u6267\u884C" }),
    /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-kv", children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u7ED3\u679C" }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", children: execution.endedAt === void 0 ? "\u8FDB\u884C\u4E2D" : execution.result === "succeeded" ? "\u6210\u529F" : execution.result === "failed" ? "\u5931\u8D25" : execution.result === "cancelled" ? "\u5DF2\u53D6\u6D88" : "\u672A\u77E5" }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u5F00\u59CB" }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", children: fmt2(execution.startedAt) }),
      execution.endedAt !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u7ED3\u675F" }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", children: fmt2(execution.endedAt) })
      ] }) : null,
      execution.sessionId !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "\u4F1A\u8BDD ID" }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", style: { wordBreak: "break-all" }, children: execution.sessionId })
      ] }) : null
    ] })
  ] });
}
var COLUMN_ORDER = ["backlog", "todo", "running", "done", "failed"];
function TaskBoardView() {
  const state3 = useTaskBoardState();
  const [local, setLocalRaw] = (0, import_react10.useState)(INITIAL_LOCAL);
  const [refreshTick, setRefreshTick] = (0, import_react10.useState)(0);
  const pendingOpen = usePendingOpenId();
  const setLocal = (patch) => {
    setLocalRaw((prev) => ({ ...prev, ...patch }));
  };
  const groups = (0, import_react10.useMemo)(() => groupBoard(state3.tasks), [state3.tasks]);
  const attentionRows = (0, import_react10.useMemo)(
    () => state3.tasks.filter((p) => p.attention !== null).sort((a, b) => (b.attention?.weight ?? 0) - (a.attention?.weight ?? 0)),
    [state3.tasks]
  );
  const selected = state3.tasks.find((p) => p.task.id === local.selectedId);
  (0, import_react10.useEffect)(() => {
    if (pendingOpen === null) return;
    setLocal({ selectedId: pendingOpen, confirmDelete: null, actionError: null, notice: null, view: "active" });
    clearPendingOpen();
  }, [pendingOpen]);
  const openTask = (id) => {
    setLocal({ selectedId: id, confirmDelete: null, actionError: null, notice: null, view: "active" });
  };
  const closeDetail = () => {
    setLocal({ selectedId: null, confirmDelete: null, actionError: null, notice: null });
  };
  const doRefresh = () => {
    const r = reconcileStore;
    if (!r) return;
    void r.refresh().then(() => setRefreshTick((n) => n + 1));
  };
  const openConversation = (sessionId) => {
    openSessionFn5?.(sessionId);
  };
  const handleAckMissed = (taskId, at) => {
    try {
      personalTasksStore.ackMissed(taskId, at);
      setLocal({ notice: "\u5DF2\u6807\u4E3A\u5DF2\u5904\u7406\uFF1A\u4E0D\u518D\u5217\u5165\u300C\u9519\u8FC7\u7684\u65F6\u95F4\u300D\uFF08\u4EC5\u672C\u5C42\u6807\u8BB0\uFF0C\u5B98\u65B9\u6267\u884C\u8BB0\u5F55\u4E0D\u53D8\uFF09\u3002" });
    } catch {
      setLocal({ actionError: "\u672C\u5730\u6807\u8BB0\u5199\u5165\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002" });
    }
  };
  const runAction = (kind, taskId) => {
    if (kind === "cancel-delete") {
      setLocal({ confirmDelete: null, actionError: null });
      return;
    }
    const client2 = actionClient;
    const r = reconcileStore;
    if (!client2 || !r) {
      setLocal({ actionError: "\u4EFB\u52A1\u677F\u5BA2\u6237\u7AEF\u672A\u5C31\u7EEA" });
      return;
    }
    if (kind === "delete") {
      if (local.confirmDelete !== taskId) {
        setLocal({ confirmDelete: taskId, actionError: null, notice: null });
        return;
      }
    }
    const task = state3.tasks.find((p) => p.task.id === taskId)?.task;
    setLocal({ busyTaskId: taskId, actionError: null, notice: null, confirmDelete: kind === "delete" ? null : local.confirmDelete });
    const dispatch = async () => {
      try {
        let snapshot = null;
        let successNotice = null;
        switch (kind) {
          case "run":
            snapshot = await client2.run(taskId);
            break;
          case "rerun":
            snapshot = await client2.rerun(taskId);
            break;
          case "archive":
            snapshot = await client2.archive(taskId);
            break;
          case "restore":
            snapshot = await client2.restore(taskId);
            break;
          case "delete":
            snapshot = await client2.delete(taskId);
            break;
          case "confirm-permission":
            snapshot = await client2.confirmPermission(taskId);
            break;
          case "move-backlog":
            snapshot = await client2.move(taskId, "backlog");
            break;
          case "move-todo":
            snapshot = await client2.move(taskId, "todo");
            break;
          case "disable-schedule":
            snapshot = await client2.disableSchedule(taskId);
            successNotice = "\u5468\u671F\u5DF2\u505C\u7528\uFF1A\u4E0D\u518D\u81EA\u52A8\u5230\u671F\u6267\u884C\uFF08\u4EFB\u52A1\u4E0E\u5386\u53F2\u4FDD\u7559\uFF0C\u4E4B\u540E\u53EF\u518D\u542F\u7528\uFF09\u3002";
            break;
          case "enable-schedule": {
            const cron = task?.schedule?.cron;
            if (!cron) {
              setLocal({ busyTaskId: null, actionError: "\u8BE5\u4EFB\u52A1\u6CA1\u6709\u53EF\u542F\u7528\u7684\u5468\u671F\u89C4\u5219\uFF08\u5B98\u65B9\u8D26\u672C\u672A\u63D0\u4F9B\uFF09\u3002" });
              return;
            }
            snapshot = await client2.enableSchedule(taskId, cron);
            successNotice = "\u5468\u671F\u5DF2\u542F\u7528\uFF1A\u5BBF\u4E3B\u5C06\u5728\u5E94\u7528\u5185\u6309\u5468\u671F\u81EA\u52A8\u6267\u884C\uFF08\u4EC5\u5728 DeepSeek Harness \u8FD0\u884C\u65F6\u89E6\u53D1\uFF09\u3002";
            break;
          }
          case "stop": {
            const execSessionId = task?.executions.find((e) => e.endedAt === void 0)?.sessionId;
            if (!execSessionId) {
              setLocal({ busyTaskId: null, actionError: "\u8BE5\u6267\u884C\u5C1A\u672A\u7ED1\u5B9A\u4F1A\u8BDD\uFF0C\u65E0\u6CD5\u505C\u6B62\uFF08\u8BF7\u7A0D\u540E\u91CD\u8BD5\u6216\u5230\u5B98\u65B9\u4F1A\u8BDD\u5185\u505C\u6B62\uFF09" });
              return;
            }
            const stopped = await stopExecution(execSessionId);
            if (!stopped.ok) {
              setLocal({ busyTaskId: null, actionError: stopped.error ?? "\u505C\u6B62\u5931\u8D25\uFF08\u5B98\u65B9\u80FD\u529B\u4E0D\u53EF\u7528\uFF09\uFF0C\u8BF7\u5230\u5B98\u65B9\u4F1A\u8BDD\u5185\u505C\u6B62" });
              return;
            }
            setLocal({ busyTaskId: null, notice: "\u505C\u6B62\u8BF7\u6C42\u5DF2\u53D1\u9001\uFF1A\u4EFB\u52A1\u5C06\u7531\u5BBF\u4E3B\u786E\u8BA4\u540E\u5F52\u4F4D\uFF08\u56DE\u5230\u5F85\u529E\uFF09\u3002" });
            void r.refresh();
            return;
          }
        }
        if (snapshot !== null) {
          r.ingest(snapshot);
          setLocal({ busyTaskId: null, confirmDelete: null, notice: successNotice });
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        setLocal({ busyTaskId: null, actionError: message });
      }
    };
    void dispatch();
  };
  return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-root", "data-dsh-plugin": "dsh-personal-workspace", "data-e4fix-board": "1", children: [
    /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-h", children: [
      "\u4EFB\u52A1\u677F",
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-sub", children: "Task Control" }),
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("button", { type: "button", className: "dtb-act", style: { marginLeft: "auto" }, onClick: doRefresh, disabled: !state3.ready, children: "\u5237\u65B0" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(SourceBadges, { state: state3 }),
    local.selectedId === null ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-toolbar", children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("button", { type: "button", className: `dtb-toggle${local.view === "active" ? " on" : ""}`, onClick: () => setLocal({ view: "active", actionError: null }), children: [
          "Active\uFF08",
          groups.active.length,
          "\uFF09"
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("button", { type: "button", className: `dtb-toggle${local.view === "archived" ? " on" : ""}`, onClick: () => setLocal({ view: "archived", actionError: null }), children: [
          "Archived / History\uFF08",
          groups.archived.length,
          "\uFF09"
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(
          "button",
          {
            type: "button",
            className: `dtb-toggle${local.view === "attention" ? " on" : ""}`,
            "data-dtb-attention-toggle": "1",
            onClick: () => setLocal({ view: "attention", actionError: null }),
            children: [
              "\u9700\u8981\u5904\u7406\uFF08",
              attentionRows.length,
              "\uFF09"
            ]
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "dtb-k", children: "\u70B9\u51FB\u5361\u7247\u67E5\u770B\u4E0E\u63A7\u5236\u4EFB\u52A1" })
      ] }),
      !state3.ready ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-empty", children: "\u6B63\u5728\u8BFB\u53D6\u4EFB\u52A1\u677F\u2026\uFF08\u65E0\u6570\u636E\u65F6\u4E0D\u731C\u6D4B\uFF09" }) : !state3.hostReachable ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-empty", children: "\u4EFB\u52A1\u677F\u5BBF\u4E3B\u4E0D\u53EF\u7528 \u2014\u2014 \u8BF7\u786E\u8BA4\u5B98\u65B9\u4EFB\u52A1\u677F\u5DF2\u542F\u7528\u540E\u5237\u65B0\u3002" }) : local.view === "active" ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(ActiveColumns, { projected: groups.active, onOpen: openTask }) : local.view === "attention" ? (
        // 需要处理：只列真实需要人介入的任务（失败 / 权限确认 / 宿主错误）。
        /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-group", "data-dtb-attention": "1", children: attentionRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-empty", children: "\u5F53\u524D\u6CA1\u6709\u9700\u8981\u4F60\u5904\u7406\u7684\u4EFB\u52A1\uFF08\u5931\u8D25 / \u9700\u6743\u9650\u786E\u8BA4 / \u5BBF\u4E3B\u9519\u8BEF\u624D\u4F1A\u51FA\u73B0\u5728\u8FD9\u91CC\uFF09\u3002" }) : attentionRows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(TaskCardView, { p, onOpen: openTask }, p.task.id)) })
      ) : /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-group", children: groups.archived.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-empty", children: "\u6CA1\u6709\u5DF2\u5F52\u6863\u4EFB\u52A1\uFF08\u5F52\u6863 = \u5B98\u65B9\u8D26\u672C archivedAt\uFF1B\u4F1A\u8BDD\u5F52\u6863\u4E0D\u6539\u53D8\u4EFB\u52A1\u72B6\u6001\uFF09\u3002" }) : groups.archived.map((p) => /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(TaskCardView, { p, onOpen: openTask }, p.task.id)) })
    ] }) : selected === void 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-empty", children: [
      "\u4EFB\u52A1\u4E0D\u5B58\u5728\uFF08\u53EF\u80FD\u5DF2\u88AB\u5220\u9664\u6216\u5F52\u6863\uFF09\u3002",
      /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("button", { type: "button", className: "dtb-act", style: { marginLeft: 8 }, onClick: closeDetail, children: "\u8FD4\u56DE\u5217\u8868" })
    ] }) : /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
      Detail,
      {
        p: selected,
        state: state3,
        local,
        onBack: closeDetail,
        runAction,
        openConversation,
        onAckMissed: handleAckMissed
      }
    ),
    local.notice ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-note", "data-dsh-action-notice": "1", children: local.notice }) : null
  ] });
}
function ActiveColumns({ projected, onOpen: onOpen2 }) {
  const byStatus = /* @__PURE__ */ new Map();
  for (const status of COLUMN_ORDER) byStatus.set(status, []);
  for (const p of projected) {
    const list = byStatus.get(p.task.status);
    if (list) list.push(p);
    else byStatus.set(p.task.status, [p]);
  }
  return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(import_jsx_runtime10.Fragment, { children: [
    COLUMN_ORDER.map((status) => {
      const list = byStatus.get(status) ?? [];
      if (list.length === 0) return null;
      return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("div", { className: "dtb-group", "data-dsh-column": status, children: [
        /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("span", { className: "dtb-k", children: [
          STATUS_LABEL[status] ?? status,
          " \xB7 ",
          list.length
        ] }),
        list.map((p) => /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(TaskCardView, { p, onOpen: onOpen2 }, p.task.id))
      ] }, status);
    }),
    projected.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "dtb-empty", children: "\u4EFB\u52A1\u677F\u4E3A\u7A7A \u2014\u2014 \u7528\u300C\uFF0B\u65B0\u4EFB\u52A1\u300D\u6216\u5B98\u65B9 New Task \u521B\u5EFA\u4F60\u7684\u7B2C\u4E00\u4E2A\u4EFB\u52A1\u3002" }) : null
  ] });
}
var stopExecutor = null;
function setStopExecutor(fn) {
  stopExecutor = fn;
}
async function stopExecution(sessionId) {
  if (stopExecutor) return stopExecutor(sessionId);
  return { ok: false, error: "\u505C\u6B62\u80FD\u529B\u672A\u5C31\u7EEA" };
}
var openSessionFn5 = null;
function setOpenSessionForBoard(fn) {
  openSessionFn5 = fn;
}

// src/workstation/personal-workspace/src/client/layering.ts
var LAYERS = {
  /** Official AppFrame in-frame overlay seat (shell.overlay). */
  frameOverlay: 20,
  /** better-sidebar body-level panel host (all Aux panels live inside it). */
  auxHost: 25,
  /** better-sidebar right/bottom workbench panel. */
  auxPanel: 40,
  /** better-sidebar free-floating window. */
  auxFloat: 42,
  /** better-sidebar top-right "＋" toggle cluster. */
  auxToggle: 45,
  /** better-sidebar boundary error banner. */
  auxBoundary: 50,
  /** better-sidebar text-selection popup. */
  auxSelection: 60,
  /**
   * hud status bar & Inspector live between the Aux selection popup (60) and
   * the official Modal (1000): they are always-on chrome that must stay above
   * the workbench panels yet never cover a modal backdrop / toast.
   */
  hudStatus: 450,
  hudInspector: 550,
  /** Official primitives band (body-portaled when they need to escape). */
  popover: 100,
  modal: 1e3,
  toast: 1100
};
function mountIntoBody(node, z) {
  try {
    if (typeof document === "undefined" || typeof document.body === "undefined") return false;
    node.style.position = "fixed";
    node.style.zIndex = String(z);
    document.body.appendChild(node);
    return true;
  } catch {
    return false;
  }
}
function overlayRootFor(z) {
  try {
    if (typeof document === "undefined" || typeof document.body === "undefined") return null;
    const attr = "data-dpw-overlay";
    const existing = document.querySelector(`[${attr}="${String(z)}"]`);
    if (existing instanceof HTMLElement) return existing;
    const root = document.createElement("div");
    root.setAttribute(attr, String(z));
    root.style.cssText = `position:fixed;inset:0;pointer-events:none;z-index:${String(z)}`;
    document.body.appendChild(root);
    return root;
  } catch {
    return null;
  }
}
function removeOverlayRoot(z) {
  try {
    if (typeof document === "undefined") return;
    document.querySelectorAll(`[data-dpw-overlay="${String(z)}"]`).forEach((el) => el.remove());
  } catch {
  }
}

// src/workstation/personal-workspace/src/client/index.tsx
var import_jsx_runtime11 = require("react/jsx-runtime");
var inject = ["sessions"];
var PKG_VERSION = "0.1.20".length > 0 ? "0.1.20" : "0.1.20";
var BUILD_SHA = "a4a2092".length > 0 ? "a4a2092" : "dev";
function ensureDiag() {
  const w = window;
  if (!w.__dshDiag) w.__dshDiag = {};
  return w.__dshDiag;
}
function diagApplyTick(ctx) {
  try {
    const d = ensureDiag();
    const pkg = d.pkg ?? {};
    d.pkg = pkg;
    pkg.workspaceInstances = (pkg.workspaceInstances ?? 0) + 1;
    pkg.workspaceVersion = PKG_VERSION;
    pkg.workspaceSha = BUILD_SHA;
    const sha = d.sha ?? {};
    d.sha = sha;
    sha.workspace = BUILD_SHA;
    if (!d.slotsRaw) {
      const raw = typeof ctx.get === "function" ? ctx.get("slots") : void 0;
      if (raw && typeof raw === "object") d.slotsRaw = raw;
    }
  } catch {
  }
}
function apply(ctx) {
  try {
    applyInner(ctx);
  } catch (error) {
    console.warn("[dsh-personal-workspace] apply aborted (kept stock UI):", error);
  }
}
function betterSidebarOf(ctx) {
  try {
    const sb = typeof ctx.get === "function" ? ctx.get("betterSidebar") : void 0;
    if (sb && typeof sb.registerTab === "function") {
      return sb;
    }
    return null;
  } catch {
    return null;
  }
}
var workbench = null;
function openNewTaskTab(text) {
  try {
    pushStartPrefill(text ?? "");
    if (mainHostOk()) {
      mainViewShow("new-task");
      return true;
    }
    const wb = workbench;
    if (!wb || typeof wb.openTab !== "function") return false;
    wb.openTab({ type: "new-task", path: "new" });
    return true;
  } catch {
    return false;
  }
}
function usePersonalMainView() {
  return (0, import_react11.useSyncExternalStore)(mainViewSubscribe, mainViewGet, () => "conversation");
}
var MAIN_RENDER = {
  home: () => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(HomeView, {}),
  "task-board": () => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(TaskBoardView, {}),
  "new-task": () => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(NewTaskTab, {}),
  "project-center": () => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(ProjectCenterView, {}),
  "project-detail": () => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(ProjectDetailView, {}),
  unassigned: () => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(UnassignedView, {}),
  "workspace-center": () => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(WorkspaceCenterView, {}),
  recent: () => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(RecentView, {})
};
var MainBoundary = class extends import_react11.Component {
  state = { failed: null };
  static getDerivedStateFromError(error) {
    return { failed: error instanceof Error ? error.message : String(error) };
  }
  componentDidCatch(error) {
    const msg = error instanceof Error ? error.message : String(error);
    console.error(`[dsh-personal-workspace] \u4E2D\u592E\u4E3B\u533A\u89C6\u56FE\u300C${this.props.view}\u300D\u6E32\u67D3\u5D29\u6E83\uFF1A`, error);
    try {
      const w = window;
      const d = w.__dshDiag ??= {};
      d.crashes = d.crashes ?? [];
      d.crashes.push({ t: Date.now(), view: this.props.view, error: msg });
    } catch {
    }
  }
  render() {
    if (this.state.failed !== null) {
      return /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)(
        "div",
        {
          className: "dpw-main-host dpw-main-error",
          "data-dsh-plugin": "dsh-personal-workspace",
          "data-dsh-main-host": "1",
          "data-dsh-main-error": "1",
          "data-dsh-main-view": this.props.view,
          children: [
            "\u4E2D\u592E\u4E3B\u533A\u89C6\u56FE\u300C",
            this.props.view,
            "\u300D\u6E32\u67D3\u5931\u8D25\uFF0C\u5DF2\u663E\u793A\u9519\u8BEF\u5360\u4F4D\uFF08\u5DF2\u8BB0\u5165\u8BCA\u65AD\uFF09\u3002",
            /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("br", {}),
            /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("code", { children: this.state.failed }),
            /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("br", {}),
            /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("br", {}),
            "\u8BF7\u70B9\u51FB\u5DE6\u4FA7\u300C\u4F1A\u8BDD\u300D\u5207\u56DE\u5B98\u65B9\u4F1A\u8BDD\uFF0C\u6216\u6539\u7528\u8F85\u52A9\u9762\u677F\u6253\u5F00\u8BE5\u89C6\u56FE\u3002"
          ]
        }
      );
    }
    return this.props.children;
  }
};
function PersonalMainOccupant() {
  const view = usePersonalMainView();
  (0, import_react11.useEffect)(() => {
    try {
      if (typeof window === "undefined" || view === "conversation") return;
      const w = window;
      const d = w.__dshDiag ??= {};
      d.mounts = d.mounts ?? [];
      d.mounts.push({ t: performance.now(), view });
      if (d.mounts.length > 60) d.mounts.splice(0, d.mounts.length - 60);
    } catch {
    }
  }, [view]);
  if (view === "conversation") return null;
  const render = MAIN_RENDER[view];
  if (!render) return null;
  return /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { className: "dpw-main-host", "data-dsh-plugin": "dsh-personal-workspace", "data-dsh-main-host": "1", "data-dsh-main-view": view, children: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(MainBoundary, { view, children: render() }, view) });
}
function auxSeedOf(view) {
  switch (view) {
    case "task-board":
      return { type: "task-board", path: "board" };
    case "new-task":
      return { type: "new-task", path: "new" };
    case "home":
      return { type: "mission-control", path: "home" };
    case "project-center":
      return { type: "project-center", path: "center" };
    case "project-detail":
      return { type: "project-detail", path: "detail", title: "\u9879\u76EE\u8BE6\u60C5" };
    case "workspace-center":
      return { type: "workspace-center", path: "center" };
    case "recent":
      return { type: "recent", path: "recent" };
    default:
      return null;
  }
}
function navigateMain(view) {
  try {
    if (view === "conversation") {
      mainViewBackToConversation();
      return true;
    }
    if (mainHostOk()) {
      mainViewShow(view);
      return true;
    }
    const seed = auxSeedOf(view);
    if (!seed) return false;
    const wb = workbench;
    if (wb && typeof wb.openTab === "function") {
      wb.openTab(seed);
      return true;
    }
    return false;
  } catch {
    return false;
  }
}
function slotsOf(ctx) {
  try {
    const viaGet = typeof ctx.get === "function" ? ctx.get("slots") : void 0;
    const s = viaGet ?? ctx.slots ?? null;
    if (s && typeof s.register === "function") return s;
  } catch {
  }
  return null;
}
function applyInner(ctx) {
  if (typeof window === "undefined") return false;
  diagApplyTick(ctx);
  const getSessions2 = () => {
    try {
      return typeof ctx.get === "function" ? ctx.get("sessions") : void 0;
    } catch {
      return void 0;
    }
  };
  const openSession = (id) => {
    try {
      mainViewBackToConversation();
    } catch {
    }
    try {
      const s = getSessions2();
      s?.open?.(id);
    } catch {
    }
  };
  const mount = () => {
    const styleEl = document.createElement("style");
    styleEl.setAttribute("data-dsh-plugin", "dsh-personal-workspace");
    styleEl.textContent = CSS_WS + "\n" + CSS_HOME + "\n" + CSS_SELECTORS + "\n" + CSS_NEWTASK + "\n" + CSS_TASKBOARD + "\n" + CSS_RECENT + "\n" + CSS_PROJECT_CENTER + "\n" + CSS_PROJECT_DETAIL + CSS_UNASSIGNED + "\n" + CSS_WORKSPACE_CENTER + "\n" + CSS_MAIN_HOST;
    document.head.appendChild(styleEl);
    const offWsCat = bindWorkspaceCatalog(() => probeWorkspaces(ctx));
    const offBindings = bindSessionBindings(ctx, getSessions2);
    const offHome = bindHomeServices(getSessions2, openSession, createConversation(ctx, getSessions2, openSession));
    const boardClient = new TaskBoardClient();
    const sessionsList = adaptSnapshotStore(getSessions2());
    const workspacesList = {
      // PHASE I（§18/§21 真相修正）：目录**未就绪**时**不提供** archivedSessionIds 字段。
      //   旧实现恒返回数组（可能是空数组）→ reconcile 的 `!Array.isArray(ids)` 永不触发 →
      //   workspacesSource 恒 true → 全产品把「归档来源不可读」显示成「没有归档」（未知当 0）。
      //   现在：未就绪 → 投递 `{}`（= 未知），由 projection.archiveTruthOf 统一判定。
      getSnapshot: () => {
        const snap = workspaceCatalogSnapshot();
        return snap.ready ? { archivedSessionIds: snap.archivedSessionIds } : {};
      },
      subscribe: (f) => subscribeWorkspaceCatalog(f)
    };
    const reconcile = new TaskReconcile({
      fetchHost: () => boardClient.state(),
      sessionsList,
      workspacesList,
      subscribeHost: (listener) => boardClient.subscribe(listener)
    });
    const offBind = bindTaskBoard(reconcile, boardClient);
    const offRecent = bindRecentServices(getSessions2, reconcile, (sessionId) => openSession(sessionId), () => void openNewTaskTab());
    setOpenSessionForBoard((sessionId) => openSession(sessionId));
    setStopExecutor((sessionId) => stopViaBinding(getSessions2(), sessionId));
    const openBoardAt2 = (taskId) => {
      try {
        requestOpenTask(taskId);
        navigateMain("task-board");
      } catch {
      }
    };
    const offHomeTasks = bindHomeTaskSource(reconcile, openBoardAt2);
    const offProjectAction = bindProjectCenterAction(openBoardAt2);
    const offDetailSessions = bindProjectDetailSessions(getSessions2, () => reconcile.getState().archivedSessionIds);
    const offDetailArchive = reconcile.subscribe(
      () => refreshProjectDetailArchived(() => reconcile.getState().archivedSessionIds)
    );
    const offDetailActions = bindProjectDetailActions({
      openSession: (sessionId) => openSession(sessionId),
      openTaskBoard: openBoardAt2,
      openProjectCenter: () => {
        try {
          navigateMain("project-center");
        } catch {
        }
      },
      openNewTaskPanel: () => {
        try {
          openNewTaskTab("");
        } catch {
        }
      },
      // IA2-8：项目详情 → 工作区中心跳转（中央 Main；host 不可用自动回退 Aux）。
      openWorkspaceCenter: () => {
        try {
          navigateMain("workspace-center");
        } catch {
        }
      }
    });
    const offCenterDetail = bindProjectCenterDetail((projectId) => {
      setDetailProjectId(projectId);
      navigateMain("project-detail");
    });
    const offCenterUnassigned = bindProjectCenterUnassigned(() => {
      navigateMain("unassigned");
    });
    const offWsCenterActions = bindWorkspaceCenterActions({
      openSession: (sessionId) => openSession(sessionId),
      openFolder: (path) => {
        try {
          const wb = workbench;
          if (wb && typeof wb.openTab === "function") {
            wb.openTab({ type: "editor", path, meta: { dir: true } });
            return;
          }
        } catch {
        }
      },
      // IA2-8：工作区中心 → 项目详情跳转（置当前项目 + 中央 Main；host 不可用回退 Aux）。
      openProjectDetail: (projectId) => {
        setDetailProjectId(projectId);
        navigateMain("project-detail");
      }
    });
    reconcile.bind();
    const offAttention = bindAttentionFeed(reconcile);
    const offLocate = bindBoardOpenTask((taskId) => {
      try {
        requestOpenTask(taskId);
      } catch {
      }
    });
    let registered = false;
    const tryRegister = (sb) => {
      workbench = sb;
      if (registered) return true;
      try {
        registered = true;
        return true;
      } catch (error) {
        console.warn("[dsh-personal-workspace] registerTab failed:", error);
        registered = false;
        return false;
      }
    };
    const s0 = betterSidebarOf(ctx);
    if (s0) tryRegister(s0);
    let tries = 0;
    const iv = window.setInterval(() => {
      tries += 1;
      if (!registered) {
        const sb = betterSidebarOf(ctx);
        if (sb) tryRegister(sb);
      }
      if (registered || tries >= 40) window.clearInterval(iv);
    }, 100);
    const offBoard = startBoardGuard();
    const offMainHost = initMainHost({ slots: slotsOf(ctx), host: PersonalMainOccupant });
    return () => {
      try {
        window.clearInterval(iv);
      } catch {
      }
      try {
        offBoard();
      } catch {
      }
      try {
        offHome();
      } catch {
      }
      try {
        offBindings();
      } catch {
      }
      try {
        offHomeTasks();
      } catch {
      }
      try {
        offProjectAction();
      } catch {
      }
      try {
        offDetailSessions();
      } catch {
      }
      try {
        offDetailArchive();
      } catch {
      }
      try {
        offDetailActions();
      } catch {
      }
      try {
        offCenterDetail();
        offCenterUnassigned();
      } catch {
      }
      try {
        offWsCenterActions();
      } catch {
      }
      try {
        offBind();
      } catch {
      }
      try {
        offRecent();
      } catch {
      }
      try {
        offWsCat();
      } catch {
      }
      try {
        offAttention();
      } catch {
      }
      try {
        offLocate();
      } catch {
      }
      try {
        offMainHost();
      } catch {
      }
      try {
        reconcile.dispose();
      } catch {
      }
      styleEl.remove();
    };
  };
  if (typeof ctx.effect === "function") {
    ctx.effect(() => mount(), "dpw: workspace host");
  } else {
    mount();
  }
  return true;
}
function adaptSnapshotStore(svc) {
  try {
    const list = (svc ?? {})?.list;
    if (list !== null && list !== void 0 && typeof list.getSnapshot === "function" && typeof list.subscribe === "function") {
      return list;
    }
  } catch {
  }
  return null;
}
function probeWorkspaces(ctx) {
  try {
    const ws = typeof ctx.get === "function" ? ctx.get("workspaces") : void 0;
    if (ws && typeof ws === "object" && "list" in ws) {
      return ws;
    }
  } catch {
  }
  return null;
}
async function stopViaBinding(sessionsSvc, sessionId) {
  try {
    const svc = sessionsSvc;
    if (!svc || typeof svc.binding !== "function") {
      return { ok: false, error: "\u5B98\u65B9\u4F1A\u8BDD\u505C\u6B62\u80FD\u529B\u4E0D\u53EF\u7528\uFF08sessions.binding \u7F3A\u5931\uFF09\u2014\u2014\u8BF7\u5230\u5B98\u65B9\u4F1A\u8BDD\u5185\u505C\u6B62" };
    }
    const session = svc.binding(sessionId)?.session;
    if (!session || typeof session.cancel !== "function") {
      return { ok: false, error: "\u8BE5\u4F1A\u8BDD\u672A\u6FC0\u6D3B\uFF0C\u65E0\u6CD5\u505C\u6B62\uFF08\u8BF7\u5230\u5B98\u65B9\u4F1A\u8BDD\u5185\u64CD\u4F5C\uFF09" };
    }
    const result = await session.cancel();
    if (result && result.ok === false) {
      return { ok: false, error: result.error ?? "\u5BBF\u4E3B\u62D2\u7EDD\u4E86\u505C\u6B62\u8BF7\u6C42" };
    }
    return { ok: true };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}
function pickTargetWorkspace(opts, getSessions2) {
  if (opts.workspaceId && opts.workspaceId.length > 0) {
    return { workspaceId: opts.workspaceId };
  }
  const cat = workspaceCatalogSnapshot();
  if (!cat.ready) {
    return {
      workspaceId: null,
      reason: cat.probing ? "\u5B98\u65B9 workspaces \u670D\u52A1\u4ECD\u5728\u63A2\u6D4B\u4E2D" : "\u672C\u73AF\u5883\u672A\u63D0\u4F9B\u5B98\u65B9 workspaces \u670D\u52A1\uFF08capability limitation\uFF09"
    };
  }
  if (cat.items.length === 0) {
    return { workspaceId: null, reason: "\u5F53\u524D\u6CA1\u6709\u4EFB\u4F55\u5B98\u65B9\u5DE5\u4F5C\u533A\u76EE\u5F55" };
  }
  let currentId = "";
  try {
    const svc = getSessions2();
    const snap = svc?.list?.getSnapshot?.();
    const cur = snap?.current;
    currentId = typeof cur === "string" ? cur : "";
  } catch {
  }
  if (currentId) {
    const hit = cat.items.find((w) => w.sessionIds.includes(currentId));
    if (hit) return { workspaceId: hit.workspaceId };
  }
  const sorted = [...cat.items].sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0));
  return { workspaceId: sorted[0]?.workspaceId ?? cat.items[0].workspaceId };
}
function prefillDraftViaConversation(ctx, sessionId, text) {
  try {
    const sessionsSvc = typeof ctx.get === "function" ? ctx.get("sessions") : void 0;
    const actx = sessionsSvc?.scope?.(sessionId);
    if (actx === void 0 || actx === null) return false;
    const conversation = typeof ctx.get === "function" ? ctx.get("conversation") : void 0;
    const input = conversation?.input?.for?.(actx);
    if (!input || typeof input.setDraft !== "function") return false;
    const draft = input.state?.getSnapshot?.().draft ?? "";
    input.setDraft(draft.trim() === "" ? text : `${draft.trim()}
${text}`);
    return true;
  } catch {
    return false;
  }
}
function createConversation(ctx, getSessions2, openSession) {
  return async (draft, opts) => {
    try {
      const t = draft.trim();
      if (!t) return { ok: false, message: "\u5185\u5BB9\u4E3A\u7A7A\u3002" };
      const target = pickTargetWorkspace(opts, getSessions2);
      const svc = getSessions2();
      if (!svc || typeof svc.create !== "function") {
        return { ok: false, message: "\u5B98\u65B9\u4F1A\u8BDD\u521B\u5EFA\u80FD\u529B\u4E0D\u53EF\u7528\uFF08sessions.create \u7F3A\u5931\uFF09\u2014\u2014\u8BF7\u6539\u7528\u5B98\u65B9 \uFF0B\u65B0\u4F1A\u8BDD\u3002" };
      }
      const wsNote = target.workspaceId ? "" : `\u672A\u6307\u5B9A\u5DE5\u4F5C\u533A\uFF1A${target.reason ?? "\u6CA1\u6709\u53EF\u7528\u5DE5\u4F5C\u533A"}\uFF08\u5DF2\u6309\u5B98\u65B9\u9ED8\u8BA4\u76EE\u5F55\u521B\u5EFA\uFF09`;
      const created = await svc.create(target.workspaceId ? { workspaceId: target.workspaceId } : {});
      const sessionId = typeof created === "string" ? created : String(created?.id ?? "");
      if (!sessionId) return { ok: false, message: "\u4F1A\u8BDD\u521B\u5EFA\u672A\u8FD4\u56DE\u4F1A\u8BDD\u7F16\u53F7\uFF0C\u8BF7\u91CD\u8BD5\u3002" };
      const applied = [];
      const failed = [];
      if (opts.agentId) {
        const r = await applyAgentPreset(sessionId, opts.agentId);
        if (r.ok) applied.push(`Agent \u9884\u8BBE\u300C${opts.agentId}\u300D\u5DF2\u6309\u5B98\u65B9\u901A\u9053\u7ED1\u5B9A`);
        else failed.push(`Agent \u9884\u8BBE\u672A\u7ED1\u5B9A\uFF1A${r.reason}`);
      }
      if (opts.permission) {
        const r = await applyPermissionPreset(sessionId, opts.permission);
        if (r.ok) applied.push(`\u6743\u9650\u9884\u8BBE\u300C${opts.permission}\u300D\u5DF2\u5E94\u7528${r.note !== void 0 ? `\uFF08${r.note}\uFF09` : "\uFF08\u5B98\u65B9\u6295\u5F71\u8BFB\u56DE\u6821\u9A8C\u901A\u8FC7\uFF09"}`);
        else failed.push(`\u6743\u9650\u9884\u8BBE\u672A\u5E94\u7528\uFF1A${r.reason}`);
      }
      if (opts.projectId) {
        try {
          projectRegistry.assignSession(sessionId, opts.projectId);
        } catch {
        }
      }
      const hasFailure = failed.length > 0;
      if (!hasFailure) {
        try {
          openSession(sessionId);
        } catch {
        }
      }
      const bindNote = () => {
        const parts = [...applied, ...failed];
        return parts.length > 0 ? parts.join("\uFF1B") : "";
      };
      const joinNotes = (...parts) => parts.filter((p) => p.length > 0).join("\uFF1B");
      const prefilled = prefillDraftViaConversation(ctx, sessionId, t);
      if (prefilled) {
        return { ok: true, sessionId, message: joinNotes(wsNote, bindNote()), failed: hasFailure };
      }
      let copiedOk = false;
      try {
        if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(t);
          copiedOk = true;
        }
      } catch {
        copiedOk = false;
      }
      const prefillNote = copiedOk ? "\u65B0\u4F1A\u8BDD\u5DF2\u6253\u5F00\uFF1B\u672A\u80FD\u81EA\u52A8\u586B\u5165\uFF0C\u76EE\u6807\u6587\u672C\u5DF2\u590D\u5236\u5230\u526A\u8D34\u677F\uFF08\u2318V \u7C98\u8D34\u53D1\u9001\uFF09\u3002" : "\u65B0\u4F1A\u8BDD\u5DF2\u6253\u5F00\uFF1B\u672A\u80FD\u81EA\u52A8\u586B\u5165\u4E14\u526A\u8D34\u677F\u4E0D\u53EF\u7528\uFF0C\u8BF7\u5728\u8F93\u5165\u6846\u624B\u52A8\u7C98\u8D34\u76EE\u6807\u6587\u672C\u3002";
      const note = joinNotes(wsNote, bindNote());
      return {
        ok: true,
        sessionId,
        message: note.length > 0 ? `${prefillNote}\uFF5C${note}` : prefillNote,
        failed: hasFailure
      };
    } catch (error) {
      return { ok: false, message: error instanceof Error ? error.message : String(error) };
    }
  };
}
return module.exports; } });
