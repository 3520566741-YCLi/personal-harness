window.__ModuleLoader__.load({ id: 'dsh-personal-quickstop', factory: (require) => { var module = { exports: {} }; var exports = module.exports;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name2 in all)
    __defProp(target, name2, { get: all[name2], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/workstation/personal-quickstop/src/client/index.tsx
var index_exports = {};
__export(index_exports, {
  DISCOVERY_NOT_WIRED_LABEL: () => DISCOVERY_NOT_WIRED_LABEL,
  HEADER_UTILITIES_SLOT: () => HEADER_UTILITIES_SLOT,
  HttpFailure: () => HttpFailure,
  NOT_WIRED_LABEL: () => NOT_WIRED_LABEL,
  QUICKSTOP_PLAN_PATH: () => QUICKSTOP_PLAN_PATH,
  QUICKSTOP_RESUME_PATH: () => QUICKSTOP_RESUME_PATH,
  QUICKSTOP_RUN_PATH: () => QUICKSTOP_RUN_PATH,
  QUICKSTOP_STATE_PATH: () => QUICKSTOP_STATE_PATH,
  QuickStopAction: () => QuickStopAction,
  RESUME_STATE_STEP: () => RESUME_STATE_STEP,
  SEAT_ID: () => SEAT_ID,
  SEAT_ORDER: () => SEAT_ORDER,
  apply: () => apply,
  createHttpIo: () => createHttpIo,
  createQuickStopAction: () => createQuickStopAction,
  createResumeBar: () => createResumeBar,
  default: () => index_default,
  describeFailure: () => describeFailure,
  describeResumeFailure: () => describeResumeFailure,
  inject: () => inject,
  name: () => name,
  pickResumeRecord: () => pickResumeRecord,
  resumeBarViewFrom: () => resumeBarViewFrom,
  summaryViewFrom: () => summaryViewFrom
});
module.exports = __toCommonJS(index_exports);
var import_react2 = require("react");

// src/workstation/personal-quickstop/server/routes.mjs
var QUICKSTOP_PREFIX = "/api/personal/quickstop";
var QUICKSTOP_STATE_PATH = `${QUICKSTOP_PREFIX}/state`;
var QUICKSTOP_READ_PATH = `${QUICKSTOP_PREFIX}/read`;
var QUICKSTOP_PLAN_PATH = `${QUICKSTOP_PREFIX}/plan`;
var QUICKSTOP_RUN_PATH = `${QUICKSTOP_PREFIX}/run`;
var QUICKSTOP_RESUME_PATH = `${QUICKSTOP_PREFIX}/resume`;

// src/workstation/personal-quickstop/server/stop-plan.mjs
var LIVE_JOB_STATUSES = Object.freeze(["running", "stopping"]);
var TERMINAL_JOB_STATUSES = Object.freeze(["completed", "killed", "failed"]);
var LIVE_AGENT_ACTIVITIES = Object.freeze(["running"]);
var LIVE_AGENT_STATUSES = Object.freeze(["running"]);
var INACTIVE_AGENT_ACTIVITIES = Object.freeze(["inactive"]);
var INACTIVE_AGENT_STATUSES = Object.freeze(["idle", "ready"]);
var DISCOVERY_SOURCES = Object.freeze(["sessions", "subagents", "tasks", "jobs"]);
var ADMISSION_KINDS = Object.freeze(["task", "agent", "subagent", "background"]);
var TASK_STATUSES = Object.freeze(["backlog", "todo", "running", "done", "failed"]);
var LIVE_TASK_STATUSES = Object.freeze(["running"]);
var INACTIVE_TASK_STATUSES = Object.freeze(["backlog", "todo", "done", "failed"]);
var QUICK_STOP_TEXTS = Object.freeze({
  tooltip: "\u5FEB\u901F\u505C\u6B62\u5F53\u524D\u8FD0\u884C\u4E2D\u7684\u4EFB\u52A1\u548C\u4F1A\u8BDD\uFF0C\u5E76\u4FDD\u5B58\u7EED\u63A5\u72B6\u6001",
  noWork: "\u5F53\u524D\u6CA1\u6709\u6B63\u5728\u8FD0\u884C\u7684\u4EFB\u52A1\u6216\u4F1A\u8BDD\u3002",
  title: "\u5FEB\u901F\u505C\u6B62\u5F53\u524D\u5DE5\u4F5C\uFF1F",
  note: "Harness \u4F1A\u5148\u4FDD\u5B58\u5F53\u524D\u8FDB\u5EA6\u548C\u7EED\u63A5\u4FE1\u606F\uFF0C\u518D\u6709\u5E8F\u505C\u6B62\u3002",
  cancel: "\u53D6\u6D88",
  confirm: "\u5FEB\u901F\u505C\u6B62",
  doneTitle: "\u5FEB\u901F\u505C\u6B62\u5B8C\u6210",
  doneNote: "\u6240\u6709\u53EF\u6062\u590D\u5DE5\u4F5C\u5DF2\u4FDD\u5B58\u7EED\u63A5\u70B9\u3002"
});
var RESUME_TEXTS = Object.freeze({
  /** 需求原文 G13（`:503`）：“该会话于 <time> 被快速停止。” */
  barTitleTemplate: "\u8BE5\u4F1A\u8BDD\u4E8E {time} \u88AB\u5FEB\u901F\u505C\u6B62\u3002",
  /** 需求原文 G13（`:507`）的按钮；原文写作 `[继续]`，方括号是**按钮记法**，标签即「继续」。 */
  continueLabel: "\u7EE7\u7EED",
  /** 需求原文 G13（`:515-516`）：`上次停在：` 单独一行、值在下一行（原文样例的版式逐字保留）。 */
  phaseLabel: "\u4E0A\u6B21\u505C\u5728\uFF1A",
  phaseLine: "\u4E0A\u6B21\u505C\u5728\uFF1A\n{value}",
  /** 需求原文 G13（`:517-518`）：这两句的值与标签同行。 */
  completedLine: "\u5DF2\u5B8C\u6210 {value}",
  nextLine: "\u4E0B\u4E00\u6B65 {value}",
  /** 需求原文 G13（`:520`）。 */
  noReexplain: "\u4E0D\u8981\u8981\u6C42\u7528\u6237\u91CD\u65B0\u89E3\u91CA\u6574\u4E2A\u4EFB\u52A1\u3002",
  // ↓↓↓ 以下为代理起草（非需求原文），待用户定稿 ↓↓↓
  acceptedNote: "\u5DF2\u628A\u7EED\u63A5\u70B9\u9001\u56DE\u4F1A\u8BDD\uFF08\u5BBF\u4E3B\u5DF2\u53D7\u7406\uFF1B\u8FD9\u4E0D\u7B49\u4E8E Agent \u5DF2\u7ECF\u8DD1\u5B8C\uFF09\u3002",
  noCheckpointNote: "\u26A0 \u8FD9\u6B21\u505C\u6B62\u6CA1\u6709\u7559\u4E0B\u7EED\u63A5\u70B9\u5185\u5BB9\u3002",
  incompleteNote: "\u26A0 \u7EED\u63A5\u70B9\u4E0D\u5B8C\u6574\uFF0C\u7F3A\uFF1A{fields}",
  /** 记录只说"不完整"、没带缺失字段清单时（`/state` 的记录就是这种）—— 不编具体字段名。 */
  missingFieldsUnknown: "\uFF08\u5B57\u6BB5\u6E05\u5355\u672A\u63D0\u4F9B\uFF09",
  readFailedTitle: "\u4E2D\u65AD\u8BB0\u5F55\u8BFB\u53D6\u5931\u8D25",
  unknownTime: "\u672A\u77E5\u65F6\u95F4",
  missingValue: "\uFF08\u7EED\u63A5\u70B9\u91CC\u6CA1\u6709\u8FD9\u4E00\u9879\uFF09",
  instructionHeader: "\u3010\u7EED\u63A5\uFF1A\u672C\u4F1A\u8BDD\u6B64\u524D\u88AB\u300C\u5FEB\u901F\u505C\u6B62\u300D\u4E2D\u65AD\uFF08{time}\uFF09\u3011",
  instructionFieldsHeader: "\uFF08\u4EE5\u4E0B\u4E3A\u8FD9\u6B21\u505C\u6B62\u4FDD\u5B58\u7684\u5B8C\u6574\u7EED\u63A5\u70B9\uFF09"
});
function formatStoppedAt(at) {
  if (typeof at !== "string" || at.trim() === "") return RESUME_TEXTS.unknownTime;
  const text = at.trim();
  const iso = /^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})(?:\.\d+)?Z$/.exec(text);
  if (iso === null) return text;
  return `${iso[1]} ${iso[2]} UTC`;
}
function resumeBarTitle(at) {
  return RESUME_TEXTS.barTitleTemplate.replace("{time}", formatStoppedAt(at));
}
function textOf(value) {
  if (value === void 0 || value === null) return RESUME_TEXTS.missingValue;
  if (Array.isArray(value)) {
    const parts = value.filter((item) => item !== void 0 && item !== null).map((item) => textOf(item));
    return parts.length === 0 ? RESUME_TEXTS.missingValue : parts.join(", ");
  }
  if (typeof value === "object") {
    try {
      return JSON.stringify(value);
    } catch {
      return RESUME_TEXTS.missingValue;
    }
  }
  const text = String(value);
  return text.trim() === "" ? RESUME_TEXTS.missingValue : text;
}
function resumeSummaryLines(checkpoint) {
  const value = checkpoint !== null && typeof checkpoint === "object" && !Array.isArray(checkpoint) ? checkpoint : null;
  return [
    RESUME_TEXTS.phaseLine.replace("{value}", textOf(value?.currentPhase)),
    RESUME_TEXTS.completedLine.replace("{value}", textOf(value?.completedWork)),
    RESUME_TEXTS.nextLine.replace("{value}", textOf(value?.nextAction))
  ];
}

// src/workstation/personal-quickstop/src/client/quick-stop-ui.tsx
var import_react = require("react");
var import_react_dom = require("react-dom");

// src/workstation/personal-workspace/src/client/layering.ts
var LAYERS = {
  /** Official AppFrame in-frame overlay seat (shell.overlay). */
  frameOverlay: 20,
  /** better-sidebar body-level panel host (all Aux panels live inside it). */
  auxHost: 25,
  /** better-sidebar right/bottom workbench panel. */
  auxPanel: 40,
  /** better-sidebar free-floating window. */
  auxFloat: 42,
  /** better-sidebar top-right "＋" toggle cluster. */
  auxToggle: 45,
  /** better-sidebar boundary error banner. */
  auxBoundary: 50,
  /** better-sidebar text-selection popup. */
  auxSelection: 60,
  /**
   * hud status bar & Inspector live between the Aux selection popup (60) and
   * the official Modal (1000): they are always-on chrome that must stay above
   * the workbench panels yet never cover a modal backdrop / toast.
   */
  hudStatus: 450,
  hudInspector: 550,
  /** Official primitives band (body-portaled when they need to escape). */
  popover: 100,
  /**
   * personal-sidebar 的浮动 tabbar（`.dps-tabbar[data-dps-overlay-open]`，浮层打开时置顶）：
   * 必须盖住官方 popover 带（100）与我方 Aux 面板，但**不得**盖住 hud status bar（450）
   * 与官方 Modal（1000）。130 = 逐值保留 2026-09-14 的原值（零行为变化；原为魔数，
   * 违反 smoke-overlay-layering 的「一律 LAYERS.xxx」守则）。
   */
  sidebarTabbarOverlay: 130,
  modal: 1e3,
  toast: 1100
};
function overlayRootFor(z) {
  try {
    if (typeof document === "undefined" || typeof document.body === "undefined") return null;
    const attr = "data-dpw-overlay";
    const existing = document.querySelector(`[${attr}="${String(z)}"]`);
    if (existing instanceof HTMLElement) return existing;
    const root = document.createElement("div");
    root.setAttribute(attr, String(z));
    root.style.cssText = `position:fixed;inset:0;pointer-events:none;z-index:${String(z)}`;
    document.body.appendChild(root);
    return root;
  } catch {
    return null;
  }
}

// src/workstation/personal-quickstop/src/client/quick-stop-ui.tsx
var import_jsx_runtime = require("react/jsx-runtime");
var DISMISS_LABEL = "\u5173\u95ED";
var QUICKSTOP_SOURCE = "Personal Harness \xB7 Quick Stop";
var CSS = `
.dps-qs-btn{border:1px solid var(--dsw-alias-border-l2);min-width:96px;height:32px;
color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family);cursor:pointer;background:0 0;
border-radius:18px;justify-content:center;align-items:center;gap:4px;padding:6px 12px;font-size:13px;
font-weight:400;line-height:20px;display:inline-flex}
.dps-qs-btn:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}
.dps-qs-btn:disabled{color:var(--dsw-alias-label-dimmed);cursor:wait}
.dps-qs-btn span{white-space:nowrap;flex:none}
.dps-qs-overlay{position:fixed;inset:0;pointer-events:auto;display:flex;align-items:center;justify-content:center;
background:rgba(12,14,22,.46)}
.dps-qs-card{min-width:380px;max-width:520px;box-sizing:border-box;padding:18px 20px;border-radius:12px;
background:var(--dsw-alias-bg-elevated,#1b1f2b);border:1px solid var(--dsw-alias-border-l1,rgba(255,255,255,.16));
color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family);font-size:13px;line-height:20px;
box-shadow:0 18px 48px rgba(0,0,0,.42)}
.dps-qs-title{font-size:15px;font-weight:600;line-height:22px;margin:0 0 10px}
.dps-qs-counts{margin:0 0 10px;padding:0;list-style:none;display:flex;flex-direction:column;gap:4px}
.dps-qs-counts li{color:var(--dsw-alias-label-secondary,var(--dsw-alias-label-primary))}
.dps-qs-note{margin:0 0 14px;color:var(--dsw-alias-label-secondary,var(--dsw-alias-label-primary))}
.dps-qs-warn{color:#e8b64c}
.dps-qs-error{margin:0 0 12px;padding:7px 9px;border-radius:7px;color:#f0b4b4;
background:rgba(229,100,106,.14);border:1px solid rgba(229,100,106,.42)}
.dps-qs-actions{display:flex;justify-content:flex-end;gap:8px}
.dps-qs-lines{margin:0 0 14px;padding:0;list-style:none;display:flex;flex-direction:column;gap:4px}
.dps-qs-resume{margin:0 0 8px;padding:8px 10px;border-radius:8px;box-sizing:border-box;max-width:560px;
  background:var(--dsw-alias-bg-elevated,#1b1f2b);border:1px solid var(--dsw-alias-border-l1,rgba(255,255,255,.16));
  color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family);font-size:13px;line-height:20px}
.dps-qs-resume-title{margin:0 0 6px;font-weight:600}
.dps-qs-resume-lines{margin:0 0 6px;padding:0;list-style:none;display:flex;flex-direction:column;gap:2px}
.dps-qs-resume-line{white-space:pre-line;color:var(--dsw-alias-label-secondary,var(--dsw-alias-label-primary))}
.dps-qs-resume-note{margin:0 0 8px;white-space:pre-line}
.dps-qs-resume-note.dps-qs-warn{color:#e8b64c}
.dps-qs-resume-note.dps-qs-error{color:#f0b4b4}
.dps-qs-resume-actions{display:flex;justify-content:flex-end;gap:8px}
`;
function ensureStyle(doc = typeof document === "undefined" ? null : document) {
  if (doc === null) return;
  const tagId = "dsh-personal-quickstop/quick-stop.css";
  if (doc.querySelector(`style[data-plugin-css="${tagId}"]`)) return;
  const tag = doc.createElement("style");
  tag.setAttribute("data-plugin-css", tagId);
  tag.textContent = CSS;
  doc.head.appendChild(tag);
}
function OverlayPortal(props) {
  const rootRef = (0, import_react.useRef)(void 0);
  if (rootRef.current === void 0) rootRef.current = overlayRootFor(LAYERS.modal);
  return rootRef.current !== null ? (0, import_react_dom.createPortal)(props.children, rootRef.current) : props.children;
}
function QuickStopPill(props) {
  ensureStyle();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    "button",
    {
      type: "button",
      className: "dps-qs-btn",
      disabled: props.disabled === true,
      title: QUICK_STOP_TEXTS.tooltip,
      onClick: props.onClick,
      children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: QUICK_STOP_TEXTS.confirm })
    }
  );
}
function QuickStopDialog(props) {
  ensureStyle();
  const plan = props.plan;
  const hasWork = plan?.hasWork === true;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverlayPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "dps-qs-overlay", role: "dialog", "aria-modal": "true", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "dps-qs-card", title: QUICKSTOP_SOURCE, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { className: "dps-qs-title", children: QUICK_STOP_TEXTS.title }),
    hasWork ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { className: "dps-qs-counts", children: (plan?.dialog?.countLines ?? []).map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, index)) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "dps-qs-note", children: QUICK_STOP_TEXTS.note })
    ] }) : plan !== null && plan !== void 0 ? (
      // I-B 追加（最小改动，I-D 接线前必需）：**只有拿到计划**才敢说"没有工作"。
      // 计划没拿到（取计划失败 / 404 未接线）时 plan = null ⇒ 此时我们对"有没有在跑的工作"
      // 一无所知，再渲染这句就是在编事实。故未知时**不渲染**该句，只让 error 行说话。
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "dps-qs-note", children: QUICK_STOP_TEXTS.noWork })
    ) : null,
    props.error !== null && props.error !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "dps-qs-error", children: props.error }) : null,
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "dps-qs-actions", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "dps-qs-btn", onClick: props.onCancel, disabled: props.busy === true, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: QUICK_STOP_TEXTS.cancel }) }),
      hasWork ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "dps-qs-btn", onClick: props.onConfirm, disabled: props.busy === true, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: QUICK_STOP_TEXTS.confirm }) }) : null
    ] })
  ] }) }) });
}
function QuickStopSummary(props) {
  ensureStyle();
  const lines = props.summary?.lines ?? [];
  const warnings = lines.filter((line) => typeof line === "string" && line.startsWith("\u26A0"));
  const normal = lines.filter((line) => !(typeof line === "string" && line.startsWith("\u26A0")));
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverlayPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "dps-qs-overlay", role: "dialog", "aria-modal": "true", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "dps-qs-card", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { className: "dps-qs-lines", children: [
      normal.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, index)),
      warnings.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { className: "dps-qs-warn", children: line }, `w${index}`))
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "dps-qs-actions", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "dps-qs-btn", onClick: props.onDismiss, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: DISMISS_LABEL }) }) })
  ] }) }) });
}
function ResumeBar(props) {
  ensureStyle();
  const view = props.view;
  if (view === null || view === void 0) return null;
  const tone = view.tone === "warn" ? " dps-qs-warn" : view.tone === "error" ? " dps-qs-error" : "";
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "dps-qs-resume", role: "status", title: QUICKSTOP_SOURCE, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "dps-qs-resume-title", children: view.title }),
    view.lines.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { className: "dps-qs-resume-lines", children: view.lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { className: "dps-qs-resume-line", children: line }, index)) }) : null,
    typeof view.note === "string" && view.note !== "" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: `dps-qs-resume-note${tone}`, children: view.note }) : null,
    view.canResume === true ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "dps-qs-resume-actions", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "button",
      {
        type: "button",
        className: "dps-qs-btn dps-qs-resume-go",
        disabled: view.busy === true || view.accepted === true,
        onClick: props.onResume,
        children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: RESUME_TEXTS.continueLabel })
      }
    ) }) : null
  ] });
}

// src/workstation/personal-quickstop/src/client/index.tsx
var import_jsx_runtime2 = require("react/jsx-runtime");
var HEADER_UTILITIES_SLOT = "conversation.session.header.utilities";
var SEAT_ID = "quick-stop";
var SEAT_ORDER = -1;
var NOT_WIRED_LABEL = "\u5BBF\u4E3B\u7F16\u6392\u5C1A\u672A\u63A5\u7EBF\uFF08V1.2-I \u9636\u6BB5 I-D\uFF09";
var DISCOVERY_NOT_WIRED_LABEL = "\u5BBF\u4E3B\u53D1\u73B0\u9762\u672A\u63A5\u7EBF\uFF08V1.2-I \u9636\u6BB5 I-D\uFF09";
function summaryViewFrom(result) {
  if (result === null || result === void 0) return null;
  const message = typeof result.message === "string" && result.message.trim() !== "" ? result.message : null;
  if (result.noWork === true) {
    const lines2 = message === null ? [] : [message];
    return lines2.length === 0 ? null : { ok: true, lines: lines2 };
  }
  const summary = result.summary ?? null;
  if (summary === null) return null;
  const engineLines = (summary.lines ?? []).filter((line) => typeof line === "string");
  if (result.ok === true) return engineLines.length === 0 ? null : { ok: true, lines: engineLines };
  const factual = engineLines.filter(
    (line) => line !== QUICK_STOP_TEXTS.doneTitle && line !== QUICK_STOP_TEXTS.doneNote
  );
  const head = message === null ? [] : [message.startsWith("\u26A0") ? message : `\u26A0 ${message}`];
  const lines = [...head, ...factual];
  return lines.length === 0 ? null : { ok: false, lines };
}
var HttpFailure = class extends Error {
  status;
  path;
  /** 服务端响应体里的 `message`（有就原样带上；没有则 null —— 不编造）。 */
  serverMessage;
  constructor(status, path, serverMessage = null) {
    super(`HTTP ${status}\uFF08${path}\uFF09`);
    this.name = "HttpFailure";
    this.status = status;
    this.path = path;
    this.serverMessage = serverMessage;
  }
};
function describeFailure(step, error) {
  if (error instanceof HttpFailure) {
    if (typeof error.serverMessage === "string" && error.serverMessage.trim() !== "") {
      return `${error.serverMessage}\uFF08HTTP ${error.status}\uFF09`;
    }
    if (error.status === 404) return `${NOT_WIRED_LABEL}\uFF1AHTTP 404`;
    if (error.status === 501) return `${DISCOVERY_NOT_WIRED_LABEL}\uFF1AHTTP 501`;
    return `${step}\u5931\u8D25\uFF1AHTTP ${error.status}`;
  }
  const status = typeof error?.status === "number" ? error.status : null;
  if (status !== null) return `${step}\u5931\u8D25\uFF1AHTTP ${status}`;
  const message = error instanceof Error ? error.message : String(error);
  return `${step}\u5931\u8D25\uFF1A${message.trim() === "" ? "\u672A\u77E5\u9519\u8BEF" : message}`;
}
function createHttpIo(deps = {}) {
  const planPath = deps.planPath ?? QUICKSTOP_PLAN_PATH;
  const runPath = deps.runPath ?? QUICKSTOP_RUN_PATH;
  const statePath = deps.statePath ?? QUICKSTOP_STATE_PATH;
  const resumePath = deps.resumePath ?? QUICKSTOP_RESUME_PATH;
  const doFetchOf = () => {
    const doFetch = deps.fetch ?? (typeof fetch === "function" ? fetch : null);
    if (doFetch === null) throw new Error("\u5F53\u524D\u73AF\u5883\u6CA1\u6709 fetch\uFF08\u65E0\u6CD5\u8BF7\u6C42\u5BBF\u4E3B\uFF09");
    return doFetch;
  };
  const parseJson = async (res) => {
    try {
      const parsed = await res.json();
      return parsed !== null && typeof parsed === "object" ? parsed : null;
    } catch {
      return null;
    }
  };
  const failFrom = async (res, path) => {
    const body = await parseJson(res);
    const message = typeof body?.message === "string" ? body.message : null;
    throw new HttpFailure(res.status, path, message);
  };
  const bodyOf = async (res, path) => {
    const body = await parseJson(res);
    if (body === null) throw new Error(`${path} \u7684\u54CD\u5E94\u4F53\u4E0D\u662F JSON \u5BF9\u8C61`);
    return body;
  };
  const post = async (path) => {
    const res = await doFetchOf()(path, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}"
    });
    if (res.ok !== true) await failFrom(res, path);
    const body = await bodyOf(res, path);
    return body;
  };
  return {
    plan: async () => {
      const body = await post(planPath);
      if (body.ok !== true) {
        const message = typeof body.message === "string" && body.message.trim() !== "" ? body.message : null;
        throw new Error(message ?? `${planPath} \u8FD4\u56DE\u4E86\u975E\u6210\u529F\u54CD\u5E94\uFF08ok !== true\uFF09`);
      }
      if (body.plan === null || body.plan === void 0) throw new Error(`${planPath} \u6210\u529F\u54CD\u5E94\u91CC\u6CA1\u6709 plan\uFF08\u5951\u7EA6\u8FDD\u89C4\uFF09`);
      return body.plan;
    },
    run: async () => {
      const body = await post(runPath);
      const renderable = body.noWork === true || body.summary !== null && body.summary !== void 0 || typeof body.message === "string" && body.message.trim() !== "";
      if (!renderable) throw new Error(`${runPath} \u6210\u529F\u54CD\u5E94\u91CC\u65E2\u6CA1\u6709 summary \u4E5F\u6CA1\u6709 message\uFF08\u5951\u7EA6\u8FDD\u89C4\uFF09`);
      return body;
    },
    /**
     * I13 读：该会话的中断记录（`GET <statePath>`，只读路由）。
     * `ok:true` 却没给 `records` 数组 ⇒ **报错**：契约违规不能退化成"没有记录"
     * （那会让续接条消失，等于把"未知"说成"没被中断过"）。
     */
    state: async () => {
      const res = await doFetchOf()(statePath, { method: "GET" });
      if (res.ok !== true) await failFrom(res, statePath);
      const body = await bodyOf(res, statePath);
      if (body.ok !== true) {
        const message = typeof body.message === "string" && body.message.trim() !== "" ? body.message : null;
        throw new Error(message ?? `${statePath} \u8FD4\u56DE\u4E86\u975E\u6210\u529F\u54CD\u5E94\uFF08ok !== true\uFF09`);
      }
      if (!Array.isArray(body.records)) throw new Error(`${statePath} \u6210\u529F\u54CD\u5E94\u91CC\u6CA1\u6709 records \u6570\u7EC4\uFF08\u5951\u7EA6\u8FDD\u89C4\uFF09`);
      return body;
    },
    /**
     * I13 写：把续接点投回该会话（`POST <resumePath>`）。
     * **只有 2xx 且 `ok:true && accepted:true` 才算投递成功**；`accepted` 只代表官方受理了这一轮，
     * 不等于 Agent 跑起来了 —— 这层含义由 `RESUME_TEXTS.acceptedNote` 在 UI 上说清。
     */
    resume: async (sessionId) => {
      const res = await doFetchOf()(resumePath, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ source: "session", sourceId: sessionId })
      });
      if (res.ok !== true) await failFrom(res, resumePath);
      const body = await bodyOf(res, resumePath);
      if (body.ok !== true || body.accepted !== true) {
        const message = typeof body.message === "string" && body.message.trim() !== "" ? body.message : null;
        throw new Error(message ?? `${resumePath} \u6210\u529F\u54CD\u5E94\u91CC ok/accepted \u4E0D\u4E3A true\uFF08\u5951\u7EA6\u8FDD\u89C4\uFF09`);
      }
      return body;
    }
  };
}
var RESUME_STATE_STEP = "\u8BFB\u53D6\u4E2D\u65AD\u8BB0\u5F55";
function pickResumeRecord(state, sessionId) {
  if (typeof sessionId !== "string" || sessionId === "") return null;
  const records = Array.isArray(state?.records) ? state.records : [];
  const mine = records.filter((row) => row?.source === "session" && row?.sourceId === sessionId);
  return mine.length === 0 ? null : mine[mine.length - 1];
}
function resumeBarViewFrom(input) {
  const sessionId = input?.sessionId;
  if (typeof sessionId !== "string" || sessionId === "") return null;
  const busy = input?.busy === true;
  const readError = typeof input?.readError === "string" && input.readError !== "" ? input.readError : null;
  if (readError !== null) {
    return {
      title: RESUME_TEXTS.readFailedTitle,
      lines: [],
      note: readError,
      tone: "error",
      canResume: false,
      accepted: false,
      busy
    };
  }
  const record = input?.record ?? null;
  if (record === null) return null;
  const failure = typeof input?.error === "string" && input.error !== "" ? input.error : null;
  const accepted = input?.accepted === true;
  const fields = Array.isArray(record.missingFields) && record.missingFields.length > 0 ? record.missingFields.join("\u3001") : RESUME_TEXTS.missingFieldsUnknown;
  let note = null;
  let tone = "info";
  if (failure !== null) {
    note = `\u26A0 ${failure}`;
    tone = "error";
  } else if (accepted) {
    note = RESUME_TEXTS.acceptedNote;
  } else if (record.checkpointIncomplete === true) {
    note = RESUME_TEXTS.incompleteNote.replace("{fields}", fields);
    tone = "warn";
  } else if (record.checkpoint === null || record.checkpoint === void 0) {
    note = RESUME_TEXTS.noCheckpointNote;
    tone = "warn";
  }
  return {
    title: resumeBarTitle(record.stoppedAt ?? null),
    lines: resumeSummaryLines(record.checkpoint ?? null),
    note,
    tone,
    // 有记录就给按钮：连"盘上有没有续接点"这件事都不该由 UI 替真源下结论（见上）。
    canResume: true,
    // 受理后**留着按钮但置灰**（同一条续接点不重复投递，同时让用户看见这次点生效了）；
    // 失败/未受理 ⇒ `accepted:false` ⇒ 按钮回到可点（允许重试，不假装已经做过）。
    accepted,
    busy
  };
}
function describeResumeFailure(step, error) {
  if (error instanceof HttpFailure) {
    if (typeof error.serverMessage === "string" && error.serverMessage.trim() !== "") {
      return `${error.serverMessage}\uFF08HTTP ${error.status}\uFF09`;
    }
    return `${step}\u5931\u8D25\uFF1AHTTP ${error.status}`;
  }
  const message = error instanceof Error ? error.message : String(error);
  return `${step}\u5931\u8D25\uFF1A${message.trim() === "" ? "\u672A\u77E5\u9519\u8BEF" : message}`;
}
function createResumeBar(deps = {}) {
  const http = createHttpIo();
  const loadState = deps.loadState ?? http.state;
  const sendResume = deps.sendResume ?? http.resume;
  return function QuickStopResumeBar(props = {}) {
    const sessionId = typeof props?.sessionId === "string" && props.sessionId !== "" ? props.sessionId : null;
    const [record, setRecord] = (0, import_react2.useState)(null);
    const [readError, setReadError] = (0, import_react2.useState)(null);
    const [busy, setBusy] = (0, import_react2.useState)(false);
    const [accepted, setAccepted] = (0, import_react2.useState)(false);
    const [error, setError] = (0, import_react2.useState)(null);
    (0, import_react2.useEffect)(() => {
      if (sessionId === null) {
        setRecord(null);
        setReadError(null);
        return void 0;
      }
      let live = true;
      setAccepted(false);
      setError(null);
      void (async () => {
        try {
          const state = await loadState(sessionId);
          if (!live) return;
          setRecord(pickResumeRecord(state, sessionId));
          setReadError(null);
        } catch (failure) {
          if (!live) return;
          setRecord(null);
          setReadError(describeResumeFailure(RESUME_STATE_STEP, failure));
        }
      })();
      return () => {
        live = false;
      };
    }, [sessionId, loadState]);
    const onResume = (0, import_react2.useCallback)(() => {
      if (sessionId === null || busy) return;
      setBusy(true);
      setError(null);
      void (async () => {
        try {
          await sendResume(sessionId);
          setAccepted(true);
        } catch (failure) {
          setError(describeResumeFailure(RESUME_TEXTS.continueLabel, failure));
        } finally {
          setBusy(false);
        }
      })();
    }, [sessionId, busy, sendResume]);
    const view = resumeBarViewFrom({ sessionId, record, readError, busy, accepted, error });
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ResumeBar, { view, onResume });
  };
}
function createQuickStopAction(deps = {}) {
  const io = deps.io ?? createHttpIo();
  const ResumeBarSeat = createResumeBar(deps.resume ?? {});
  return function QuickStopAction2(props = {}) {
    const [phase, setPhase] = (0, import_react2.useState)("idle");
    const [plan, setPlan] = (0, import_react2.useState)(null);
    const [summary, setSummary] = (0, import_react2.useState)(null);
    const [error, setError] = (0, import_react2.useState)(null);
    const busy = phase === "planning" || phase === "running";
    const requestPlan = (0, import_react2.useCallback)(async () => {
      setError(null);
      setSummary(null);
      setPlan(null);
      setPhase("planning");
      try {
        const next = await io.plan();
        if (next === null || next === void 0) throw new Error("\u5BBF\u4E3B\u6CA1\u6709\u8FD4\u56DE\u505C\u6B62\u8BA1\u5212\uFF08plan \u4E3A\u7A7A\uFF09");
        setPlan(next);
        setPhase("confirm");
      } catch (failure) {
        setPlan(null);
        setError(describeFailure("\u83B7\u53D6\u505C\u6B62\u8BA1\u5212", failure));
        setPhase("error");
      }
    }, [io]);
    const requestRun = (0, import_react2.useCallback)(async () => {
      setError(null);
      setPhase("running");
      try {
        const result = await io.run();
        const view = summaryViewFrom(result);
        if (view === null) {
          const message = typeof result?.message === "string" && result.message.trim() !== "" ? result.message : "\u5BBF\u4E3B\u6CA1\u6709\u8FD4\u56DE\u53EF\u663E\u793A\u7684\u505C\u6B62\u7ED3\u679C\uFF08summary \u4E0E message \u90FD\u4E3A\u7A7A\uFF09";
          throw new Error(message);
        }
        setSummary(view);
        setPhase("summary");
      } catch (failure) {
        setSummary(null);
        setError(describeFailure("\u505C\u6B62\u6D41\u7A0B", failure));
        setPhase("error");
      }
    }, [io]);
    const cancel = (0, import_react2.useCallback)(() => {
      setPlan(null);
      setSummary(null);
      setError(null);
      setPhase("idle");
    }, []);
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_jsx_runtime2.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(QuickStopPill, { onClick: () => {
        void requestPlan();
      }, disabled: busy }),
      phase === "confirm" || phase === "error" ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        QuickStopDialog,
        {
          plan,
          busy,
          error,
          onConfirm: () => {
            void requestRun();
          },
          onCancel: cancel
        }
      ) : null,
      phase === "summary" && summary !== null ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(QuickStopSummary, { summary, onDismiss: cancel }) : null,
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ResumeBarSeat, { sessionId: props?.sessionId })
    ] });
  };
}
var QuickStopAction = createQuickStopAction();
function apply(ctx) {
  try {
    const slots = ctx?.slots;
    if (!slots || typeof slots.inject !== "function" || typeof slots.register !== "function") {
      console.warn("[dsh-personal-quickstop] slots \u670D\u52A1\u4E0D\u53EF\u7528\uFF1A\u4E0D\u5360\u5EA7\uFF08\u5B98\u65B9 UI \u7167\u5E38\uFF09");
      return;
    }
    const occupy = () => slots.inject(
      HEADER_UTILITIES_SLOT,
      () => slots.register({ name: HEADER_UTILITIES_SLOT, id: SEAT_ID, order: SEAT_ORDER }, QuickStopAction),
      "dsh-personal-quickstop: \u4F1A\u8BDD\u5934\u5DE5\u5177\u533A"
    );
    if (typeof ctx.effect === "function") ctx.effect(occupy, "dsh-personal-quickstop: header utilities");
    else occupy();
  } catch (error) {
    console.warn("[dsh-personal-quickstop] apply aborted:", error);
  }
}
var name = "dsh-personal-quickstop";
var inject = ["slots"];
var plugin = { name, inject, apply };
var index_default = plugin;
return module.exports; } });
