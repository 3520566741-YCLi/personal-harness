// src/workstation/personal-workspace/src/server/memory-curator.ts
var CURATOR_MAX_NEW = 10;
var CURATOR_MIN_TEXT_CHARS = 12;
var CURATOR_LINK_MAX_GAP_MS = 30 * 60 * 1e3;
var CURATOR_LINK_MIN_SHARED_TAGS = 2;
var EMIT_ORDER = ["duplicate-merge", "link", "importance"];
function normalizeText(s) {
  return s.replace(/\s+/gu, " ").trim().toLowerCase();
}
function bodyOf(r) {
  const parts = [];
  if (typeof r.summary === "string" && r.summary.trim() !== "") parts.push(r.summary.trim());
  if (typeof r.userText === "string" && r.userText.trim() !== "") parts.push(r.userText.trim());
  return parts.join("\n");
}
function denseRank(values) {
  const uniq = [...new Set(values)].sort((a, b) => a - b);
  const m = /* @__PURE__ */ new Map();
  uniq.forEach((v, i) => m.set(v, uniq.length <= 1 ? 1 : i / (uniq.length - 1)));
  return m;
}
function curateMemoryGraph(records, options = {}) {
  const now = Number.isFinite(options.now) ? Number(options.now) : Date.now();
  const maxNew = Number.isFinite(options.maxNew) && Number(options.maxNew) > 0 ? Math.floor(Number(options.maxNew)) : CURATOR_MAX_NEW;
  const dismissed = new Set((options.dismissed ?? []).filter((k) => typeof k === "string" && k !== ""));
  const valid = records.filter((r) => r !== null && typeof r === "object" && typeof r.id === "string" && r.id !== "");
  const hasTs = (r) => typeof r.ts === "number" && Number.isFinite(r.ts);
  const texts = /* @__PURE__ */ new Map();
  let noText = 0;
  let tooShort = 0;
  for (const r of valid) {
    const body = bodyOf(r);
    if (body === "") {
      noText++;
      continue;
    }
    const norm = normalizeText(body);
    if (norm.length < CURATOR_MIN_TEXT_CHARS) {
      tooShort++;
      continue;
    }
    texts.set(r.id, { body: norm, normalizedChars: norm.length, tagList: [...new Set((r.tags ?? []).filter((t) => typeof t === "string" && t !== ""))].sort() });
  }
  const noTs = valid.filter((r) => !hasTs(r)).length;
  const byText = /* @__PURE__ */ new Map();
  for (const r of valid) {
    const t = texts.get(r.id);
    if (t === void 0) continue;
    const bucket = byText.get(t.body);
    if (bucket === void 0) byText.set(t.body, [r.id]);
    else bucket.push(r.id);
  }
  const dupCandidates = [];
  for (const [body, idsRaw] of byText) {
    if (idsRaw.length < 2) continue;
    const ids = [...idsRaw].sort();
    const tagSets = ids.map((id) => new Set(texts.get(id).tagList));
    const sharedTags = [...tagSets[0]].filter((t) => tagSets.every((s) => s.has(t))).sort();
    dupCandidates.push({
      key: `dup:${ids.join("+")}`,
      kind: "duplicate-merge",
      recordIds: ids,
      basis: { normalizedChars: body.length, sharedTags, exact: true }
    });
  }
  dupCandidates.sort((a, b) => a.key.localeCompare(b.key));
  const ranked = valid.filter(hasTs);
  const recency = denseRank(ranked.map((r) => r.ts));
  const turnIndexByTs = /* @__PURE__ */ new Map();
  for (const r of ranked) {
    const sid = r.sessionId ?? "";
    const per = turnIndexByTs.get(sid) ?? /* @__PURE__ */ new Map();
    if (per.size === 0) turnIndexByTs.set(sid, per);
    per.set(r.ts, 0);
  }
  for (const [sid, per] of turnIndexByTs) turnIndexByTs.set(sid, denseRank([...per.keys()]));
  const impCandidates = [];
  for (const r of ranked) {
    const t = texts.get(r.id);
    if (t === void 0) continue;
    const tagCount = t.tagList.length;
    const turnIndex = turnIndexByTs.get(r.sessionId ?? "")?.get(r.ts) ?? 1;
    const recencyRank = recency.get(r.ts) ?? 1;
    const score = Math.round(
      100 * (0.35 * (Math.min(t.normalizedChars, 2e3) / 2e3) + 0.25 * (Math.min(tagCount, 8) / 8) + 0.2 * turnIndex + 0.2 * recencyRank)
    );
    impCandidates.push({
      key: `imp:${r.id}`,
      kind: "importance",
      recordId: r.id,
      score,
      // ④ value/alpha **不进公式**（真机实测全 0；照 E1 纪律 ⑤ 不按价值排序），但如实带出原值供审计。
      basis: { textChars: t.normalizedChars, tagCount, turnIndex, recencyRank, value: typeof r.value === "number" ? r.value : null, alpha: typeof r.alpha === "number" ? r.alpha : null }
    });
  }
  impCandidates.sort((a, b) => b.score - a.score || a.key.localeCompare(b.key));
  const linkCandidates = [];
  for (let i = 0; i < ranked.length; i++) {
    for (let j = i + 1; j < ranked.length; j++) {
      const a = ranked[i];
      const b = ranked[j];
      if ((a.sessionId ?? "") === (b.sessionId ?? "")) continue;
      const ta = texts.get(a.id)?.tagList ?? [];
      const tb = new Set(texts.get(b.id)?.tagList ?? []);
      const sharedTags = ta.filter((t) => tb.has(t)).sort();
      if (sharedTags.length < CURATOR_LINK_MIN_SHARED_TAGS) continue;
      const gapMs = Math.abs(a.ts - b.ts);
      if (gapMs > CURATOR_LINK_MAX_GAP_MS) continue;
      const from = a.id < b.id ? a.id : b.id;
      const to = a.id < b.id ? b.id : a.id;
      linkCandidates.push({
        key: `link:${from}>${to}`,
        kind: "link",
        fromRecordId: from,
        toRecordId: to,
        basis: { sharedTags, gapMs, crossSession: true }
      });
    }
  }
  linkCandidates.sort((a, b) => a.key.localeCompare(b.key));
  const available = {
    "duplicate-merge": dupCandidates.filter((s) => !dismissed.has(s.key)),
    importance: impCandidates.filter((s) => !dismissed.has(s.key)),
    link: linkCandidates.filter((s) => !dismissed.has(s.key))
  };
  const dismissedApplied = dupCandidates.filter((s) => dismissed.has(s.key)).length + impCandidates.filter((s) => dismissed.has(s.key)).length + linkCandidates.filter((s) => dismissed.has(s.key)).length;
  const candidates = available["duplicate-merge"].length + available.importance.length + available.link.length;
  const cursors = { "duplicate-merge": 0, importance: 0, link: 0 };
  const suggestions = [];
  for (; ; ) {
    let advanced = false;
    for (const k of EMIT_ORDER) {
      if (suggestions.length >= maxNew) break;
      const list = available[k];
      if (cursors[k] < list.length) {
        suggestions.push(list[cursors[k]]);
        cursors[k]++;
        advanced = true;
      }
    }
    if (advanced !== true || suggestions.length >= maxNew) break;
  }
  const skipped = [];
  if (noText > 0) skipped.push({ reason: "no-text", count: noText });
  if (tooShort > 0) skipped.push({ reason: "text-too-short", count: tooShort });
  if (noTs > 0) skipped.push({ reason: "no-ts", count: noTs });
  return {
    at: now,
    suggestions,
    stats: {
      records: valid.length,
      textful: texts.size,
      ranked: ranked.length,
      duplicateGroups: dupCandidates.length,
      linkPairs: linkCandidates.length,
      importanceScored: impCandidates.length
    },
    budget: { maxNew, candidates, emitted: suggestions.length, deferred: candidates - suggestions.length },
    skipped,
    dismissedApplied
  };
}
export {
  CURATOR_LINK_MAX_GAP_MS,
  CURATOR_LINK_MIN_SHARED_TAGS,
  CURATOR_MAX_NEW,
  CURATOR_MIN_TEXT_CHARS,
  curateMemoryGraph
};
