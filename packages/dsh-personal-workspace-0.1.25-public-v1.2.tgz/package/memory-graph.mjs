// src/workstation/personal-workspace/src/server/memory-graph.ts
var DEFAULT_MAX_NODES = 300;
var DEFAULT_MAX_LABEL_CHARS = 200;
function adaptEpisodes(episodes) {
  const out = [];
  for (const e of episodes ?? []) {
    if (!e || typeof e.id !== "string" || e.id === "") continue;
    out.push({
      id: e.id,
      idKind: "episode",
      sessionId: typeof e.sessionId === "string" && e.sessionId !== "" ? e.sessionId : void 0,
      ownerWorkspaceId: typeof e.ownerWorkspaceId === "string" && e.ownerWorkspaceId !== "" ? e.ownerWorkspaceId : void 0,
      ownerProfileId: typeof e.ownerProfileId === "string" && e.ownerProfileId !== "" ? e.ownerProfileId : void 0,
      ownerAgentKind: typeof e.ownerAgentKind === "string" && e.ownerAgentKind !== "" ? e.ownerAgentKind : void 0,
      ts: typeof e.startedAt === "number" && Number.isFinite(e.startedAt) ? e.startedAt : void 0,
      summary: typeof e.preview === "string" ? e.preview : void 0,
      episodeStatus: typeof e.status === "string" ? e.status : void 0,
      tags: Array.isArray(e.tags) ? e.tags.filter((x) => typeof x === "string") : void 0
    });
  }
  return out;
}
var TOPICS_UNAVAILABLE_REASON = "\u5B9E\u6D4B tags \u4E3A\u5DE5\u5177\u540D\u96C6\u5408\uFF08bash/git/read/shell \u7B49\uFF09\uFF0C\u975E\u4E3B\u9898\u6807\u7B7E\uFF1B\u672C\u673A\u65E0\u4E3B\u9898\u771F\u6E90\uFF0C\u6545\u4E0D\u751F\u6210 Topics \u8282\u70B9";
function clampLabel(text, max) {
  const s = String(text ?? "");
  if (s.length <= max) return { label: s, truncated: false };
  return { label: s.slice(0, max), truncated: true };
}
function labelSource(t) {
  const summary = (t.summary ?? "").trim();
  if (summary !== "") return summary;
  const user = (t.userText ?? "").trim();
  if (user === "") return "";
  return user.split("\n")[0].trim();
}
function shortId(id, n = 8) {
  const s = String(id ?? "");
  return s.length <= n ? s : s.slice(-n);
}
function tsOf(t) {
  const v = Number(t.ts);
  return Number.isFinite(v) ? v : 0;
}
function identityOf(t) {
  if (t.idKind === "episode") return { traceId: null, episodeId: t.id };
  return { traceId: t.id, episodeId: t.episodeId ?? null };
}
function episodeAliasFactOf(records) {
  const kinds = new Set(records.map((t) => t.idKind === "episode" ? "episode" : "trace"));
  const seen = /* @__PURE__ */ new Map();
  for (const t of records) {
    const ep = identityOf(t).episodeId;
    if (ep === null || ep === "") continue;
    seen.set(ep, (seen.get(ep) ?? 0) + 1);
  }
  const duplicates = [...seen.entries()].filter(([, n]) => n > 1).map(([id]) => id).sort();
  const withEpisodeId = [...seen.values()].reduce((a, c) => a + c, 0);
  const base = {
    records: records.length,
    withEpisodeId,
    distinctEpisodeIds: seen.size,
    duplicateEpisodeIds: duplicates.slice(0, 8)
  };
  if (records.length === 0) return { ...base, holds: null, basis: "no-records" };
  if (kinds.has("episode")) {
    return kinds.size > 1 ? { ...base, holds: null, basis: "mixed-face-unverifiable" } : { ...base, holds: null, basis: "episodes-face-unverifiable" };
  }
  if (duplicates.length > 0) return { ...base, holds: false, basis: "traces-face-bijection" };
  if (withEpisodeId !== records.length) return { ...base, holds: null, basis: "traces-face-missing-episode-id" };
  return { ...base, holds: true, basis: "traces-face-bijection" };
}
function projectMemoryGraph(traces, options = {}) {
  const budget = Math.max(1, Math.floor(options.maxNodes ?? DEFAULT_MAX_NODES));
  const maxLabel = Math.max(1, Math.floor(options.maxLabelChars ?? DEFAULT_MAX_LABEL_CHARS));
  const labels = options.workspaceLabels ?? {};
  const lt = options.layerTotals ?? {};
  const tracesTotal = options.tracesTotal ?? null;
  const usable = [];
  let inputCount = 0;
  let ungrouped = 0;
  for (const t of traces ?? []) {
    if (!t || typeof t.id !== "string" || t.id === "") continue;
    inputCount++;
    if (typeof t.sessionId !== "string" || t.sessionId === "") {
      ungrouped++;
      continue;
    }
    usable.push(t);
  }
  const byRecency = [...usable].sort((a, b) => tsOf(b) - tsOf(a) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  const chosen = [];
  const sessionIds = /* @__PURE__ */ new Set();
  const workspaceIds = /* @__PURE__ */ new Set();
  const countNodes = () => chosen.length + sessionIds.size + workspaceIds.size;
  for (const t of byRecency) {
    const wsId = typeof t.ownerWorkspaceId === "string" && t.ownerWorkspaceId !== "" ? t.ownerWorkspaceId : "unknown";
    const nextSessions = new Set(sessionIds);
    nextSessions.add(t.sessionId);
    const nextWorkspaces = new Set(workspaceIds);
    nextWorkspaces.add(wsId);
    const prospective = chosen.length + 1 + nextSessions.size + nextWorkspaces.size;
    if (prospective > budget) break;
    chosen.push(t);
    sessionIds.add(t.sessionId);
    workspaceIds.add(wsId);
  }
  chosen.sort((a, b) => tsOf(a) - tsOf(b) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  const nodes = [];
  const edges = [];
  const nodesByKind = { workspace: 0, session: 0, turn: 0 };
  const edgesByKind = { contains: 0, sequence: 0 };
  const episodeAlias = episodeAliasFactOf(chosen);
  const wsStat = /* @__PURE__ */ new Map();
  const seStat = /* @__PURE__ */ new Map();
  for (const t of chosen) {
    const wsId = typeof t.ownerWorkspaceId === "string" && t.ownerWorkspaceId !== "" ? t.ownerWorkspaceId : "unknown";
    const w = wsStat.get(wsId) ?? { sessions: /* @__PURE__ */ new Set(), turns: 0, firstTs: Infinity, lastTs: -Infinity };
    w.sessions.add(t.sessionId);
    w.turns++;
    w.firstTs = Math.min(w.firstTs, tsOf(t));
    w.lastTs = Math.max(w.lastTs, tsOf(t));
    wsStat.set(wsId, w);
    const s = seStat.get(t.sessionId) ?? { ws: wsId, turns: [] };
    s.turns.push(t);
    seStat.set(t.sessionId, s);
  }
  const wsNodeId = (wsId) => `ws:${wsId}`;
  const seNodeId = (sid) => `se:${sid}`;
  const trNodeId = (tid) => `tr:${tid}`;
  for (const wsId of [...wsStat.keys()].sort()) {
    const w = wsStat.get(wsId);
    const named = typeof labels[wsId] === "string" && labels[wsId] !== "";
    nodes.push({
      id: wsNodeId(wsId),
      type: "workspace",
      position: { x: 0, y: 0 },
      data: {
        kind: "workspace",
        workspaceId: wsId,
        label: named ? labels[wsId] : `\u5DE5\u4F5C\u533A ${shortId(wsId)}`,
        labelDerived: !named,
        sessionCount: w.sessions.size,
        turnCount: w.turns,
        firstTs: Number.isFinite(w.firstTs) ? w.firstTs : null,
        lastTs: Number.isFinite(w.lastTs) ? w.lastTs : null
      }
    });
    nodesByKind.workspace++;
  }
  for (const sid of [...seStat.keys()].sort()) {
    const s = seStat.get(sid);
    const turns = [...s.turns].sort((a, b) => tsOf(a) - tsOf(b) || a.id.localeCompare(b.id));
    const profiles = [...new Set(turns.map((t) => t.ownerProfileId).filter((p) => !!p))].sort();
    nodes.push({
      id: seNodeId(sid),
      type: "session",
      position: { x: 0, y: 0 },
      data: {
        kind: "session",
        sessionId: sid,
        workspaceId: s.ws,
        label: `\u4F1A\u8BDD ${shortId(sid)}`,
        labelDerived: true,
        turnCount: turns.length,
        firstTs: tsOf(turns[0]),
        lastTs: tsOf(turns[turns.length - 1]),
        ownerProfileIds: profiles,
        statuses: [...new Set(turns.map((t) => t.episodeStatus).filter((x) => !!x))].sort()
      }
    });
    nodesByKind.session++;
    edges.push({
      id: `e:${wsNodeId(s.ws)}->${seNodeId(sid)}`,
      source: wsNodeId(s.ws),
      target: seNodeId(sid),
      type: "smoothstep",
      data: { kind: "contains" }
    });
    edgesByKind.contains++;
    let prev = null;
    for (let turnIndex = 0; turnIndex < turns.length; turnIndex++) {
      const t = turns[turnIndex];
      const src = labelSource(t);
      const { label, truncated } = clampLabel(src, maxLabel);
      const ep = identityOf(t);
      nodes.push({
        id: trNodeId(t.id),
        type: "turn",
        position: { x: 0, y: 0 },
        data: {
          kind: "turn",
          recordId: t.id,
          traceId: ep.traceId,
          episodeId: ep.episodeId,
          traceIdKnown: ep.traceId !== null,
          // ① episode:trace = 1:1 ⇒ episode 不是上层，只作为来源指针保留（不另建节点）。
          // ⑨ 该标注**由数据算出**（`episodeAliasFactOf`）：可证为 true、有反例为 false、无法验证为 null。
          episodeIsTurnAlias: episodeAlias.holds,
          sessionId: sid,
          workspaceId: s.ws,
          turnId: t.turnId ?? null,
          ts: tsOf(t),
          label,
          labelDerived: false,
          labelLost: src === "",
          labelTruncated: truncated,
          episodeStatus: t.episodeStatus ?? null,
          ownerProfileId: t.ownerProfileId ?? null,
          ownerAgentKind: t.ownerAgentKind ?? null,
          // ④ tags 是**工具名**集合，字段名如实体现，图上不生成 Topics 节点。
          toolTags: [...t.tags ?? []].map((x) => String(x)).sort(),
          value: Number.isFinite(Number(t.value)) ? Number(t.value) : null,
          alpha: Number.isFinite(Number(t.alpha)) ? Number(t.alpha) : null,
          sourceRef: {
            sessionId: sid,
            episodeId: ep.episodeId,
            traceId: ep.traceId,
            turnId: t.turnId ?? null,
            ts: tsOf(t)
          }
        }
      });
      nodesByKind.turn++;
      if (prev === null) {
        edges.push({
          id: `e:${seNodeId(sid)}->${trNodeId(t.id)}`,
          source: seNodeId(sid),
          target: trNodeId(t.id),
          type: "smoothstep",
          data: { kind: "contains" }
        });
        edgesByKind.contains++;
      } else {
        edges.push({
          id: `e:${trNodeId(prev.id)}~>${trNodeId(t.id)}`,
          source: trNodeId(prev.id),
          target: trNodeId(t.id),
          type: "smoothstep",
          data: { kind: "sequence" }
        });
        edgesByKind.sequence++;
      }
      prev = t;
    }
  }
  const values = chosen.map((t) => Number.isFinite(Number(t.value)) ? Number(t.value) : 0);
  const alphas = chosen.map((t) => Number.isFinite(Number(t.alpha)) ? Number(t.alpha) : 0);
  const byValue = values.some((v) => v !== 0) || alphas.some((v) => v !== 0);
  const idKinds = new Set(chosen.map((t) => t.idKind === "episode" ? "episode" : "trace"));
  const recordKind = idKinds.size === 0 ? "trace" : idKinds.size > 1 ? "mixed" : idKinds.values().next().value;
  return {
    nodes,
    edges,
    stats: {
      inputCount,
      tracesIn: usable.length,
      ungrouped,
      tracesTotal,
      sessions: seStat.size,
      workspaces: wsStat.size,
      nodesByKind,
      edgesByKind
    },
    layers: {
      traces: { total: tracesTotal, fetched: chosen.length },
      // ③ number = 已取到的真实计量（0 = 确实为空）；null = 未取到（未知）。
      policies: lt.policies === void 0 ? null : lt.policies,
      worldModels: lt.worldModels === void 0 ? null : lt.worldModels,
      skills: lt.skills === void 0 ? null : lt.skills
    },
    semanticLayers: { topics: "unavailable", reason: TOPICS_UNAVAILABLE_REASON },
    rankable: {
      byValue,
      reason: byValue ? "\u4E0A\u6E38\u5B58\u5728\u975E\u96F6 value/alpha\uFF0C\u53EF\u6309\u4EF7\u503C\u6392\u5E8F" : '\u5B9E\u6D4B\u672C\u6279 value/alpha \u5168\u4E3A 0\uFF08\u4E0A\u6E38 reward/value \u65AD\u94FE\uFF09\u21D2 \u53EA\u80FD\u6309\u65F6\u95F4\u4E0E\u8F6E\u6B21\u987A\u5E8F\u6392\uFF0C\u4E0D\u5F97\u6309"\u91CD\u8981\u6027"\u6392'
    },
    truncation: {
      budget,
      included: chosen.length,
      dropped: Math.max(0, usable.length - chosen.length),
      byRecency: true
    },
    recordIds: { kind: recordKind },
    episodeAlias,
    shape: {
      episodeTraceIsOneToOne: episodeAlias.holds,
      hierarchy: ["workspace(ownerWorkspaceId)", "session(sessionId)", "turn(trace\u2261episode)"]
    }
  };
}
export {
  DEFAULT_MAX_LABEL_CHARS,
  DEFAULT_MAX_NODES,
  adaptEpisodes,
  episodeAliasFactOf,
  projectMemoryGraph
};
